#include "app.h"
#include "ui.h"
#include "packet.h"
#include "receipt.h"
#include "log.h"
#include "oper.h"
#include "ped.h"
#include "SendSignature.h"
#include "localmanage.h"
#include "Batch.h"
#include "sale.h"
#include "ec.h"
#include "updata.h"
#include "offline.h"
#include "logon.h"
#include "paramdwn.h"
#include "auth.h"
#include "setup.h"
#include "transconfig.h"


extern int LocManage_PrintTermParam(void *pstTransIn);
extern int TipUnpack(uchar *psDataIn, uint uiDataLen, ST_TRANSDATA *pstDataOut);
extern int ScriptlUnpack(uchar *psDataIn, uint uiDataLen, ST_TRANSDATA *pstDataOut);

ST_BANKNAME s_arstBankList[] =
{
    {"0102", "工商银行", "工行 银联"},
    {"0103", "农业银行", "农行 银联"},
    {"0104", "中国银行", "中行 银联"},
    {"0105", "建设银行", "建行 银联"},
    {"0100", "邮储银行", "邮储 银联"},
    {"0301", "交通银行", "交行 银联"},
    {"0302", "中信银行", "中信 银联"},
    {"0303", "光大银行", "光大 银联"},
    {"0304", "华夏银行", "华夏 银联"},
    {"0305", "民生银行", "民生 银联"},
    {"0306", "广发银行", "广发 银联"},
    {"0307", "深发银行", "深发 银联"},
    {"0308", "招商银行", "招行 银联"},
    {"0309", "兴业银行", "兴业 银联"},
    {"0310", "浦发银行", "浦发 银联"},
    {"4802", "银联商务", "银联 商务"},
};

// 消费55域EMV标签
static DE55EmvTag sg_SaleTagList[] =
{
    {0x9F26},
    {0x9F27},
    {0x9F10},
    {0x9F37},
    {0x9F36},
    {0x95},
    {0x9A},
    {0x9C},
    {0x9F02},
    {0x5F2A},
    {0x82},
    {0x9F1A},
    {0x9F03},
    {0x9F33},
    {0x9F34},
    {0x9F35},
    {0x9F1E},
    {0x84},
    {0x9F09},
    {0x9F41},
    {0x9F63},
    {0},
};

// 查余额55域EMV标签
static DE55EmvTag sg_QueTagList[] =
{
    {0x9F26},
    {0x9F27},
    {0x9F10},
    {0x9F37},
    {0x9F36},
    {0x95},
    {0x9A},
    {0x9C},
    {0x9F02},
    {0x5F2A},
    {0x82},
    {0x9F1A},
    {0x9F03},
    {0x9F33},
    {0x9F34},
    {0x9F35},
    {0x9F1E},
    {0x84},
    {0x9F09},
    {0x9F41},
    {0x9F63},

    {0},
};

// 脱机消费（EC）55域EMV标签
static DE55EmvTag sg_EcOffTagList[] =
{
    {0x9F26},
    {0x9F27},
    {0x9F10},
    {0x9F37},
    {0x9F36},
    {0x95},
    {0x9A},
    {0x9C},
    {0x9F02},
    {0x5F2A},
    {0x82},
    {0x9F1A},
    {0x9F03},
    {0x9F33},
    {0x9F1E},
    {0x84},
    {0x9F09},
    {0x9F41},
    {0x9F34},
    {0x9F35},
    {0x9F63},
    {0x9F74},
    {0x8A},
    {0},
};


// 预授权55域EMV标签
static DE55EmvTag sg_PreAuthTagList[] =
{
    {0x9F26},
    {0x9F27},
    {0x9F10},
    {0x9F37},
    {0x9F36},
    {0x95},
    {0x9A},
    {0x9C},
    {0x9F02},
    {0x5F2A},
    {0x82},
    {0x9F1A},
    {0x9F03},
    {0x9F33},
    {0x9F34},
    {0x9F35},
    {0x9F1E},
    {0x84},
    {0x9F09},
    {0x9F41},
    {0x9F63},
    {0},
};

// 消费冲正55域EMV标签
static DE55EmvTag sg_SaleRevTagList[] =
{
    {0x95},
    {0x9F1E},
    {0x9F10},
    {0x9F36},
    {0xDF31},
    {0},
};

// 脚本上送55域EMV标签
static DE55EmvTag sg_ScriptSendTagList[] =
{
    {0x9F33},
    {0x95},
    {0x9F37},
    {0x9F1E},
    {0x9F10},
    {0x9F26},
    {0x9F36},
    {0x82},
    {0xDF31},
    {0x9F1A},
    {0x9A},
    {0},
};

ST_TRANSCONFIG stTransConfig[] = 
{
   //交易类型          	原交易类型		冲正交易类型	   批上送时交易类型		    实现                9C    交易名称                      卡受理方式                              55域tag表                 冲正55域tag表             是否记录冲正  是否冲正上送  是否脚本上送   是否脱机上送
   //传统交易           
    {TRANS_SALE,        "",     		TRANS_SALE_REV,			FALSE,			    Trans_Sale,	        "00",  "QuickPass",              SWIPE_CARD|INSERT_CARD|TAP_CARD,                sg_SaleTagList,         sg_SaleRevTagList,          TRUE ,		TRUE ,      TRUE ,		TRUE },  //消费
    {TRANS_SALE_VOID,   "TRANS_SALE",   TRANS_SALE_VOID_REV,	FALSE,    		    Trans_Void,	        "20",  "Wechat",          SWIPE_CARD|INSERT_CARD|TAP_CARD,                NULL,                   NULL,                       TRUE ,		TRUE ,      TRUE ,		TRUE },  //消费撤销
    {TRANS_REFUND,      "TRANS_SALE",   FALSE,					TRANS_REFUND_BAT,   Trans_Refund,       "20",  "Alipay",              SWIPE_CARD|INSERT_CARD|TAP_CARD,                NULL,                   NULL,                       FALSE,		TRUE ,      TRUE,		TRUE },  //退货
    {TRANS_AUTH,        "",           	TRANS_AUTH_REV,			FALSE,		        Trans_Auth,		    "03",  "预授权",            KEYIN_CARD|SWIPE_CARD|INSERT_CARD|TAP_CARD,     sg_PreAuthTagList,      sg_SaleRevTagList,          TRUE ,		TRUE ,      TRUE ,		TRUE },  //预授权
    {TRANS_AUTHCM,      "TRANS_AUTH",   TRANS_AUTHCM_REV,       TRANS_AUTHCM_ADV_BAT,Trans_AuthCm,      "00",  "预授权完成(请求)",  KEYIN_CARD|SWIPE_CARD|INSERT_CARD|TAP_CARD,     NULL,                   NULL,                       TRUE ,		TRUE ,		TRUE ,		TRUE },  //预授权完成请求
    {TRANS_AUTH_VOID,   "TRANS_AUTH",   TRANS_AUTH_VOID_REV,    FALSE,              Trans_AuthVoid,     "20",  "预授权撤销",        KEYIN_CARD|SWIPE_CARD|INSERT_CARD|TAP_CARD,     NULL,                   NULL,                       TRUE ,		TRUE ,		TRUE ,		TRUE },  //预授权撤销
    {TRANS_AUTHCM_VOID, "TRANS_AUTHCM", TRANS_AUTHCM_VOID_REV,  FALSE,		        Trans_AuthCmVoid,   "20",  "预授权完成撤销",    FALSE,                                          NULL,                   NULL,                       TRUE ,		TRUE ,		TRUE ,		TRUE },  //预授权完成请求撤销 
    {TRANS_AUTHCM_ADV,  "TRANS_AUTH",   FALSE,        			FALSE,		        Trans_AuthCmAdv,    "00",  "预授权完成(通知)",  KEYIN_CARD|SWIPE_CARD|INSERT_CARD|TAP_CARD,     NULL,                   NULL,                       FALSE,		TRUE ,		TRUE ,		TRUE },  //预授权完成通知 
    {TRANS_QUE,         "",            	FALSE,					FALSE,		        Trans_Query,	    "31",  "Baidu",          SWIPE_CARD|INSERT_CARD|TAP_CARD,                sg_QueTagList,          NULL,                       FALSE,		TRUE ,		TRUE ,		TRUE },  //联机查余额
    {TRANS_OFFCM,       "",           	FALSE,					TRANS_OFFCM_BAT,	Trans_OfflineSettle,"00",  "离线结算",          KEYIN_CARD,                                     NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  //离线结算
    {TRANS_ADJUST,      "TRANS_SALE|TRANS_OFFCM", FALSE,        TRANS_ADJUST_BAT, 	Trans_OfflineAdjust,"00",  "结算调整",          FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  //结算调整
    {TRANS_TIP,         "TRANS_SALE",   FALSE,        			TRANS_TIP_BAT,		NULL,               "00",  "结算调整小费",      FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  //结算调整小费
   //电子现金交易                  																					
    {TRANS_EC_SALE,     "",           	FALSE,					FALSE,		        Trans_Ec_Sale,		"00",	"电子现金消费",     INSERT_CARD|TAP_CARD,                           sg_SaleTagList,         sg_SaleRevTagList,          TRUE ,		TRUE ,		TRUE ,		TRUE },  //电子现金消费(转联机)
    {TRANS_EC_CLSSSALE, "",           	FALSE,					FALSE,		        Trans_Ec_ClssSale,	"00",	"电子现金消费",     TAP_CARD,                                       NULL,                   NULL,                       TRUE ,		TRUE ,		TRUE ,		TRUE },  //快速支付电子现金消费(转联机)
    {TRANS_EC_CONTACTSALE,	"",			FALSE, 					FALSE,		        Trans_Ec_ContactSale,"00",	"电子现金消费",     INSERT_CARD,                                    NULL,                   NULL,                       TRUE ,		TRUE ,		TRUE ,		TRUE },  //普通支付电子现金消费(转联机)
    //管理类交易                   
    {TRANS_LOGON,       "", 			FALSE,					FALSE,		        Trans_PosLogon,		"", 	"签到",             FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // POS签到
    {TRANS_LOGOFF,      "", 			FALSE,					FALSE,		        PosLogoff,		    "", 	"签退",             FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // POS签退
    {TRANS_SETT,        "", 			FALSE,					FALSE,		        Batch_Settlement,	"", 	"结算",             FALSE,                                          NULL,                   NULL,                       FALSE,		TRUE ,		TRUE,		FALSE},  // POS结算
    {TRANS_IC_DOWN_CA,  "", 			FALSE,					FALSE,		        Trans_IcCaDown,		"", 	"公钥下载",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // IC卡公钥下载
    {TRANS_IC_DOWN_PARA,"", 			FALSE,					FALSE,		        Trans_IcParamDown,	"", 	"AID下载",          FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // IC卡参数下载
    {TRANS_SEND_PARA,   "", 			FALSE,					FALSE,		        Trans_ParamUpload,	"", 	"状态上送",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // 磁条卡状态上送
    {TRANS_DOWN_PARA,   "", 			FALSE,					FALSE,			    Trans_ParamDwn,	    "", 	"参数下载",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // 磁条卡参数下载
    {TRANS_TMS_DOWN_PARA,"",			FALSE,					FALSE,		        Trans_TMSParamDwn,	"", 	"TMS参数下载",      FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // POSTMS参数下载
    {TRANS_DOWN_BLACK,   "",			FALSE,					FALSE,		        Trans_BlackListDwn,	"", 	"黑名单下载",       FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // 黑名单下载
    //冲正类交易         																										
    {TRANS_SALE_VOID_REV,  	"TRANS_SALE",		FALSE,			FALSE,				NULL,               "", 	"",        		    FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,		FALSE,		FALSE},   
    {TRANS_AUTHCM_VOID_REV,	"TRANS_AUTHCM_VOID",FALSE,			FALSE,				NULL,               "", 	"",        		    FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,		FALSE,		FALSE}, 
    {TRANS_AUTH_VOID_REV,  	"TRANS_AUTH_VOID",	FALSE,			FALSE,				NULL,               "", 	"",        		    FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,		FALSE,		FALSE}, 
    //本地管理
    {ADMIN_EC_QUE,  	    "",			FALSE,					FALSE,				Trans_EcQue,        "", 	"电子现金余额查询", TAP_CARD,                           NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_IC_DETAIL,   	"",			FALSE,					FALSE,				Trans_ICCDetail,    "", 	"明细查询",         INSERT_CARD|TAP_CARD,                           NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_OPER_LOGON,   	"",			FALSE,					FALSE,				setup_OperLogon,          "", 	"操作员签到",       FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_QUE_TOTAL,   	"",			FALSE,					FALSE,				LocManage_QueTotal,     "", 	"查询总计",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_QUE_DETAIL,   	"",			FALSE,					FALSE,				LocManage_QueDetail,    "", 	"明细查询",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_QUE_ANY,   	    "",			FALSE,					FALSE,				LocManage_QueByVoucher, "", 	"交易查询",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_PRT_LAST,   	    "",			FALSE,					FALSE,				LocManage_ReprintLast,  "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_PRT_ANY,   	    "",			FALSE,					FALSE,				LocManage_ReprintAny,   "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_PRT_DETAIL,   	"",			FALSE,					FALSE,				LocManage_PrintDetail,  "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_PRT_TOTAL,   	"",			FALSE,					FALSE,				LocManage_PrintTotal,   "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_PRT_LAST_TOTAL,  "",			FALSE,					FALSE,				LocManage_PrintLastTotal,"", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {FUNC_REPRINT_PARAM,   	"",			FALSE,					FALSE,				LocManage_PrintTermParam,"", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_LOCK_TERM,   	"",			FALSE,					FALSE,				Oper_PosLockUnLock,      "", 	"锁定",             FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_DISP_VERSION,   	"",			FALSE,					FALSE,				LocManage_ShowVersion,  "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {ADMIN_IC_DISP_AID,   	"",			FALSE,					FALSE,				LocManage_QueAidList,   "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    //其他
    {TRANS_TEST,            "",			FALSE,					FALSE,		        Trans_EchoTest,		"", 	"回响测试",         FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // POS回响测试
    {TRANS_SIG_SEND,        "",			FALSE,					FALSE,				NULL,               "", 	"电子签名上送",     FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},  // 电子签名上送
    {TRANS_IC_OFF_SEND,  	"",			FALSE,					FALSE,				NULL,               "", 	"离线上送",         FALSE,                                          sg_EcOffTagList,        NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_SCR_SEND,  	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          sg_ScriptSendTagList,   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_BATCH_UP,     	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_BATCHUP_END,     "",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_FAIL_BAT,     "",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_TC_BAT,       "",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_AUTHCM_ADV_BAT,  "",			FALSE,					FALSE,				NULL,               "",		"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_REFUND_BAT,      "",			FALSE,					FALSE,				NULL,               "",		"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_BONUS_REFUND_BAT,"",			FALSE,					FALSE,				NULL,               "",		"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_EC_REFUND_BAT, 	"",			FALSE,					FALSE,				NULL,               "",		"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_OFF_BAT,   	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_OFFCM_BAT,    	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_ADJUST_BAT,   	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_TIP_BAT,      	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_MON_CA,    	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_DOWNCA_END,	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_MON_PARA,  	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_IC_DOWNPA_END,	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_DOWNBLK_END,  	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
    {TRANS_TMS_PARA_END, 	"",			FALSE,					FALSE,				NULL,               "", 	"",                 FALSE,                                          NULL,                   NULL,                       FALSE,		FALSE,      FALSE,		FALSE},
};         


static ST_PACKETCONFIG stPacketConfig[] = 
{
    //交易类型                     消息类型  处理码 服务码 功能码 网络码 打包处理函数              MAC函数  解包处理函数  校验MAC函数
    {TRANS_QUE,                     "0200", "310000", "00", "01", "000", QueryPacket,               Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*联机查余额*/
    {TRANS_SALE,                    "0200", "000000", "00", "22", "000", SalePacket,                NULL, Packet_GeneralUnpack, NULL}, /*消费*/
    {TRANS_SALE_REV,                "0400", "000000", "00", "22", "000", SaleRevPacket,             Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*消费冲正*/
    {TRANS_SALE_VOID,               "0200", "200000", "00", "23", "000", SaleVoidPacket,            Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*消费撤销*/
    {TRANS_SALE_VOID_REV,           "0400", "200000", "00", "23", "000", SaleVoidRevPacket,         Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*消费撤销冲正*/
    {TRANS_REFUND,                  "0220", "200000", "00", "25", "000", RefundPacket,              Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*退货*/
    {TRANS_AUTH,                    "0100", "030000", "06", "10", "000", AuthPacket,                Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权*/
    {TRANS_AUTH_REV,                "0400", "030000", "06", "10", "000", AuthRevPacket,             Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权冲正*/
    {TRANS_AUTH_VOID,               "0100", "200000", "06", "11", "000", AuthVoidPacket,            Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权撤销*/
    {TRANS_AUTH_VOID_REV,           "0400", "200000", "06", "11", "000", AuthVoidRevPacket,         Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权撤销冲正*/
    {TRANS_AUTHCM,                  "0200", "000000", "06", "20", "000", AuthCmPacket,              Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权完成(请求)*/
    {TRANS_AUTHCM_REV,              "0400", "000000", "06", "20", "000", AuthCmRevPacket,           Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权完成(请求)冲正*/
    {TRANS_AUTHCM_VOID,             "0200", "200000", "06", "21", "000", AuthCmVoidPacket,          Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权完成(请求)撤销 */
    {TRANS_AUTHCM_VOID_REV,         "0400", "200000", "06", "21", "000", AuthCmVoidRevPacket,       Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权完成(请求)撤销冲正*/
    {TRANS_AUTHCM_ADV,              "0220", "000000", "06", "24", "000", AuthCmAdvPacket,           Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*预授权完成通知 */
    {TRANS_OFFCM,                   "0220", "000000", "00", "30", "000", OfflineSettlePacket,       Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*离线结算*/
    {TRANS_ADJUST,                  "0220", "000000", "00", "32", "000", OfflineAdjustPacket,       Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*结算调整*/
    {TRANS_TIP,                     "0220", "000000", "00", "34", "000", OfflineAdjustPacket,       Ped_GenMac, TipUnpack, Ped_ChkMac}, /*结算调整小费*/
    {TRANS_EC_SALE,                 "0200", "000000", "00", "22", "000", SalePacket,                Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*电子现金现金消费(转联机)*/
    {TRANS_EC_SALE_REV,             "0400", "000000", "00", "22", "000", AuthRevPacket,             Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*电子现金现金消费(转联机)冲正*/
    {TRANS_IC_OFF_SEND,             "0200", "000000", "00", "36", "000", IcOffBatPacket,            Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*IC脱机交易上送*/
    {TRANS_IC_SCR_SEND,             "0620", "000000", "00", "00", "951", ScriptUploadPacket,        Ped_GenMac, ScriptlUnpack, Ped_ChkMac}, /*IC卡脚本结果上送*/
    {TRANS_LOGON,                   "0800", "",       "",   "00", "003", LogonPacket,               NULL,   Packet_GeneralUnpack, NULL},   /*POS签到*/
    {TRANS_LOGOFF,                  "0820", "",       "",   "00", "002", LogoutPacket,              NULL,   Packet_GeneralUnpack, NULL},   /*POS签退*/
    {TRANS_SETT,                    "0500", "",       "",   "00", "201", Batch_SettlePacket,        NULL,   Batch_SettleUnpack, NULL},   /*POS结算*/
    {TRANS_BATCH_UP,                "0320", "",       "",   "00", "201", Batch_UpPacket,            NULL,   Packet_GeneralUnpack, NULL},   /*联机批上送*/
    {TRANS_BATCHUP_END,             "0320", "",       "",   "00", "207", Batch_UpEndPacket,         NULL,   Packet_GeneralUnpack, NULL},   /*联机批上送结束*/
    {TRANS_IC_MON_CA,               "0820", "", 	  "",   "00", "372", ICMonCaUploadPack,        	NULL, Packet_GeneralUnpack, NULL}, /*IC卡公钥下载状态上送*/
    {TRANS_IC_DOWN_CA,              "0800", "", 	  "",   "00", "370", ICMonCaDownPack,           NULL, Packet_GeneralUnpack, NULL}, /*IC卡公钥下载*/
    {TRANS_IC_DOWNCA_END,           "0800", "", 	  "",   "00", "371", ICMonCaEndPack,            NULL, Packet_GeneralUnpack, NULL}, /*IC卡公钥下载结束*/
    {TRANS_IC_MON_PARA,             "0820", "", 	  "",   "00", "382", ICParamUploadPack,         NULL, Packet_GeneralUnpack, NULL}, /*IC卡参数下载状态上送*/
    {TRANS_IC_DOWN_PARA,            "0800", "",       "",   "00", "380", ICParamDownPack,           NULL, Packet_GeneralUnpack, NULL}, /*IC卡参数下载*/
    {TRANS_IC_DOWNPA_END,           "0800", "", 	  "",   "00", "381", ICParamEndPack,            NULL, Packet_GeneralUnpack, NULL}, /*IC卡参数下载结束*/
    {TRANS_SEND_PARA,               "0820", "", 	  "",   "00", "362", ParamUploadPack,           NULL,   Packet_GeneralUnpack, NULL},   /*磁条卡状态上送*/
    {TRANS_DOWN_PARA,               "0800", "",       "",   "00", "360", ParamDwnPack,              NULL,   Packet_GeneralUnpack, NULL},   /*磁条卡参数下载*/
    {TRANS_TMS_DOWN_PARA,           "0800", "",       "",   "00", "364", TMSParamDwnPack,           NULL,   Packet_GeneralUnpack, NULL},   /*POSTMS参数下载*/
    {TRANS_TMS_PARA_END,            "0800", "",       "",   "00", "365", TMSParamEndPack,           NULL,   Packet_GeneralUnpack, NULL},   /*POSTMS参数下载结束*/
    {TRANS_DOWN_BLACK,              "0800", "",  	  "",   "00", "390", BlkListDwnPack,            NULL,   Packet_GeneralUnpack, NULL},   /*黑名单下载*/
    {TRANS_DOWNBLK_END,             "0800", "",       "",   "00", "391", BlkListEndPack,            NULL,   Packet_GeneralUnpack, NULL},   /*黑名单下载结束*/
    {TRANS_TEST,                    "0820", "",       "",   "", "301", EchoTestPack,              NULL,   Packet_GeneralUnpack, NULL},   /*POS回响测试*/
    {TRANS_SIG_SEND,                "0820", "000000", "00", "07", "800", SignSendPack,              Ped_GenMac, Packet_GeneralUnpack, Ped_ChkMac}, /*电子签名上送*/
    {TRANS_IC_OFF_BAT,              "0320", "000000", "00", "36", "000", IcOffBatPacket,            NULL,   Packet_GeneralUnpack, NULL},   /*IC脱机交易批上送*/
    {TRANS_IC_TC_BAT,               "0320", "", 	  "",   "00", "203", Batch_UpIcTcPacket,             NULL,   Packet_GeneralUnpack, NULL},   /*IC交易TC上送*/
    {TRANS_IC_FAIL_BAT,             "0320", "000000", "00", "00", "204", Batch_UpIcFailPacket,           NULL,   Packet_GeneralUnpack, NULL},   /*IC失败交易上送(包括脱机失败和ARPC错)*/
    {TRANS_OFFCM_BAT,               "0320", "000000", "00", "30", "000", Batch_UpNoticePacket,       NULL,   Packet_GeneralUnpack, NULL},   /*批上送 离线结算*/
    {TRANS_ADJUST_BAT,              "0320", "000000", "00", "32", "000", Batch_UpNoticePacket,       NULL,   Packet_GeneralUnpack, NULL},   /*批上送 结算调整*/
    {TRANS_TIP_BAT,                 "0320", "000000", "00", "34", "000", Batch_UpNoticePacket,       NULL,   TipUnpack, NULL},   /*批上送 结算调整小费*/
    {TRANS_REFUND_BAT,              "0320", "200000", "00", "25", "000", Batch_UpNoticePacket,       NULL,   Packet_GeneralUnpack, NULL},   /*批上送 隔日退货*/
    {TRANS_EC_REFUND_BAT,           "0320", "200000", "00", "27", "000", Batch_UpNoticePacket,       NULL,   Packet_GeneralUnpack, NULL},   /*EC隔日退货批上送*/
    {TRANS_AUTHCM_ADV_BAT,          "0320", "000000", "06", "24", "000", Batch_UpNoticePacket,       NULL,   Packet_GeneralUnpack, NULL},   /*预授权离线上送*/
};

ST_PRINTCONFIG  stPrintConfig[] =
{
   //交易类型             交易名称          	            是否隐藏卡号	备注栏打印IC卡信息样式  是否纳入打印明细    是否纳入打印失败明细     明细单打印类型   组织电子签名上送55域数据
   //传统交易          
    {TRANS_SALE,         	"消费(SALE)",                       TRUE ,          TRUE ,                  TRUE,		    FALSE,          "S",            PrepareSaleSign55 },  //消费
    {TRANS_SALE_VOID,    	"消费撤销(VOID)",                   TRUE ,          FALSE ,                 FALSE,     	    FALSE,          "",             PrepareSaleVoidSign55},  //消费撤销
    {TRANS_REFUND,       	"退货(REFUND)",                     TRUE,           FALSE,                  TRUE,		    FALSE,          "R",            PrepareRefundSign55 },  //退货
    {TRANS_AUTH,         	"预授权(AUTH)",                     FALSE ,         TRUE ,                  FALSE,		    FALSE,          "",             PrepareAuthSign55 },  //预授权
    {TRANS_AUTHCM,       	"预授权完成(请求)(AUTH COMPLETE)",  TRUE ,          FALSE ,			        TRUE,		    FALSE,          "P",            PrepareAuthCmSign55 },  //预授权完成请求
    {TRANS_AUTH_VOID,  		"预授权撤销(CANCEL)",               TRUE ,          FALSE ,			        FALSE,		    FALSE,          "",             PrepareAuthVoidSign55 },  //预授权撤销
    {TRANS_AUTHCM_VOID,		"预授权完成撤销(COMPLETE VOID)",    TRUE ,          FALSE ,			        FALSE,		    FALSE,          "",             PrepareAuthCmVoidSign55 },  //预授权完成请求撤销 
    {TRANS_AUTHCM_ADV, 		"预授权完成(通知)(AUTH SETTLEMENT)",TRUE,           FALSE,			        TRUE,		    FALSE,          "C",            PrepareAuthCmAdvSign55 },  //预授权完成通知 
    {TRANS_OFFCM,      		"离线结算(OFFLINE)",                FALSE,          FALSE,	                TRUE,		    TRUE,		    "L",            PrepareOffcmSign55	},  //离线结算
    {TRANS_ADJUST,     		"结算调整(ADJUST)",                 FALSE,          FALSE,	                TRUE,		    TRUE,		    "L",            PrepareAdjustSign55	},  //结算调整
    {TRANS_TIP,        		"结算调整(ADJUST)",                 TRUE,           FALSE,	                TRUE,		    TRUE,		    "S",            PrepareTipSign55	},  //结算调整小费
    {TRANS_EC_SALE,    		"电子现金消费(EC SALE)",            TRUE ,          TRUE ,		            TRUE,		    TRUE,		    "S",            PrepareEcSaleSign55 },  //电子现金消费
	{TRANS_EC_REFUND,		"电子现金退货(EC REFUND)",			TRUE , 		    FALSE ,		            TRUE,		    FALSE,          "R",            PrepareEcRefundSign55 },  //电子现金退货
};

static ST_UI_PAGE stUiMenu[] = 
{
	//菜单类
	{CMD_TRANS_MENU,                    MAIN_MENU,                      TIMEOUT},//主菜单
	{CMD_MENU_PARAMSET,                 MAINSET_MENU,                   TIME_NOLIMIT},//参数设置菜单
	{CMD_MENU_OPERMANAGER,              MASTER_MENU,                    TIMEOUT},    //管理员操作菜单
	{CMD_MENU_DOWNLOAD,                 DOWNLOAD_MENU,                  TIMEOUT},    //下载菜单
	{CMD_MENU_ORG_CODE,                 INTERCODE_MENU,                 TIMEOUT},    //国际组织代码菜单
	{CMD_MENU_PAY_PYTE,                 PAYTYPE_MENU,                 TIMEOUT},    //国际组织代码菜单
	{CMD_MENU_SELECT_IDTYPE,            HOLDERID_MENU,                  TIMEOUT},   //证件类型选择菜单
	{CMD_MENU_ENABLETRANS,              ENABLETRANS_MENU,               TIMEOUT},   //交易开关菜单
	{CMD_MENU_SELECTAPP,                SELECTAPP_MENU,                 TIME_NOLIMIT},   //应用选择
	{CMD_SWICTH_MENU,                   XML_SWITCH_MENU,                NO_TIMEOUT},//开关列表
};

static ST_UI_PAGE stUiPage[] = 
{
    //页面类
    {CMD_INPUT_COMMON,                  XML_INPUT_COMMON,               NO_TIMEOUT},
    {CMD_HOME_SCREEN,                   XML_HOME_SCREEN,                NO_TIMEOUT},  //待机界面
	{CMD_STARTUP_SCREEN,                XML_STARTUP_SCREEN,             NO_TIMEOUT},  //待机界面
    {CMD_HOME_TIME,                     NULL,                           NO_TIMEOUT},//待机界面动态时间显示
    {CMD_GET_AMT,                       XML_GETDATA_AMT,                TIMEOUT},//金额输入界面
    {CMD_GET_AMT_ADJUST,                XML_GETDATA_ADJUST,             TIMEOUT},//金额输入界面
    {CMD_GET_TIP,                       XML_GETDATA_TIP,                TIMEOUT},//金额输入界面
    {CMD_PROMPT_READ_CARD,              XML_GETCARD,                    NO_TIMEOUT},//刷卡提示界面
    {CMD_PROMPT_READ_CARD_AMT,          XML_GETCARD_AMT,                NO_TIMEOUT},//刷卡带金额提示界面
    {CMD_GET_CARDNO,                    XML_GETCARD_INPUT_CARDNO,       TIMEOUT},//手输卡号界面
    {CMD_GET_PIN,                       XML_GETPIN,                     NO_TIMEOUT},//输PIN界面
    {CMD_GET_VOUCHERNO,                 XML_GETDATA_ORIG_VOUCHER,       TIMEOUT},//凭证号输入界面
    {CMD_GET_BATCHNO,                   XML_GETDATA_ORIG_BATCHNO,       TIMEOUT},//设置批次号
    {CMD_GET_AUTHNO,                    XML_GETDATA_AUTHNO,             TIMEOUT},//授权号输入界面
    {CMD_GET_REFRENCENO,                XML_GETDATA_ORIG_REFERNO,       TIMEOUT},//参考号输入界面
    {CMD_GET_TRANSDATE,                 XML_GETDATA_ORIG_TRANSDATE,     TIMEOUT},//交易日期界面
	{CMD_GET_IDNO,                      XML_GETDATA_IDNO,               TIMEOUT},//输入证件号
    {CMD_GET_EXPDATE,                   XML_GETDATA_EXPDATE,            TIMEOUT},//卡片有效期输入界面
    {CMD_GET_MANAGERPWD,                XML_GETDATA_MANAGERPWD,         TIMEOUT},//主管密码输入界面
    {CMD_HOME_MANAGE,                   XML_HOME_MANAGE,                TIMEOUT},//管理员操作待机界面
    {CMD_OPER_INPUT_OPERNO,             XML_GET_OPERNO,                 TIME_NOLIMIT},//操作员号输入界面
    {CMD_OPER_INPUT_OPERPWD,            XML_GET_OPERPWD,                TIME_NOLIMIT},//操作员号密码输入界面
    {CMD_INPUT_NEWPWD,                  XML_GETDATA_INPUTNEWPWD,        TIMEOUT},//输入新密码界面
    {CMD_INPUT_PWDAGAIN,                XML_GETDATA_INPUTPWD_AGAIN,     TIMEOUT},//重输密码界面
    {CMD_PARAM_MERCHANTID,              XML_PARAM_MERCHANTID,           TIMEOUT},//设置商户号
    {CMD_PARAM_MERCHANTNAME,            XML_PARAM_MERCHANTNAME,         TIMEOUT},//设置商户中文名称
	{CMD_PARAM_INPUT_CHINESE,           XML_PARAM_INPUT_CHINESE,        TIMEOUT},//中文
    {CMD_PARAM_CONFIRM_CHINESE,         XML_PARAM_CONFIRM_CHINESE,      TIMEOUT},//确认所输入的中文
	{CMD_PARAM_MERCHANTENGNAME,         XML_PARAM_MERCHANTENGNAME,      TIMEOUT},//设置商户英文名称
    {CMD_PARAM_INPUT_EN,                XML_PARAM_INPUT_EN ,            TIMEOUT},//英文名称输入
    {CMD_PARAM_CONFIRM_EN,              XML_PARAM_CONFIRM_EN,           TIMEOUT},//确认所输入的英文
    {CMD_PARAM_TERMID,                  XML_PARAM_TERMID,               TIMEOUT},//设置终端号
    {CMD_DATADISP_CARDNO,               XML_DISPINFO_CARD_NO,           TIMEOUT},//显示卡号
    {CMD_GET_SYSPWD,                    XML_GETDATA_SYSPWD,         	TIMEOUT},//获取系统密码
    {CMD_GET_SAFETYPWD,                 XML_GETSAFETYPWD,               TIMEOUT},//安全密码输入界面
    {CMD_PROMPT_LOGON_SUCC,             XML_PROMPT_LOGON_SUCC,          DISP_TIMEOUT},//签到成功
    {CMD_PROMPT_DISP_COMLETE,           XML_PROMPT_DISP_COMLETE,        NO_TIMEOUT},//显示完成（如：明细查询）
    {CMD_PROMPT_OFFLINEUPLOAD,          XML_PROMPT_OFFLINEUPLOAD,       NO_TIMEOUT},//离线上送提示界面
    {CMD_PROMPT_IC_OFFLINEUPLOAD,       XML_PROMPT_IC_OFFLINEUPLOAD,    NO_TIMEOUT},//上送IC卡脱机交易提示界面
    {CMD_PROMPT_MSG,                    XML_PROMPT_MSG,                 NO_TIMEOUT},//消息提示
    {CMD_PROMPT_MSG_WAIT,               NULL,                           NO_TIMEOUT},//消息提示等待按键
    {CMD_PROMPT_BATCHUP_CONTINUE,       XML_PROMPT_BATCHUP_PROC,        TIME_NOLIMIT},//继续批上送提示
    {CMD_PROMPT_BATCHUP,                XML_PROMPT_BATCHUP_PROC,        NO_TIMEOUT},//批上送提示
    {CMD_PROMPT_IS_PRTDETAIL,           XML_PROMPT_IS_PRTDETAIL,        TIME_NOLIMIT},//是否打印明细提示
    {CMD_PROMPT_IS_PRTERRDETAIL,        XML_PROMPT_IS_PRTERRDETAIL,     TIME_NOLIMIT},//是否打印失败明细提示
    {CMD_REMIND_ERRPIN,                 XML_REMIND_ERRPIN,              DISP_TIMEOUT},//密码错误
    {CMB_DATEDISP_TERMENU,              XML_PROMPT_TERMMENU,            TIMEOUT},//显示版本
    {CMB_DATEDISP_LIBVER,               XML_PROMPT_LIBVER,              TIMEOUT},//显示库版本
    //EMV UI页面
    {CMD_EMV_CERTVERIFY,                XML_EMV_CERTVERIFY,             TIMEOUT},//CertVerify       
    {CMD_REMIND_LOWBATTERY,             XML_REMIND_LOWBATTERY,          DISP_TIMEOUT},//低电量提醒
    {CMD_REMIND_NO_LOGON,               XML_REMIND_NO_LOGON,            DISP_TIMEOUT},//终端未签到
    {CMD_REMIND_NEED_SETTLE,            XML_REMIND_NEED_SETTLE,         DISP_TIMEOUT},//结算提醒
    {CMD_REMIND_NEED_SETTLELATER,       XML_REMIND_NEED_SETTLELATER,    DISP_TIMEOUT},//结算提醒
    {CMD_REMIND_SETUP_NEED_SETTLELATER, XML_REMIND_SETUP_NEED_SETTLE,   DISP_TIMEOUT},//结算提醒  
    {CMD_REMIND_STORAGE_FULL,           XML_REMIND_STORAGE_FULL,        DISP_TIMEOUT},//存储空间不足
    {CMD_REMIND_READCARD_ERR,           XML_REMIND_READCARD_ERR,        DISP_TIMEOUT},//刷卡错误界面
    {CMD_REMIND_READCARD_INMENU_ERR,    XML_REMIND_READCARD_IN_MENU_ERR,NO_TIMEOUT},//界面刷卡失败界面
    {CMD_OPER_FAIL,                     XML_OPER_FAIL,                  DISP_TIMEOUT},//操作员操作失败
    {CMD_OPER_SUCC,                     XML_OPER_SUCC,                  DISP_TIMEOUT},//操作员操作成功
    {CMD_DATADISP_QUEAMT,               XML_PROMPT_QUEAMT,              DISP_TIMEOUT},//显示查询金额界面
    {CMD_DATEDISP_AMTCONFIRM,           XML_AFFIRM_AMT,                 TIMEOUT},//确定金额界面
    {CMD_DATADISP_QUETRANS,             XML_PROMPT_TRANSINFO,           TIMEOUT},//显示单笔交易信息
    {CMD_DATADISP_AID,                  XML_PROMPT_AID,                 TIMEOUT},//显示单笔交易信息
    {CMD_DATADISP_AIDLIST,              XML_PROMPT_AIDLIST,             TIMEOUT},//显示单笔交易信息
    {CMD_DATEDISP_ICCDETAIL_1,          XML_PROMPT_ICCDETAIL_1,         TIMEOUT},//显示IC卡交易信息（查询）
    {CMD_DATEDISP_ICCDETAIL_2,          XML_PROMPT_ICCDETAIL_2,         TIMEOUT},//显示IC卡交易信息（查询）
    {CMD_DATEDISP_OPERICJUDG,           XML_PROMPT_OPERICJUDG,          TIMEOUT},//显示IC卡交易信息（查询）
    {CMD_DATADISP_ORIGTRANS,            XML_PROMPT_ORIGTRANS,           TIMEOUT},//显示当前撤销交易信息
    {CMD_PARAM_IS_SUPPORT,              XML_PARAM_IS_SUPPORT,           TIMEOUT}, //选1模板（是否支持）
    {CMD_PARAM_IS_PROMPT,               XML_PARAM_IS_PROMPT,            TIMEOUT},//选1模板（是否提示）
    {CMD_PARAM_IS_KEYIN_CARDNO,         XML_PARAM_IS_KEYIN_CARDNO,      TIMEOUT},//显示是否输入主管密码撤销/退货类交易
    {CMD_PARAM_IS_MANAGER_VOIDREFUND,   XML_PARAM_IS_MANAGER_VOIDREFUND,TIMEOUT},//显示是否打开手输卡号模板
    {CMD_PARAM_IS_SWPIE_CARD,           XML_PARAM_IS_SWPIE_CARD,        TIMEOUT},//显示是否刷卡2选1模板
    {CMD_PARAM_IS_ENCRYPT,              XML_PARAM_IS_ENCRYPT,           TIMEOUT},//显示磁道是否加密2选1模板
    {CMD_PARAM_IS_INPUT_PIN,            XML_PARAM_IS_INPUT_PIN,         TIMEOUT},//显示是否输入密码2选1模板
    {CMD_PARAM_ICC_DECIDE_MODE,         XML_PARAM_ICC_DECIDE_MODE,      TIMEOUT},//显示芯片卡判断方式2选1模板
    {CMD_PARAM_IS_MASKCARDNO,           XML_PARAM_IS_MASK_CARDNO,       TIMEOUT},//显示是否屏蔽卡号2选1模板
	{CMD_PARAM_IS_ELCSIGN,              XML_PARAM_IS_ELCSIGN,           TIMEOUT}, //显示是否电子签名
	{CMD_PARAM_SET_ELCSIGNBRUSH,        XML_PARAM_SET_SIGNBRUSH,         TIMEOUT},  //设置签名板笔画粗细
	{CMD_PARAM_SET_ELCSIGNTIMEOUT,      XML_PARAM_SET_SIGNTIMEOUT,      TIMEOUT},   //签名板超时时间
	{CMD_PARAM_SET_ELCSIGNREVTIMES,     XML_PARAM_SET_SIGNREVTIMES,      TIMEOUT},   //电子签名重发次数
	{CMD_PARAM_SET_SIGNPADPORT,         XML_PARAM_SET_SIGNPADPORT,      TIMEOUT},   //签名板内外置设置
	{CMD_ERR_SIGNDISP,					XML_APP_SIGN_WARN,				TIMEOUT},   //电子签名笔画太少错误提示
	{CMD_PARAM_SET_HOLDTICKS,           XML_PARAM_SET_HOLDTICKS,        TIMEOUT},    //是否打印持卡人联
	{CMD_PARAM_IS_PRTEN,                XML_PARAM_IS_PRTEN,             TIMEOUT}, //显示签购单是否打印英文
    {CMD_PARAM_CITYCODE,                XML_PARAM_CITYCODE,             TIMEOUT},//设置地区码
    {CMD_PARAM_COMMERCIALBANKCODE,      XML_PARAM_COMMERCIALBANKCODE,   TIMEOUT},//商行代码
    {CMD_PARAM_TRANOTHERDATETIME,       XML_PARAM_TRANOTHERDATETIME,    TIMEOUT},//设置POS日期时间
    {CMD_PARAM_RECEIPT_NUM,             XML_PARAM_RECEIPT_NUM,          TIMEOUT},//设置打印凭单联数
    {CMD_PARAM_RECEIPT_GRAY,            XML_PARAM_CITYGRAY,             TIMEOUT},//设置打印灰度
    {CMD_PARAM_AUTHCM_MODE,             XML_PARAM_AUTHCM_MODE,          TIMEOUT},//授权完成方式
    {CMD_PARAM_SYSTRACENO,              XML_GETTRANSNO,                 TIMEOUT},//设置流水号
    {CMD_PARAM_SYSBATCHNO,              XML_GETBATCHNO,                 TIMEOUT},//设置批次号
    {CMD_PARAM_HOMETITLE,               XML_PARAM_HOMETITLE,            TIMEOUT},//设置主页面标题
    {CMD_PARAM_CONFIRM_MAINTITLE,       XML_PARAM_CONFIRM_MAINTITLE,    TIMEOUT},//设置主页面标题
    {CMD_PARAM_TRANOTHERREFUNDLIMIT,    XML_PARAM_TRANOTHERREFUNDLIMIT, TIMEOUT},//设置退货限额
    {CMD_PARAM_OFFLINELIMIT,            XML_PARAM_OFFLINELIMIT,         TIMEOUT},//自动上送累计笔数
    {CMD_PARAM_RECEIPT_TITLE,           XML_PARAM_RECEIPT_TITLE,        TIMEOUT},//签购单抬头设置
    {CMD_PARAM_SYSREVTIMES,             XML_PARAM_SYSREVTIMES,          TIMEOUT},//重发次数设置
    {CMD_PARAM_SYSREVTYPE,              XML_PARAM_SYSREVTYPE,           TIMEOUT},//接收超时即刻冲正设置
    {CMD_PARAM_SYSMAXTRAN,              XML_PARAM_SYSMAXTRAN,           TIMEOUT},//最大交易笔数
    {CMD_PARAM_SYS_CLSSREADER,          XML_PARAM_SYS_CLSSREADER,       TIMEOUT},//内外置非接设置
    {CMD_PARAM_SYS_OUTCLSSREADER,       XML_PARAM_SYS_OUTCLSSREADER,    TIMEOUT},//非接设备设置
    {CMD_PARAM_SYS_OUTCLSSREADERNO,     XML_PARAM_SYS_OUTCLSSREADERNO,  TIMEOUT},//外置非接设备串口号
    {CMD_PARAM_SYS_OUTCLSSREADERRATE,   XML_PARAM_SYS_OUTCLSSREADERRATE,TIMEOUT},//外置非接设备速率
    {CMD_PARAM_SYSTIP,                  XML_PARAM_SYSTIP,               TIMEOUT},//是否支持小费
    {CMD_PARAM_SYSTIPPERCENT,           XML_PARAM_SYSTIPPERCENT,        TIMEOUT},     //设置小费比例
    {CMD_PARAM_SYSVOIDSIGNAL,           XML_PARAM_SYSVOIDSIGNAL,        TIMEOUT},     //撤销类交易打负号
    {CMD_PARAM_SYSFDBLACKLIST,          XML_PARAM_SYSFDBLACKLIST,       TIMEOUT},     //强制下载黑名单
    {CMD_PARAM_MODEMNEEDEXTNO,          XML_PARAM_MODEMNEEDEXTNO,       TIMEOUT},     //是否需要外线号码
    {CMD_PARAM_MODEMEXTNO,              XML_PARAM_MODEMEXTNO,           TIMEOUT},     //外线号码设置
    {CMD_PARAM_MODEMEXTNODELAY,         XML_PARAM_MODEMEXTNODELAY,      TIMEOUT},     //外线延时设置
    {CMD_PARAM_MODEMPHONE1,             XML_PARAM_MODEMPHONE1,          TIMEOUT},     //电话号码1设置
    {CMD_PARAM_MODEMPHONE2,             XML_PARAM_MODEMPHONE2,          TIMEOUT},     //电话号码2设置
    {CMD_PARAM_MODEMPHONE3,             XML_PARAM_MODEMPHONE3,          TIMEOUT},     //电话号码3设置
    {CMD_PARAM_MODEMOTHERPARAM,         XML_PARAM_MODEMOTHERPARAM,      TIMEOUT},     //其他拨号参数设置
    {CMD_PARAM_MODEMDAILLEVEL,          XML_PARAM_MODEMDAILLEVEL,       TIMEOUT},     //拨号电平设置
    {CMD_PARAM_MODEMDAILDP,             XML_PARAM_MODEMDAILDP,          TIMEOUT},     //拨号方式设置
    {CMD_PARAM_MODEMDAILCHDT,           XML_PARAM_MODEMDAILCHDT,        TIMEOUT},     //是否检测拨号音
    {CMD_PARAM_MODEMDAILDT1,            XML_PARAM_MODEMDAILDT1,         TIMEOUT},     //拨号音最长等待时间
    {CMD_PARAM_MODEMDAILDT2,            XML_PARAM_MODEMDAILDT2,         TIMEOUT},     //拨号音最长等待时间
    {CMD_PARAM_COMMTPDU,                XML_PARAM_COMMTPDU,             TIMEOUT},     //设置TPDU
    {CMD_PARAM_MODEMDAILHT,             XML_PARAM_MODEMDAILHT,          TIMEOUT},     //设置单一号码保持时间
    {CMD_PARAM_MODEMDAILWT,             XML_PARAM_MODEMDAILWT,          TIMEOUT},     //设置两个号码间隔
    {CMD_PARAM_MODEMDAILSSETUP,         XML_PARAM_MODEMDAILSSETUP,      TIMEOUT},     //通讯字节设置
    {CMD_PARAM_MODEMDAILDTIMES,         XML_PARAM_MODEMDAILDTIMES,      TIMEOUT},     //重拨次数
    {CMD_PARAM_MODEMIDLETIMEOUT,        XML_PARAM_MODEMIDLETIMEOUT,     TIMEOUT},     //应用层无数据交互通讯超时
    {CMD_PARAM_MODEMDAILTIMEOUT,        XML_PARAM_MODEMDAILTIMEOUT,     TIMEOUT},     //通讯超时
    {CMD_PARAM_COMMPREDAIL,             XML_PARAM_MODEMDAILPRE,         TIMEOUT},     //预拨设置
    {CMD_PARAM_GPRSAPN,                 XML_PARAM_COMMGPRSAPN,          TIMEOUT},   //APN设置
    {CMD_PARAM_LOCALIP,                 XML_PARAM_LOCALIP,              TIMEOUT},    //本机IP设置
    {CMD_PARAM_SUBNETMASK,              XML_PARAM_SUBNETMASK,           TIMEOUT},//子网掩码设置
    {CMD_PARAM_GATEWAY,                 XML_PARAM_GATEWAY,              TIMEOUT},    //网关设置
    {CMD_PARAM_COMMLAN1IP,              XML_PARAM_COMMLAN1IP,           TIMEOUT},    //主机1IP设置
    {CMD_PARAM_COMMLAN1PORT,            XML_PARAM_COMMLAN1PORT,         TIMEOUT},   //主机1端口设置
    {CMD_PARAM_COMMLAN2IP,              XML_PARAM_COMMLAN2IP,           TIMEOUT},      //主机2IP设置
    {CMD_PARAM_COMMLAN2PORT,            XML_PARAM_COMMLAN2PORT,         TIMEOUT},   //主机2端口设置
    {CMD_PARAM_NEEDUSER,                XML_PARAM_NEEDUSER,             TIMEOUT},       //是否需要用户名
    {CMD_PARAM_COMMSHORTLINK,           XML_PARAM_COMMSHORTLINK,        TIMEOUT}, //无线是否为短链接
    {CMD_PARAM_PWDCHANGE,               XML_PARAM_SYSPWDCHANGEMENU,     TIMEOUT},//更改密码
    {CMD_PARAM_AUTOLOGOFF,              XML_PARAM_AUTOLOGOFF,           TIMEOUT},//自动签退
    {CMD_PARAM_TRAN_DEFAULT,            XML_PARAM_DEFAULT_TRANS,        TIMEOUT},//主界面默认交易
    {CMD_PARAM_SALEPROCTYPE,            XML_PARAM_DEFAULT_SALEPROCTYPE, TIMEOUT},
    {CMD_PARAM_OTHERFUNC,               XML_PARAM_OTHERFUNC,            TIMEOUT},
    {CMD_DISP_RESULT,                   XML_DISP_RESULT,                DISP_TIMEOUT},//结果显示
	{CMD_DISP_SUCC,                     XML_DISP_RESULT,                NO_TIMEOUT},//结果显示
    {CMD_PARAM_CDMANUM,                 XML_PARAM_CDMANUM,              TIMEOUT},  //CDMA接入号码设置 
    {CMD_PARAM_SETUSER,                 XML_PARAM_CDMAUSER,             TIMEOUT},  //用户名设置
    {CMD_PARAM_SETPWD,                  XML_PARAM_CDMAPWD,              TIMEOUT},  //CDMA密码设置
    {CMD_PARAM_PPPCONMODE,              XML_PARAM_PPPCONMODE,           TIMEOUT},  //ppp连接认证算法模式
    {CMD_PARAM_CLEAN_FILE,              XML_PARAM_CLEAN_FILE,           TIMEOUT},  //清交易流水    
    {CMD_PARAM_KEYINDEX,                XML_PARAM_KEYINDEX,             TIMEOUT},   //主密钥索引设置
    {CMD_PARAM_DESTYPE,                 XML_PARAM_DESTYPE,              TIMEOUT},   //DES算法设置
    {CMD_PARAM_KEYVALUE,                XML_PARAM_KEYVALUE,             TIMEOUT},   //主密钥值设置
    {CMD_PARAM_PINPAD,                  XML_PARAM_PINPAD,               TIMEOUT},   //密码键盘设置
    {CMD_DATEDISP_TRANSTOTAL,           XML_PARAM_DISPTOTAL,            TIME_NOLIMIT},   //显示交易汇总
    {CMD_SELECT_AUTHMODE,               XML_SELECT_AUTHMODE,            TIMEOUT},   //授权模式
	{CMD_SELECT_UARTMODE,               XML_SELECT_UARTMODE,            TIMEOUT},   //串口模式
    {CMD_GET_AUTHUNIT,                  XML_GET_AUTHUNIT,               TIMEOUT},   //授权机构代码
    {CMD_OPER_QUE,                      XML_QUE_OPER,                   TIMEOUT},   //授权机构代码
    {CMD_GET_PROJECTCODE,               XML_GETDATA_PROJECT_ID,         TIMEOUT},  //输入项目ID
    {CMD_GET_INSTALMENT_NUM,            XML_GETDATA_INSTNUM,            TIMEOUT},  //输入分期数
    {CMD_GET_INSTALMENT_MODE,           XML_GETDATA_INSTMODE,           TIMEOUT}, 
	{CMD_SELECT_BONUSTYPE,				XML_BONUSTYPE,					TIME_NOLIMIT},	//积分类型
    {CMD_GET_ORIGTERMID,                XML_GETDATA_ORIG_TERMID,        TIMEOUT}, //采集原交易终端号  
    {CMD_GET_PHONENO,           		XML_GET_PHONENO,           		TIMEOUT}, //采集手机号
	{CMD_GET_RESCODE,					XML_GET_RESCODE,				TIMEOUT},	//采集预约码
	{CMD_GET_CVN,                       XML_GETDATA_CVN2,               TIMEOUT}, //卡片CVN2
    {CMD_GET_IDENTITYCARD,              XML_GETDATA_IDENTITY_CARD,      TIMEOUT},//身份证后六位
    {CMD_GET_CARDHOLDER_NAME,           XML_GETDATA_CARDHOLDER_NAME,    TIMEOUT},//持卡人姓名
	{CMD_DATEDISP_DEPOSITCONFIRM,       XML_DEPOSITCONFIRM,             TIMEOUT},//身份ID确认界面
	{CMD_DATEDISP_DEPOSIT_AMTCONFIRM,   XML_DEPOSIT_AMTCONFIRM,         TIMEOUT}, //充值金额确认
	{CMD_DATEDISP_DEPOSIT_AMTADJUST,    XML_DEPOSIT_AMTADJUST,          TIMEOUT}, //调整充值金额
	{CMD_GET_SIGNATURE,                 XML_SIGN,                       NO_TIMEOUT},
	{CMD_SIGN_TIME,                     XML_SIGN,						NO_TIMEOUT},
	{CMD_PARAM_PARTAIL_ACCEPT,          XML_PARTAIL_ACCEPT,             TIME_NOLIMIT},//部分承兑
	{CMD_NO_PAY_AMT,                    XML_NO_PAY_AMT,                 TIMEOUT},  //未付金额
	{CMD_PROMPT_UP_SIGN,                XML_PROMPT_UP_SIGN,             TIMEOUT},//正在上送电子签名
	{CMD_PROMPT_TRANS_PRO,              XML_PROMPT_TRANS_PRO,           NO_TIMEOUT}, //交易处理中
	{CMD_BTN_ISSUPPORT,                 XML_BTN_ISSUPPORT,              TIMEOUT},//是否支持（按钮风格）
	//电子签名
    {CMD_SIGNRESULT,                    XML_SIGN_RESULT,                TIMEOUT},//显示电子签名结果
    //闪卡
    {CMD_PARAM_CURTORNTIMEROUT,         XML_PARAM_CURTORNTIMEROUT, TIMEOUT},//设置当前闪卡超时时间
    {CMD_PARAM_WHOLETORNTIMEROUT,       XML_PARAM_WHOLETORNTIMEROUT, TIMEOUT},//设置完全闪卡超时时间
    {CMD_PARAM_TORNTRANSNUM,            XML_PARAM_TORNTRANSNUM, TIMEOUT},         //设置闪卡记录笔数  
    {CMD_PARAM_KEYIMPORT_SELECT,        XML_KEYIMPORT_SELECT, TIMEOUT},         //密钥密文导入设置
    {CMD_PROMPT_READ_CARD_AMT_EX,       XML_GETCARD_AMT_EX,                NO_TIMEOUT},//刷卡带金额提示界面
    {CMD_GET_PIN_EX,                    XML_GETPIN_EX,                     NO_TIMEOUT},//输PIN界面
    {CMD_DATADISP_QUEAMT_EX,            XML_PROMPT_QUEAMT_EX,              DISP_TIMEOUT},//显示查询金额界面
	{CMD_DATEDISP_IDLEEX,               XML_PROMPT_IDLE_EX,                NO_TIMEOUT},
    {CMD_GET_PLAINPIN,                  XML_PLAINPIN_EX,                   TIMEOUT},//输PIN界面
    //{CMD_SET_LANGUGE,                   XML_SET_LANGUGE,                    TIMEOUT},//语言设置
};

static ST_TRADE_TYPE sgst_TradeType[]=
{
	FILL(TRANS_NO_SELECT),
	FILL(TRANS_SALE),
	FILL(TRANS_SALE_REV),
	FILL(TRANS_AUTH),
	FILL(TRANS_AUTH_REV),
	FILL(TRANS_AUTHCM),
	FILL(TRANS_AUTHCM_REV),
	FILL(TRANS_AUTH_VOID),
	FILL(TRANS_AUTH_VOID_REV),
	FILL(TRANS_AUTHCM_VOID),
	FILL(TRANS_AUTHCM_VOID_REV),
	FILL(TRANS_AUTHCM_ADV),
	FILL(TRANS_SALE_VOID),
	FILL(TRANS_SALE_VOID_REV),
	FILL(TRANS_REFUND),
	FILL(TRANS_QUE),
	FILL(TRANS_OFFCM),
	FILL(TRANS_ADJUST),
	FILL(TRANS_TIP),
	FILL(TRANS_EC_CLSSSALE),
	FILL(TRANS_EC_CONTACTSALE),
	FILL(TRANS_EC_SALE),
	FILL(TRANS_EC_SALE_REV),
	FILL(TRANS_EC_REFUND),
	FILL(TRANS_IC_OFF_SEND),
	FILL(TRANS_IC_SCR_SEND),
	FILL(END_FINANCE_TRANS),
	FILL(TRANS_LOGON),
	FILL(TRANS_LOGOFF),
	FILL(TRANS_BONUS_LOGON),
	FILL(TRANS_SETT),
	FILL(TRANS_BATCH_UP),
	FILL(TRANS_BATCHUP_END),
	FILL(TRANS_IC_MON_CA),
	FILL(TRANS_IC_DOWN_CA),
	FILL(TRANS_IC_DOWNCA_END),
	FILL(TRANS_IC_MON_PARA),
	FILL(TRANS_IC_DOWN_PARA),
	FILL(TRANS_IC_DOWNPA_END),
	FILL(TRANS_SEND_PARA),
	FILL(TRANS_DOWN_PARA),
	FILL(TRANS_TMS_DOWN_PARA),
	FILL(TRANS_TMS_PARA_END),
	FILL(TRANS_DOWN_BLACK),
	FILL(TRANS_DOWNBLK_END),
	FILL(TRANS_TEST),
	FILL(TRANS_SIG_SEND),
	FILL(TRANS_IC_OFF_BAT),
	FILL(TRANS_IC_TC_BAT),
	FILL(TRANS_IC_FAIL_BAT),
	FILL(TRANS_OFFCM_BAT),
	FILL(TRANS_ADJUST_BAT),
	FILL(TRANS_TIP_BAT),
	FILL(TRANS_REFUND_BAT),
	FILL(TRANS_BONUS_REFUND_BAT),
	FILL(TRANS_EC_REFUND_BAT),
	FILL(TRANS_AUTHCM_ADV_BAT),
	FILL(END_ONLINE_TRANS),
	FILL(ADMIN_EC_QUE),
	FILL(ADMIN_IC_DETAIL),
	FILL(ADMIN_LOAD_DETAIL_ONE),
	FILL(ADMIN_LOAD_DETAIL_ALL),
	FILL(ADMIN_QPBOC_QUE),
	FILL(ADMIN_OPER_LOGON),
	FILL(ADMIN_MAN_CHGPWD),
	FILL(ADMIN_MAN_LOGOFF),
	FILL(ADMIN_OPER_CHGPWD),
	FILL(ADMIN_OPER_ADD),
	FILL(ADMIN_OPER_DEL),
	FILL(ADMIN_OPER_DISP),
	FILL(ADMIN_QUE_TOTAL),
	FILL(ADMIN_QUE_DETAIL),
	FILL(ADMIN_QUE_ANY),
	FILL(ADMIN_QUE_IC_LAST),
	FILL(ADMIN_PRT_LAST),
	FILL(ADMIN_PRT_ANY),
	FILL(ADMIN_PRT_DETAIL),
	FILL(ADMIN_PRT_TOTAL),
	FILL(ADMIN_PRT_LAST_TOTAL),
	FILL(ADMIN_PRT_TERM_INFO),
	FILL(ADMIN_LOCK_TERM),
	FILL(ADMIN_SETUP_EXTNUM),
	FILL(ADMIN_DISP_VERSION),
	FILL(ADMIN_IC_SYN_READER),
	FILL(ADMIN_IC_DISP_AID),
	FILL(END_OFF_MAN_TRANS),
	FILL(FUNC_REPRINT_LAST),
	FILL(FUNC_REPRINT_ANYONE),
	FILL(FUNC_REPRINT_DETAIL),
	FILL(FUNC_REPRINT_TOTAL),
	FILL(FUNC_LOCK_TERMINAL),
	FILL(FUNC_GET_VERSION),
	FILL(FUNC_REPRINT_PARAM),
	FILL(MANAGER_PWD_CHANGE),
	FILL(MANAGER_OPER_ADD),
	FILL(MANAGER_OPER_QUE),
	FILL(MANAGER_OPER_DEL),
	FILL(MANAGER_LOGINOFF),
	FILL(MANAGER_PARAMSET),
	FILL(PARAMSET_TERM),
	FILL(PARAMSET_COMM_MODEM),
	FILL(PARAMSET_COMM_RS232),
	FILL(PARAMSET_COMM_GPRS),
	FILL(PARAMSET_COMM_CDMA),
	FILL(PARAMSET_COMM_LAN),
	FILL(PARAMSET_TRADTION_TRANS_SWITCH),
	FILL(PARAMSET_EC_TRANS_SWITCH),
	FILL(PARAMSET_INSTALMENT_TRANS_SWITCH),
	FILL(PARAMSET_BONUS_TRANS_SWITCH),
	FILL(PARAMSET_MOBILE_TRANS_SWITCH),
	FILL(PARAMSET_RES_TRANS_SWITCH),
	FILL(PARAMSET_BOOKING_TRANS_SWITCH),
	FILL(PARAMSET_OTHER_TRANS_SWITCH),
	FILL(PARAMSET_TRANS_IS_PWD),
	FILL(PARAMSET_VOID_TRANS_IS_SWIPCARD),
	FILL(PARAMSET_SETT_TRANS),
	FILL(PARAMSET_OFFLINE_TRANS),
	FILL(PARAMSET_OTHER_SWITCH),
	FILL(PARAMSET_SYS_TRANS),
	FILL(PARAMSET_SYS_RF),
	FILL(PARAMSET_SYS_ELCSIGN),
	FILL(PARAMSET_KEY_INDEX),
	FILL(PARAMSET_KEY_VALUE),
	FILL(PARAMSET_KEY_DES_TYPE),
	FILL(PARAMSET_KEY_PINPAD),
	FILL(PARAMSET_PWD),
	FILL(PARAMSET_OTHER),
	FILL(PARAMSET_IS_PBOC),
	FILL(PARAMSET_IS_CLSS),
	FILL(PARAMSET_IS_QUE),
	FILL(PARAMSET_IS_AUTH),
	FILL(PARAMSET_IS_AUTHVOID),
	FILL(PARAMSET_IS_AUTHCM),
	FILL(PARAMSET_IS_AUTHCM_VOID),
	FILL(PARAMSET_IS_AUTHCM_ADV),
	FILL(PARAMSET_IS_SALE_VOID),
	FILL(PARAMSET_IS_REFUND),
	FILL(PARAMSET_DOWNLOAD_MASTERKEY),
	FILL(PARAMSET_DOWNLOAD_SZCUP_MASTERKEY),
	FILL(PARAMSET_DOWNLOAD_GZCUP_MASTERKEY),
	FILL(PARAMSET_DOWNLOAD_UMS_MASTERKEY),
	FILL(END_ALL_TRANS),
};

ST_BANKNAME *GetBankNameConfigData(char* pszBankID)
{
    int i;
    
    for(i = 0; i < sizeof(s_arstBankList) / sizeof(ST_BANKNAME); i++)
	{
	    if( memcmp(pszBankID, s_arstBankList[i].szBankID, 4)==0 )
	    {
	        return &s_arstBankList[i];    
	    }
	}
    return NULL;
}

/******************************************************************************************************************
原型: ST_TRANSCONFIG *GetTransConfigData(uint uiTransType)
功能: 获取交易属性配置参数
入参: uiTransType   --交易类型
出参: 无
返回: 交易属性配置结构指针 
备注:
******************************************************************************************************************/
ST_TRANSCONFIG *GetTransConfigData(uint uiTransType)
{
    int i;
    
    for(i = 0; i < sizeof(stTransConfig) / sizeof(ST_TRANSCONFIG); i++)
    {
        if(stTransConfig[i].uiTransType == uiTransType)
        {
            return &stTransConfig[i];
        }
    }
  
	return NULL;
}

/******************************************************************************************************************
原型: ST_PACKETCONFIG *GetPacketConfigData(uint uiTransType)
功能: 获取组包属性配置参数
入参: uiTransType   --交易类型
出参: 无
返回: 组包属性配置结构指针 
备注:
******************************************************************************************************************/
ST_PACKETCONFIG *GetPacketConfigData(uint uiTransType)
{
	int i;
	
    for(i = 0; i < sizeof(stPacketConfig) / sizeof(ST_PACKETCONFIG); i++)
    {
        if(uiTransType == stPacketConfig[i].uiTransType)
        {
            return &stPacketConfig[i];
        }
    }
    return NULL;
}

/******************************************************************************************************************
原型: ST_PRINTCONFIG *GetPrintConfigData(uint uiTransType)
功能: 获取交易属性配置参数
入参: uiTransType   --交易类型
出参: 无
返回: 交易属性配置结构指针 
备注:
******************************************************************************************************************/
ST_PRINTCONFIG *GetPrintConfigData(uint uiTransType)
{
    int i;
    
    for(i = 0; i < sizeof(stPrintConfig) / sizeof(ST_PRINTCONFIG); i++)
    {
        if(stPrintConfig[i].uiTransType == uiTransType)
        {
            return &stPrintConfig[i];
        }
    }
  
	return NULL;
}

/******************************************************************************************************************
原型: ST_UI_PAGE *GetUiPage(int iCmd)
功能: 获取页面配置参数
入参: iCmd   --页面CMD
出参: 无
返回: 页面配置结构指针 
备注: 
******************************************************************************************************************/
ST_UI_PAGE *GetUiPage(int iCmd)
{
	int i = 0;
	
    for(i = 0; i < sizeof(stUiPage) / sizeof(ST_UI_PAGE); i++)
    {
        if(iCmd == stUiPage[i].iCmd)
        {
            return &stUiPage[i];
        }
    }
    return NULL;
}

/******************************************************************************************************************
原型: ST_UI_PAGE *GetUiMenu(int iCmd)
功能: 获取菜单配置参数
入参: iCmd   --页面CMD
出参: 无
返回: 页面配置结构指针 
备注: 

******************************************************************************************************************/
ST_UI_PAGE *GetUiMenu(int iCmd)
{
	int i = 0;

	for(i = 0; i < sizeof(stUiMenu) / sizeof(ST_UI_PAGE); i++)
	{
		if(iCmd == stUiMenu[i].iCmd)
		{
			return &stUiMenu[i];
		}
	}
	return NULL;
}

/****************************************************************************
* 函数名  : AdkC_GetPrintTransType
* 功能描述: 获取交易类型(打印交易明细时用)
            S	消费
            T	分期付款交易
            B	积分消费
            E	电子现金（钱包）消费
            R	退货
            P	预授权完成（请求）
            C	预授权完成（通知）
            L	离线结算
            Q	圈存类、充值类交易
* 入参    : uiTransType --交易类型
* 出参    : cTransType --打印明细的交易类型
* 返回值  : 
* 说明    : 
****************************************************************************/
int AdkC_GetPrintTransType(uint uiTransType, char *cTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(0 == strlen(pstPrintCfg->iPrintType))
        {
            return FALSE;
        }
        strcpy(cTransType, pstPrintCfg->iPrintType);
        return  TRUE;
    }

    return FALSE;
}
#if 0
int AdkC_GetPrintTransType(ST_TRANSLOG *pstTransLog, char *cTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    if(pstTransLog->ucEmvResult == ADK_EMV_OFFLINE_APPROVED)
    {
        *cTransType = 'E';
        return  TRUE;
    }
    else
    {
        pstPrintCfg = GetPrintConfigData(uiTransType);
        if(pstPrintCfg)
        {
            if(0 == strlen(pstPrintCfg->iPrintType))
            {
                return FALSE;
            }
            strcpy(cTransType, pstPrintCfg->iPrintType);
            return  TRUE;
        }
    }
    return FALSE;
}
#endif
/*******************************************************************************************
 * 函数名:AdkC_GetPrintIccInfo
 * 功能描述:根据交易类型判断打印凭条是否在备注栏打印IC卡信息
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:TRUE
 *******************************************************************************************/
int AdkC_GetPrintIccInfoflag(unsigned int uiTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(FALSE == pstPrintCfg->iPrintIccInfo)
        {
            return FALSE;
        }
        return  TRUE;
    }
    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetPrintTransIfHideCardNo
 * 功能描述:根据交易类型判断打印凭条时是否隐藏卡号
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
int AdkC_GetPrintHideCardNoFlag(unsigned int uiTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(FALSE == pstPrintCfg->iHideCardNo)
        {
            return FALSE;
        }
        return  TRUE;
    }
    return TRUE;
}

/****************************************************************************
* 函数名  : AdkC_GetPrintTransName
* 功能描述: 根据交易类型获取打印的交易名称
* 入参    : uiTransType  --交易类型
* 出参    : *pszOut      --获取到的打印交易名称
* 返回值  : 无
* 说明    : 
****************************************************************************/
int AdkC_GetPrintTransName(unsigned int uiTransType, char *pszOut)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
       sprintf(pszOut, "%s", pstPrintCfg->szChnName);
       return TRUE;
    }
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetTransName ERR");
    return FALSE;
}

/****************************************************************************
* 函数名  : AdkC_GetBankName
* 功能描述: 通过银行ID获取银行名称
* 入参    : pszBankID --银行ID
* 出参    : pszBankName --银行名称
* 返回值  : 无
* 说明    : 
****************************************************************************/
void AdkC_GetBankName(char *pszBankID, char *pszBankName)
{
    int iRet = 0;
    char szTemp[128] = {0};
    ST_BANKNAME *pBankInfo;
        
    iRet = AdkParam_Get(PTAG_MERCH_MERCHCODE, szTemp);
    if(iRet == ADK_SUCC)
    {
        if(memcmp(szTemp, pszBankID, 4) == 0)
        {
            sprintf((char *)pszBankName, "商业银行");
            return;
        }
    }

    BaseUtil_TrimSpcStr((uchar *)pszBankID,' ');
    sprintf((char *)pszBankName, "%s", pszBankID);

    pBankInfo = GetBankNameConfigData(pszBankID);
    if(NULL == pBankInfo)
    {
       return;    
    }
    
    iRet = AdkParam_Get(PTAG_MERCH_AREACODE, szTemp);
    if(iRet == ADK_SUCC)
    {
        if(memcmp(szTemp, "0000", 4) == 0 || memcmp(szTemp, &pszBankID[4], 2) == 0)
        {
            sprintf((char *)pszBankName, "%s", pBankInfo->szName1);
        }
        else
        {
            sprintf((char *)pszBankName, "%s", pBankInfo->szName2);
        }
    }
    else
    {
        sprintf((char *)pszBankName, "%s", pBankInfo->szName2);
    }
 
    return;
}

/*******************************************************************************************
 * 函数名:AdkC_GetTransFunc
 * 功能描述:根据交易类型获取对应交易电子签名55域数据实现的函数指针
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:NULL  成功:功能函数指针
 *******************************************************************************************/
PREPARE_FUNC AdkC_GetPrepareSign55Func(unsigned int uiTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(NULL == pstPrintCfg->func)
        {
            return NULL;
        }
        
        return  pstPrintCfg->func;
    }
    return NULL;
}


/*******************************************************************************************
 * 函数名:AdkC_GetTransIfJoinErrDetail
 * 功能描述:根据交易类型判断是否加入打印明细
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
int AdkC_GetTransIfJoinErrDetail(unsigned int uiTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(FALSE == pstPrintCfg->iJoinPrintErrdetail)
        {
            return FALSE;
        }
        return  TRUE;
    }
    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetTransIfJoinDetail
 * 功能描述:根据交易类型判断是否加入打印明细
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
int AdkC_GetTransJoinDetailFlag(unsigned int uiTransType)
{
    ST_PRINTCONFIG *pstPrintCfg = NULL;

    pstPrintCfg = GetPrintConfigData(uiTransType);
    if(pstPrintCfg)
    {
        if(FALSE == pstPrintCfg->iJoinPrintdetail)
        {
            return FALSE;
        }
        return  TRUE;
    }
    return FALSE;
}

/****************************************************************************
* 函数名  : AdkC_GetTransTitle
* 功能描述: 根据交易类型获取界面标题
* 入参    : uiTransType       --交易类型
* 出参    : *pszTitle          --获取到的标题
* 返回值  : 无
* 说明    : 
****************************************************************************/
int AdkC_GetTransTitle(uint uiTransType,char *pszTitle)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        if(0 == strlen(pstTransCfg->szChnName))
        {
            return FALSE;
        }
        strcpy(pszTitle, pstTransCfg->szChnName);
        return  TRUE;
    }
    return FALSE;
}

/****************************************************************************
* 函数名  : AdkC_GetTransReadMode
* 功能描述: 根据交易类型获取卡受理方式
* 入参    : uiTransType       --交易类型
* 出参    : *pszTitle          --获取到的标题
* 返回值  : 无
* 说明    : 
****************************************************************************/
int AdkC_GetTransReadMode(uint uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        if(FALSE == pstTransCfg->iReadMode)
        {
            return FALSE;
        }
        return  pstTransCfg->iReadMode;
    }
    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetTransRev55Tag
 * 功能描述:获取对应交易的冲正的55域tag表指针
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
DE55EmvTag* AdkC_GetTransRev55Tag(unsigned int uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        if(NULL == pstTransCfg->pstRevList)
        {
            return NULL;
        }
        
        return  pstTransCfg->pstRevList;
    }
    return NULL;
}

/*******************************************************************************************
 * 函数名:AdkC_GetTrans55Tag
 * 功能描述:获取对应交易的55域tag表指针
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
DE55EmvTag* AdkC_GetTrans55Tag(unsigned int uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        if(NULL == pstTransCfg->pstList)
        {
            return NULL;
        }
        
        return  pstTransCfg->pstList;
    }
    return NULL;
}


/*******************************************************************************************
 * 函数名:AdkC_GetTransFunc
 * 功能描述:获取对应交易实现函数指针
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
TRANS_FUNC AdkC_GetTransFunc(unsigned int uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        if(NULL == pstTransCfg->func)
        {
            return NULL;
        }
        
        return  pstTransCfg->func;
    }
    return NULL;
}

/*******************************************************************************************
 * 函数名:AdkC_GetBatTransType
 * 功能描述:获取对应交易的冲正交易类型
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
int AdkC_GetBatTransType(unsigned int uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        if(FALSE == pstTransCfg->uiBatTransType)
        {
            return FALSE;
        }
        
        return  pstTransCfg->uiBatTransType;
    }
    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetRevTransType
 * 功能描述:获取对应交易的冲正交易类型
 * 入参: usTransType     --当前交易类型
 * 出参: 无
 * 返回值: 失败:FALSE  成功:冲正交易类型
 *******************************************************************************************/
int AdkC_GetRevTransType(unsigned int uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        if(FALSE == pstTransCfg->uiRevTransType)
        {
            return FALSE;
        }
        
        return  pstTransCfg->uiRevTransType;
    }
    return FALSE;
}

/*******************************************************************************************
 * 函数名:_GetTradeType
 * 功能描述:交易类型由字符串转枚举
 * 入参: pszIndication     --当前交易类型
 * 出参: 无
 * 返回值:  成功 交易类型的枚举值 失败 APP_ERR_INVAILD_PARA
 *******************************************************************************************/
int _GetTradeType(char *pszIndication)
{
	int i;

	for (i = 0; i < (sizeof(sgst_TradeType)/sizeof(ST_TRADE_TYPE)); i++)
	{
		if (strncmp(sgst_TradeType[i].szTradeMsg,pszIndication,
			strlen(sgst_TradeType[i].szTradeMsg)) == 0
			&& strlen(sgst_TradeType[i].szTradeMsg) == strlen(pszIndication))
		{
			return sgst_TradeType[i].eTradeType;
		}
	}

	return	APP_ERR_INVAILD_PARA;
}

/*******************************************************************************************
 * 函数名:AdkC_GetOriTransType
 * 功能描述:获取对应交易的原交易类型
 * 入参: usTransType     --当前交易类型
 * 出参: puiOriTransType --原交易类型组合
         iNum            --原交易类型格式
 * 返回值:  TRUE 成功    FALSE 失败
 *******************************************************************************************/
int AdkC_GetOriTransType(unsigned int uiTransType, unsigned int *puiOriTransType,int *iNum)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;
    char sTempBuf[40+1],szTransTypeBuf[20],*p;
    int num = 0,ioff = 0, i= 0,ilen = 0;

    num = 0;
    memset(sTempBuf,0x00,sizeof(sTempBuf));
    
    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {   
        if(strlen(pstTransCfg->uiOrgTransType) == 0)
        {
            return FALSE;
        }

        strcpy(sTempBuf, pstTransCfg->uiOrgTransType);
        //判断是否含有多个交易
        do
        {
            p = strchr(sTempBuf + ioff, '|');
            if(p)
            {
                ilen = p - sTempBuf-ioff;
                
                memset(szTransTypeBuf,0x00,sizeof(szTransTypeBuf));
                memcpy(szTransTypeBuf, sTempBuf + ioff, ilen);
             
                puiOriTransType[i] = _GetTradeType(szTransTypeBuf);
                i++;
                num++;
                ioff = ilen + 1;
            }
            else
            {
                memset(szTransTypeBuf,0x00,sizeof(szTransTypeBuf));
                strcpy(szTransTypeBuf, sTempBuf + ioff);
              
                puiOriTransType[i] = _GetTradeType(szTransTypeBuf);
                num++;
                break;
            }
        }while(1);
        *iNum = num;
        
        return TRUE;
    }

    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetTransName
 * 功能描述:获取芯片卡交易中交易类型(TAG 9C)
 * 入参: usTransType   --当前交易类型
 * 出参: pszOut        --交易名称
 * 返回值: TRUE 成功    FALSE 失败
 *******************************************************************************************/
int AdkC_GetTransName(unsigned int uiTransType, char *pszOut)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
       sprintf(pszOut, "%s", pstTransCfg->szChnName);
       return TRUE;
    }
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetTransName ERR");
    return FALSE;
}

/*******************************************************************************************
 * 函数名:AdkC_GetICCTransType
 * 功能描述:获取芯片卡交易中交易类型(TAG 9C)
 * 入参: usTransType   --当前交易类型
 * 出参: 无
 * 返回值: ucTransType	  --交易类型
 *******************************************************************************************/
uchar AdkC_GetICCTransType(unsigned int uiTransType)
{
    uchar ucType = 0x00;
    ST_TRANSCONFIG *pstTransCfg = NULL;

    pstTransCfg = GetTransConfigData(uiTransType);
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType pstTransCfg = %d", pstTransCfg);
    if(pstTransCfg)
    {
        BaseUtil_Asc2Bcd((uchar *)pstTransCfg->szProcCode, 2, (uchar *)&ucType);
    }
    ADKC_LOG(LOG_FILE, PDK_TLOG, "AdkC_GetICCTransType ucTransType = %d", ucType);
    return ucType;
}

/*************************************************************************************************** 
原型: int AdkC_IsNeedReversal(uint uiTransType)
功能: 根据交易类型确认交易是否需要冲正
入参: uiTransType --交易类型
出参: 无
返回: 1--需要冲正
      0--不需要冲正
备注: 新增交易类型时，需修改添加交易类型判断
***************************************************************************************************/
int AdkC_IsNeedReversal(uint uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    ADKC_LOG(LOG_FILE, PDK_ELOG, "AdkC_IsNeedReversal transType = %d", uiTransType);
    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        return pstTransCfg->iReversal;
    }
    return FALSE;
}

/*************************************************************************************************** 
原型: int AdkC_IsNeedScriptSend(uint uiTransType)
功能: 根据交易类型确认交易是否需要脚本上送
入参: uiTransType --交易类型
出参: 无
返回: 1--需要脚本上送
      0--不需要脚本上送
备注: 新增交易类型时，需修改添加交易类型判断
***************************************************************************************************/
int AdkC_IsNeedScriptSend(uint uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    ADKC_LOG(LOG_FILE, PDK_ELOG, "AdkC_IsNeedScriptSend transType = %d", uiTransType);
    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        return pstTransCfg->iScriptSend;
    }
    return FALSE;
}

/*************************************************************************************************** 
原型: int AdkC_IsNeedReversalSend(uint uiTransType)
功能: 根据交易类型确认交易是否需要冲正上送
入参: uiTransType --交易类型
出参: 无
返回: 1--需要冲正上送
      0--不需要冲正上送
备注: 新增交易类型时，需修改添加交易类型判断
***************************************************************************************************/
int AdkC_IsNeedReversalSend(uint uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    ADKC_LOG(LOG_FILE, PDK_ELOG, "AdkC_IsNeedReversalSend transType = %d", uiTransType);
    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        return pstTransCfg->iReversalSend;
    }
    return FALSE;
}


/*************************************************************************************************** 
原型: int AdkC_IsNeedOfflineSend(uint uiTransType)
功能: 根据交易类型确认交易是否需要脱机上送
入参: uiTransType --交易类型
出参: 无
返回: 1--需要脱机上送
      0--不需要脱机上送
备注: 新增交易类型时，需修改添加交易类型判断
***************************************************************************************************/
int AdkC_IsNeedOfflineSend(uint uiTransType)
{
    ST_TRANSCONFIG *pstTransCfg = NULL;

    ADKC_LOG(LOG_FILE, PDK_ELOG, "AdkC_IsNeedOfflineSend transType = %d", uiTransType);
    pstTransCfg = GetTransConfigData(uiTransType);
    if(pstTransCfg)
    {
        return pstTransCfg->iOfflineSend;
    }
    return FALSE;
}

