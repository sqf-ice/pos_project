/*------------------------------------------------------------
* FileName: sup58m1BTPrinter.h
* Author: Kevin Liu
* Date: 2015-07-07
------------------------------------------------------------*/

#ifndef SUP58M1BTPRINTER_H
#define SUP58M1BTPRINTER_H

#include <prolin_bt.h>
#include <global.h>

enum{CONNECT_NO, CONNECT_OK};

//bluetooth printer connect flag

uchar ucBTConnectFlag;


/****************************************************************************
 Function:		BTPrn_Open
 Param In:
				name, visible
 Param Out:

 Return Code:   prolin_bt return code
 Description:	open pos bluetooth according to name and visible
****************************************************************************/
int BTPrn_Open(const char *name, int visible);

/****************************************************************************
 Function:		BTPrn_Scan
 Param In:

 Param Out:
				scanResult, scanCount
 Return Code:   prolin_bt return code
 Description:	scan bluetooth device, return scanResult and scanCount
****************************************************************************/
int BTPrn_Scan(ST_BT_SCAN_RESULT *scanResult, int *scanCount);

/****************************************************************************
 Function:		BTPrn_Pair
 Param In:
				Auth, Mitm, btName, passwd
 Param Out:

 Return Code:   prolin_bt return code
 Description:	pair and connect bluetooth device
****************************************************************************/
int BTPrn_Pair(BT_PAIR_AUTH Auth, int Mitm, const char *btName, const char *passwd);

/****************************************************************************
 Function:		BTPrn_AutoConnect
 Param In:

 Param Out:

 Return Code:   prolin_bt return code
 Description:	if paired successful before, call this function can auto connect last device
****************************************************************************/
int BTPrn_AutoConnect();

/****************************************************************************
 Function:		BTPrn_InitSendRecv
 Param In:

 Param Out:

 Return Code:   0 - success, other error
 Description:	must call this function before send and receive
****************************************************************************/
int BTPrn_InitSendRecv();

/****************************************************************************
 Function:		BTPrn_Send
 Param In:
				data, len
 Param Out:

 Return Code:   0 - success, other error
 Description:	send msg to connected bluetooth device
****************************************************************************/
int BTPrn_Send(const void *data, int len);

/****************************************************************************
 Function:		BTPrn_Recv
 Param In:

 Param Out:
				RecvBuf, RecvLen, TimeoutMs
 Return Code:   0 - success, other error
 Description:	receive msg from connected bluetooth device
****************************************************************************/
int BTPrn_Recv(void *RecvBuf, int RecvLen, int TimeoutMs);

/****************************************************************************
 Function:		BTPrn_Close
 Param In:

 Param Out:

 Return Code:
 Description:	close BT
****************************************************************************/
void BTPrn_Close();

void BTPrn_ReconnectOp();

#endif
