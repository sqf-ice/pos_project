/*
 ============================================================================
 Name        : Autowrap.h
 Author      : PAX
 Version     : 
 Copyright   : PAX Computer Technology(Shenzhen) CO., LTD
 Description : PAX POS Shared Library
 ============================================================================
 */
 
 
#ifndef SHARED_LIBRARY_H_Autowrap
#define SHARED_LIBRARY_H_Autowrap

#ifdef __cplusplus
extern "C"
{
#endif

typedef int (*CALCWIDTH)(const char *str, int len);
typedef void (*OUTPUT)(const char *str);
void AutoWrap(const char *str, int lineWidth, CALCWIDTH calc_func, OUTPUT output_func);

#ifdef __cplusplus
};
#endif

#endif /* SHARED_LIBRARY_H_Autowrap */

