
#include "global.h"

/********************** Internal macros declaration ************************/
/********************** Internal structure declaration *********************/
/********************** Internal functions declaration *********************/
enum{
//    PRN_SIZE_SMALL  = 12,
//	PRN_SIZE_NORMAL = 15,
//	PRN_SIZE_LARGE  = 20,

//	    PRN_SIZE_SMALL  = 12,
//		PRN_SIZE_NORMAL = 15,
//		PRN_SIZE_LARGE  = 20,
//		PRN_SIZE_LARGE_2  = 24,


	    PRN_SIZE_SMALL  = 9,
		PRN_SIZE_NORMAL = 12,
		PRN_SIZE_LARGE  = 15,
		PRN_SIZE_LARGE_2  = 20,

};
static char bOpenPrinter = FALSE;
static char sg_recvBuff[512];
static char sg_SMS_Buffer[2048] = {0};

extern int WlPortOpen(const char *Attr);
extern int WlPortRecv(void *RecvBuf, int RecvLen, int TimeoutMs);
extern void WlPortReset();
extern int WlPortSend(const void *SendBuf, int SendLen);

//added by Kevin for bluetooth printer

static unsigned char *curBuf = NULL;
static int printTime = 0;
static int totalLen = 0;
static unsigned char cBuf[20480] = {0};
static char curLineStr[49] = {'\0'};
static int curLineLen = 32;
static unsigned char prevSize = PRN_SIZE_NORMAL;
int PrnInit()
{
    if(!bOpenPrinter)
    {
#ifndef TEST_SMS
        if(!ChkHardware(HWCFG_PRINTER, 0))
        {
            int ret = OsPrnOpen(PRN_REAL, NULL);
            if(ret != RET_OK)
                return ret;
        }
#endif
        bOpenPrinter = TRUE;
    }
    OsPrnReset();

    FtFontStyle(1,0);
    FtFontAlign(FT_ALIGN_LEFT);
    PrnSetNormal();
    FtFontDoubleSize(0, 1);
    return RET_OK;
}

static int PrnFootLogo_BT(void);
static int PrnFootLogo(void);
static int PrnFootLogoFail(void);
static int  PrintReceipt_FreeFmat(uchar ucPrnFlag);
static int  PrintReceipt_SMS(uchar ucPrnFlag);
static int  PrintReceipt_T(uchar ucPrnFlag);
static int  PrintReceipt_BT(uchar ucPrnFlag);
static int  PrnCurAcqTransList_T(void);
static int PrnCurAcqTransList_BT(void);

int PrnCurAcqTransList_T__Details(void);
int PrnCurAcqTransList_BT_Details(void);

static void PrnHead(uchar ucFreeFmat);
static int  PrnCustomLogo_T(void);
static int  PrnCustomLogo_Pen(void);
static int  PrnCustomLogo_BT(void);
static void PrnHead_T(void);
static void PrnHead_TREP(void);
static void PrnHead_BT(void);
static void PrnAmount(const uchar *pszIndent, uchar ucNeedSepLine);
static void PrnDccAmount(void);
static void PrnDescriptor(void);
static void PrnAdditionalPrompt(void);
static void PrnStatement(void);
static void PrnTotalInfo(const void *pstInfo);
void PrnTotalInfo_Details(const void *pstInfo);
void PrnGrandTotalInfo_Details(void) ;
static int  PrnParaAcq(uchar ucAcqIndex);
static void PrnParaIssuer(uchar ucAcqIndex);
static void PrnParaIssuerSub(uchar ucIssuerKey);
static void PrnIssuerOption(const uchar *psOption);
static void PrnCardTable(uchar ucIssuerKey);
static int  PrnInstalmentPara(void);
static int  PrnEmvPara(void);
static void PrnHexString(const char *pszTitle, const uchar *psHexStr, int iLen, uchar bNewLine);
static int  DispPrnError(int iErrCode);
static void  PrnDccDisclaimer(void);
static int BT_Ft_CreateSendBuf(uchar *printBuf, int type);
static int BT_Ft_Print();

/********************** Internal variables declaration *********************/
/********************** external reference declaration *********************/

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/

// For thermal, small={8x16,16x16}
// Modified by Kim_LinHB 2014-6-8
void PrnSetSmall(void)
{
	FtFontSize(PRN_SIZE_SMALL);
}

// For thermal,  normal = {12x24,24x24}
// For sprocket, normal = {6x8,16x16}
void PrnSetNormal(void)
{
    FtFontSize(PRN_SIZE_NORMAL);
}

// For thermal, normal=big={12x24,24x24}
// For sprocket, big={8x16,16x16}
void PrnSetBig(void)
{
    FtFontSize(PRN_SIZE_LARGE);
}

int PrintReceipt_failPrint_T(uchar ucPrnFlag)
{
	uchar	ucNum;
	uchar   szTotalAmt[12+1];
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1], szOrgTranName[16+1];
	uchar 	szText[32], szDccInfo[8+1], szDccValue[1024];
	int iCnt = 0;


	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	for(ucNum=0; ucNum<1; ucNum++)
	{
		PrnInit();

		PrnCustomLogo_T();
		PrnStep(5);
		PrnHead_T();

		// Issuer Name
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-10.10s", szIssuerName);
		//linzhao
		if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
		{
			if( ChkIssuerOption(ISSUER_MASK_EXPIRY) )
			{
				MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
			}
			else
			{
				//only customer copy have the exipry, others must mask.linzhao
				if (1==ucNum)
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %2.2s/%2.2s\n", (char *)_T("EXP."), &glProcInfo.stTranLog.szExpDate[2],
							   glProcInfo.stTranLog.szExpDate);
				}
				else
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
				}
			}
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "\n");
		}

		// PAN(CARD NUMBER)
		if (ChkIfTransMaskPan(ucNum))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
		}
		else
		{
			strcpy((char *)szBuff, (char *)glProcInfo.stTranLog.szPan);
		}

		if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
		{
			sprintf(szBuf1, "%s (S)", szBuff);
		}
		else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
		{
			sprintf(szBuf1, "%s (C)", szBuff);
		}
		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
				 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
		{
			sprintf(szBuf1, "%s (F)", szBuff);
		}
		else
		{
			sprintf(szBuf1, "%s (M)", szBuff);
		}
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-23.23s\n", szBuf1);

		//linzhao
		if (0!=glProcInfo.stTranLog.szHolderName[0])
		{
			uchar *pFindDoubleSpace = NULL;
			pFindDoubleSpace = strstr(glProcInfo.stTranLog.szHolderName, "  ");
			if (NULL!=pFindDoubleSpace)
			{
				glProcInfo.stTranLog.szHolderName[pFindDoubleSpace-glProcInfo.stTranLog.szHolderName] = 0;
			}
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", (char *)_T("HOLDER"));
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.26s\n", glProcInfo.stTranLog.szHolderName);

		}
		PrnStep(15);
		//linzhao 20150917
		// AID, Application label
//		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) {
//			PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
//			PubTrimTailChars(szBuff, 'F');
//			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-32.32s", (char *)_T("AID: "), szBuff);
//			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);
//		}

		// Transaction type, Expiry date




		// Batch, Invoice
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%06lu",   _T("BATCH: "),   glCurAcq.ulCurBatchNo);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%06lu\n", _T("RECEIPT #: "), glProcInfo.stTranLog.ulInvoiceNo);

		// Date, Time
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-*.*s", _T("DATE: "), strlen(szBuff)-5, strlen(szBuff)-5, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.5s\n",  _T("TIME: "), szBuff+strlen(szBuff)-5);

		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "TRANSACTION FAILED\n" );
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "COMMS ERROR -CERS\n" );

		//print host error reason. linzhao 20160112
	    int     iCnt;
	    char    szHostMsg[64];

	    for(iCnt=0; glHostErrMsg[iCnt].szRspCode[0]!=0; iCnt++)
	    {
	        if( memcmp(glProcInfo.stTranLog.szRspCode, glHostErrMsg[iCnt].szRspCode, 2)==0 )
	        {
	            break;
	        }
	    }
	    sprintf(szHostMsg, "HOST DECLINE:%s", _T(glHostErrMsg[iCnt].szMsg));
	    sprintf(szHostMsg + strlen(szHostMsg), "  %.2s\n\n", glProcInfo.stTranLog.szRspCode);
	    OsLog(LOG_ERROR, "%s--%d, %s", __FILE__, __LINE__, szHostMsg);//linzhao
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, szHostMsg );

		// RRN, AUTH NO
//		if(OFF_SALE == glProcInfo.stTranLog.ucTranType)
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s",    _T("Approved Offline"));
//		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s%-13.13s", _T("RRN: "), glProcInfo.stTranLog.szRRN);
//		}
//        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%6.6s\n",  _T("AUTH NO: "), glProcInfo.stTranLog.szAuthCode);


        /*=======BEGIN: Jason 2015.01.07  16:41 modify===========*/
//        if  ( strlen(glProcInfo.stTranLog.szECRRRN) != 0 )
//        {
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "ECR REF. NO: %s\n", glProcInfo.stTranLog.szECRRRN);
//        }
//        /*====================== END======================== */
//        if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
//        {
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPLUS TXN ID:");
//            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szTI+1);
//        }

        PrnStep(PRN_SIZE_NORMAL);
		PrnDescriptor();

		// Amount
		//FALSE -> TRUE, linzhao
//		PrnAmount((uchar *)"", TRUE);

		// DCC Transaction
//		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
//		{
//		    uchar szRate[10];
//		    GetDccRate(glProcInfo.stTranLog.stDccInfo.szDccExRate, szRate);
//
//            PrnStep(15);
//            //change the style of exchange print. linzhao
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: 1 %s = %s %s\n", _T("Exchange Rate*"),
//            				 glProcInfo.stTranLog.stTranCurrency.szName, szRate, glProcInfo.stTranLog.stHolderCurrency.szName);
//            //MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s: %s%%\n", _T("Commission"), glProcInfo.stTranLog.stDccInfo.szCommission);
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s%%\n", _T("Mark-Up on Exchange Rate INCL"), glProcInfo.stTranLog.stDccInfo.szDccMarginRate);
//            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s%s%s\n", _T("(Transaction Currency:"), glProcInfo.stTranLog.stHolderCurrency.szName, ")");
//
//            PrnStep(5);
//            PrnDccAmountX((uchar *)"");
            //move it into PrnAmountWithX(), linzhao
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "[ X ]");
//            App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
//            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

            //linzhao
//            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I accept that I have been offered a choice of currencies");
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "for payment & that this choice is final.");

            //linzhao, 从ENV文件里面提取定制信息
//            for (iCnt=0; iCnt<6; iCnt++)
//            {
//            	sprintf(szDccInfo, "DCINF_%d", iCnt);
//            	if (0==GetEnv(szDccInfo, szText))
//            	{
//            		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T(szText));;
//            	}
//            }
//            PrnStep(15);
//            if(0 == strcmp(szIssuerName, "VISA"))
//            {
//            	//linzhao
////                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "Dynamic Currency Conversion is conducted by the");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " Merchant and is not associated with or endorsed by Visa. ");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I ACCEPT THAT I HAVE BEEN OFFERED");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "A CHOICE OF CURRENCIES FOR PAYMENT");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "& THAT THIS CHOICE IS FINAL.");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DYNAMIC CURRENCY CONVERSION IS");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONDUCTED BY THE MERCHANT AND IS NOT");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "ASSOCIATED WITH OR ENDORSED BY VISA.");
//            }
//            else if(0 == strcmp(szIssuerName, "MASTER"))
//            {
//            	//linzhao
////                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I understand that MasterCard has a currency conversion");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " process and that I have chosen not to use the");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " MasterCard currency conversion process and I will");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "have no recourse against MasterCard with respect to ");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "any matter related to the currency conversion or");
////				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "disclosure thereof.");
//
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I'VE BEEN GIVEN A CHOICE TO PAY IN CURR");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DIFFERS FROM MY LOCAL CURR,I ACCEPT THIS");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CHOICE , I'VE CHOSEN NOT TO USE THE MC");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CURR CONVERSION PROCESS AND I'LL HAVE NO");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "RECOURSE AGAINST MC CONCERNING THE CURR");
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONVERSION OR ITS DISCLOSURE.");
//            }
//            PrnStep(15);
////    		if (0!=strcmp(glSysParam.stEdcInfo.szHelpTelNo, "000000000000000000000000"))
////    		{
////    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s     %s\n",
////    							glSysParam.stEdcInfo.szHelpTelNo, glSysParam.stEdcInfo.szPabx);
////    		}
////    		else
////    		{
////    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s", glSysParam.stEdcInfo.szPabx);
////
////    		}
//		}
//        PrnStep(15);
//
//		PrnAdditionalPrompt();
//
//		// approve online/offline
//		if (glProcInfo.stTranLog.uiStatus == TS_OK)
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED ONLINE"));
//		}
//		else if (glProcInfo.stTranLog.uiStatus & TS_OFFLINE_SEND)
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED ONLINE"));
//		}
//		else if (glProcInfo.stTranLog.uiStatus & TS_NOSEND)
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED OFFLINE"));
//		}
//		else
//		{
//			FtPrn();
//		}
//		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT)
//		{
//			// offline PIN
//			if (glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN)
//			{
//				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("OFFLINE PIN ENTERED"));
//			}
//			else
//			{
//				FtPrn();
//			}
//
//			// TC, linzhao
//			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
//			{
//				PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff);
//				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%.16s\n", _T("TC: "), szBuff);
//			}
//
//#ifdef ENABLE_EMV
////#ifdef APP_DEBUG
//			//EMP need to delete TVR. linzhao 20150618
////            PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff);
////            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TSI: %s\n", szBuff);
////            PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff);
////            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TVR: %s\n", szBuff);
////#endif
//#endif
//		}
//
//		PrnStatement();
//
//        PrnStep(15);
//
//		// DCC Transaction
//		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
//		{
//			//linzhao
//			if (0==ucNum)
//			{
//			// Card Holder Name
//				//MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n\n\n\n\n",  _T("Card Holder Name"));
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL - 2, "\n\n\n%s%s\n\n",
//						   "X:----------------------------------------\n",
//						   _T("I AGREE TO PAY ABOVE TOTAL AMOUNT"));
//			}
//		}
//		else if(ucNum == 0)
//		{
//			// Holder name
//			if(VOID != glProcInfo.stTranLog.ucTranType && SALE_COMP != glProcInfo.stTranLog.ucTranType &&
//			   VOID_AUTH != glProcInfo.stTranLog.ucTranType)
//			{
//				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-26.26s\n", glProcInfo.stTranLog.szHolderName);
//			}
//			else if(OFF_SALE == glProcInfo.stTranLog.ucTranType || TS_NOSEND == glProcInfo.stTranLog.uiStatus)
//			{
//				MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "\n\n\n\n");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n%s\n%s\n",
//						_T("I AGREE TO PAY ABOVE TOTAL AMOUNT"),
//						_T("ACCORDING TO CARD ISSUER AGREEMENT"),
//						_T("MERCHANT AGREEMENT IF CREDIT VOUCHER"));
//			}
////			else
////			{
////				PrnStep(20);
////			}
//			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n", (char *)_T("CARDHOLDER SIGNATURE"));
//			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "--------------------------------------\n");
//			// MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL-5, "%s\n", _T("I ACKNOWLEDGE SATISFACTORY RECEIPT\nOF RELATIVE  GOODS/SERVICE"));
//		}
//
//		//EMPlus
//		if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
//		{
//		    uchar szTemp[300+1];
//		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPlus\n");
//		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");
//
//		    if(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints[0])
//            {
//		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints+1, 5, szBuff);
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("REWARDED POINTS"));
//                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
//            }
//
//		    if(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints[0])
//		    {
//		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints+1, 5, szBuff);
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS BALANCE"));
//                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
//                PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount+1, 6, szBuf1);
//                App_ConvAmountTran(szBuf1, szBuff, 0);
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("EQUIVALENT AMOUNT"));
//                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
//            }
//
//		    if(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints[0])
//		    {
//		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints+1, 5, szBuff);
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS UNDER PROCESS"));
//                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
//            }
//
//		    if(glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0])
//            {
//                strcpy(szTemp, glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1);
//                uchar *p = szTemp;
//                int len = strlen(szTemp);
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");
//                while(p < szTemp + len){
//                    if(0x5E == *p){
//                        *p = '\n';
//                    }
//                    ++p;
//                }
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n\n", szTemp);
//            }
//
//		    if(glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer[0])
//		    {
//		        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "CURRENT OFFER\n");
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");
//                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer+1);
//		    }
//		}
//
		PrnStep(20);
		//PrnFootLogoFail();
		if( ucPrnFlag==PRN_REPRINT )
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "* %s *\n", _T("REPRINT"));
		}
//
//		PrnSetNormal();
//		if (0!=GetEnv("FTLOGO", szText))
//		{
//			strcpy(szText, "");
//		}
//		if( ucNum==0 )
//		{
//			//linzhao
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("MERCHANT COPY"));
////			if (glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
////			{
////				PrnStep(15);
////			}
////			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
//
//		}
//		else if( ucNum==1 )
//		{
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("CUSTOMER COPY"));
//			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
//			{
//				PrnStep(15);
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
//			}
//		}
//		else if( ucNum==2 )
//		{
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("BANK COPY"));
//			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
//			{
//				PrnStep(15);
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
//			}
//		}
//
//		//MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n\n\n");
//
//		PrnStep(15);
//		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "EMPay Transaction\n");
//		PrnStep(15);
//		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** THANK YOU **\n");
//		PrnStep(15);

		if (ChkIfTrainMode())
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "***** %s *****\n", _T("DEMO"));
		}
		else
		{
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
//		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** %s **\n", (char *)_T("FOR EMV TEST ONLY"));
#endif
#endif
		}
#ifndef TEST_SMS
		if(!ChkHardware(HWCFG_PRINTER, 0))
		    MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
		StartPrinter();

		if( ucNum==0 && NumOfReceipt() != 1)
		{
            kbflush();

			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
		}
	}

	return 0;
}

int PrintReceipt(uchar ucPrnFlag)
{
	uchar	szBuff[100];
	uchar	szIssuerName[10+1], szAmount[16];
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	if( !ChkIssuerOption(ISSUER_EN_PRINT) )
	{
		return 0;
	}

	if (ChkIfIrDAPrinter())
	{
		SetOffBase(OffBaseDisplay);
		ChkOnBase();
	}

	//D200 the dcc amount below 20USD, user can choose BT printer or SMS.linzhao add begin. 20150825
	App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szAmount, 0);
	if(ChkTerm(_TERMINAL_D200_) && DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption &&
	    ( atof(szAmount + 4) < 20) && (atof(szAmount + 4) > 0))
	{
	    int iRet;
	    int iSelected;
	    GUI_MENU stMenu;
	    GUI_MENUITEM stMenuItem[] = {
	        { _T_NOOP("Bluetooth Printer"), 1,TRUE,  NULL},	//kevintest
	        { _T_NOOP("SMS"), 2,TRUE,  NULL},
	        { _T_NOOP("EMAIL"), 3,FALSE,  NULL},
	        { "", -1,FALSE,  NULL},
	    };

	    if(ChkHardware(HWCFG_BLTH, HW_NONE))
	    {
	        stMenuItem[0].bVisible = FALSE;
	    }

	    if (ChkHardware(HWCFG_GPRS, HW_NONE) && ChkHardware(HWCFG_CDMA, HW_NONE))
	    {
	        stMenuItem[1].bVisible = FALSE;
	    }

	    if (ChkHardware(HWCFG_GPRS, HW_NONE) &&
	         ChkHardware(HWCFG_CDMA, HW_NONE) &&
	         ChkHardware(HWCFG_WIFI, HW_NONE))
	    {
	        stMenuItem[2].bVisible = FALSE;
	    }

	    if(!stMenuItem[0].bVisible && !stMenuItem[1].bVisible && !stMenuItem[2].bVisible)
	        return 0;

	    Gui_BindMenu(NULL, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stMenuItem, &stMenu);
	    iSelected = 0;
	    while( 1 )
	    {
	    	OsLog(LOG_ERROR, "%s--%d, enter while", __FILE__, __LINE__);//linzhao
	        Gui_ClearScr();

	        iRet = Gui_ShowMenuList(&stMenu, 0, USER_OPER_TIMEOUT, &iSelected);
	        if(iRet != GUI_OK)
	        {
	            break;
	        }

	    	OsLog(LOG_ERROR, "%s--%d, selected:%d", __FILE__, __LINE__, iSelected);//linzhao
	        switch(iSelected)
	        {
	            case 1:
//	                iRet = SetBtPrinter();	//modified by Kevin 20150720
	                if(iRet == GUI_OK)
	                {
	                	glSysParam.stEdcInfo.ucPrinterType = PRNMODE_BTPRNTER;
	                	SaveSysParam();
	                }
	                break;
	            case 2:
	                iRet = SetSMS(&glCurAcq);	//modified by Kevin 20150720
	                if(iRet == GUI_OK)
					{
	                	glSysParam.stEdcInfo.ucPrinterType = PRNMODE_SMS;
						SaveSysParam();
					}
	                break;
	            case 3:
	                // SetEmail(smtpServer,port,username,password);
	                break;
	        }
	        if (1!=iSelected || 2!=iSelected)
	        {
	        	break;
	        }
	    }

	}
	//linzhao add end. 20150825
#ifndef TEST_SMS
	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_SMS))
#endif
    {
	    //TODO if()  acquirer printer type
	    // for now, just SMS
	    int iRet;
	    uchar   szBuff[30] = {0};
	    GUI_INPUTBOX_ATTR stInputAttr;

	    memset(&stInputAttr, 0, sizeof(stInputAttr));
	    stInputAttr.eType = GUI_INPUT_MIX;
	    stInputAttr.bEchoMode = 1;
	    stInputAttr.nMinLen = 1;
	    stInputAttr.nMaxLen = 25;

	    Gui_ClearScr();
	    iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("PHONE NO"), gl_stLeftAttr,
	        szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
	    if(iRet != GUI_OK)
	        return 0;
	    if(memcmp(szBuff, "00", 2) && memcmp(szBuff, "+", 1))
	    {
	        uchar   szCountryCallingCode[120];
	        GetEnv("TELCODE", szCountryCallingCode);
	        sprintf(glProcInfo.stTranLog.szLastCustomerPhoneNo, "%s%s", szCountryCallingCode, szBuff);
	    }
	    else
	        strcpy(glProcInfo.stTranLog.szLastCustomerPhoneNo, szBuff);
	    DispSend();
        return PrintReceipt_SMS(ucPrnFlag);
    }

	DispPrinting();
	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		return PrintReceipt_BT(ucPrnFlag);
	}

	DispPrinting();
	if( ChkIfThermalPrinter() )
	{
		return PrintReceipt_T(ucPrnFlag);
	}
	
	if( ChkEdcOption(EDC_FREE_PRINT) )	// Free format print
	{
		return PrintReceipt_FreeFmat(ucPrnFlag);
	}

	PrnInit();
	PrnSetNormal();

	PrnStep(30);
	PrnHead(FALSE);

	ConvIssuerName(glCurIssuer.szName, szIssuerName);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szIssuerName); // issuer Name

	// 	memcpy(szBuff, glProcInfo.stTranLog.szPan, sizeof(glProcInfo.stTranLog.szPan));
	if (ChkIfTransMaskPan(1))
	{
		//////MaskPan(glProcInfo.stTranLog.szPan, szBuff);
		MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
	}
	else
	{
		strcpy(szBuff, glProcInfo.stTranLog.szPan);
	}

	if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
	{
	    strcat(szBuff, " S\n");
	}
	else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
	    strcat(szBuff, " C\n");
	}
	else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
	{
	    strcat(szBuff, " F\n");
	}
	else
	{
	    strcat(szBuff, " M\n");
	}
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szHolderName);

	// print txn name & expiry
	if( glProcInfo.stTranLog.ucTranType==VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType || (glProcInfo.stTranLog.uiStatus & TS_VOID) )
	{		
		sprintf((char *)szBuff, "%s(%s)", _T("VOID"), _T(glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel));
	}
	else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
	{
		sprintf((char *)szBuff, "%s(%s)", _T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), _T("ADJ"));
	}
	else
	{
		sprintf((char *)szBuff, "%s", _T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel));
	}
	if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, " %-16.16s", szBuff);
		if( ChkIssuerOption(ISSUER_MASK_EXPIRY) )
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "**/**\n");
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%2.2s/%2.2s\n", &glProcInfo.stTranLog.szExpDate[2],
					glProcInfo.stTranLog.szExpDate);
		}
	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, " %s\n", szBuff);
	}

	// Batch NO & invoice #
	PrnStep(6);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%06ld", glCurAcq.ulCurBatchNo);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%06ld\n", glProcInfo.stTranLog.ulInvoiceNo);

	Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);  //DATE/TIME
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%22s\n", szBuff);

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%12s", glProcInfo.stTranLog.szRRN);
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%06s\n", glProcInfo.stTranLog.szAuthCode);

    PrnStep(2);
	if( glProcInfo.stTranLog.ucInstalment!=0 )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s:%02d\n", _T("NO. OF INSTALMENT"), glProcInfo.stTranLog.ucInstalment);
	}
	
    /*=======BEGIN: Jason 2015.01.07  16:41 modify===========*/

    if  ( strlen(glProcInfo.stTranLog.szECRRRN) != 0 )
    {
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "ECR REF. NO: %s\n", glProcInfo.stTranLog.szECRRRN);
    }
    /*====================== END======================== */
	
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
        if (strlen(glProcInfo.stTranLog.szAppPreferName)!=0)
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %.16s\n", _T("APP"), glProcInfo.stTranLog.szAppPreferName);
        } 
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %.16s\n", _T("APP"), glProcInfo.stTranLog.szAppLabel);
        }
		PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
		PubTrimTailChars(szBuff, 'F');
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %s\n", _T("AID"), szBuff);
		PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s : %s\n", _T("TC"), szBuff);
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
// 		PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff);
// 		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %s\n", _T("TSI"), szBuff);
// 		PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff);
// 		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %s\n", _T("TVR"), szBuff);
#endif
#endif
		if( glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN )
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s\n", _T("PIN VERIFIED"));
		}
		else
		{
		    FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
		}
	}

	PrnDescriptor();

	// amount
	PrnAmount((uchar *)"   ", TRUE);

	PrnAdditionalPrompt();

	PrnStatement();

	FtFontAlign(FT_ALIGN_CENTER);
	if( ucPrnFlag==PRN_REPRINT )
	{
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", _T("REPRINT"));
	}
	if (ChkIfTrainMode())
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "**** %s ****\n", _T("DEMO"));
	}
	else
	{
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", _T("FOR EMV TEST ONLY"));
#endif
#endif
	}

#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif

	StartPrinter();
	return 0;
}

int PrnAllList_PreAuth(void)
{
	int		iRet;
	uchar	ucIndex;
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	SetCurrTitle(_T("PRINT AUTH LOG")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	// for print control
	glProcInfo.bPrnAllAcq = FALSE;
	iRet = SelectAcq(FALSE, GetCurrTitle(), &ucIndex);
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}

	if( ucIndex!=ACQ_ALL )
	{
//		SetCurAcq(ucIndex);  // ALEX ADD
		// for print control
		glProcInfo.bPrnAllAcq = FALSE;
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
//		PrnCurAcqTransList();
		PrnCurAcqTransListPreAuth();
		return ERR_NO_DISP;
	}
	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

	// print all acquier
	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
	{
		SetCurAcq(ucIndex);
//		PrnCurAcqTransList();
		PrnCurAcqTransListPreAuth();
	}

	// for print control
	glProcInfo.bPrnAllAcq = FALSE;
	return 0;
}

// 打印明细
// Print the list of all transaction
int PrnAllList(void)
{
	int		iRet;
	uchar	ucIndex;
	//====Stop Printer============
//	   if ( MirroringCheckEcr())
//    	    {
//		      	   	   	   return  0 ;
//		     }
	 //===========================
	SetCurrTitle(_T("PRINT LOG")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	// for print control
	glProcInfo.bPrnAllAcq = FALSE;

	iRet = SelectAcq(TRUE, GetCurrTitle(), &ucIndex);

	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}



	if (glProcInfo.bPrnAllAcq)
	{
		// print all acquier
		for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
		{
			SetCurAcq(ucIndex);
			PrnCurAcqTransList();
		}

		glProcInfo.bPrnAllAcq = FALSE;
		return 0;
	}



	//=========================================

   //===================================

	if( ucIndex!=ACQ_ALL )
	{
//		SetCurAcq(ucIndex);  // ALEX ADD
		// for print control
		glProcInfo.bPrnAllAcq = FALSE;
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
		PrnCurAcqTransList();
		return ERR_NO_DISP;
	}
	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

	// print all acquier
//	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
//	{
//		SetCurAcq(ucIndex);
//		PrnCurAcqTransList();
//	}

	// for print control
	glProcInfo.bPrnAllAcq = FALSE;
	return 0;
}

// 打印明细
// Print the list of all transaction
int PrnAllList_Details(void)
{
	int		iRet;
	uchar	ucIndex;
	//====Stop Printer============
//	   if ( MirroringCheckEcr())
//    	    {
//		      	   	   	   return  0 ;
//		     }
	 //===========================
	SetCurrTitle(_T("PRINT LOG")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	// for print control
//	glProcInfo.bPrnAllAcq = FALSE;
//
//	 iRet = SelectAcq_Details(TRUE, GetCurrTitle(), &ucIndex);

	PrnCurAcqTransList_Details();


//	if( iRet!=0 )
//	{
//		return ERR_NO_DISP;
//	}



//	if (glProcInfo.bPrnAllAcq)
//	{
//		// print all acquier
//		for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
//		{
//			SetCurAcq(ucIndex);
//			PrnCurAcqTransList_Details();
//		}
//
//		glProcInfo.bPrnAllAcq = FALSE;
//		return 0;
//	}



	//=========================================

   //===================================

//	if( ucIndex!=ACQ_ALL )
//	{
////		SetCurAcq(ucIndex);  // ALEX ADD
//		// for print control
//		glProcInfo.bPrnAllAcq = FALSE;
//		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
//		PrnCurAcqTransList_Details() ;////TRUE
//		return ERR_NO_DISP;
//	}
//	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

	// print all acquier
//	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
//	{
//		SetCurAcq(ucIndex);
//		PrnCurAcqTransList();
//	}

	// for print control
//	glProcInfo.bPrnAllAcq = FALSE;
	return 0;
}



//linzhao 20160104
int PrnCurAcqTransListPreAuth(void)
{
	int		iCnt, iNumOfOnePage, iPageNum, iMaxNumOfOnePage;
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szDateTime[14+1], szTranName[16+1];

	SetCurrTitle(_T("PRINT PREAUTH LOG"));
	glProcInfo.stTranLog.ucTranType = MAX_TRANTYPE;//in order to not show transaction type in the CuiAcqTransList. linzhao 20151029
	if( GetTranLogNumOfPreAuth(glCurAcq.ucKey) <= 0 )
	{
	    OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);
		PubBeepErr();
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return 1;
	}

	DispPrinting();
	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
//		return PrnCurAcqTransList_BT();
	}
	if( ChkIfThermalPrinter() )
	{
		return PrnCurAcqTransListPreauth_T();
	}

	PrnInit();

	PrnSetNormal();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T("TRANSACTION LIST"));

	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s", _T("HOST NII"), glCurAcq.szNii);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.10s\n", glCurAcq.szPrgName);
#ifdef ENABLE_DCC
	uchar szDcc[120];
	if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
	{
	    if(0 ==GetEnv("DCC_NII", szDcc))
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
	}
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }

	PrnStep(15);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n\n", glCurAcq.szTermID, glCurAcq.szMerchantID);

	iMaxNumOfOnePage = ChkEdcOption(EDC_TIP_PROCESS) ? 4 : 6;
	iNumOfOnePage = 0;
	iPageNum = 1;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		FindIssuer(glProcInfo.stTranLog.ucIssuerKey);  //Alex add
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.10s\n", _T("ISSUER"), szIssuerName);

		if( ChkIfDispMaskPan2() )
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), szBuff);
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), glProcInfo.stTranLog.szPan);
		}

		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", _T(szTranName));
		}
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%21.21s", szBuff);
	    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%06lu\n", glProcInfo.stTranLog.ulInvoiceNo);
		PrnAmount((uchar *)"", FALSE);
		FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");

		iNumOfOnePage++;
		if( (iPageNum==1 && iNumOfOnePage==3) ||
			(iPageNum!=1 && iNumOfOnePage==iMaxNumOfOnePage) )
		{
#ifndef TEST_SMS
		    if(!ChkHardware(HWCFG_PRINTER, 0))
		        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
			if( StartPrinter()!=0 )
			{
				return 1;
			}

			iNumOfOnePage = 0;
			iPageNum++;

			PrnInit();
			PrnStep(20);
		}
	}
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF LIST"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	return StartPrinter();
}


// print list of transaction of current acquirer
int PrnCurAcqTransList(void)
{
	int		iCnt, iNumOfOnePage, iPageNum, iMaxNumOfOnePage;
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szDateTime[14+1], szTranName[16+1];
	uchar   szMessageBatch[50];
	//====Stop Printer============
	 //  if ( MirroringCheckEcr())
    	//    {
		   	   	   	  // 	   return  0 ;
		 //   }
	 //===========================
	SetCurrTitle(_T("PRINT LOG"));
	glProcInfo.stTranLog.ucTranType = MAX_TRANTYPE;//in order to not show transaction type in the CuiAcqTransList. linzhao 20151029
	if( GetTranLogNum(glCurAcq.ucKey)/*-GetTranLogNumOfPreAuth(glCurAcq.ucKey)*/ <= 0 )
	{
		PubBeepErr();
		memset(szMessageBatch,0,sizeof(szMessageBatch));
		strcpy(szMessageBatch,glCurAcq.szName);
		strcat(szMessageBatch,"\n");
		strcat(szMessageBatch, _T("EMPTY BATCH"));

		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr,szMessageBatch , gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return 1;
	}

	DispPrinting();
	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		return PrnCurAcqTransList_BT();
	}
	if( ChkIfThermalPrinter() )
	{
		return PrnCurAcqTransList_T();
	}

	PrnInit();

	PrnSetNormal();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T("TRANSACTION LIST"));

	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s", _T("HOST NII"), glCurAcq.szNii);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.10s\n", glCurAcq.szPrgName);
#ifdef ENABLE_DCC
	uchar szDcc[120];
	if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
	{
	    if(0 ==GetEnv("DCC_NII", szDcc))
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
	}
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }

	PrnStep(15);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n\n", glCurAcq.szTermID, glCurAcq.szMerchantID);

	iMaxNumOfOnePage = ChkEdcOption(EDC_TIP_PROCESS) ? 4 : 6;
	iNumOfOnePage = 0;
	iPageNum = 1;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		FindIssuer(glProcInfo.stTranLog.ucIssuerKey);  //Alex add
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.10s\n", _T("ISSUER"), szIssuerName);

		if( ChkIfDispMaskPan2() )
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), szBuff);
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), glProcInfo.stTranLog.szPan);
		}

		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", _T(szTranName));
		}
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%21.21s", szBuff);
	    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%06lu\n", glProcInfo.stTranLog.ulInvoiceNo);
		PrnAmount((uchar *)"", FALSE);
		FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");

		iNumOfOnePage++;
		if( (iPageNum==1 && iNumOfOnePage==3) ||
			(iPageNum!=1 && iNumOfOnePage==iMaxNumOfOnePage) )
		{
#ifndef TEST_SMS
		    if(!ChkHardware(HWCFG_PRINTER, 0))
		        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
			if( StartPrinter()!=0 )
			{
				return 1;
			}

			iNumOfOnePage = 0;
			iPageNum++;

			PrnInit();
			PrnStep(20);
		}
	}
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF LIST"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	return StartPrinter();
}

int PrnCurAcqTransList_Details(void)
{
	int		iCnt, iNumOfOnePage, iPageNum, iMaxNumOfOnePage;
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szDateTime[14+1], szTranName[16+1];
	uchar   szMessageBatch[50];
	int ucIndex ;


	//====Stop Printer============
	 //  if ( MirroringCheckEcr())
    	//    {
		   	   	   	  // 	   return  0 ;
		 //   }


	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)

		{
				SetCurAcq(ucIndex);
		 		if (	GetTranLogNum(glCurAcq.ucKey) > 0 )
		 		{
		 			break;
		 		}

		}






	//===========================
	SetCurrTitle(_T("PRINT LOG"));
	glProcInfo.stTranLog.ucTranType = MAX_TRANTYPE;//in order to not show transaction type in the CuiAcqTransList. linzhao 20151029
	if( GetTranLogNum(glCurAcq.ucKey)/*-GetTranLogNumOfPreAuth(glCurAcq.ucKey)*/ <= 0 )
	{
		PubBeepErr();
		memset(szMessageBatch,0,sizeof(szMessageBatch));
//		strcpy(szMessageBatch,glCurAcq.szName);
//		strcat(szMessageBatch,"\n");

		strcpy(szMessageBatch, _T("EMPTY BATCH"));

		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr,szMessageBatch , gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return 1;
	}

	DispPrinting();


	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		return PrnCurAcqTransList_BT_Details();
	}
	if( ChkIfThermalPrinter() )
	{
		return PrnCurAcqTransList_T__Details();
	}
////=======================HHHHHHHHHHHHHHHHHHHHHHHHHH============================================================================
	PrnInit();

	PrnSetNormal();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T("TRANSACTION LIST"));

	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s", _T("HOST NII"), glCurAcq.szNii);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.10s\n", glCurAcq.szPrgName);
#ifdef ENABLE_DCC
	uchar szDcc[120];
	if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
	{
	    if(0 ==GetEnv("DCC_NII", szDcc))
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
	}
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }

	PrnStep(15);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n\n", glCurAcq.szTermID, glCurAcq.szMerchantID);

	iMaxNumOfOnePage = ChkEdcOption(EDC_TIP_PROCESS) ? 4 : 6;
	iNumOfOnePage = 0;
	iPageNum = 1;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		FindIssuer(glProcInfo.stTranLog.ucIssuerKey);  //Alex add
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.10s\n", _T("ISSUER"), szIssuerName);

		if( ChkIfDispMaskPan2() )
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), szBuff);
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("PAN"), glProcInfo.stTranLog.szPan);
		}

		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", _T(szTranName));
		}
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%21.21s", szBuff);
	    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%06lu\n", glProcInfo.stTranLog.ulInvoiceNo);
		PrnAmount((uchar *)"", FALSE);
		FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");

		iNumOfOnePage++;
		if( (iPageNum==1 && iNumOfOnePage==3) ||
			(iPageNum!=1 && iNumOfOnePage==iMaxNumOfOnePage) )
		{
#ifndef TEST_SMS
		    if(!ChkHardware(HWCFG_PRINTER, 0))
		        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
			if( StartPrinter()!=0 )
			{
				return 1;
			}

			iNumOfOnePage = 0;
			iPageNum++;

			PrnInit();
			PrnStep(20);
		}
	}
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF LIST"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	return StartPrinter();
}

int PrnCurAcqTransList_BT(void)
{
	int		iCnt, iNumOfOnePage;
	uchar	szDateTime[14+1];
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szTranName[16+1];

	PrnInit();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)_T("AUDIT REPORT"));


	// Merchant name, Merchant address, Help tel no, Terminal ID, Merchant ID
	PrnHead_T();


	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", (char *)_T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%d\n", glCurAcq.ulCurBatchNo);


	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	// Aquirer Name, NII
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  glCurAcq.szName);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("NII"), glCurAcq.szNii);
#ifdef ENABLE_DCC
    uchar szDcc[120];
    if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    {
        if(0 ==GetEnv("DCC_NII", szDcc))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("DCC NII"), szDcc);
    }
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("Loyalty NII"), szLoyalty);
    }
	PrnStep(15);

	////////////////////////////////////////////////////////////
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("INV# TRANS"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("AUTH"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("CARD NUMBER"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("CARD TYPE"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("DATE"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("TIME"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("INPUT TYPE"));
	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_NORMAL, "%s",   (char *)_T("DCC AMOUNT"));
	//linzhao, add for restaurant
	char szMerType[4];
	//linzhao
	if (0==GetEnv((char *)"MERTYPE", (char *)szMerType) && '0' == szMerType[0])
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (const char *)_T("TIP"));
	}
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (const char *)_T("TOTAL"));

	PrnStep(15);

	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
	iNumOfOnePage = 0;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

		if(PREAUTH == glProcInfo.stTranLog.ucTranType)
		{
			continue;
		}

		// Trace NO(Invoice), Transaction Name, AUTH NO
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("ADJ"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", (char *)_T(szTranName));
		}
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%06lu %s", glProcInfo.stTranLog.ulInvoiceNo, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szAuthCode);

		// PAN, Card Type
//		if( ChkIfDispMaskPan2() )
		if (ChkIfTransMaskPan(1))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:****", (char *)_T("EXP"));
		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", glProcInfo.stTranLog.szPan);
//		}
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);

		// Date, Time of transaction
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	    if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
        {
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "SWIPE");
        }
        else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "ICC");
        }
        else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "FALL BACK");
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "MANUAL");
        }

		PrnDccAmount();
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "-------------------------------");

		PrnStep(15);

		iNumOfOnePage++;
		if( (iNumOfOnePage%5)==0 )
		{
#ifndef TEST_SMS
			//linzhao
//		    if(!ChkHardware(HWCFG_PRINTER, 0))
//		        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			iNumOfOnePage = 0;
			PrnInit();
			PrnStep(30);
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", (char *)_T("END OF AUDIT REPORT"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	int iRet = StartPrinter();
	if(iRet != RET_OK)
	    return iRet;
	//linzhao
	CalcTotal(glCurAcq.ucKey);
	return PrnTotalAcq();
}


int PrnCurAcqTransList_BT_Details(void)
{
	int		iCnt, iNumOfOnePage;
	uchar	szDateTime[14+1];
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szTranName[16+1];

	PrnInit();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)_T("AUDIT REPORT"));


	// Merchant name, Merchant address, Help tel no, Terminal ID, Merchant ID
	PrnHead_T();


	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", (char *)_T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%d\n", glCurAcq.ulCurBatchNo);


	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	// Aquirer Name, NII
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  glCurAcq.szName);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("NII"), glCurAcq.szNii);
#ifdef ENABLE_DCC
    uchar szDcc[120];
    if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    {
        if(0 ==GetEnv("DCC_NII", szDcc))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("DCC NII"), szDcc);
    }
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", (char *)_T("Loyalty NII"), szLoyalty);
    }
	PrnStep(15);

	////////////////////////////////////////////////////////////
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("INV# TRANS"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("AUTH"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("CARD NUMBER"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("CARD TYPE"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("DATE"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("TIME"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   (char *)_T("INPUT TYPE"));
	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_NORMAL, "%s",   (char *)_T("DCC AMOUNT"));
	//linzhao, add for restaurant
	char szMerType[4];
	//linzhao
	if (0==GetEnv((char *)"MERTYPE", (char *)szMerType) && '0' == szMerType[0])
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (const char *)_T("TIP"));
	}
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", (const char *)_T("TOTAL"));

	PrnStep(15);

	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
	iNumOfOnePage = 0;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

		if(PREAUTH == glProcInfo.stTranLog.ucTranType)
		{
			continue;
		}

		// Trace NO(Invoice), Transaction Name, AUTH NO
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("ADJ"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", (char *)_T(szTranName));
		}
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%06lu %s", glProcInfo.stTranLog.ulInvoiceNo, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szAuthCode);

		// PAN, Card Type
//		if( ChkIfDispMaskPan2() )
		if (ChkIfTransMaskPan(1))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:****", (char *)_T("EXP"));
		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", glProcInfo.stTranLog.szPan);
//		}
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);

		// Date, Time of transaction
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	    if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
        {
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "SWIPE");
        }
        else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "ICC");
        }
        else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "FALL BACK");
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "MANUAL");
        }

		PrnDccAmount();
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "-------------------------------");

		PrnStep(15);

		iNumOfOnePage++;
		if( (iNumOfOnePage%5)==0 )
		{
#ifndef TEST_SMS
			//linzhao
//		    if(!ChkHardware(HWCFG_PRINTER, 0))
//		        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			iNumOfOnePage = 0;
			PrnInit();
			PrnStep(30);
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", (char *)_T("END OF AUDIT REPORT"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	int iRet = StartPrinter();
	if(iRet != RET_OK)
	    return iRet;
	//linzhao
	CalcTotal(glCurAcq.ucKey);
	return PrnTotalAcq();
}

//only for preauth
int PrnCurAcqTransListPreauth_T(void)
{
	int		iCnt, iNumOfOnePage;
	uchar	szDateTime[14+1];
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szTranName[16+1];

	OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);
	PrnInit();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", _T("PREAUTH AUDIT REPORT"));
	

	// Merchant name, Merchant address, Help tel no, Terminal ID, Merchant ID
	PrnHead_T();
	

	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", _T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%d\n", glCurAcq.ulCurBatchNo);
	

	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	// Aquirer Name, NII
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  glCurAcq.szName);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("NII"), glCurAcq.szNii);
#ifdef ENABLE_DCC
    uchar szDcc[120];
    if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    {
        if(0 ==GetEnv("DCC_NII", szDcc))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
    }
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }
	PrnStep(15);

	////////////////////////////////////////////////////////////
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INV# TRANS"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("AUTH"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("CARD NUMBER"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("CARD TYPE"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("DATE"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIME"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INPUT TYPE"));
	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_NORMAL, "%s",   _T("DCC AMOUNT"));
	//linzhao, add for restaurant
	char szMerType[4];
	//linzhao
	if (0==GetEnv((char *)"MERTYPE", (char *)szMerType) && '0' == szMerType[0])
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIP"));
	}
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TOTAL"));

	PrnStep(15);

	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
	iNumOfOnePage = 0;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
//		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
//		{
//			continue;
//		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
		LoadAuthTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);

		//linzhao 20151230
//		if(PREAUTH == glProcInfo.stTranLog.ucTranType)
//		{
//			continue;
//		}

		// Trace NO(Invoice), Transaction Name, AUTH NO
		if (0==(glProcInfo.stTranLog.uiStatus & TS_NOT_COMP))
		{
		   continue;
		}
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_NOT_COMP)
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("NOTCOMP"));
		}
//		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
//		{
//			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
//		}
//		else
//		{
//			sprintf((char *)szBuff, "%s", _T(szTranName));
//		}
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%06lu %s", glProcInfo.stTranLog.ulInvoiceNo, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szAuthCode);

		// PAN, Card Type
//		if( ChkIfDispMaskPan2() )
		if (ChkIfTransMaskPan(1))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", szBuff);
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s:****", _T("EXP"));
		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", glProcInfo.stTranLog.szPan);
//		}
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);

		// Date, Time of transaction
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	    if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
        {
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "SWIPE");
        }
        else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "ICC");
        }
        else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "FALL BACK");
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "MANUAL");
        }

		PrnDccAmount();
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "------------------------------------------------");

		PrnStep(15);

		iNumOfOnePage++;
		if( (iNumOfOnePage%5)==0 )
		{
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			iNumOfOnePage = 0;
			PrnInit();
			PrnStep(30);
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF AUDIT REPORT"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	int iRet = StartPrinter();
	if(iRet != RET_OK)
	    return iRet;
	//linzhao

	return 0;
//	CalcTotal(glCurAcq.ucKey);
//	return PrnTotalAcq();
}

int PrnCurAcqTransList_T(void)
{
	int		iCnt, iNumOfOnePage;
	uchar	szDateTime[14+1];
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szTranName[16+1];

	PrnInit();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", _T("AUDIT REPORT"));


	// Merchant name, Merchant address, Help tel no, Terminal ID, Merchant ID
	PrnHead_T();


	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", _T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%d\n", glCurAcq.ulCurBatchNo);


	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	// Aquirer Name, NII
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  glCurAcq.szName);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("NII"), glCurAcq.szNii);
#ifdef ENABLE_DCC
    uchar szDcc[120];
    if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    {
        if(0 ==GetEnv("DCC_NII", szDcc))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
    }
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
        if(0 ==GetEnv("LOY_NII", szLoyalty))
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }
	PrnStep(15);

	////////////////////////////////////////////////////////////
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INV# TRANS"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("AUTH"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("CARD NUMBER"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("CARD TYPE"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("DATE"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIME"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INPUT TYPE"));
	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_NORMAL, "%s",   _T("DCC AMOUNT"));
	//linzhao, add for restaurant
	char szMerType[4];
	//linzhao
	if (0==GetEnv((char *)"MERTYPE", (char *)szMerType) && '0' == szMerType[0])
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIP"));
	}
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TOTAL"));

	PrnStep(15);

	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
	iNumOfOnePage = 0;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		SetCurIssuer(glProcInfo.stTranLog.ucIssuerKey);//linzhao 20160331

		//linzhao 20151230
		if((PREAUTH == glProcInfo.stTranLog.ucTranType) && (glProcInfo.stTranLog.uiStatus & TS_NOT_COMP))
		{
			continue;
		}

		// Trace NO(Invoice), Transaction Name, AUTH NO
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_AUTH_SEND)
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("COMP"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", _T(szTranName));
		}
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%06lu %s", glProcInfo.stTranLog.ulInvoiceNo, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szAuthCode);

		// PAN, Card Type
//		if( ChkIfDispMaskPan2() )
		if (ChkIfTransMaskPan(1))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", szBuff);
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "    %s:****", _T("EXP"));
		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", glProcInfo.stTranLog.szPan);
//		}
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);

		// Date, Time of transaction
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	    if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
        {
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "SWIPE");
        }
        else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "ICC");
        }
        else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "FALL BACK");
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "MANUAL");
        }

		PrnDccAmount();
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "------------------------------------------------");

		PrnStep(15);

		iNumOfOnePage++;
		if( (iNumOfOnePage%5)==0 )
		{
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			iNumOfOnePage = 0;
			PrnInit();
			PrnStep(30);
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF AUDIT REPORT"));//aaaaend of report
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	int iRet = StartPrinter();
	if(iRet != RET_OK)
	    return iRet;
	//linzhao
	CalcTotal(glCurAcq.ucKey);
	return PrnTotalAcq();
}



int PrnCurAcqTransList_T__Details(void)
{
	int		iCnt, iNumOfOnePage;
	uchar	szDateTime[14+1];
	uchar	szBuff[30], szIssuerName[10+1];
	uchar   szTranName[16+1];
	uchar   blFirst=TRUE;
	PrnInit();

	PrnStep(30);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", _T("AUDIT REPORT DETAILS"));
	

	// Merchant name, Merchant address, Help tel no, Terminal ID, Merchant ID
	PrnHead_T();
	

	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", _T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%d\n", glCurAcq.ulCurBatchNo);
	

	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	// Aquirer Name, NII
//	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  glCurAcq.szName);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE,  "%.10s\n",  "EMP");
//	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("NII"), glCurAcq.szNii);
#ifdef ENABLE_DCC
    uchar szDcc[120];
    if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    {
//        if(0 ==GetEnv("DCC_NII", szDcc))
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("DCC NII"), szDcc);
    }
#endif
    uchar szLoyalty[120];
    if(0 ==GetEnv("E_LOY", szLoyalty) && '1' == szLoyalty[0])
    {
//        if(0 ==GetEnv("LOY_NII", szLoyalty))
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.3s\n", _T("Loyalty NII"), szLoyalty);
    }
	PrnStep(15);

	////////////////////////////////////////////////////////////
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INV# TRANS"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("AUTH"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("CARD NUMBER"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("CARD TYPE"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("DATE"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIME"));
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s",   _T("INPUT TYPE"));
	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_NORMAL, "%s",   _T("DCC AMOUNT"));
	//linzhao, add for restaurant
	char szMerType[4];
	//linzhao
	if (0==GetEnv((char *)"MERTYPE", (char *)szMerType) && '0' == szMerType[0])
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TIP"));
	}
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", _T("TOTAL"));

	PrnStep(15);

	OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
	iNumOfOnePage = 0;
	for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
	{
//		if( glSysCtrl.sAcqKeyList[iCnt]!=glCurAcq.ucKey )
//		{
//			continue;
//		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&glProcInfo.stTranLog, (ushort)iCnt);
		SetCurIssuer(glProcInfo.stTranLog.ucIssuerKey);//linzhao 20160331

		if (glProcInfo.stTranLog.ulInvoiceNo == 0 )
		{
			continue;
		}


		if( glSysCtrl.sAcqKeyList[iCnt]!=glProcInfo.stTranLog.ucAcqKey )
			{
				continue;
			}

		//linzhao 20151230
		if((PREAUTH == glProcInfo.stTranLog.ucTranType) && (glProcInfo.stTranLog.uiStatus & TS_NOT_COMP))
		{
			continue;
		}

		// Trace NO(Invoice), Transaction Name, AUTH NO
		if (blFirst==TRUE)
		{
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "------------------------------------------------");
		blFirst =FALSE;
		}
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("VOID"));
		}
		else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_AUTH_SEND)
		{
			sprintf((char *)szBuff, "%s(%s)", _T(szTranName), _T("COMP"));
		}
		else
		{
			sprintf((char *)szBuff, "%s", _T(szTranName));
		}
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%06lu %s", glProcInfo.stTranLog.ulInvoiceNo, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.szAuthCode);

		// PAN, Card Type
//		if( ChkIfDispMaskPan2() )
		if (ChkIfTransMaskPan(1))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n%s:****", _T("EXP"));
		}
//		else
//		{
//			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", glProcInfo.stTranLog.szPan);
//		}
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);

		// Date, Time of transaction
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-12.13s", szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.6s\n",  szBuff+14);

	    if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
        {
	        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "SWIPE");
        }
        else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "ICC");
        }
        else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "FALL BACK");
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s",  "MANUAL");
        }

		PrnDccAmount();
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "------------------------------------------------");

		PrnStep(15);
		
		iNumOfOnePage++;
		if( (iNumOfOnePage%5)==0 )
		{
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			iNumOfOnePage = 0;
			PrnInit();
			PrnStep(30);
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("END OF AUDIT REPORT DETAILS"));//aaaaend of report

#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	int iRet = StartPrinter();
	if(iRet != RET_OK)
	    return iRet;
	//linzhao


	 g_AR_BASE=0;
	 g_AR_TIPS=0;
	 g_AR_FEE=0;
	 g_AR_SALES=0;
	 g_AR_REFUND=0;
	 g_AR_VOID_SALES=0;
	 g_AR_VOID_REFUND=0;
	 g_AR_NET_TOTAL=0;
	 g_AR_NET_Total_SUM_TOTAL = 0.0 ;

	  g_AR_NET_Tip_SUM_TOTAL = 0.0 ;
	  g_AR_NET_Fee_SUM_TOTAL = 0.0 ;
	  g_AR_NET_Refund_SUM_TOTAL = 0.0 ;
	  g_AR_NET_VoidSale_SUM_TOTAL = 0.0 ;
	  g_AR_NET_VoidRefund_SUM_TOTAL = 0.0 ;


	  g_AR_NET_Base_SUM_TOTAL =0.0 ;

	   int ucIndex;
		for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
		{
			SetCurAcq(ucIndex);
			//PrnCurAcqTransList();
			//hhhHasan(       GetTranLogNum(glCurAcq.ucKey));

			if ( GetTranLogNum(glCurAcq.ucKey)<=0 )
			{
				continue ;
			}


			CalcTotal_Details(glCurAcq.ucKey);
			PrnTotalAcq_Details();
		}

		 PrnGrandTotalInfo_Details();

	//return PrnTotalAcq();



	return 0 ;
}


int PrintReceipt_FreeFmat(uchar ucPrnFlag)
{
	uchar	szBuff[50];
	uchar	szIssuerName[10+1];

	PrnInit();

    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n");
	PrnHead(TRUE);

	// issuer Name
	ConvIssuerName(glCurIssuer.szName, szIssuerName);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %-10.10s", _T("CARD TYPE"), szIssuerName);

	// Expiry date
	if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
	{
		if( ChkIssuerOption(ISSUER_MASK_EXPIRY) )
		{
		    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "**/**");
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2],
					glProcInfo.stTranLog.szExpDate);
		}
	}

	FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");

	//	PAN
	if (ChkIfTransMaskPan(1))
	{
		//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
		MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
	}
	else
	{
		strcpy(szBuff, glProcInfo.stTranLog.szPan);
	}
	if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s S\n", _T("CARD NO"), szBuff);
	}
	else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s C\n", _T("CARD NO"), szBuff);
	}
	else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s F\n", _T("CARD NO"), szBuff);
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s M\n", _T("CARD NO"), szBuff);
	}

	// Holder
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("HOLDER"), glProcInfo.stTranLog.szHolderName);

	// print txn name & expiry
	if( glProcInfo.stTranLog.ucTranType==VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType || (glProcInfo.stTranLog.uiStatus & TS_VOID) )
	{		
		sprintf((char *)szBuff, "%s(%s)", _T("VOID"), _T(glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel));
	}
	else if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
	{
		sprintf((char *)szBuff, "%s(%s)", _T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), _T("ADJ"));
	}
	else
	{
		sprintf((char *)szBuff, "%s", _T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel));
	}
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	// Batch NO & invoice #
	PrnStep(6);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %06ld", _T("BATCH NO"), glCurAcq.ulCurBatchNo);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %06ld\n", _T("REF"), glProcInfo.stTranLog.ulInvoiceNo);

	// RRN, AuthCode
    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %-12.12s", _T("RRN"), glProcInfo.stTranLog.szRRN);
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %-6.6s\n", _T("AUTH"), glProcInfo.stTranLog.szAuthCode);

	PrnStep(2);
	if( glProcInfo.stTranLog.ucInstalment!=0 )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s:%02d\n", _T("NO. OF INSTALMENT"), glProcInfo.stTranLog.ucInstalment);
	}

    /*=======BEGIN: Jason 2015.01.07  16:41 modify===========*/

    if  ( strlen(glProcInfo.stTranLog.szECRRRN) != 0 )
    {
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "ECR REF. NO: %s\n", glProcInfo.stTranLog.szECRRRN);
    }
    /*====================== END======================== */

	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
        if (strlen(glProcInfo.stTranLog.szAppPreferName)!=0)
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %.16s\n", _T("APP"), glProcInfo.stTranLog.szAppPreferName);
        } 
        else
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %.16s\n", _T("APP"), glProcInfo.stTranLog.szAppLabel);
        }
		PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
		PubTrimTailChars(szBuff, 'F');
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %s\n", _T("AID"), szBuff);
		PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s: %s\n", _T("T C"), szBuff);
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
// 		PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff);
// 		PrnStr("   TSI: %s\n", szBuff);
// 		PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff);
// 		PrnStr("   TVR: %s\n", szBuff);
#endif
#endif
		if( glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN )
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %s\n", _T("PIN VERIFIED"));
		}
		else
		{
		    FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
		}
	}

	PrnDescriptor();

	PrnAmount((uchar *)"   ", TRUE);

	PrnAdditionalPrompt();

	PrnStatement();

    FtFontAlign(FT_ALIGN_CENTER);
	if( ucPrnFlag==PRN_REPRINT )
	{
        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", _T("REPRINT"));
	}
	if (ChkIfTrainMode())
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "**** %s ****\n", _T("DEMO"));
	}

#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	StartPrinter();
	return 0;
}

static int  PrintReceipt_SMS(uchar ucPrnFlag)
{
    uchar   ucNum;
    uchar   szTotalAmt[12+1];
    uchar   szBuff[50],szBuf1[50];
    uchar   szIssuerName[10+1], szTranName[16+1], szOrgTranName[16+1];

    for(ucNum=0; ucNum<1/*NumOfReceipt()*/; ucNum++)
    {
        PrnInit();

        // Transaction type, Expiry date
        sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
        sprintf(szOrgTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
        if (glProcInfo.stTranLog.ucTranType == VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType || (glProcInfo.stTranLog.uiStatus & TS_VOID))
        {
            sprintf((char *) szBuff, "%s %s", _T(szTranName), _T(szOrgTranName));
        }
        else if (glProcInfo.stTranLog.uiStatus & TS_ADJ)
        {
            sprintf((char *) szBuff, "%s(%s)", _T(szTranName), _T("ADJ"));
        }
        else
        {
            sprintf((char *) szBuff, "%s", szTranName);
        }

        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "You have a %s Trx on your card:", szBuff);

        // PAN(CARD NUMBER)
        if (ChkIfTransMaskPan(ucNum))
        {
           // MaskPan(glProcInfo.stTranLog.szPan, szBuff);
            MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
        }
        else
        {
            strcpy((char *)szBuff, (char *)glProcInfo.stTranLog.szPan);
        }

        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s.", szBuff);

        if (!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
        {
            PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
        }
        else
        {
            memcpy(szTotalAmt, glProcInfo.stTranLog.szAmount, sizeof(szTotalAmt));
        }
        App_ConvAmountTran(szTotalAmt, szBuff, 0);

       MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, " TOTAL: %s", szBuff);

       //linzhao add begin, 20150825
       if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
       {
    	   App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
    	   MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, " Exchange: %s", szBuff);
       }

        // Date, Time
        Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, " %s%-12.13s", _T("DATE: "), szBuff);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, " %s%5.6s",  _T("TIME: "), szBuff+14);

#ifndef TEST_SMS
        if(!ChkHardware(HWCFG_PRINTER, 0))
            MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
        StartPrinter();

        if( ucNum==0 && NumOfReceipt() != 1)
        {
            kbflush();

            Gui_ClearScr();
            Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
        }
    }

    return 0;
}

int PrintReceipt_BT(uchar ucPrnFlag)
{
	uchar	ucNum;
	uchar   szTotalAmt[12+1];
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1], szOrgTranName[16+1];
	uchar 	szText[32], szDccInfo[8+1], szDccValue[1024];
	int iCnt = 0;

	for(ucNum=0; ucNum<NumOfReceipt(); ucNum++)
	{
		PrnCustomLogo_BT();
		MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, " \n");
		PrnHead_BT();

		// Issuer Name
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-10.10s\n", szIssuerName);

		// PAN(CARD NUMBER)
		if (ChkIfTransMaskPan(ucNum))
		{
			// MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
		}
		else
		{
			strcpy((char *)szBuff, (char *)glProcInfo.stTranLog.szPan);
		}

		if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
		{
			sprintf(szBuf1, "%s (S)", szBuff);
		}
		else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
		{
			sprintf(szBuf1, "%s (C)", szBuff);
		}
		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
				 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
		{
			sprintf(szBuf1, "%s (F)", szBuff);
		}
		else
		{
			sprintf(szBuf1, "%s (M)", szBuff);
		}
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-23.23s\n", szBuf1);

		if (0!=glProcInfo.stTranLog.szHolderName[0])
		{
			uchar *pFindDoubleSpace = NULL;
			pFindDoubleSpace = strstr(glProcInfo.stTranLog.szHolderName, "  ");
			if (NULL!=pFindDoubleSpace)
			{
				glProcInfo.stTranLog.szHolderName[pFindDoubleSpace-glProcInfo.stTranLog.szHolderName] = 0;
			}
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", (char *)_T("HOLDER"));
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.26s\n", glProcInfo.stTranLog.szHolderName);

		}

		// AID, Application label
		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) {
			PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
			PubTrimTailChars(szBuff, 'F');
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-32.32s", (char *)_T("AID: "), szBuff);
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);
		}

		// Transaction type, Expiry date
		sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		sprintf(szOrgTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
		if (glProcInfo.stTranLog.ucTranType == VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType || (glProcInfo.stTranLog.uiStatus & TS_VOID))
		{
			sprintf((char *) szBuff, "%s %s", (char *)_T(szTranName), (char *)_T(szOrgTranName));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_ADJ)
		{
			sprintf((char *) szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("ADJ"));
		}
		else
		{
			sprintf((char *) szBuff, "%s", szTranName);
		}
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s", szBuff);

		if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
		{
			if( ChkIssuerOption(ISSUER_MASK_EXPIRY) )
			{
				MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
			}
			else
			{
				//only customer copy have the exipry, others must mask.linzhao
				if (1==ucNum)
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %2.2s/%2.2s\n", (char *)_T("EXP."), &glProcInfo.stTranLog.szExpDate[2],
							   glProcInfo.stTranLog.szExpDate);
				}
				else
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
				}
			}
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "\n");
		}

		// Batch, Invoice
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%06lu",   (char *)_T("BATCH: "),   glCurAcq.ulCurBatchNo);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%06lu\n", (char *)_T("RECEIPT #: "), glProcInfo.stTranLog.ulInvoiceNo);

		// Date, Time
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-12.13s", (char *)_T("DATE: "), szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.6s\n",  (char *)_T("TIME: "), szBuff+14);

		// RRN, AUTH NO
		if(OFF_SALE == glProcInfo.stTranLog.ucTranType)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s",    (char *)_T("Approved Offline"));
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s%-13.13s", (char *)_T("RRN: "), glProcInfo.stTranLog.szRRN);
		}
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%6.6s\n",  (char *)_T("AUTH#: "), glProcInfo.stTranLog.szAuthCode);


        /*=======BEGIN: Jason 2015.01.07  16:41 modify===========*/
        if  ( strlen(glProcInfo.stTranLog.szECRRRN) != 0 )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "ECR REF. NO: %s\n", glProcInfo.stTranLog.szECRRRN);
        }
        /*====================== END======================== */
        if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPLUS TXN ID:");
            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szTI+1);
        }

        PrnStep(PRN_SIZE_NORMAL);
		PrnDescriptor();

		// Amount
		PrnAmount((uchar *)"", TRUE);

		// DCC Transaction
		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
		{
		    uchar szRate[10];
		    GetDccRate(glProcInfo.stTranLog.stDccInfo.szDccExRate, szRate);

            PrnStep(15);
            //change the style of exchange print. linzhao
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s: 1 %s = %s %s\n", (char *)_T("Exchange Rate*"),
            				 glProcInfo.stTranLog.stTranCurrency.szName, szRate, glProcInfo.stTranLog.stHolderCurrency.szName);
            //MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s: %s%%\n", (char *)_T("Commission"), glProcInfo.stTranLog.stDccInfo.szCommission);
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s: %s%%\n", (char *)_T("Mark-Up on Exchange Rate"), glProcInfo.stTranLog.stDccInfo.szDccMarginRate);
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s%s%s\n", (char *)_T("(Transaction Currency:"), glProcInfo.stTranLog.stHolderCurrency.szName, ")");

            PrnStep(5);
			PrnDccAmountX((uchar *)"");
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "[ X ]");
//            App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
//            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
//            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I accept that I have been offered a choice of currencies");
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "for payment & that this choice is final.");

            //linzhao, 从ENV文件里面提取定制信息
//            for (iCnt=0; iCnt<6; iCnt++)
//            {
//            	sprintf(szDccInfo, "DCINF_%d", iCnt);
//            	if (0==GetEnv(szDccInfo, szText))
//            	{
//            		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T(szText));;
//            	}
//            }
//            PrnStep(15);
            if(0 == strcmp(szIssuerName, "VISA"))
            {
            	//linzhao
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "Dynamic Currency Conversion is conducted by the");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " Merchant and is not associated with or endorsed by Visa. ");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I ACCEPT THAT I HAVE BEEN OFFERED");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "A CHOICE OF CURRENCIES FOR PAYMENT");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "& THAT THIS CHOICE IS FINAL.");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DYNAMIC CURRENCY CONVERSION IS");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONDUCTED BY THE MERCHANT AND IS NOT");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "ASSOCIATED WITH OR ENDORSED BY VISA.");
            }
            else if(0 == strcmp(szIssuerName, "MASTER"))
            {
            	//linzhao
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I understand that MasterCard has a currency conversion");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " process and that I have chosen not to use the");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " MasterCard currency conversion process and I will");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "have no recourse against MasterCard with respect to ");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "any matter related to the currency conversion or");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "disclosure thereof.");

                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I'VE BEEN GIVEN A CHOICE TO PAY IN CURR");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DIFFERS FROM MY LOCAL CURR,I ACCEPT THIS");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CHOICE , I'VE CHOSEN NOT TO USE THE MC");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CURR CONVERSION PROCESS AND I'LL HAVE NO");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "RECOURSE AGAINST MC CONCERNING THE CURR");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONVERSION OR ITS DISCLOSURE.");
            }
            PrnStep(15);
    		if (0!=strcmp(glSysParam.stEdcInfo.szHelpTelNo, "000000000000000000000000"))
    		{
    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s     %s\n",
    							glSysParam.stEdcInfo.szHelpTelNo, glSysParam.stEdcInfo.szPabx);
    		}
    		else
    		{
    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s", glSysParam.stEdcInfo.szPabx);

    		}
		}
        PrnStep(15);

		PrnAdditionalPrompt();

		// approve online/offline
		if (glProcInfo.stTranLog.uiStatus == TS_OK)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("APPROVED ONLINE"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_OFFLINE_SEND)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("APPROVED ONLINE"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_NOSEND)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("APPROVED OFFLINE"));
		}
		else
		{
			//buletooth printer
//			if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.ucPrnMode == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_OK))
//			{
//				BT_Ft_Print();
//				printTime = 0;
//			}
			FtPrn();
		}
		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT)
		{
			// offline PIN
			if (glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", (char *)_T("OFFLINE PIN ENTERED"));
			}
			else
			{
				//buletooth printer
//				if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.ucPrnMode == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_OK))
//				{
//					BT_Ft_Print();
//					printTime = 0;
//				}
				FtPrn();
			}

			// TC, linzhao
			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff);
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%.16s\n", (char *)_T("TC: "), szBuff);
			}

#ifdef ENABLE_EMV
//#ifdef APP_DEBUG
			//EMP need to delete TVR. linzhao 20150618
//            PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff);
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TSI: %s\n", szBuff);
//            PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff);
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TVR: %s\n", szBuff);
//#endif
#endif
		}

		PrnStatement();

        PrnStep(25);

		// DCC Transaction
		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
		{
			//linzhao
			if (0==ucNum)
			{
			// Card Holder Name
				//MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n\n\n\n\n",  (char *)_T("Card Holder Name"));
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");

				//foura 17.11.2016 add pen
				PrnCustomLogo_Pen();
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
				//MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n","X:-----------------------------");

				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", (char *)_T("I AGREE TO PAY ABOVE TOTAL AMOUNT"));

			}
		}
		else if(ucNum == 0)
		{
			// Holder name
			if(VOID != glProcInfo.stTranLog.ucTranType && SALE_COMP != glProcInfo.stTranLog.ucTranType &&
			   VOID_AUTH != glProcInfo.stTranLog.ucTranType)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-26.26s\n", glProcInfo.stTranLog.szHolderName);
			}
			else if(OFF_SALE == glProcInfo.stTranLog.ucTranType || TS_NOSEND == glProcInfo.stTranLog.uiStatus)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "\n\n\n\n");
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n",(char *)_T("I AGREE TO PAY ABOVE TOTAL AMOUNT"));
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n",(char *)_T("ACCORDING TO CARD ISSUER AGREEMENT"));
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n",(char *)_T("MERCHANT AGREEMENT IF CREDIT VOUCHER"));
			}
			else
			{
				PrnStep(20);
			}
			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n", (char *)_T("CARDHOLDER SIGNATURE"));
			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "--------------------------------------\n");
			// MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL-5, "%s\n", (char *)_T("I ACKNOWLEDGE SATISFACTORY RECEIPT\nOF RELATIVE  GOODS/SERVICE"));
		}

		//EMPlus
		if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
		{
		    uchar szTemp[300+1];
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPlus\n");
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "-------------------------------\n");

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints[0])
            {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("REWARDED POINTS"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints[0])
		    {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS BALANCE"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
                PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount+1, 6, szBuf1);
                App_ConvAmountTran(szBuf1, szBuff, 0);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("EQUIVALENT AMOUNT"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints[0])
		    {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS UNDER PROCESS"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0])
            {
                strcpy(szTemp, glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1);
                uchar *p = szTemp;
                int len = strlen(szTemp);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "-------------------------------\n");
                while(p < szTemp + len){
                    if(0x5E == *p){
                        *p = '\n';
                    }
                    ++p;
                }
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n\n", szTemp);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer[0])
		    {
		        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "CURRENT OFFER\n");
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "-------------------------------\n");
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer+1);
		    }
		}

		if( ucPrnFlag==PRN_REPRINT )
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "* %s *\n", (char *)_T("REPRINT"));
		}

		PrnSetNormal();
		if (0!=GetEnv("FTLOGO", szText))
		{
			strcpy(szText, "");
		}
		if( ucNum==0 )
		{
			//linzhao
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", (char *)_T("MERCHANT COPY"));
			if (glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
			{
				PrnStep(15);
			}
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);

		}
		else if( ucNum==1 )
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", (char *)_T("CUSTOMER COPY"));
			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
			}
		}
		else if( ucNum==2 )
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", (char *)_T("BANK COPY"));
			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
			}
		}

		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", (char *)_T(" "));

		//MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n\n\n");
		PrnFootLogo_BT();

		if (ChkIfTrainMode())
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "***** %s *****\n", (char *)_T("DEMO"));
		}
		else
		{
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** %s **\n", (char *)_T("FOR EMV TEST ONLY"));
#endif
#endif
		}
#ifndef TEST_SMS
		if(!ChkHardware(HWCFG_PRINTER, 0))
		    MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
		StartPrinter();

		if( ucNum==0 && NumOfReceipt() != 1)
		{
            kbflush();

			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
		}
	}

	return 0;
}

void PrintReceiptTest()
{
	uchar szBuff[50];
	uchar szSN[32], ucAcqIndex;
	int iRet;


	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return   ;
		    }
	 //===========================
		PrnInit();

	MultiLngPrnStr(FT_ALIGN_CENTER,  PRN_SIZE_LARGE, "%s\n", (char *)_T("Printer Test"));
	PrnStep(30);

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n",     glSysParam.stEdcInfo.szMerchantName);
	PrnStep(5);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "%s\n", glSysParam.stEdcInfo.szMerchantAddr);
	PrnStep(/*5*/10);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "TEL:%s\n", glSysParam.stEdcInfo.szHelpTelNo);
	PrnStep(15);

	for(ucAcqIndex=0; ucAcqIndex<glSysParam.ucAcqNum; ucAcqIndex++)
	{
		SetCurAcq(ucAcqIndex);

		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("ACQUIRER:"));
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szPrgName);
		PrnStep(5);

		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("TERMINAL ID.:"));
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szTermID);
		PrnStep(5);

		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("MERCHANT ID.:"));
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szMerchantID);
		PrnStep(5);

		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("MERCHANT NAME.:"));
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szMerchantID);
		PrnStep(5);
	}

	PrnStep(15);
	ReadSN(szSN);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("TEMINAL SN:"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szSN);
	PrnStep(15);


	Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_SMALL, "%s%-12.13s", (char *)_T("DATE: "), szBuff);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s%5.6s",  (char *)_T("TIME: "), szBuff+14);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_SMALL, "%s%5.6s\n",  (char *)_T("TIME: "), szBuff+14);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-12.13s", (char *)_T("DATE: "), szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.6s\n",  (char *)_T("TIME: "), szBuff+14);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s%-12.13s", (char *)_T("DATE: "), szBuff);//dddddddddddate
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s%5.6s\n",  (char *)_T("TIME: "), szBuff+14);///tttttttttttime
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n\n\n\n\n",  (char *)_T("TEST END"));
//	PubDebugOutput("edc:", glSysParam.stEdcInfo.sOption, 5, DEVICE_PRN, HEX_MODE);
//	PubDebugOutput("acq:", glSysParam.stAcqList[0].sOption, 4, DEVICE_PRN, HEX_MODE);
//	PubDebugOutput("issuer:", glSysParam.stIssuerList[0].sOption, 4, DEVICE_PRN, HEX_MODE);

	StartPrinter();

}

static int PrnFootLogo(void)
{
	uchar	*psLogoData;
	int		iWidth = 10 /*0*/;
//	int 		iHeigh;

	psLogoData = NULL;
	GetNowPrnFTLogo(&psLogoData);
	if (psLogoData!=NULL)
	{

		PrnLeftIndent(iWidth);
		//FIXME Kim on Prolin, range of left indent is 0 - 100, not 0 - 300
		//need to print space before print logo for center alignment or right alignment
		PrnLogo(psLogoData);
		PrnLeftIndent(0);
		PrnStep(PRN_SIZE_SMALL);
		return 0;
	}

	return -1;
}

static int PrnFootLogoFail(void)
{
	uchar	*psLogoData;
	int		iWidth = 10 /*0*/;
//	int 		iHeigh;

	psLogoData = NULL;
	GetNowPrnFTLogoFail(&psLogoData);
	if (psLogoData!=NULL)
	{

		PrnLeftIndent(iWidth);
		//FIXME Kim on Prolin, range of left indent is 0 - 100, not 0 - 300
		//need to print space before print logo for center alignment or right alignment
		PrnLogo(psLogoData);
		PrnLeftIndent(0);
		PrnStep(PRN_SIZE_SMALL);
		return 0;
	}

	return -1;
}
static int PrnFootLogo_BT(void)
{
	uchar	*psLogoData;
	int		iWidth = 32 /*0*/;
//	int 		iHeigh;

	psLogoData = NULL;
	GetNowPrnFTLogo(&psLogoData);
	if (psLogoData!=NULL)
	{

		//PrnLeftIndent(iWidth);
		//FIXME Kim on Prolin, range of left indent is 0 - 100, not 0 - 300
		//need to print space before print logo for center alignment or right alignment
		BT_Ft_CreateSendBuf(psLogoData, 1);
		return 0;
	}
	return -1;
}

int PrintReceipt_T(uchar ucPrnFlag)
{	//AADIB PRINT
	uchar	ucNum;
	uchar   szTotalAmt[12+1];
	uchar	szBuff[50],szBuf1[50];
	uchar	szIssuerName[10+1], szTranName[16+1], szOrgTranName[16+1];
	uchar 	szText[32], szDccInfo[8+1], szDccValue[1024];
	int iCnt = 0;



	for(ucNum=0; ucNum<NumOfReceipt(); ucNum++)
	{
		PrnInit();

		PrnCustomLogo_T();

		PrnStep(5);
		PrnHead_T();





		// Issuer Name
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-10.10s", szIssuerName);
		//linzhao
		if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
		{
			if( ChkIssuerOption(ISSUER_MASK_EXPIRY) )
			{
				MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
			}
			else
			{
				//only customer copy have the exipry, others must mask.linzhao
				if (1==ucNum)
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %2.2s/%2.2s\n", (char *)_T("EXP."), &glProcInfo.stTranLog.szExpDate[2],
							   glProcInfo.stTranLog.szExpDate);
				}
				else
				{
					MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s: %s\n", (char *)_T("EXP."), "**/**");
				}
			}
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "\n");
		}

		// PAN(CARD NUMBER)
		if (ChkIfTransMaskPan(ucNum))
		{
			//MaskPan(glProcInfo.stTranLog.szPan, szBuff);
			MaskPan_nagy(glProcInfo.stTranLog.szPan, szBuff);
		}
		else
		{
			strcpy((char *)szBuff, (char *)glProcInfo.stTranLog.szPan);
		}


//		if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT == TRUE)
//		{
//			sprintf(szBuf1, "%s (S)", szBuff);
//		}
//		else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
//		{
//			sprintf(szBuf1, "%s (C)", szBuff);
//		}
//		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
//				 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
//		{
//			sprintf(szBuf1, "%s (F)", szBuff);
//		}
//		else
//		{
//			sprintf(szBuf1, "%s (M)", szBuff);
//		}

		if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )//== TRUE
		{
			sprintf(szBuf1, "%s (S)", szBuff);
		}
		else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
		{
			sprintf(szBuf1, "%s (I)", szBuff);
		}
		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
				 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
		{
			sprintf(szBuf1, "%s (F)", szBuff);
		}
		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_MANUAL_INPUT) )
		{
			sprintf(szBuf1, "%s (K)", szBuff);
		}
		else
		{
			sprintf(szBuf1, "%s (T)", szBuff);
		}


//		I-Chip Entry transaction
//		S-MagStripe transaction
//		K- Manual Entry transaction
//		T- Contactless transaction
//		TRANSACTION TYPE
//

		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-23.23s\n", szBuf1);

		//linzhao
		if (0!=glProcInfo.stTranLog.szHolderName[0])
		{
			uchar *pFindDoubleSpace = NULL;
			pFindDoubleSpace = strstr(glProcInfo.stTranLog.szHolderName, "  ");
			if (NULL!=pFindDoubleSpace)
			{
				glProcInfo.stTranLog.szHolderName[pFindDoubleSpace-glProcInfo.stTranLog.szHolderName] = 0;
			}
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", (char *)_T("HOLDER"));
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%.26s\n", glProcInfo.stTranLog.szHolderName);

		}
		PrnStep(15);
		//linzhao 20150917
		// AID, Application label
//		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) {
//			PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
//			PubTrimTailChars(szBuff, 'F');
//			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-32.32s", (char *)_T("AID: "), szBuff);
//			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);
//		}

		// Transaction type, Expiry date

		if (NULL != strstr(glCurIssuer.szName, "CUP"))
					{
								//MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%16lu\n",   _T("AID: "),   glProcInfo.stTranLog.sAID);
				  	  	  	   memset(	szBuff,0,sizeof(szBuff));
					 			PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff);
					 			PubTrimTailChars(szBuff, 'F');
					 			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-32.32s", (char *)_T("AID: "), szBuff);
					 			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAppLabel);
					}



		// Batch, Invoice
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%06lu",   _T("BATCH: "),   glCurAcq.ulCurBatchNo);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%06lu\n", _T("RECEIPT #: "), glProcInfo.stTranLog.ulInvoiceNo);

		// Date, Time
		Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-*.*s", _T("DATE: "), strlen(szBuff)-5, strlen(szBuff)-5, szBuff);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.5s\n",  _T("TIME: "), szBuff+strlen(szBuff)-5);

		// RRN, AUTH NO
		if(OFF_SALE == glProcInfo.stTranLog.ucTranType)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s",    _T("Approved Offline"));
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s%-13.13s", _T("RRN: "), glProcInfo.stTranLog.szRRN);

			 MultiLngPrnStr(FT_ALIGN_RIGHT,  PRN_SIZE_NORMAL,  "%s%06d", _T("STAN: "), glProcInfo.stTranLog.ulSTAN);



		}


		//MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s%6.6s\n",  _T("AUTH NO: "), glProcInfo.stTranLog.szAuthCode);


        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "\n%s", (char *)_T("AUTH NO: "));
      	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE_2, "%s\n", glProcInfo.stTranLog.szAuthCode);



        /*=======BEGIN: Jason 2015.01.07  16:41 modify===========*/
        if  ( strlen(glProcInfo.stTranLog.szECRRRN) != 0 )
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "ECR REF. NO: %s\n", glProcInfo.stTranLog.szECRRRN);
        }
        /*====================== END======================== */
        if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
        {
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPLUS TXN ID:");
            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szTI+1);
        }

        PrnStep(PRN_SIZE_NORMAL);
		PrnDescriptor();

		// Amount
		//FALSE -> TRUE, linzhao
		PrnAmount((uchar *)"", TRUE);


		PrnStep(15);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "PLEASE DEPIT MY ACCOUNT\n");//ADIB


		// DCC Transaction
		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
		{
		    uchar szRate[10];
		    GetDccRate(glProcInfo.stTranLog.stDccInfo.szDccExRate, szRate);

            PrnStep(15);
            //change the style of exchange print. linzhao
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: 1 %s = %s %s\n", _T("Exchange Rate*"),
            				 glProcInfo.stTranLog.stTranCurrency.szName, szRate, glProcInfo.stTranLog.stHolderCurrency.szName);
            //MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s: %s%%\n", _T("Commission"), glProcInfo.stTranLog.stDccInfo.szCommission);
            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s%%\n", _T("Mark-Up on Exchange Rate INCL"), glProcInfo.stTranLog.stDccInfo.szDccMarginRate);
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s%s%s\n", _T("(Transaction Currency:"), glProcInfo.stTranLog.stHolderCurrency.szName, ")");

            PrnStep(5);
            PrnDccAmountX((uchar *)"");
            //move it into PrnAmountWithX(), linzhao
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "[ X ]");
//            App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
//            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

            //linzhao
//            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I accept that I have been offered a choice of currencies");
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "for payment & that this choice is final.");

            //linzhao, 从ENV文件里面提取定制信息
//            for (iCnt=0; iCnt<6; iCnt++)
//            {
//            	sprintf(szDccInfo, "DCINF_%d", iCnt);
//            	if (0==GetEnv(szDccInfo, szText))
//            	{
//            		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T(szText));;
//            	}
//            }
//            PrnStep(15);
            if(0 == strcmp(szIssuerName, "VISA"))
            {
            	//linzhao
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "Dynamic Currency Conversion is conducted by the");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " Merchant and is not associated with or endorsed by Visa. ");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I ACCEPT THAT I HAVE BEEN OFFERED");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "A CHOICE OF CURRENCIES FOR PAYMENT");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "& THAT THIS CHOICE IS FINAL.");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DYNAMIC CURRENCY CONVERSION IS");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONDUCTED BY THE MERCHANT AND IS NOT");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "ASSOCIATED WITH OR ENDORSED BY VISA.");
            }
            else if(0 == strcmp(szIssuerName, "MASTER"))
            {
            	//linzhao
//                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I understand that MasterCard has a currency conversion");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " process and that I have chosen not to use the");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", " MasterCard currency conversion process and I will");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "have no recourse against MasterCard with respect to ");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "any matter related to the currency conversion or");
//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "disclosure thereof.");

                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "I'VE BEEN GIVEN A CHOICE TO PAY IN CURR");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "DIFFERS FROM MY LOCAL CURR,I ACCEPT THIS");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CHOICE , I'VE CHOSEN NOT TO USE THE MC");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CURR CONVERSION PROCESS AND I'LL HAVE NO");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "RECOURSE AGAINST MC CONCERNING THE CURR");
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL, "%s\n", "CONVERSION OR ITS DISCLOSURE.");
            }
            PrnStep(15);
//    		if (0!=strcmp(glSysParam.stEdcInfo.szHelpTelNo, "000000000000000000000000"))
//    		{
//    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s     %s\n",
//    							glSysParam.stEdcInfo.szHelpTelNo, glSysParam.stEdcInfo.szPabx);
//    		}
//    		else
//    		{
//    			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL,  "%s", glSysParam.stEdcInfo.szPabx);
//
//    		}
		}
        PrnStep(15);

		PrnAdditionalPrompt();

		// approve online/offline
		if (glProcInfo.stTranLog.uiStatus == TS_OK)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED ONLINE"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_OFFLINE_SEND)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED ONLINE"));
		}
		else if (glProcInfo.stTranLog.uiStatus & TS_NOSEND)
		{
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("APPROVED OFFLINE"));
		}
		else
		{
			FtPrn();
		}
		if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT)
		{
			// offline PIN
			if (glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", _T("OFFLINE PIN ENTERED"));
			}
			else
			{
				FtPrn();
			}

			// TC, linzhao
			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff);
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%.16s\n", _T("TC: "), szBuff);
			}

#ifdef ENABLE_EMV
//#ifdef APP_DEBUG
			//EMP need to delete TVR. linzhao 20150618
//            PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff);
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TSI: %s\n", szBuff);
//            PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff);
//            MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   TVR: %s\n", szBuff);
//#endif
#endif
		}

		PrnStatement();

        PrnStep(15);

		// DCC Transaction
		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
		{
			//linzhao
			if (0==ucNum)
			{
			// Card Holder Name
				//MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n\n\n\n\n",  _T("Card Holder Name"));

				//foura 17.11.2016 add pen
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n\n\n");
				PrnCustomLogo_Pen();
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n");
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL - 2, "%s\n\n", _T("I AGREE TO PAY ABOVE TOTAL AMOUNT"));

//				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL - 2, "\n\n\n%s%s\n\n",
//						   "X:----------------------------------------\n",
//						   _T("I AGREE TO PAY ABOVE TOTAL AMOUNT"));
			}
		}
		else if(ucNum == 0)
		{
			// Holder name
			if(VOID != glProcInfo.stTranLog.ucTranType && SALE_COMP != glProcInfo.stTranLog.ucTranType &&
			   VOID_AUTH != glProcInfo.stTranLog.ucTranType)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-26.26s\n", glProcInfo.stTranLog.szHolderName);
			}
			else if(OFF_SALE == glProcInfo.stTranLog.ucTranType || TS_NOSEND == glProcInfo.stTranLog.uiStatus)
			{
				MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "\n\n\n\n");
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n%s\n%s\n",
						_T("I AGREE TO PAY ABOVE TOTAL AMOUNT"),
						_T("ACCORDING TO CARD ISSUER AGREEMENT"),
						_T("MERCHANT AGREEMENT IF CREDIT VOUCHER"));
			}
//			else
//			{
//				PrnStep(20);
//			}
			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "%s\n", (char *)_T("CARDHOLDER SIGNATURE"));
			// MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL,  "--------------------------------------\n");
			// MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_SMALL-5, "%s\n", _T("I ACKNOWLEDGE SATISFACTORY RECEIPT\nOF RELATIVE  GOODS/SERVICE"));
		}

		//EMPlus
		if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
		{
		    uchar szTemp[300+1];
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "EMPlus\n");
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints[0])
            {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("REWARDED POINTS"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints[0])
		    {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS BALANCE"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
                PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount+1, 6, szBuf1);
                App_ConvAmountTran(szBuf1, szBuff, 0);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("EQUIVALENT AMOUNT"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints[0])
		    {
		        PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints+1, 5, szBuff);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:", _T("POINTS UNDER PROCESS"));
                MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0])
            {
                strcpy(szTemp, glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1);
                uchar *p = szTemp;
                int len = strlen(szTemp);
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");
                while(p < szTemp + len){
                    if(0x5E == *p){
                        *p = '\n';
                    }
                    ++p;
                }
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n\n", szTemp);
            }

		    if(glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer[0])
		    {
		        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "CURRENT OFFER\n");
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "----------------------------------\n");
                MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer+1);
		    }
		}

		PrnStep(20);
		//PrnFootLogo();// عملية مقبولة
		if( ucPrnFlag==PRN_REPRINT )
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "* %s *\n", _T("REPRINT"));
		}

		PrnSetNormal();
		if (0!=GetEnv("FTLOGO", szText))
		{
			strcpy(szText, "");
		}
		if( ucNum==0 )
		{

		    //FOURA PRINT SIGN

		      if( NULL != strstr(glCurIssuer.szName, "AMEX") && !(glProcInfo.stTranLog.uiEntryMode & MODE_OFF_PIN)  )
		         {

		    		//foura 17.11.2016 add pen
		    		PrnCustomLogo_Pen();
		    		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n");

		    	 // MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "X%s \n", _T("--------------------------------------------"));


		              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T("    I AGREE TO PAY THE ABOVE TOTAL AMOUNT"));
		              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T(""));

		         }else if( (NULL != strstr(glCurIssuer.szName, "CUP")) && ((glProcInfo.stTranLog.uiEntryMode & MODE_PINBYPASS) ) )

		         {


		        			    		//foura 17.11.2016 add pen
		        			    		PrnCustomLogo_Pen();
		        			    		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n");

		        			    	 // MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "X%s \n", _T("--------------------------------------------"));


		        			              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T("    I AGREE TO PAY THE ABOVE TOTAL AMOUNT"));
		        			              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T(""));

		         }else if ((glProcInfo.stTranLog.uiEntryMode & MODE_SIGNATURE_REQ) ||(glProcInfo.stTranLog.uiEntryMode & MODE_PIN_SIGNATURE_REQ)  )

		         {
		        		//foura 17.11.2016 add pen
		        			        			    		PrnCustomLogo_Pen();
		        			        			    		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n");

		        			        			    	 // MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "X%s \n", _T("--------------------------------------------"));


		        			        			              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T("    I AGREE TO PAY THE ABOVE TOTAL AMOUNT"));
		        			        			              MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_SMALL, "%s\n", _T(""));


		         }

			//linzhao
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("MERCHANT COPY"));

			PrnStep(15);
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** THANK YOU FOR YOUR CUSTOMS **\n");
			PrnStep(15);
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "PLEASE KEEP THIS COPY FOR YOUR RECORDS\n");
			PrnStep(15);

//			if (glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
//			{
//				PrnStep(15);
//			}
//			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);

		}
		else if( ucNum==1 )
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("CUSTOMER COPY"));


				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "I ACKNOWLEDGE THE SERVIS(S) RECEIVED\n");
				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** THANK ADIB MARCHENT SERVISES **\n");

			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
			}
		}
		else if( ucNum==2 )
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "**** %s ****\n", _T("BANK COPY"));
			if (glProcInfo.stTranLog.ucDccOption != DCC_TYPE_DCC)
			{
				PrnStep(15);
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n", (char *)szText);
			}
		}

		//MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n\n\n");

//		PrnStep(15);
//		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "ADIB Transaction\n");
//		PrnStep(15);
//		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** THANK YOU **\n");
//		PrnStep(15);

		if (ChkIfTrainMode())
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "***** %s *****\n", _T("DEMO"));
		}
		else
		{
#ifdef ENABLE_EMV
#ifdef EMV_TEST_VERSION
//		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "** %s **\n", (char *)_T("FOR EMV TEST ONLY"));
#endif
#endif
		}
#ifndef TEST_SMS
		if(!ChkHardware(HWCFG_PRINTER, 0))
		    MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
		StartPrinter();

		if( ucNum==0 && NumOfReceipt() != 1)
		{
            kbflush();

			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRESS ANY KEY"), gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL);
		}
	}

	return 0;
}

void PrnHead(uchar ucFreeFmat)
{
	uchar	szBuff[32];

	if (ChkIfTrainMode())
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T("DEMONSTRATE ONLY\nNOT FOR PAYMENT PROOF"));
	} 
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", glSysParam.stEdcInfo.szMerchantName);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", glSysParam.stEdcInfo.szMerchantAddr);
	}

	PrnStep(15);

	if (ucFreeFmat)
	{
		GetEngTime(szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:%-15.15s", _T("MID"), glCurAcq.szMerchantID);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%5.5s\n", szBuff+11);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:%-8.8s", _T("TID"), glCurAcq.szTermID);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%10.10s\n", szBuff);
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n", glCurAcq.szTermID, glCurAcq.szMerchantID);
	}
	PrnStep(15);
}

int PrnCustomLogo_BT(void)
{
	uchar	*psLogoData;
	int		iWidth, iHeigh;
	char str[5] = "", str1[10] = "";

	psLogoData = NULL;
	GetNowPrnLogo(&psLogoData);
	if (psLogoData!=NULL)
	{
		iWidth = 0;
		iHeigh = 0;
		GetLogoWidthHeigh(psLogoData, &iWidth, &iHeigh);
		if (iWidth<384)
		{
			iWidth = (384-iWidth)/2;	// let logo be printed at center
			if(iWidth > 100)
				iWidth = 95;
		}
		else
		{
			iWidth = 0;
		}
//		sprintf(str, "%d", iWidth);
//		strcat(str1, "\x1B\x44");
//		strcat(str1, str);
//		strcat(str1, "\x00");

//		BTPrn_Send(str1, strlen(str1)+1);
//		BTPrn_Send("\x1B\x24\xFF\x00", 4);
		BT_Ft_CreateSendBuf(psLogoData, 0);

		return 0;
	}

	return -1;
}

void PrnHead_BT(void)
{
	PrnStep(20);

	if (ChkIfTrainMode())
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", (char *)_T("DEMONSTRATE ONLY"));
		PrnStep(10);

		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", (char *)_T("NOT FOR PAYMENT PROOF"));
		PrnStep(15);
	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n",     glSysParam.stEdcInfo.szMerchantName);
		PrnStep(5);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "%s\n", glSysParam.stEdcInfo.szMerchantAddr);
		PrnStep(5);
		FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
		PrnStep(20);
	}

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("TERMINAL ID.:"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szTermID);

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("MERCHANT #:"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szMerchantID);
}

int PrnCustomLogo_T(void)
{
	uchar	*psLogoData;
	int		iWidth, iHeigh;

	// TODO even by email?
	if(ChkHardware(HWCFG_PRINTER, 0))
	    return 0;

	psLogoData = NULL;
	GetNowPrnLogo(&psLogoData);
	if (psLogoData!=NULL)
	{
		iWidth = 0;
		iHeigh = 0;
		GetLogoWidthHeigh(psLogoData, &iWidth, &iHeigh);
		if (iWidth<384)
		{
			iWidth = (384-iWidth)/2;	// let logo be printed at center
			if(iWidth > 100)
				iWidth = /*95*/ 2;
		}
		else
		{
			iWidth = 0;
		}

		PrnLeftIndent(iWidth);
		//FIXME Kim on Prolin, range of left indent is 0 - 100, not 0 - 300
		//need to print space before print logo for center alignment
		PrnLogo(psLogoData);
		PrnLeftIndent(0);
		PrnStep(PRN_SIZE_SMALL);
		return 0;
	}

	return -1;
}

int PrnCustomLogo_Pen(void)
{
	uchar	*psLogoData;
	int		iWidth, iHeigh;

	// TODO even by email?
	if(ChkHardware(HWCFG_PRINTER, 0))
	    return 0;

	psLogoData = NULL;
	//GetNowPrnLogo(&psLogoData);
	GetNowLogoPen(&psLogoData);
	if (psLogoData!=NULL)
	{
		iWidth = 0;
		iHeigh = 0;
		GetLogoWidthHeigh(psLogoData, &iWidth, &iHeigh);
		if (iWidth<384)
		{
			iWidth = (384-iWidth)/2;	// let logo be printed at center
			if(iWidth > 100)
				iWidth = /*95*/ 2;
		}
		else
		{
			iWidth = 0;
		}

		PrnLeftIndent(iWidth);
		//FIXME Kim on Prolin, range of left indent is 0 - 100, not 0 - 300
		//need to print space before print logo for center alignment
		PrnLogo(psLogoData);
		PrnLeftIndent(0);
		PrnStep(PRN_SIZE_SMALL);
		return 0;
	}

	return -1;
}


void PrnHead_T(void)
{
	PrnStep(20);

	if (ChkIfTrainMode())
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", _T("DEMONSTRATE ONLY"));
		PrnStep(10);
		
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", _T("NOT FOR PAYMENT PROOF"));
		PrnStep(15);
	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n",     glSysParam.stEdcInfo.szMerchantName);
		PrnStep(5);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "%s\n", glSysParam.stEdcInfo.szMerchantAddr);
		PrnStep(/*5*/10);
		//linzhao 20150917
		//if the telNo is all 0, don't print it.linzhao 20150618
		if (0!=strcmp(glSysParam.stEdcInfo.szHelpTelNo, "000000000000000000000000"))
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "TEL:%s\n", glSysParam.stEdcInfo.szHelpTelNo);
		}
		else
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "TEL:\n" );

		}
		PrnStep(20);
		//buletooth printer
//		if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.ucPrnMode == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_OK))
//		{
//			BT_Ft_Print();
//			printTime = 0;
//		}
		{
			uchar szTranName[16+1], szOrgTranName[16+1], szBuff[24];

			if (MAX_TRANTYPE != glProcInfo.stTranLog.ucTranType )
			{
			    //LEEN FOURA
				sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
				//sprintf(szTranName, "%.16s", "SETTLEMENT");

				sprintf(szOrgTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
			}
			if (glProcInfo.stTranLog.ucTranType == VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType ||
			   (glProcInfo.stTranLog.uiStatus & TS_VOID))
			{
				if ( VOID_AUTH==glProcInfo.stTranLog.ucTranType)
				{
					sprintf((char *) szBuff, "%s", (char *)_T(szTranName));
				}
				//for now
				/*
				else if (TS_NOT_COMP & glProcInfo.stTranLog.ucTranType)
				{
					sprintf((char *)szBuff, "%s", (char *)_T("VOID COMPLETION"));
				}
				*/
				else
				{
					sprintf((char *) szBuff, "%s %s", (char *)_T(szTranName), (char *)_T(szOrgTranName));
				}
			}
			else if (glProcInfo.stTranLog.uiStatus & TS_ADJ)
			{
				sprintf((char *) szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("ADJ"));
			}
			else if (glProcInfo.stTranLog.uiStatus & TS_AUTH_SEND)
			{
				sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("COMPLETION"));
			}
			else
			{
				sprintf((char *) szBuff, "%s", szTranName);
			}
			if  (MAX_TRANTYPE != glProcInfo.stTranLog.ucTranType )
			{
				MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s", szBuff);
			}
		}

		FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
		PrnStep(20);
	}

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", _T("POS ID.:"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szTermID);

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", _T("MERCHANT #:"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szMerchantID);
	if (NULL != strstr(glCurIssuer.szName, "AMEX"))
	{

			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", _T("AMEX MID #:"));
	      // MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n",glCurAcq.szMerchantID  );//glCurAcq.szMerchantID"9630113538"
          MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glSysCtrl.szMerchantID_AMEX );//glCurAcq.szMerchantID"9630113538"
	}




	//linzhao  20151118
	if (SETTLEMENT == glProcInfo.stTranLog.ucTranType)
	{
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("ACQUIRER:"));
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n\n\n", glCurAcq.szName);
//		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n\n\n", glCurAcq.szPrgName);
		PrnStep(10);
	}
}


void PrnHead_TREP(void)
{
    PrnStep(20);

    if (ChkIfTrainMode())
    {
        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", _T("DEMONSTRATE ONLY"));
        PrnStep(10);

        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "* %s *\n", _T("NOT FOR PAYMENT PROOF"));
        PrnStep(15);
    }
    else
    {
        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s\n",     glSysParam.stEdcInfo.szMerchantName);
        PrnStep(5);
        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "%s\n", glSysParam.stEdcInfo.szMerchantAddr);
        PrnStep(/*5*/10);
        //linzhao 20150917
        //if the telNo is all 0, don't print it.linzhao 20150618
        if (0!=strcmp(glSysParam.stEdcInfo.szHelpTelNo, "000000000000000000000000"))
        {
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "TEL:%s\n", glSysParam.stEdcInfo.szHelpTelNo);
        }
        else
        {
            MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL,  "TEL:\n" );

        }
        PrnStep(20);
        //buletooth printer
//      if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.ucPrnMode == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_OK))
//      {
//          BT_Ft_Print();
//          printTime = 0;
//      }
        {
            uchar szTranName[16+1], szOrgTranName[16+1], szBuff[24];

            if (MAX_TRANTYPE != glProcInfo.stTranLog.ucTranType )
            {
                //LEEN FOURA
               // sprintf(szTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
                sprintf(szTranName, "%.16s", "SETTLEMENT");

                sprintf(szOrgTranName, "%.16s", glTranConfig[glProcInfo.stTranLog.ucOrgTranType].szLabel);
            }
            if (glProcInfo.stTranLog.ucTranType == VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType ||
               (glProcInfo.stTranLog.uiStatus & TS_VOID))
            {
                if ( VOID_AUTH==glProcInfo.stTranLog.ucTranType)
                {
                    sprintf((char *) szBuff, "%s", (char *)_T(szTranName));
                }
                //for now
                /*
                else if (TS_NOT_COMP & glProcInfo.stTranLog.ucTranType)
                {
                    sprintf((char *)szBuff, "%s", (char *)_T("VOID COMPLETION"));
                }
                */
                else
                {
                    sprintf((char *) szBuff, "%s %s", (char *)_T(szTranName), (char *)_T(szOrgTranName));
                }
            }
            else if (glProcInfo.stTranLog.uiStatus & TS_ADJ)
            {
                sprintf((char *) szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("ADJ"));
            }
            else if (glProcInfo.stTranLog.uiStatus & TS_AUTH_SEND)
            {
                sprintf((char *)szBuff, "%s(%s)", (char *)_T(szTranName), (char *)_T("COMPLETION"));
            }
            else
            {
                sprintf((char *) szBuff, "%s", szTranName);
            }
            if  (MAX_TRANTYPE != glProcInfo.stTranLog.ucTranType )
            {
                MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "%s", szBuff);
            }
        }

        FtPrn(); //MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
        PrnStep(20);
    }

    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", _T("TERMINAL ID.:"));
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szTermID);

    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", _T("MERCHANT #:"));
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n", glCurAcq.szMerchantID);

    //linzhao  20151118
    if (SETTLEMENT == glProcInfo.stTranLog.ucTranType)
    {
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s", (char *)_T("ACQUIRER:"));
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n\n\n", glCurAcq.szName);
//      MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%15.15s\n\n\n", glCurAcq.szPrgName);
        PrnStep(10);
    }
}
void PrnDccAmountX(const uchar *pszIndent)
{
	uchar szBuff[64], szTotalAmt[12+1], szBuffConv[64];

//	App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
	if (glProcInfo.stTranLog.uiStatus & TS_VOID)
	{
		App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0x40);
	}
	else
	{
		App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);
	}
//	if ((glProcInfo.stTranLog.uiStatus & TS_ADJ) ||
//		((glProcInfo.stTranLog.uiStatus & TS_VOID) && ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))||
//		ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
	if ((ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) ||(glProcInfo.stTranLog.uiStatus & TS_ADJ) ||
		((glProcInfo.stTranLog.uiStatus & TS_VOID) && (!ChkIfZeroAmt(glProcInfo.stTranLog.stDccInfo.szTipAmt))) ) && ChkIfNeedTip())
	{
		MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%s", (char *)_T(pszIndent), (char *)_T("BASE"));
		if (ChkIfZeroAmt(glProcInfo.stTranLog.stDccInfo.szTipAmt) )
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "[ X ]");
		}
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%s", (char *)_T(pszIndent), (char *)_T("TIP"));
		if (ChkIfZeroAmt(glProcInfo.stTranLog.stDccInfo.szTipAmt))
		{
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s%s\n", (char *)_T(pszIndent), (char *)glProcInfo.stTranLog.stHolderCurrency.szName);
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%s", (char *)_T(pszIndent), (char *)_T("TOTAL"));
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s%s\n", (char *)_T(pszIndent), (char *)glProcInfo.stTranLog.stHolderCurrency.szName);
		}
		else
		{
//			App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szTipAmt, szBuff, 0);
			if (glProcInfo.stTranLog.uiStatus & TS_VOID)
			{
				App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szTipAmt, szBuff, 0x40);
			}
			else
			{
				App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szTipAmt, szBuff, 0);
			}
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%s", (char *)_T(pszIndent), (char *)_T("TOTAL"));
            PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szBuffConv);
//			App_ConvAmountDccTran(szBuffConv, szBuff, 0);
			if (glProcInfo.stTranLog.uiStatus & TS_VOID)
			{
				App_ConvAmountDccTran(szBuffConv, szBuff, 0x40);
			}
			else
			{
				App_ConvAmountDccTran(szBuffConv, szBuff, 0);
			}
			MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_LARGE, "[ X ]");
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
		}
	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "[ X ]");
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
	}

}

void PrnAmount(const uchar *pszIndent, uchar ucNeedSepLine)
{
	uchar	szBuff[50], szTotalAmt[12+1], szDisCount[12+1];
	uchar   szTempBuff[100];

	sprintf(szDisCount, "%012lu", 0L);

	//del & TS_VOID linzhao 20150908
	//delete this control by ChkIfNeed Tip(),  linzhao 20151229
//    if ((ChkIfNeedTip() /*&& !(glProcInfo.stTranLog.uiStatus & TS_VOID)*/) ||
//         (LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption))
//	{
		//-------------------------------- BASE --------------------------------
    	if (glProcInfo.stTranLog.uiStatus & TS_VOID)
    	{
    		App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szBuff, 0x40);
    	}
    	else
    	{
    		App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szBuff, 0);
    	}
		if (ChkIfThermalPrinter())
		{
		    uchar szEnableFee[8];
		    if ((0==GetEnv("E_FEE", szEnableFee)) && (0!=atoi(szEnableFee)))
		    {
		        PrnStep(5);
		    }
		    else
		    {
		        MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("AMOUNT"));
		        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE_2, "%s\n", szBuff);
		    }
		}
		else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
		{
			OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);//linzhao
			MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("AMOUNT"));
			MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
		}
		else
		{
			OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);//linzhao
		    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s%s", pszIndent, "AMOUNT");
		    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
		}

		//-------------------------------- TIPS --------------------------------
//		if (ChkIfNeedTip() && !(glProcInfo.stTranLog.uiStatus & TS_VOID))
		if (ChkIfNeedTip() /*&& (glProcInfo.stTranLog.uiStatus & TS_VOID)*/)
		{
//            App_ConvAmountTran(glProcInfo.stTranLog.szTipAmount, szBuff, 0);
	    	if (glProcInfo.stTranLog.uiStatus & TS_VOID)
	    	{
	    		App_ConvAmountTran(glProcInfo.stTranLog.szTipAmount, szBuff, 0x40);
	    	}
	    	else
	    	{
	    		App_ConvAmountTran(glProcInfo.stTranLog.szTipAmount, szBuff, 0);
	    	}
            if (ChkIfThermalPrinter())
            {
                if(!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", _T(pszIndent), _T("TIPS"));
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
                }
                //linzhao, 2015.8.13
                else if (glProcInfo.stTranLog.ucDccOption!=DCC_TYPE_DCC)
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s\n", (char *)_T(pszIndent), (char *)_T("TIPS"));
                }
            }
			else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
            {
                if(!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("TIPS"));
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
                }
				//linzhao, 2015.8.13
                else if (glProcInfo.stTranLog.ucDccOption!=DCC_TYPE_DCC)
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s\n", (char *)_T(pszIndent), (char *)_T("TIPS"));
                }
            }
            else
            {
                if( !ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) )
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", pszIndent, "TIPS");
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
                }
            }
		}

		//-------------------------------- survice charge--------------------------

//		uchar szEnableFee[8];
//
//		if ((!ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee)) && (0==GetEnv("E_FEE", szEnableFee))
//		     && (0!=atoi(szEnableFee)))
//		{
//		    if (glProcInfo.stTranLog.uiStatus & TS_VOID)
//		    {
//		        App_ConvAmountTran(glProcInfo.stTranLog.szSurFee, szBuff, 0x40);
//		    }
//		    else
//		    {
//		        App_ConvAmountTran(glProcInfo.stTranLog.szSurFee, szBuff, 0);
//		    }
//            MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s%s", pszIndent, "FEE");
//            MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
//
//		}

		//-------------------------------- DISCOUNT --------------------------------
		if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
		{
            memset(szTempBuff, 0, sizeof(szTempBuff));
            PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.sDiscountAmt+1, 6, szTempBuff);

            if(!ChkIfZeroAmt(szTempBuff) )
            {
                App_ConvAmountTran(szTempBuff, szBuff, 0);
                if (ChkIfThermalPrinter())
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("DISCOUNT"));
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
                }
                else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("DISCOUNT"));
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
                }
                else
                {
                    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%s", pszIndent, "DISCOUNT");
                    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
                }
            }
		}
//	}

    //-------------------------------- TOTAL --------------------------------
    if( ucNeedSepLine )
    {
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "-----------------\n");
    }

    if (!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
    {
        PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
    }
    else
    {
        memcpy(szTotalAmt, glProcInfo.stTranLog.szAmount, sizeof(szTotalAmt));
    }

    uchar szEnableFee[8];
    if ((!ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee)) && (0==GetEnv("E_FEE", szEnableFee))
         && (0!=atoi(szEnableFee)))//linzhao 20160113
    {
        uchar szTotalAmt2[12+1];

        PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt2);
        PubAscAdd(szTotalAmt2, glProcInfo.stTranLog.szSurFee, 12, szTotalAmt);
    }
    PubAscSub(szTotalAmt, szDisCount, 12, szTotalAmt);
//    App_ConvAmountTran(szTotalAmt, szBuff, 0);
	if (glProcInfo.stTranLog.uiStatus & TS_VOID)
	{
		App_ConvAmountTran(szTotalAmt, szBuff, 0x40);
	}
	else
	{
		App_ConvAmountTran(szTotalAmt, szBuff, 0);
	}

    if (ChkIfThermalPrinter())
    {
    	//linzhao, 2015.8.13, add surCharge judge, linzhao 20160113
    	if (glProcInfo.stTranLog.ucDccOption!=DCC_TYPE_DCC && ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount)
    	    && ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee)    &&  ChkIfNeedTip())
    	{
    		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s\n", (char *)_T(pszIndent), (char *)_T("TOTAL"));
    		return;
    	}
    	else if (ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) && ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee))
    	{
    		return;
    	}
    	else
    	{
    		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", (char *)_T(pszIndent), (char *)_T("TOTAL"));
    		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
    	}
    }
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
    {
    	if (glProcInfo.stTranLog.ucDccOption!=DCC_TYPE_DCC && ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
    	{
    		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%s\n", (char *)_T(pszIndent), (char *)_T("TOTAL"));
    		return;
    	}
    	else if (ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
    	{
    		return;
    	}
    	else
    	{
    		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s%s", (char *)_T(pszIndent), (char *)_T("TOTAL"));
    		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
    	}
    }
    else
    {
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s%s", pszIndent , "TOTAL");
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%s\n", szBuff);
    }

    if( ucNeedSepLine )
    {
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "=====================\n");
    }
}

void PrnDccAmount(void)
{
	uchar	szBuff[50], szTotalAmt[12+1];
	uchar   szTempBuff[100], szMerType[4];
	uchar	szBuffCurrency[6],	szBuffAmount[50];
	// Frn Amout
	if(glProcInfo.stTranLog.ucDccOption==DCC_TYPE_DCC)
	{
	    PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTotalAmt);
		App_ConvAmountDccTran(szTotalAmt, szBuff, 0);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", szBuff);//1111
	}

	// Local Amount
	//when env file has a tag called MERTYPE it must print tips. linzhao
	if(((0==GetEnv("MERTYPE", szMerType) && '0' == szMerType[0])))
	{
//		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
//		App_ConvAmountLocal(szTotalAmt, szBuff, 0);
		App_ConvAmountLocal(glProcInfo.stTranLog.szTipAmount, szBuff, 0);
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
		App_ConvAmountLocal(glProcInfo.stTranLog.szAmount, szBuff, 0);///2222
	}
	else if (!ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee))
	{
	    uchar szTotalAmt2[12+1];

		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt2);
		PubAscAdd(szTotalAmt2, glProcInfo.stTranLog.szSurFee, 12, szTotalAmt);
	    App_ConvAmountLocal(szTotalAmt, szBuff, 0);
	}
	else if (!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) )//linzhao 20160112
	{
	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	    App_ConvAmountLocal(szTotalAmt, szBuff, 0);
	}
	else
	{
		App_ConvAmountLocal(glProcInfo.stTranLog.szAmount, szBuff, 0);
	}

	if( glProcInfo.stTranLog.uiStatus & TS_VOID )
	{
		int kok=0;

		 memset(	szBuffCurrency,0,sizeof(szBuffCurrency)  );
		 memset(	szBuffAmount,0,sizeof(szBuffAmount)  );


		if (strlen(szBuff)>=4)
		{

				strncpy(szBuffCurrency, szBuff, 4);


				for (kok=4;kok<strlen(szBuff);kok++)
				{
					szBuffAmount[kok-4]=szBuff[kok];
				}
				szBuffAmount[strlen(szBuff)]='\0';

		}

		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s-%s\n",szBuffCurrency, szBuffAmount);


	//MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);


	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
	}

}

// print product descriptor
void PrnDescriptor(void)
{
	uchar	ucCnt, ucMaxNum, ucTemp;
	uchar	szBuf[50];

	if( ChkIfDccAcquirer() )
	{
		return;
	}

	ucMaxNum = (uchar)MIN(MAX_GET_DESC, glProcInfo.stTranLog.ucDescTotal);
	for(ucCnt=0; ucCnt<ucMaxNum; ucCnt++)
	{
		ucTemp = glProcInfo.stTranLog.szDescriptor[ucCnt] - '0';
		PubASSERT( ucTemp<MAX_DESCRIPTOR );
		memset(szBuf, 0, sizeof(szBuf));
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %-20.20s\n", glSysParam.stDescList[ucTemp].szText);
	}

	if (!ChkIfThermalPrinter())
	{
		if( (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) || ChkEdcOption(EDC_FREE_PRINT) )
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n");
		}
		else
		{
			for(; ucCnt<MAX_GET_DESC; ucCnt++)
			{
			    FtPrn();
			}
		}
	}
}

void PrnAdditionalPrompt(void)
{
	uchar	szBuf[50];

	if( !ChkAcqOption(ACQ_ADDTIONAL_PROMPT) && !ChkAcqOption(ACQ_AIR_TICKET) )
	{
		return;
	}

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%-14.14s",  glSysParam.stEdcInfo.szAddlPrompt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%16.16s\n", glProcInfo.stTranLog.szAddlPrompt);
}

void PrnStatement(void)
{
	if( glProcInfo.stTranLog.ucTranType==INSTALMENT )
	{
		if( ChkIfBea() )
		{
		    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", _T("I ACCEPT THE T&C OVERLEAF"));
		}
	}
}

// print total information of ucIssuerKey
int PrnTotalIssuer(uchar ucIssuerKey)
{
	uchar	ucIndex, szBuff[20];
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	for(ucIndex=0; ucIndex<glSysParam.ucIssuerNum; ucIndex++)
	{
		if( glSysParam.stIssuerList[ucIndex].ucKey==ucIssuerKey )
		{
			break;
		}
	}
	memcpy(&glPrnTotal, &glIssuerTotal[ucIndex], sizeof(TOTAL_INFO));

	if( ChkIfZeroTotal(&glPrnTotal) )
	{
		return 0;
	}
	
	ConvIssuerName(glSysParam.stIssuerList[ucIndex].szName, szBuff);
	if( ChkIfThermalPrinter() )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s  : %-10.10s\n", _T("ISSUER"), szBuff);
	}
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s  : %-10.10s\n", (char *)_T("ISSUER"), szBuff);
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "  %s  : %-10.10s\n", _T("ISSUER"), szBuff);
	}

	PrnTotalInfo(&glPrnTotal);

	return 0;
}

int PrnTotalIssuer_Details(uchar ucIssuerKey)
{
	uchar	ucIndex, szBuff[20];
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	for(ucIndex=0; ucIndex<glSysParam.ucIssuerNum; ucIndex++)
	{
		if( glSysParam.stIssuerList[ucIndex].ucKey==ucIssuerKey )
		{
			break;
		}
	}
	memcpy(&glPrnTotal, &glIssuerTotal[ucIndex], sizeof(TOTAL_INFO));

	if( ChkIfZeroTotal(&glPrnTotal) )
	{
		return 0;
	}

	ConvIssuerName(glSysParam.stIssuerList[ucIndex].szName, szBuff);
	if( ChkIfThermalPrinter() )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s  : %-10.10s\n", _T("ISSUER"), szBuff);
	}
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s  : %-10.10s\n", (char *)_T("ISSUER"), szBuff);
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "  %s  : %-10.10s\n", _T("ISSUER"), szBuff);
	}

	PrnTotalInfo_Details(&glPrnTotal);

	return 0;
}

// print total information
void PrnTotalInfo(const void *pstInfo)
{
	uchar		szBuff[50] = {0,}, szBaseAmt[20] = {0,};
	TOTAL_INFO	*pstTotal = NULL;
	uchar szEnableFee[8] = {0,};

	pstTotal = (TOTAL_INFO *)pstInfo;
	PubAscSub(pstTotal->szSaleAmt, pstTotal->szTipAmt, 12, szBaseAmt);
	OsLog(LOG_ERROR, "%s--%d, szBaseAmt:%s", __FILE__, __LINE__, szBaseAmt);
	//linzhao 20160202
	if(0==GetEnv("E_FEE", szEnableFee) && 0!=atoi(szEnableFee))
	{
	    uchar szTemp[20] = {0, };
	    PubAscSub(szBaseAmt, pstTotal->szFeeAmt, 12, szTemp);
	    strcpy(szBaseAmt, szTemp);
	}

	OsLog(LOG_ERROR, "%s--%d, szBaseAmt:%s", __FILE__, __LINE__, szBaseAmt);
	App_ConvAmountTran(szBaseAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("BASE"), pstTotal->uiSaleCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szTipAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("TIPS"), pstTotal->uiTipCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);


    if(0==GetEnv("E_FEE", szEnableFee) && 0!=atoi(szEnableFee))
    {
        App_ConvAmountTran(pstTotal->szFeeAmt, szBuff, 0);
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("FEE"), pstTotal->uiFeeCnt);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
    }

	App_ConvAmountTran(pstTotal->szSaleAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("SALES"), pstTotal->uiSaleCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szRefundAmt, szBuff, GA_NEGATIVE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("REFUND"), pstTotal->uiRefundCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szVoidSaleAmt, szBuff, GA_NEGATIVE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("VOID SALES"), pstTotal->uiVoidSaleCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szVoidRefundAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("VOID REFUND"), pstTotal->uiVoidRefundCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "----------------------------------------------");
	App_ConvAmountTran(pstTotal->szSaleAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("NET TOTAL"), pstTotal->uiSaleCnt);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n\n", szBuff);
}


void PrnTotalInfo_Details(const void *pstInfo)
{

	double dblTemp=0.0;
	uchar		szBuff[50] = {0,}, szBaseAmt[20] = {0,};
	TOTAL_INFO	*pstTotal = NULL;
	uchar szEnableFee[8] = {0,};

	pstTotal = (TOTAL_INFO *)pstInfo;
	PubAscSub(pstTotal->szSaleAmt, pstTotal->szTipAmt, 12, szBaseAmt);
	OsLog(LOG_ERROR, "%s--%d, szBaseAmt:%s", __FILE__, __LINE__, szBaseAmt);
	//linzhao 20160202
	if(0==GetEnv("E_FEE", szEnableFee) && 0!=atoi(szEnableFee))
	{
	    uchar szTemp[20] = {0, };
	    PubAscSub(szBaseAmt, pstTotal->szFeeAmt, 12, szTemp);
	    strcpy(szBaseAmt, szTemp);
	}
///==============

//	uchar		szSaleAmt[12+1];	// base amount + tip amount
//	uchar		szTipAmt[12+1];
//	uchar       szFeeAmt[12+1];
//	uchar		szRefundAmt[12+1];
//	uchar		szVoidSaleAmt[12+1];
//	uchar		szVoidRefundAmt[12+1];



	////===========
	OsLog(LOG_ERROR, "%s--%d, szBaseAmt:%s", __FILE__, __LINE__, szBaseAmt);
	App_ConvAmountTran(szBaseAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("BASE"), pstTotal->uiSaleCnt);

	g_AR_BASE = g_AR_BASE + pstTotal->uiSaleCnt ;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szTipAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("TIPS"), pstTotal->uiTipCnt);

	g_AR_TIPS = g_AR_TIPS + pstTotal->uiTipCnt;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);


    if(0==GetEnv("E_FEE", szEnableFee) && 0!=atoi(szEnableFee))
    {
        App_ConvAmountTran(pstTotal->szFeeAmt, szBuff, 0);
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("FEE"), pstTotal->uiFeeCnt);

        g_AR_FEE =  g_AR_FEE+  pstTotal->uiFeeCnt ;

        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
    }

	App_ConvAmountTran(pstTotal->szSaleAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("SALES"), pstTotal->uiSaleCnt);


	g_AR_SALES =g_AR_SALES + pstTotal->uiSaleCnt  ;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szRefundAmt, szBuff, GA_NEGATIVE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("REFUND"), pstTotal->uiRefundCnt);


	g_AR_REFUND =g_AR_REFUND +pstTotal->uiRefundCnt;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szVoidSaleAmt, szBuff, GA_NEGATIVE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s :%-03d", _T("VOID SALES"), pstTotal->uiVoidSaleCnt);

	g_AR_VOID_SALES = g_AR_VOID_SALES + pstTotal->uiVoidSaleCnt ;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);

	App_ConvAmountTran(pstTotal->szVoidRefundAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("VOID REFUND"), pstTotal->uiVoidRefundCnt);
	g_AR_VOID_REFUND = g_AR_VOID_REFUND +pstTotal->uiVoidRefundCnt ;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n", szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "----------------------------------------------");
	App_ConvAmountTran(pstTotal->szSaleAmt, szBuff, 0);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s :%-03d", _T("NET TOTAL"), pstTotal->uiSaleCnt);

	 g_AR_NET_TOTAL =  g_AR_NET_TOTAL + pstTotal->uiSaleCnt ;

	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s\n\n", szBuff);


	 g_AR_NET_Total_SUM_TOTAL = g_AR_NET_Total_SUM_TOTAL + atof( pstTotal->szSaleAmt)/1000.0 ;

	g_AR_NET_Base_SUM_TOTAL += atof(szBaseAmt)/1000.0 ;

	  g_AR_NET_Tip_SUM_TOTAL += atof( pstTotal->szTipAmt)/1000.0 ;
	  g_AR_NET_Fee_SUM_TOTAL += atof( pstTotal->szFeeAmt )/1000.0 ;
	  g_AR_NET_Refund_SUM_TOTAL += atof( pstTotal->szRefundAmt)/1000.0 ;
	  g_AR_NET_VoidSale_SUM_TOTAL += atof( pstTotal->szVoidSaleAmt)/1000.0 ;
	  g_AR_NET_VoidRefund_SUM_TOTAL += atof( pstTotal->szVoidRefundAmt)/1000.0 ;


	  //g_AR_NET_Total_SUM_TOTAL = g_AR_NET_Total_SUM_TOTAL + g_AR_NET_Base_SUM_TOTAL+ g_AR_NET_Fee_SUM_TOTAL-( g_AR_NET_Refund_SUM_TOTAL+ g_AR_NET_VoidSale_SUM_TOTAL +g_AR_NET_VoidRefund_SUM_TOTAL );


}

void PrnGrandTotalInfo_Details(void)
{
	uchar		szBuff[50] = {0,}, szBaseAmt[20] = {0,};
	uchar		szBuffAmount[12] = {0,};
	uchar szEnableFee[8] = {0,};


///==============


	PrnInit();
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n%s\n", "================================================");
	MultiLngPrnStr(FT_ALIGN_CENTER,  25, "%s\n", _T("GRAND TOTAL"));

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s :%d", _T("BASE"), g_AR_BASE);
	MultiLngPrnStr(FT_ALIGN_RIGHT,  PRN_SIZE_LARGE,"%.3f\n", g_AR_NET_Base_SUM_TOTAL);






	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s :%d", _T("TIPS"), g_AR_TIPS);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE,"%.3f\n", g_AR_NET_Tip_SUM_TOTAL );







    if(0==GetEnv("E_FEE", szEnableFee) && 0!=atoi(szEnableFee))
    {

        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s :%d", _T("FEE"),  g_AR_FEE);
        MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%.3f\n",g_AR_NET_Fee_SUM_TOTAL  );

    }


	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s :%d", _T("SALES"), g_AR_SALES);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "%.3f\n",g_AR_NET_Total_SUM_TOTAL);




	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s :%d", _T("REFUND"),g_AR_REFUND);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_LARGE, "-%.3f\n",g_AR_NET_Refund_SUM_TOTAL );


	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_LARGE, "%s :%d", _T("VOID SALES"), g_AR_VOID_SALES);
	MultiLngPrnStr(FT_ALIGN_RIGHT,PRN_SIZE_LARGE,"-%.3f\n", g_AR_NET_VoidSale_SUM_TOTAL );


	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s :%d", _T("VOID REFUND"), g_AR_VOID_REFUND);
	MultiLngPrnStr(FT_ALIGN_RIGHT,  PRN_SIZE_LARGE,"%.3f\n", g_AR_NET_VoidRefund_SUM_TOTAL  );


//	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", "----------------------------------------------");
//	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_LARGE, "%s :%d", _T("TOTAL"),g_AR_NET_TOTAL);




//	MultiLngPrnStr(FT_ALIGN_RIGHT,  PRN_SIZE_LARGE, "%.3f\n", g_AR_NET_Total_SUM_TOTAL);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n%s\n\n", "************************************************");
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "END OF GRAND TOTAL\n\n\n\n\n\n\n\n");
	StartPrinter();

}

int PrnTotalAcq(void)
{
	uchar	ucCnt;
	int		iRet;
	uchar   szDateTime[14+1];
	uchar   szBuff[50];
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	PrnInit();
	glProcInfo.stTranLog.ucTranType = MAX_TRANTYPE;//linzhao 20151029


	PrnStep(30);

	if( ChkIfThermalPrinter() )
	{
	    PrnHead_T();
	}
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		PrnHead_BT();
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n", glCurAcq.szTermID, glCurAcq.szMerchantID);
		PrnStep(15);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "  %s: %-10.10s\n", _T("ACQUIRER"), glCurAcq.szName);
	}

	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "DATE: %-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "TIME: %5.6s\n",  szBuff+14);

	PrnStep(5);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n",  _T("TRANS TOTALS BY ISSUER"));
	PrnStep(15);

	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", _T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%6.6d\n", glCurAcq.ulCurBatchNo);
	PrnStep(30);

	OsLog(LOG_INFO, "%s-%d, glSysParam.ucIssuerNum=%d", __FILE__, __LINE__, glSysParam.ucIssuerNum);
	for(ucCnt=0; ucCnt<glSysParam.ucIssuerNum; ucCnt++)
	{
		OsLog(LOG_INFO, "%s-%d, ucCnt=%d, glCurAcq.sIssuerKey[ucCnt]=%d", __FILE__, __LINE__, ucCnt, glCurAcq.sIssuerKey[ucCnt]);
		if( glCurAcq.sIssuerKey[ucCnt]!=INV_ISSUER_KEY )
		{
			OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
			PrnTotalIssuer(glCurAcq.sIssuerKey[ucCnt]);
		}
		if( (ucCnt%5)==4 )
		{
			iRet = StartPrinter();
			if( iRet!=0 )
			{
				return iRet;
			}
			PrnInit();
			PrnSetNormal();
		}
	}
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", (char *)_T("END  OF  TOTAL"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	StartPrinter();

	return 0;
}

int PrnTotalAcq_Details(void)
{
	uchar	ucCnt;
	int		iRet;
	uchar   szDateTime[14+1];
	uchar   szBuff[50];
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	PrnInit();
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n%s\n", "================================================");
	glProcInfo.stTranLog.ucTranType = MAX_TRANTYPE;//linzhao 20151029


	PrnStep(30);

	if( ChkIfThermalPrinter() )
	{
	    PrnHead_T();
	}
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		PrnHead_BT();
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%14.8s\n%21.15s\n", glCurAcq.szTermID, glCurAcq.szMerchantID);
		PrnStep(15);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "  %s: %-10.10s\n", _T("ACQUIRER"), glCurAcq.szName);
	}

	// Date, time of print audit
	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "DATE: %-12.13s", szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "TIME: %5.6s\n",  szBuff+14);

	PrnStep(5);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n",  _T("TRANS TOTALS BY ISSUER"));
	PrnStep(15);

	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s:", _T("BATCH"));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%6.6d\n", glCurAcq.ulCurBatchNo);
	PrnStep(30);

	OsLog(LOG_INFO, "%s-%d, glSysParam.ucIssuerNum=%d", __FILE__, __LINE__, glSysParam.ucIssuerNum);
	for(ucCnt=0; ucCnt<glSysParam.ucIssuerNum; ucCnt++)
	{
		OsLog(LOG_INFO, "%s-%d, ucCnt=%d, glCurAcq.sIssuerKey[ucCnt]=%d", __FILE__, __LINE__, ucCnt, glCurAcq.sIssuerKey[ucCnt]);
		if( glCurAcq.sIssuerKey[ucCnt]!=INV_ISSUER_KEY )
		{
			OsLog(LOG_INFO, "%s-%d", __FILE__, __LINE__);
			PrnTotalIssuer_Details(glCurAcq.sIssuerKey[ucCnt]);
		}
		if( (ucCnt%5)==4 )
		{
			iRet = StartPrinter();
			if( iRet!=0 )
			{
				return iRet;
			}
			PrnInit();
			PrnSetNormal();
		}
	}
//	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
//	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, " \n");
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", (char *)_T("END  OF  TOTAL"));
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	StartPrinter();

	return 0;
}

int PrintSettle(uchar ucPrnFlag)
{
	ulong ulInvoice;
	uchar szBuff[50] = {0};
	//====Stop Printer============
	 //  if ( MirroringCheckEcr())
    //	    {
		  // 	   	   	   	   return  0 ;
		//    }
	 //===========================
	if( ucPrnFlag==PRN_NORMAL )
	{
		// save settle information for reprint
		glSysCtrl.stRePrnStlInfo.bValid[glCurAcq.ucIndex]    = TRUE;
		glSysCtrl.stRePrnStlInfo.ulSOC[glCurAcq.ucIndex]     = glSysCtrl.ulInvoiceNo;
		glSysCtrl.stRePrnStlInfo.ulBatchNo[glCurAcq.ucIndex] = glCurAcq.ulCurBatchNo;
		sprintf((char *)glSysCtrl.stRePrnStlInfo.szSettleMsg[glCurAcq.ucIndex], "%s", glProcInfo.szSettleMsg);
		memcpy(&glSysCtrl.stRePrnStlInfo.stAcqTotal[glCurAcq.ucIndex], &glAcqTotal[glCurAcq.ucIndex], sizeof(TOTAL_INFO));
		memcpy(glSysCtrl.stRePrnStlInfo.stIssTotal[glCurAcq.ucIndex], glIssuerTotal, sizeof(glIssuerTotal));
		SaveRePrnStlInfo();
	}

	PrnInit();

	if( ChkIfThermalPrinter() )
	{
		PrnHead_T();
	}
	else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
	{
		PrnHead_BT();
	}
	else
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n\n");
		PrnHead(FALSE);
	}

	// Date, time
	Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-12.13s", _T("DATE: "), szBuff);
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.6s\n",  _T("TIME: "), szBuff+14);

	// Batch NO.
	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s",    _T("BATCH: "));
	MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL,  "%06lu\n",      glCurAcq.ulCurBatchNo);

	PrnStep(20);

	MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s\n",    _T("GRAND TOTALS"));

	PrnTotalInfo(&glTransTotal);

	MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("SETTLEMENT APPROVED"));

	if( ucPrnFlag==PRN_REPRINT )
	{
	    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n%s", _T("REPRINT"));
	}
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	return StartPrinter();
}


//leen foura
int PrintSettleREP(uchar ucPrnFlag)
{
    ulong ulInvoice;
    uchar szBuff[50] = {0};

    if( ucPrnFlag==PRN_NORMAL )
    {
        // save settle information for reprint
        glSysCtrl.stRePrnStlInfo.bValid[glCurAcq.ucIndex]    = TRUE;
        glSysCtrl.stRePrnStlInfo.ulSOC[glCurAcq.ucIndex]     = glSysCtrl.ulInvoiceNo;
        glSysCtrl.stRePrnStlInfo.ulBatchNo[glCurAcq.ucIndex] = glCurAcq.ulCurBatchNo;
        sprintf((char *)glSysCtrl.stRePrnStlInfo.szSettleMsg[glCurAcq.ucIndex], "%s", glProcInfo.szSettleMsg);
        memcpy(&glSysCtrl.stRePrnStlInfo.stAcqTotal[glCurAcq.ucIndex], &glAcqTotal[glCurAcq.ucIndex], sizeof(TOTAL_INFO));
        memcpy(glSysCtrl.stRePrnStlInfo.stIssTotal[glCurAcq.ucIndex], glIssuerTotal, sizeof(glIssuerTotal));
        SaveRePrnStlInfo();
    }

    PrnInit();

    if( ChkIfThermalPrinter() )
    {
        PrnHead_TREP();
    }
    else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))
    {
        PrnHead_BT();
    }
    else
    {
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n\n\n");
        PrnHead(FALSE);
    }

    // Date, time
    Conv2EngTime(glProcInfo.stTranLog.szDateTime, szBuff);
    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL, "%s%-12.13s", _T("DATE: "), szBuff);
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "%s%5.6s\n",  _T("TIME: "), szBuff+14);

    // Batch NO.
    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s",    _T("BATCH: "));
    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL,  "%06lu\n",      glCurAcq.ulCurBatchNo);

    PrnStep(20);

    MultiLngPrnStr(FT_ALIGN_LEFT,  PRN_SIZE_NORMAL,  "%s\n",    _T("GRAND TOTALS"));

    PrnTotalInfo(&glTransTotal);

    MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
    MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", _T("SETTLEMENT APPROVED"));

    if( ucPrnFlag==PRN_REPRINT )
    {
        MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n%s", _T("REPRINT"));
    }
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
    return StartPrinter();
}
void PrnEngTime(void)
{
	uchar	szDateTime[14+1], szBuff[30];

	GetDateTime(szDateTime);
	Conv2EngTime(szDateTime, szBuff);
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n", szBuff);
}

// 打印终端参数
// Print parameter
int PrintParam(void)
{
	uchar	ucCnt;
	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return  0 ;
		    }
	 //===========================
	SetCurrTitle(_T("PRINT PARAMETER"));
	if( PasswordTerm()!=0 )
	{
		return ERR_NO_DISP;
	}

	SetOffBase(OffBaseCheckPrint);

	Gui_ClearScr();
	// Modified by Kim_LinHB 2014-8-11 v1.01.0003
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	PrnInit();
	PrnSetNormal();

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n\n%s\n", glSysParam.stEdcInfo.szMerchantName);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n",     glSysParam.stEdcInfo.szMerchantAddr);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.8s\n", _T("INIT TID"), glSysParam.stEdcInfo.szDownLoadTID);
	PrnHexString("EDC OPTION:", glSysParam.stEdcInfo.sOption, 5, TRUE);

	PrnEngTime();
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("APP VERSION"), EDC_VER_PUB);

	if (glSysParam.ucDescNum)
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:\n", _T("DESCRIPTION"));
		for(ucCnt=0; ucCnt<glSysParam.ucDescNum; ucCnt++)
		{
		    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "   %.2s:%.20s\n", glSysParam.stDescList[ucCnt].szCode,
					glSysParam.stDescList[ucCnt].szText);
		}
	}

	PrnInstalmentPara();

	for(ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		if( PrnParaAcq(ucCnt)==0 )
		{
			if( StartPrinter()!=0 )
			{
				return ERR_NO_DISP;
			}
			PrnInit();
			//PrnStep(20);
		}
	}
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	if( StartPrinter()!=0 )
	{
		return ERR_NO_DISP;
	}

	if (!ChkIfEmvEnable())
	{
		return 0;
	}

#ifdef ENABLE_EMV
	Gui_ClearScr();
	if(GUI_OK == Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRN EMV PARA ?"), gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL)){
		PrnEmvPara();
	}
#endif
	return 0;
}

int PrnParaAcq(uchar ucAcqIndex)
{
	PubASSERT(glSysParam.stAcqList[ucAcqIndex].ucKey!=INV_ACQ_KEY);
	if( glSysParam.stAcqList[ucAcqIndex].ucKey==INV_ACQ_KEY )
	{
		return 1;
	}

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n========================\n");
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%.3s  %.10s\n", glSysParam.stAcqList[ucAcqIndex].szNii,
			glSysParam.stAcqList[ucAcqIndex].szName);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.8s\n", _T("TID"), glSysParam.stAcqList[ucAcqIndex].szTermID);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %.15s\n", _T("MID"), glSysParam.stAcqList[ucAcqIndex].szMerchantID);
	PrnHexString("ACQ OPTION:", glSysParam.stAcqList[ucAcqIndex].sOption, 4, TRUE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s %.24s\n", _T("TXN TEL1"), glSysParam.stAcqList[ucAcqIndex].TxnTelNo1);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s %.24s\n", _T("TXN TEL2"), glSysParam.stAcqList[ucAcqIndex].TxnTelNo2);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s %.24s\n", _T("SET TEL1"), glSysParam.stAcqList[ucAcqIndex].StlTelNo1);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s %.24s\n", _T("SET TEL2"), glSysParam.stAcqList[ucAcqIndex].StlTelNo2);

	//tcp/ip
	if (strlen(glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[0].szIP) )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:\n", _T("TCP/IP PARAM"));
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s:%.5s\n",  _T("TXN 1"), glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[0].szIP,
	                                                glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[0].szPort);
	}
    if (strlen(glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[1].szIP) )
	{
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s:%.5s\n",  _T("TXN 2"), glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[1].szIP,
                                                glSysParam.stAcqList[ucAcqIndex].stTxnTCPIPInfo[1].szPort);
	}

    if (strlen(glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[0].szIP) )
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s:\n", _T("GPRS PARAM"));
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s:%.5s\n",  _T("TXN 1"), glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[0].szIP,
                                                       glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[0].szPort);
	}
    if (strlen(glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[1].szIP) )
	{
        MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s:%.5s\n",  _T("TXN 2"), glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[1].szIP,
                                                       glSysParam.stAcqList[ucAcqIndex].stTxnGPRSInfo[0].szPort);
	}

	PrnParaIssuer(ucAcqIndex);

	return 0;
}

void PrnParaIssuer(uchar ucAcqIndex)
{
	uchar	ucCnt;

	for(ucCnt=0; ucCnt<glSysParam.ucIssuerNum; ucCnt++)
	{
		if( glSysParam.stAcqList[ucAcqIndex].sIssuerKey[ucCnt]!=INV_ISSUER_KEY &&
		    glSysParam.stAcqList[ucAcqIndex].sIssuerKey[ucCnt]!=0)
		{
			PrnParaIssuerSub(glSysParam.stAcqList[ucAcqIndex].sIssuerKey[ucCnt]);
		}
	}
}

void PrnParaIssuerSub(uchar ucIssuerKey)
{
	uchar	ucCnt, szBuff[20];

	if( ucIssuerKey==INV_ISSUER_KEY )
	{
		return;
	}

	for(ucCnt=0; ucCnt<glSysParam.ucIssuerNum; ucCnt++)
	{
		if( glSysParam.stIssuerList[ucCnt].ucKey==ucIssuerKey )
		{
			break;
		}
	}
	PubASSERT( ucCnt<glSysParam.ucIssuerNum );
	if( ucCnt>=glSysParam.ucIssuerNum )
	{
	    //OsLog(LOG_ERROR, "%d", ucIssuerKey);
		return;
	}

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\n---%s: %-10.10s---\n", _T("ISSUER"), glSysParam.stIssuerList[ucCnt].szName);
	PrnHexString("ISSUER OPTION:", glSysParam.stIssuerList[ucCnt].sOption, 4, TRUE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %02x %02x %02x\n", _T("PAN MASK"),
			(uchar)(0xFF^glSysParam.stIssuerList[ucCnt].sPanMask[0]),
			(uchar)(0xFF^glSysParam.stIssuerList[ucCnt].sPanMask[1]),
			(uchar)(0xFF^glSysParam.stIssuerList[ucCnt].sPanMask[2]));

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %lu\n", _T("FLOOR LIMIT"), glSysParam.stIssuerList[ucCnt].ulFloorLimit);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %d%%\n", _T("ADJUSTMENT PERCENT"), glSysParam.stIssuerList[ucCnt].ucAdjustPercent);

	PrnIssuerOption(glSysParam.stIssuerList[ucCnt].sOption);
	PrnCardTable(ucIssuerKey);
}

void PrnIssuerOption(const uchar *psOption)
{
	static	OPTION_INFO	stIssuerOptList[] =
	{
// 		{"ENABLE BALANCE?",		ISSUER_EN_BALANCE},
		{"ENABLE ADJUST",		ISSUER_EN_ADJUST,			FALSE,	PM_MEDIUM},
		{"ENABLE OFFLINE",		ISSUER_EN_OFFLINE,			FALSE,	PM_MEDIUM},
		{"EN. (PRE)AUTH",		ISSUER_NO_PREAUTH,			TRUE,	PM_MEDIUM},
		{"EN. REFUND",			ISSUER_NO_REFUND,			TRUE,	PM_MEDIUM},
		{"EN. VOID",			ISSUER_NO_VOID,				TRUE,	PM_MEDIUM},
// 		{"ENABLE EXPIRY",		ISSUER_EN_EXPIRY,			FALSE,	PM_MEDIUM},
// 		{"CHECK EXPIRY",		ISSUER_CHECK_EXPIRY,		FALSE,	PM_MEDIUM},
// 		{"CHKEXP OFFLINE",		ISSUER_CHECK_EXPIRY_OFFLINE,FALSE,	PM_MEDIUM},
// 		{"CHECK PAN",			ISSUER_CHKPAN_MOD10,		FALSE,	PM_MEDIUM},
// 		{"EN DISCRIPTOR",		ISSUER_EN_DISCRIPTOR,		FALSE,	PM_MEDIUM},
		{"ENABLE MANUAL",		ISSUER_EN_MANUAL,			FALSE,	PM_MEDIUM},
// 		{"ENABLE PRINT",		ISSUER_EN_PRINT,			FALSE,	PM_MEDIUM},
		{"VOICE REFERRAL",		ISSUER_EN_VOICE_REFERRAL,	FALSE,	PM_MEDIUM},
// 		{"PIN REQUIRED",		ISSUER_EN_PIN,				FALSE,	PM_MEDIUM},
// 		{"ACCOUNT SELECT",		ISSUER_EN_ACCOUNT_SELECTION,FALSE,	PM_MEDIUM},
// 		{"ROC INPUT REQ",		ISSUER_ROC_INPUT_REQ,		FALSE,	PM_MEDIUM},
// 		{"DISP AUTH CODE",		ISSUER_AUTH_CODE,			FALSE,	PM_MEDIUM},
// 		{"ADDTIONAL DATA",		ISSUER_ADDTIONAL_DATA,		FALSE,	PM_MEDIUM},
		{"SECURITY CODE",		ISSUER_SECURITY_SWIPE,		FALSE,	PM_MEDIUM},
		{"SECU. CODE MANUL",	ISSUER_SECURITY_MANUL,		FALSE,	PM_MEDIUM},
		{NULL, 0, FALSE, PM_MEDIUM},
	};
	uchar	ucCnt;

	for(ucCnt=0; stIssuerOptList[ucCnt].pText!=NULL; ucCnt++)
	{
	    MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "    %s", stIssuerOptList[ucCnt].pText);
		if( (!stIssuerOptList[ucCnt].ucInverseLogic && ChkOptionExt(psOption, stIssuerOptList[ucCnt].uiOptVal)) ||
			(stIssuerOptList[ucCnt].ucInverseLogic && !ChkOptionExt(psOption, stIssuerOptList[ucCnt].uiOptVal)) )
		{
		    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "[ on]\n");
		}
		else
		{
		    MultiLngPrnStr(FT_ALIGN_RIGHT, PRN_SIZE_NORMAL, "[off]\n");
		}
	}
}

void PrnCardTable(uchar ucIssuerKey)
{
	uchar	ucCnt, szBuff[30];

	if( ucIssuerKey==INV_ISSUER_KEY )
	{
		return;
	}

	for(ucCnt=0; ucCnt<glSysParam.ucCardNum; ucCnt++)
	{
		if( glSysParam.stCardTable[ucCnt].ucIssuerKey==ucIssuerKey )
		{
			PubBcd2Asc0(glSysParam.stCardTable[ucCnt].sPanRangeLow, 5, szBuff);
			szBuff[10] = '~';
			PubBcd2Asc0(glSysParam.stCardTable[ucCnt].sPanRangeHigh, 5, &szBuff[11]);
			MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", szBuff);
		}
	}
}

int PrnInstalmentPara(void)
{
	uchar	ucCnt, szBuff[20], szBuff1[50], ucAcqIndex;

	if( !ChkIfInstalmentPara() )
	{
		return 1;
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n======== %s =======\n", _T("INSTALMENT"));
	for(ucCnt=0; ucCnt<glSysParam.ucPlanNum; ucCnt++)
	{
		PubASSERT( glSysParam.stPlanList[ucCnt].ucIndex!=0xFF );
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%02d.%-7.7s - %dmths\n", ucCnt+1, glSysParam.stPlanList[ucCnt].szName,
				glSysParam.stPlanList[ucCnt].ucMonths);

		sprintf((char *)szBuff, "%lu", glSysParam.stPlanList[ucCnt].ulBottomAmt);
		App_ConvAmountLocal(szBuff, szBuff1, 0);
		ucAcqIndex = glSysParam.stPlanList[ucCnt].ucAcqIndex;
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%-10.10s  %s\n", glSysParam.stAcqList[ucAcqIndex].szName, szBuff1);
	}

	return 0;
}

#ifdef ENABLE_EMV
// 打印EMV参数
// Print EMV parameter
int PrnEmvPara(void)
{
	int			iRet, iCnt;
	EMV_APPLIST	stEmvApp;
	EMV_CAPK	stEmvCapk;

	PrnInit();
	PrnSetNormal();

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n========= %s =======\n", _T("EMV PARAMETER"));
	EMVGetParameter(&glEmvParam);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %02X\n", _T("TERMINAL TYPE"), glEmvParam.TerminalType);
	PrnHexString("TERMINAL CAPA:",  glEmvParam.Capability, 3, TRUE);
	PrnHexString("TERM EX-CAPA :",  glEmvParam.ExCapability, 5, TRUE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %02X\n", _T("TXN CURR EXP "), glEmvParam.TransCurrExp);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %02X\n", _T("REF CURR EXP "), glEmvParam.ReferCurrExp);
	PrnHexString("REF CURR CODE:", glEmvParam.ReferCurrCode, 2, TRUE);
	PrnHexString("COUNTRY CODE :", glEmvParam.CountryCode, 2, TRUE);
	PrnHexString("TXN CURR CODE:", glEmvParam.TransCurrCode, 2, TRUE);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %ld\n", _T("REF CURR CON "), glEmvParam.ReferCurrCon);
	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n",  _T("SELECT PSE   "), glEmvParam.SurportPSESel ? _T("YES") : _T("NO"));

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n\n\n======== %s =========\n", _T("EMV APP LIST"));
	for(iCnt=0; iCnt<MAX_APP_NUM; iCnt++)
	{
		memset(&stEmvApp, 0, sizeof(EMV_APPLIST));
		iRet = ReadAIDFile(iCnt, &stEmvApp);
		if( iRet!=EMV_OK )
		{
			continue;
		}
		PrnHexString("AID:",  stEmvApp.AID, (int)stEmvApp.AidLen, TRUE);
		PrnHexString("VERSION:",  stEmvApp.Version, 2, TRUE);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s MATCH\n", _T("SELECT FLAG   "), stEmvApp.SelFlag==FULL_MATCH ? _T("FULL") : _T("PARTIAL"));
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %d\n", _T("PRIORITY      "), stEmvApp.Priority);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %d\n", _T("TARGET PER    "), stEmvApp.TargetPer);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %d\n", _T("MAX TARGET PER"), stEmvApp.MaxTargetPer);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("CHECK FLOOR   "), stEmvApp.FloorLimitCheck ? _T("YES") : _T("NO"));
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("RANDOM SELECT "), stEmvApp.RandTransSel    ? _T("YES") : _T("NO"));
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %s\n", _T("CHECK VELOCITY"), stEmvApp.VelocityCheck   ? _T("YES") : _T("NO"));
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %lu\n", _T("FLOOR LIMIT   "), stEmvApp.FloorLimit);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %lu\n", _T("THRESHOLD     "), stEmvApp.Threshold);
		PrnHexString("TAC DENIAL :",  stEmvApp.TACDenial,  5, TRUE);
		PrnHexString("TAC ONLINE :",  stEmvApp.TACOnline,  5, TRUE);
		PrnHexString("TAC DEFAULT:",  stEmvApp.TACDefault, 5, TRUE);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "-----------------------------\n");
		if( (iCnt%5)==0 )
		{
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			PrnInit();
		}
	}

	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n\n========= %s ========\n", _T("EMV CAPK LIST"));
	for(iCnt=0; iCnt<MAX_KEY_NUM; iCnt++)
	{
		memset(&stEmvCapk, 0, sizeof(EMV_CAPK));
		iRet = ReadCAPKFile(iCnt, &stEmvCapk);
		if( iRet!=EMV_OK )
		{
			continue;
		}
		PrnHexString("RID:",  stEmvCapk.RID, 5, TRUE);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, " %s: %02X\n", _T("ID"), stEmvCapk.KeyID);
// 		PrnStr("HASH   : %02X\n",  stEmvCapk.HashInd);
// 		PrnStr("ARITH  : %02X\n",  stEmvCapk.ArithInd);
		PrnHexString("EXP DATE:",  stEmvCapk.ExpDate, 3, TRUE);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s: %d\n",  _T("MOD LEN"), (int)(8 * stEmvCapk.ModulLen));
		PrnHexString("EXPONENT:",  stEmvCapk.Exponent, (int)stEmvCapk.ExponentLen, TRUE);
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "-----------------------------\n");
		if( (iCnt%5)==0 )
		{
// 			PrnStr("\f");
			if( StartPrinter()!=0 )
			{
				return 1;
			}
			PrnInit();
		}
	}
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	return StartPrinter();
}

void PrintEmvErrLogSub(void)
{
	ushort			uiCnt, uiActNum, uiTemp;
	uchar			szBuff[50];
	EMV_ERR_LOG		stErrLog;

	//====Stop Printer============
	   if ( MirroringCheckEcr())
    	    {
		   	   	   	   	   return   ;
		    }
	 //===========================

	PrnInit();
	PrnSetNormal();
	MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s\n\n", _T("EMV ERROR LOG"));

	for(uiActNum=uiCnt=0; uiCnt<MAX_ERR_LOG; uiCnt++)
	{
		memset(&stErrLog, 0, sizeof(EMV_ERR_LOG));
		LoadErrLog(uiCnt, &stErrLog);
		if( !stErrLog.bValid )
		{
			continue;
		}

		uiActNum++;
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "\nSTAN: %06lu\n", stErrLog.ulSTAN);
		PubBcd2Asc0(stErrLog.sAID, stErrLog.ucAidLen, szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "AID: %s\n", szBuff);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "PAN: %s\n", stErrLog.szPAN);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "PAN SEQ #: %02X\n", stErrLog.ucPANSeqNo);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "AMT: %.12s\n", stErrLog.szAmount);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "TIP: %.12s\n", stErrLog.szTipAmt);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "RSP: %.2s\n",  stErrLog.szRspCode);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "RRN: %.12s\n", stErrLog.szRRN);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "AUT: %.6s\n",  stErrLog.szAuthCode);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "TVR: %02X %02X %02X %02X %02X\n", stErrLog.sTVR[0], stErrLog.sTVR[1],
					   stErrLog.sTVR[2], stErrLog.sTVR[3], stErrLog.sTVR[4]);
		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "TSI: %02X %02X\n", stErrLog.sTSI[0], stErrLog.sTSI[1]);

		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "REQ BIT 55:\n");
		for(uiTemp=0; uiTemp<stErrLog.uiReqICCDataLen; uiTemp++)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "%02X %s", stErrLog.sReqICCData[uiTemp], (uiTemp%8)==7 ? "\n" : "");
		}
		if(uiTemp>0)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "\n");
		}

		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "REQ BIT 56:\n");
		for(uiTemp=0; uiTemp<stErrLog.uiReqField56Len; uiTemp++)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "%02X %s", stErrLog.sReqField56[uiTemp], (uiTemp%8)==7 ? "\n" : "");
		}
		if(uiTemp>0)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "\n");
		}

		MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "RSP BIT 55:\n");
		for(uiTemp=0; uiTemp<stErrLog.uiRspICCDataLen; uiTemp++)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "%02X %s", stErrLog.sRspICCData[uiTemp], (uiTemp%8)==7 ? "\n" : "");
		}
		if(uiTemp>0)
		{
			MultiLngPrnStr(FT_ALIGN_NONE, PRN_SIZE_NORMAL, "\n");
		}

		if( (uiActNum%5)==4 )
		{
			if( StartPrinter()!=0 )
			{
				return;
			}

			PrnInit();
			PrnSetNormal();
		}
	}

	if (uiActNum>0)
	{
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "%s", (ChkIfThermalPrinter() ? "\n" : "\f"));
	}
	else
	{
		MultiLngPrnStr(FT_ALIGN_CENTER, PRN_SIZE_NORMAL, "\n  ( NO RECORD )");
	}
#ifndef TEST_SMS
    if(!ChkHardware(HWCFG_PRINTER, 0))
        MultiLngPrnStr(FT_ALIGN_LEFT,   PRN_SIZE_NORMAL, "\n\n\n\n");
#endif
	StartPrinter();
}
#endif


void PrnHexString(const char *pszTitle, const uchar *psHexStr, int iLen, uchar bNewLine)
{
	int		iCnt;

	MultiLngPrnStr(FT_ALIGN_LEFT, PRN_SIZE_NORMAL, "%s\n", pszTitle);

	FtFontSize(PRN_SIZE_NORMAL);
	for(iCnt=0; iCnt<iLen; iCnt++)
	{
	    if(iCnt % 8 == 0){
	        FtFontAlign(FT_ALIGN_LEFT);
	    }
	    else{
	        FtFontAlign(FT_ALIGN_NONE);
	    }
		FtPrnStr(" %02X", psHexStr[iCnt]);
		if(iCnt % 8 == 7){
		    FtPrn();
		}
	}
	if (bNewLine)
	{
	    FtPrn();
	}
}

//added by Kevin 20150720
//this function only provide EMP logo buf create, please modify it if different
int BT_Ft_CreateSendBuf(uchar *printBuf, int type)
{
	int bufLen = 0;
	int i = 0;
	int lineNum = 0;
	unsigned char *curPos;
	int strLen = 0;

	lineNum = PubChar2Long(printBuf, 1);
	OsLog(LOG_INFO, "lineNum=%d", lineNum);

	curPos = printBuf+1;

	memset(cBuf, 0 ,sizeof(cBuf));
	curBuf = cBuf;
	totalLen = 0;

	totalLen = totalLen + 48*lineNum;
	for(i=0; i<lineNum; i++)
	{
		strLen = PubChar2Long(curPos, 2);
		OsLog(LOG_INFO, "strLen = %d", strLen);
		if(strLen <= 48)
		{
			if(0 == type)
			{
//				memcpy(curBuf, curPos+2, strLen);
				memcpy(curBuf+(48-22)/2, curPos+2, 22);	//EMP logo 22 buf has data
			}
			else if(1 == type)
			{
				memcpy(curBuf, curPos+2, 48);
			}
		}
		else
		{
			if(0 == type)
			{
//				memcpy(curBuf, curPos+2, 48);
				memcpy(curBuf+(48-22)/2, curPos+2, 22);	//EMP logo 22 buf has data
			}
			else if(1 == type)
			{
				memcpy(curBuf, curPos+2, 48);
			}
		}
		curBuf = curBuf+48;
		curPos = curPos+strLen+2;
	}
	BT_Ft_PrintBmp();

	memset(cBuf, '\0',sizeof(cBuf));
	curBuf = cBuf;
	totalLen = 0;

	return 0;
}

//added by Kevin 20150720
int BT_Ft_Print()
{
	int iRet = 0;

	iRet = BTPrn_Send(cBuf , strlen(cBuf));
	if(iRet != 0)
	{
		return iRet;
	}

	return 0;
}

//added by Kevin 20150720
int BT_Ft_Print1()
{
	int iRet = 0;
	char str[5] = "", str1[10] = "";

	DispPrinting();
	BTPrn_InitSendRecv();

	sprintf(str, "%d", totalLen);
	strcat(str1, "\x1f\x43\x01");
	strcat(str1, str);
	strcat(str1, "\x0d");

	iRet = BTPrn_Send(str1 , strlen(str1));
	if(iRet != 0)
	{
		return iRet;
	}
	OsLog(LOG_INFO, "BTPrn_Send success!");
	OsSleep(50);

	OsLog(LOG_INFO, "totalLen = %d", totalLen);
	iRet = BTPrn_Send(cBuf, totalLen);
	if(iRet != 0)
	{
		return iRet;
	}
//	OsSleep(800);

	memset(cBuf, 0 ,sizeof(cBuf));
	curBuf = cBuf;
	totalLen = 0;

	return 0;
}

//added by Kevin 20150720
int BT_Ft_PrintBmp()
{
	int iRet = 0, i = 0;
	char str[5] = "", str1[10] = "";

//	DispPrinting();

	OsLog(LOG_INFO, "totalLen = %d", totalLen);

	for(i=0; i<totalLen/4896; i++)
	{
		memset(str, 0 ,sizeof(str));
		memset(str1, 0 ,sizeof(str1));

		sprintf(str, "%d", 4896);
		strcat(str1, "\x1f\x43\x01");
		strcat(str1, str);
		strcat(str1, "\x0d");

		iRet = BTPrn_Send(str1 , strlen(str1));
		if(iRet != 0)
		{
			return iRet;
		}
		OsLog(LOG_INFO, "BTPrn_Send success!");
		OsSleep(50);


		iRet = BTPrn_Send(cBuf+4896*i, 4896);
		if(iRet != 0)
		{
			return iRet;
		}
		OsSleep(4896/3);
	}

	memset(str, 0 ,sizeof(str));
	memset(str1, 0 ,sizeof(str1));

	sprintf(str, "%d", totalLen%4896);
	strcat(str1, "\x1f\x43\x01");
	strcat(str1, str);
	strcat(str1, "\x0d");

	OsLog(LOG_INFO, "str1=%x", str1[0]);
	OsLog(LOG_INFO, "str1=%x", str1[1]);
	OsLog(LOG_INFO, "str1=%x", str1[2]);
	OsLog(LOG_INFO, "str1=%x", str1[3]);
	OsLog(LOG_INFO, "str1=%x", str1[4]);
	OsLog(LOG_INFO, "str1=%x", str1[5]);
	OsLog(LOG_INFO, "str1=%x", str1[6]);
	OsLog(LOG_INFO, "str1=%x", str1[7]);
	OsLog(LOG_INFO, "str1=%x", str1[8]);

	iRet = BTPrn_Send(str1 , strlen(str1));
	if(iRet != 0)
	{
		return iRet;
	}
	OsLog(LOG_INFO, "BTPrn_Send success!");
	OsSleep(50);

	OsLog(LOG_INFO, "totalLen = %d", totalLen);
	iRet = BTPrn_Send(cBuf+4896*i, totalLen%4896);
	if(iRet != 0)
	{
		return iRet;
	}
	OsSleep(totalLen%4896/3);

	return 0;
}

// 打印错误提示
// Start-up printer, and show error if any.
// Modified by Kim_LinHB 2014-6-8
int StartPrinter(void)
{
	int	iRet, iRet2;
	uchar szBuff[32];
	//====Stop Printer============
//	   if ( MirroringCheckEcr())
//    	    {
//		   	   	   	   	   return  0 ;
//		    }
	 //===========================
    while (1)
    {
        SB_ManuallyRefresh(SB_ICON_PRINTER, OPENICON_PRINTER);
        DispPrinting();
        PrintOne();
#ifndef TEST_SMS
        if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_SMS))	//modified by Kevin 20150720
#endif
        {
            iRet = RET_OK;
            break;
        }
        else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))	//added by Kevin 20150720
        {
            iRet = RET_OK;
            break;
        }
#ifndef TEST_SMS
        else
        {
            iRet = OsPrnStart();
            if (iRet == RET_OK)
            {
                break;
            }
        }
#endif

        iRet2 = DispPrnError(iRet);
        if (iRet != PRN_NO_PAPER)
        {
            break;
        }

        if (GUI_ERR_USERCANCELLED == iRet2 || GUI_ERR_TIMEOUT == iRet2)
        {
            Gui_ClearScr();
            Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLEASE REPRINT"), gl_stCenterAttr, GUI_BUTTON_OK, 2, NULL );
            break;
        }
    }
    SB_ManuallyRefresh(SB_ICON_PRINTER, CLOSEICON_PRINTER);
#ifndef TEST_SMS
    if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_SMS))	//modified by Kevin 20150720
#endif
    {
        int iRest = strlen(sg_SMS_Buffer);
        int iCnt = 0;
        while(1){
            int ret = WlPortOpen("115200,8,n,1");
            printf("OsWlPortOpen, ret=%d\n", ret);
            if(ret < 0)
                return -1;

            WlPortReset();

            WlPortSend("AT\r", 3);
            memset(sg_recvBuff, 0x00, sizeof(sg_recvBuff));
            ret = WlPortRecv(sg_recvBuff, sizeof(sg_recvBuff), 500);
            //OsLog(LOG_ERROR, "recv(%d):\n", ret);
            //OsLog(LOG_ERROR, "\n%s", sg_recvBuff);

            WlPortSend("AT+CMGF=1\r", 10);
            memset(sg_recvBuff, 0x00, sizeof(sg_recvBuff));
            ret = WlPortRecv(sg_recvBuff, sizeof(sg_recvBuff), 500);
            //OsLog(LOG_ERROR, "recv(%d):\n", ret);
            //OsLog(LOG_ERROR, "\n%s", sg_recvBuff);

            memset(sg_recvBuff, 0, sizeof(sg_recvBuff));
            sprintf(sg_recvBuff, "AT+CMGS=\"%s\"%s\r", glProcInfo.stTranLog.szLastCustomerPhoneNo, '+' == glProcInfo.stTranLog.szLastCustomerPhoneNo[0] ? ",145":"");
            WlPortSend(sg_recvBuff, strlen(sg_recvBuff) + 1);
            memset(sg_recvBuff, 0x00, sizeof(sg_recvBuff));
            ret = WlPortRecv(sg_recvBuff, sizeof(sg_recvBuff), 500);
            //OsLog(LOG_ERROR, "recv(%d):\n", ret);
            //OsLog(LOG_ERROR, "\n%s", sg_recvBuff);
            OsSleep(500);
            memset(sg_recvBuff, 0x00, sizeof(sg_recvBuff));

            if(iRest > 120)
            {
                WlPortSend(sg_SMS_Buffer+iCnt * 120, 120);
                WlPortSend("\x1A", 1);
                OsSleep(500);
                WlClosePort();
                ++iCnt;
                iRest -= 120;
            }
            else{
                WlPortSend(sg_SMS_Buffer+iCnt * 120, iRest);
                WlPortSend("\x1A", 1);
                OsSleep(500);
                WlClosePort();
                bOpenPrinter = FALSE;
                memset(sg_SMS_Buffer, 0, sizeof(sg_SMS_Buffer));
                break;
            }
        }

//        XuiImg *img = XuiImgLoadFromFile("./data/lastreceipt.bmp");
//        XuiImgSaveToFile(img, "./data/lastreceipt.png");
//        XuiImgFree(img);
    }
    else if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER))	//added by Kevin 20150720
	{
    	//added by Kevin for last
    	BT_Ft_Print();
		memset(cBuf, '\0', sizeof(cBuf));
		memset(curLineStr, '\0', sizeof(curLineStr));
		totalLen = 0;

		iRet = BTPrn_Send("\x1B\x64\x01", 3);
		OsSleep(50);
	}

    //add begin linzhao, 20150902
    App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szBuff, 0);

	if(ChkTerm(_TERMINAL_D200_) && DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption &&
			( atof(szBuff + 4) < 20) && (atof(szBuff+ 4) > 0))
	{
	   glSysParam.stEdcInfo.ucPrinterType = PRNMODE_BTPRNTER;
	   SaveSysParam();
	}
	//add end linzhao, 20150902

    if(iRet == RET_OK)
        return 0;
	return ERR_NO_DISP;
}

// Modified by Kim_LinHB 2014-6-8
int DispPrnError(int iErrCode)
{
	unsigned char szBuff[100];
	Gui_ClearScr();
	PubBeepErr();
	switch( iErrCode )
	{
	case ERR_PRN_BUSY:
		strcpy(szBuff, _T("PRINTER BUSY"));
		break;

	case ERR_PRN_PAPEROUT:
		strcpy(szBuff, _T("OUT OF PAPER"));
		return Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
		break;

	case ERR_PRN_WRONG_PACKAGE:
		strcpy(szBuff, _T("PRN DATA ERROR"));
		break;

	case ERR_PRN_OVERHEAT:
		strcpy(szBuff, _T("PRINTER OVERHEAT"));
		break;

#if 0    // won't happen on prolin2.4
	case PRN_ERR:
		strcpy(szBuff, _T("PRINTER ERROR"));
		break;

	case PRN_NO_DOT:
		strcpy(szBuff, _T("FONT MISSING"));
		break;
#endif

	case ERR_PRN_OUTOFMEMORY:
		strcpy(szBuff, _T("PRN OVERFLOW"));
		break;

	default:
		strcpy(szBuff, _T("PRINT FAILED"));
		break;
	}
	return Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
}
static char sgTempBuffer[500] = {0};
void Print_Callback(const char *str)
{
	FtPrnStr(str);
}
int 	Calc_Callback(const char *str, int len)
{
	int w = 0,h = 0;
	sprintf(sgTempBuffer, "%.*s", len, str);
	FtGetStrArea(sgTempBuffer, &w, &h);
	return w;
}

void MultiLngPrnStr(uchar alignment, uchar size, const char *str, ...)
{
	int w = 0,h = 0,i = 0, iRet = 0;
    static char sbuffer[2048];
    char temp[2048] = "";
    va_list pVaList;
    va_start(pVaList, str);
    vsnprintf(sbuffer, sizeof(sbuffer), (char*)str, pVaList);
    va_end(pVaList);
    int curOffset = 0;
    int len = 0;

    //TODO for now just for sms
#ifndef TEST_SMS
    if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_SMS))
#endif
    {
        if(sg_SMS_Buffer[0] == 0)
            strcpy(sg_SMS_Buffer, sbuffer);
        else
            strcat(sg_SMS_Buffer, sbuffer);
        return;
    }

    //added by Kevin for bluetooth printer
	if(ChkHardware(HWCFG_PRINTER, 0) && (glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_OK))
	{
		//some str has many blank character in the end, remove it
		len = strlen(sbuffer);
		for(i=0; i<len; i++)
		{
			if(sbuffer[len-1-i] == ' ')
			{
				sbuffer[len-1-i] = '\0';
			}
			else
			{
				break;
			}
		}

		//if str width is exceed the receipt width, put prev buf into prn buf
		if((size == PRN_SIZE_NORMAL || size == PRN_SIZE_LARGE) && (strlen(sbuffer) > 32))
		{
			return;	//TODO
			for(i=0; i<sizeof(curLineStr); i++)
			{
				if(curLineStr[i] == '\0')
				{
					break;
				}
			}
			if(i < sizeof(curLineStr))
			{
				for(i=0; i<sizeof(curLineStr); i++)
				{
					if(curLineStr[i] == '\0')
					{
						curLineStr[i] = ' ';
					}
				}
				memcpy(cBuf + totalLen, curLineStr, 32);
				strcat(cBuf, "\n");
				totalLen = totalLen + 33;
				memset(curLineStr, '\0', sizeof(curLineStr));
			}
		}
		if((size == PRN_SIZE_SMALL) && (strlen(sbuffer) > 48))
		{
			return;	//TODO
			for(i=0; i<sizeof(curLineStr); i++)
			{
				if(curLineStr[i] == '\0')
				{
					break;
				}
			}
			if(i < sizeof(curLineStr))
			{
				for(i=0; i<sizeof(curLineStr); i++)
				{
					if(curLineStr[i] == '\0')
					{
						curLineStr[i] = ' ';
					}
				}
				memcpy(cBuf + totalLen, curLineStr, 48);
				strcat(cBuf, "\n");
				totalLen = totalLen + 49;
				memset(curLineStr, '\0', sizeof(curLineStr));
			}
		}

		//if font size is changed
		if(size != prevSize)
		{
			BT_Ft_Print();
			memset(cBuf, '\0', sizeof(cBuf));
			memset(curLineStr, '\0', sizeof(curLineStr));
			totalLen = 0;
			OsLog(LOG_INFO, "line=%d", __LINE__);
//			OsSleep(500);

			if(size == PRN_SIZE_SMALL)
			{
				iRet = BTPrn_Send("\x1B\x21\x01" , 3);
				if(iRet != 0)
				{
					return;
				}
				curLineLen = 48;
				prevSize = PRN_SIZE_SMALL;
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
			else if(size == PRN_SIZE_NORMAL)
			{
				iRet = BTPrn_Send("\x1B\x21\x00" , 3);
				if(iRet != 0)
				{
					return;
				}
				curLineLen = 32;
				prevSize = PRN_SIZE_NORMAL;
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
			else if(size == PRN_SIZE_LARGE)
			{
				iRet = BTPrn_Send("\x1B\x21\x10" , 3);
				if(iRet != 0)
				{
					return;
				}
				curLineLen = 32;
				prevSize = PRN_SIZE_LARGE;
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
		}

		//if str width is exceed the receipt width, insert \n to print a new line
		memset(temp, '\0', sizeof(temp));
		if((size == PRN_SIZE_NORMAL || size == PRN_SIZE_LARGE) && (strlen(sbuffer) > 32))
		{
			OsLog(LOG_INFO, "strlen(sbuffer)=%d", strlen(sbuffer));
			OsLog(LOG_INFO, "sbuffer=%s", sbuffer);
			if(sbuffer[strlen(sbuffer)-1] == '\n')
			{
				for(i=0; i<(strlen(sbuffer)-1)/curLineLen; i++)
				{
					memcpy(temp+32*i+i, sbuffer+32*i, curLineLen);
					strcat(temp, "\n");
					OsLog(LOG_INFO, "line=%d", __LINE__);
				}
				memcpy(temp+32*i+i, sbuffer+32*i, strlen(sbuffer)%curLineLen);
				OsLog(LOG_INFO, "line=%d", __LINE__);
				memset(sbuffer, '\0', sizeof(temp));
				memcpy(sbuffer, temp, strlen(temp));
			}
			else
			{
				for(i=0; i<strlen(sbuffer)/curLineLen; i++)
				{
					memcpy(temp+32*i+i, sbuffer+32*i, curLineLen);
					strcat(temp, "\n");
					OsLog(LOG_INFO, "line=%d", __LINE__);
				}
				memcpy(temp+32*i+i, sbuffer+32*i, strlen(sbuffer)%curLineLen);
				strcat(temp, "\n");		//added by Kevin 20150722
				OsLog(LOG_INFO, "line=%d", __LINE__);
				memset(sbuffer, '\0', sizeof(sbuffer));
				memcpy(sbuffer, temp, strlen(temp));	//modified by Kevin 20150722
			}
			memcpy(cBuf + totalLen, sbuffer, strlen(temp));
			totalLen = totalLen + strlen(temp);
			return;
		}

		if((size == PRN_SIZE_SMALL) && (strlen(sbuffer) > 48))
		{
			if(sbuffer[strlen(sbuffer)-1] == '\n')
			{
				for(i=0; i<(strlen(sbuffer)-1)/curLineLen; i++)
				{
					memcpy(temp+48*i+i, sbuffer+48*i, curLineLen);
					strcat(temp, "\n");
					OsLog(LOG_INFO, "line=%d", __LINE__);
				}
				memcpy(temp+48*i+i, sbuffer+48*i, strlen(sbuffer)%curLineLen);
				OsLog(LOG_INFO, "line=%d", __LINE__);
				memset(sbuffer, '\0', sizeof(sbuffer));
				memcpy(sbuffer, temp, strlen(temp));
			}
			else
			{
				for(i=0; i<strlen(sbuffer)/curLineLen; i++)
				{
					memcpy(temp+48*i+i, sbuffer+48*i, curLineLen);
					strcat(temp, "\n");
					OsLog(LOG_INFO, "line=%d", __LINE__);
				}
				memcpy(temp+48*i+i, sbuffer+48*i, strlen(sbuffer)%curLineLen);
				strcat(temp, "\n");		//added by Kevin 20150722
				OsLog(LOG_INFO, "line=%d", __LINE__);
				memset(sbuffer, '\0', sizeof(sbuffer));
				memcpy(sbuffer, temp, strlen(temp));
			}
			memcpy(cBuf + totalLen, sbuffer, strlen(temp));	//modified by Kevin 20150722
			totalLen = totalLen + strlen(temp);
			return;
		}

		//create line buf according to alignment
		if(alignment == FT_ALIGN_LEFT)
		{
			if(sbuffer[strlen(sbuffer)-1] == '\n')
			{
				memcpy(curLineStr, sbuffer, strlen(sbuffer)-1);
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
			else
			{
				memcpy(curLineStr, sbuffer, strlen(sbuffer));
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
		}
		else if(alignment == FT_ALIGN_CENTER)
		{
			if(sbuffer[strlen(sbuffer)-1] == '\n')
			{
				curOffset = (curLineLen - (strlen(sbuffer)-1))/2;
				memcpy(curLineStr + curOffset, sbuffer, strlen(sbuffer)-1);
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
			else
			{
				curOffset = (curLineLen - strlen(sbuffer))/2;
				memcpy(curLineStr + curOffset, sbuffer, strlen(sbuffer));
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
		}
		else if(alignment == FT_ALIGN_RIGHT)
		{
			if(sbuffer[strlen(sbuffer)-1] == '\n')
			{
				curOffset = curLineLen - (strlen(sbuffer)-1);
				memcpy(curLineStr + curOffset, sbuffer, strlen(sbuffer)-1);
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
			else
			{
				curOffset = curLineLen - strlen(sbuffer);
				memcpy(curLineStr + curOffset, sbuffer, strlen(sbuffer));
				OsLog(LOG_INFO, "line=%d", __LINE__);
			}
		}

		//if the last char is \n, generate the line buf and put into prn buf
		if(sbuffer[strlen(sbuffer)-1] == '\n')
		{
			curLineStr[curLineLen] = '\n';
			for(i=0; i<curLineLen; i++)
			{
				OsLog(LOG_INFO, "line=%d", __LINE__);
				if(curLineStr[i] == '\0')
				{
					curLineStr[i] = ' ';
				}
			}

			OsLog(LOG_INFO, "line=%d", __LINE__);
			memcpy(cBuf + totalLen, curLineStr, curLineLen);
			totalLen = totalLen + curLineLen;
			memset(curLineStr, '\0', sizeof(curLineStr));
		}
		OsLog(LOG_INFO, "line=%d", __LINE__);
		return;
	}

#ifdef AREA_Arabia
    if(strcmp(LANGCONFIG, "Arabia") == 0)
    {
        if (alignment == GUI_ALIGN_LEFT)
        {
            FtFontAlign(GUI_ALIGN_RIGHT);
        }
        else if (alignment == GUI_ALIGN_RIGHT)
        {
            FtFontAlign(GUI_ALIGN_LEFT);
        }
        else if (alignment == GUI_ALIGN_CENTER)
        {
            FtFontAlign(GUI_ALIGN_CENTER);
        }
    }
    else
    {
        FtFontAlign(alignment);
    }
#else
    FtFontAlign(alignment);
#endif

    FtFontSize(size);
    FtGetStrArea(sbuffer, &w,&h);
    if(w > 384)
        AutoWrap(sbuffer, 384, Calc_Callback, Print_Callback);
    else
    	FtPrnStr(sbuffer);
}


// end of file

