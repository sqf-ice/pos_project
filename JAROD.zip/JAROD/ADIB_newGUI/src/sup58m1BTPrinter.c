/*------------------------------------------------------------
* FileName: sup58m1BTPrinter.c
* Author: Kevin Liu
* Date: 2015-07-07
------------------------------------------------------------*/
//#include "prolin_bt.h"
//#include <fcntl.h>
//#include <stdio.h>
//#include <sys/stat.h>
//#include <sys/types.h>
//#include <unistd.h>
//#include <string.h>
//#include <errno.h>
//#include <stdarg.h>
//#include <termios.h>
//#include <stdlib.h>
//#include <osal.h>
#include <global.h>

static int g_itty = -1;
static int bt_connect = 0;
static int pair_result = 0;
static int bt_found = 0;
static ST_BT_SCAN_RESULT glScanResult[50] = {0};
static int glScanCount = 0;

static int time_compare(struct timeval tv1, struct timeval tv2)
{
    if (tv1.tv_sec > tv2.tv_sec) {
        return 1;
    }
    else if (tv1.tv_sec < tv2.tv_sec) {
        return -1;
    }
    else if (tv1.tv_usec > tv2.tv_usec) {
        return 1;
    }
    else if (tv1.tv_usec < tv2.tv_usec) {
        return -1;
    }
    else {
        return 0;
    }
}

static void time_add_ms(struct timeval *tv, int ms)
{
    tv->tv_sec += ms / 1000;
    tv->tv_usec += ((ms % 1000) * 1000);
}

static void uart_set(int fd, char *baudr, char *par, char *bits, char *stopb, int hwf, int swf)
{
    int spd = -1;
    int newbaud;
    int bit = bits[0];
    struct termios tty;

    tcgetattr(fd, &tty);
    if (bit == '7' && (par[0] == 'M' || par[0] == 'S'))
        bit = '8';
    if ((newbaud = (atol(baudr) / 100)) == 0 && baudr[0] != 0)
        newbaud = -1;
    switch (newbaud)
    {
        case 0:
            spd = 0;
            break;
        case 3:
            spd = B300;
            break;
        case 6:
            spd = B600;
            break;
        case 12:
            spd = B1200;
            break;
        case 24:
            spd = B2400;
            break;
        case 48:
            spd = B4800;
            break;
        case 96:
            spd = B9600;
            break;
        case 192:
            spd = B19200;
            break;
        case 384:
            spd = B38400;
            break;
        case 576:
            spd = B57600;
            break;
        case 1152:
            spd = B115200;
            break;
        case 2304:
            spd = B230400;
            break;
    }
    if (spd != -1) {
        cfsetospeed(&tty, (speed_t)spd);
        cfsetispeed(&tty, (speed_t)spd);
    }
    switch (bit) {
        case '5':
            tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS5;
            break;
        case '6':
            tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS6;
            break;
        case '7':
            tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS7;
            break;
        case '8':
        default:
            tty.c_cflag = (tty.c_cflag & ~CSIZE) | CS8;
            break;
    }
    tty.c_iflag = IGNBRK;
    tty.c_lflag = 0;
    tty.c_oflag = 0;
    tty.c_cflag |= CLOCAL | CREAD;
    tty.c_cc[VMIN] = 1;
    tty.c_cc[VTIME] = 5;

    if (swf)
        tty.c_iflag |= IXON | IXOFF;
    else
        tty.c_iflag &= ~(IXON | IXOFF | IXANY);
    tty.c_cflag &= ~(PARENB | PARODD);
    if (par[0] == 'E')
        tty.c_cflag |= PARENB;
    else if (par[0] == 'O')
        tty.c_cflag |= (PARENB | PARODD);
    if (stopb[0] == '2')
        tty.c_cflag |= CSTOPB;
    else
        tty.c_cflag &= ~CSTOPB;
    tcsetattr(fd, TCSANOW, &tty);
}

static int tty_open(void)
{
    char name[32] = "";
    int ret = -1;

    ret = OsBluetoothGetSPPDevice(name, sizeof(name));
    if(g_itty > 0) {
        return g_itty;
    }
    if(ERR_BT_NONE == ret) {
        g_itty = open(name, O_RDWR);
        if (g_itty > 0) {
            uart_set(g_itty, "115200", "N", "8", "1", 0, 0);
            OsLog(LOG_INFO,"pax:%s, tty open succes.name: %s g_itty=%d\n", __func__, name, g_itty);
            ret = g_itty;
        }
        else{
            OsLog(LOG_INFO,"pax:%s, tty open error.name: %s  errno:%d\n", __func__, name, errno);
            ret = -1;
        }
    }
    else {
        OsLog(LOG_INFO,"OsBluetoothGetSPPDevice error ret:%d\n",ret);
        ret = -1;
    }
    return ret;
}

static int tty_write(const void *data, int len)
{
    int iRet = -1;
    char *buf = data;

    if (g_itty < 0) {
    	OsLog(LOG_INFO, "%s, error read!\r\n", __func__);
        return -1;
    }
    OsLog(LOG_INFO, "tty_write data=%s len=%d", data, len);
//    OsSleep(100);
    while(len > 0)
    {
    	iRet = write(g_itty, buf, len);	//Initialize printer
		if (iRet < 0) {
			break;
		}
		buf += iRet;
		len -= iRet;
    }
    return (iRet >= 0) ? 0 : -1;
}

static int tty_read(void *RecvBuf, int RecvLen, int TimeoutMs)
{
	char *buf = RecvBuf;
	int ret, err, total;
	struct timeval tv1, tv2;

	if (TimeoutMs < 100 && TimeoutMs > 0) {
		TimeoutMs = 100;
	}

	if (gettimeofday(&tv1, NULL) < 0) {
		return -3209;
	}
	time_add_ms(&tv1, TimeoutMs);

	total = 0;
	while (RecvLen > 0) {
		ret = read(g_itty, buf, RecvLen);
		if (ret < 0) {
			return -1;
		}
		else {
			buf += ret;
			RecvLen -= ret;
			total += ret;
			if (RecvLen <= 0)
				break;
			if (gettimeofday(&tv2, NULL) < 0) {
				return -3209;
			}
			if (time_compare(tv1, tv2) <= 0) {
				break;
			}
		}
	}
	return total;
}

static void tty_close(void)
{
    if (g_itty != -1) {
        close(g_itty);
        g_itty = -1;
    }
    return;
}

static int pair_callback(BT_ACTION Action, 
        char *Mac, 
        char *Key)
{
	OsLog(LOG_INFO,"pair_callback-------------");
    OsLog(LOG_INFO,"pax:%s Mac:%s\n",__func__,Mac);
    OsLog(LOG_INFO,"key:%s\n",Key);
//    pair_result = 1;
    return 0;
}

static void discon_callback(void)
{
    OsLog(LOG_INFO,"pax:%s\n",__func__);
    ucBTConnectFlag = CONNECT_NO;
    bt_connect = 0;
}

static void pairresult_callback(char *Mac, 
        int Result)
{
	OsLog(LOG_INFO,"pax:%s   Result:%d\n",__func__,Result);
    OsLog(LOG_INFO,"MAC:%s\n",Mac);
    if(Result == 0) {
    	pair_result = 1;
    }
}

static void connresult_callback(int Result)
{
    OsLog(LOG_INFO,"pax:%s   Result:%d\n",__func__,Result);
    if(Result == 0) {
    	ucBTConnectFlag = CONNECT_OK;
		bt_connect = 1;
		BTPrn_InitSendRecv();
	}
}

static void scan_callback(ST_BT_SCAN_RESULT Scan[], int Count)
{
	int i = 0;

	OsLog(LOG_INFO,"pax:%s\n",__func__);
	if(Count > 50)
	{
		Count = 50;
	}

	glScanCount = Count;
	for(i=0; i<Count; i++)
	{
		OsLog(LOG_INFO,"Name:%s\n", Scan[i].Name);
		OsLog(LOG_INFO,"MAC:%s\n", Scan[i].Mac);

		strcpy(glScanResult[i].Name, Scan[i].Name);
		strcpy(glScanResult[i].Mac, Scan[i].Mac);
		bt_found = 1;
	}
}

int BTPrn_Open(const char *name, int visible)
{
	int iRet = 0;

	iRet = OsBluetoothOpen(name, visible);
	if(iRet != 0) {
		OsLog(LOG_INFO,"OsBluetoothOpen error iret:%d\n",iRet);
		return iRet;
	}
	OsLog(LOG_INFO,"OsBluetoothOpen succes iret:%d\n",iRet);
	OsBluetoothSetMode( BT_MODE_STD );
	iRet = OsBluetoothSetCallback(pair_callback,
			discon_callback,
			pairresult_callback,
			connresult_callback);
	if(0 != iRet) {
		OsLog(LOG_INFO,"OsBluetoothSetCallback error iret:%d\n",iRet);
		return iRet;
	}

	return ERR_BT_NONE;
}

int BTPrn_Scan(ST_BT_SCAN_RESULT *scanResult, int *scanCount)
{
	int iRet = 0;
	int cnt_tmp = 0;

	bt_found = 0;
	iRet = OsBluetoothStartScan(scan_callback);
	if(iRet != 0) {
		OsLog(LOG_INFO,"OsBluetoothStartScan error iret:%d\n",iRet);
		return iRet;
	}

	cnt_tmp = 0;
	while( bt_found != 1 ) {
		if(cnt_tmp > 30 ) {
			break;
		}
		cnt_tmp ++;
		sleep(1);
	}

	if(bt_found != 1) {
		OsLog(LOG_INFO,"%s(%d) bt_found  error\n",__FILE__,__LINE__);
		return ERR_BT_SCAN_FAIL;
	}

	*scanCount = glScanCount;
	memcpy(scanResult, glScanResult, sizeof(ST_BT_SCAN_RESULT)*glScanCount);

	return ERR_BT_NONE;
}

int BTPrn_Pair(BT_PAIR_AUTH Auth, int Mitm, const char *btName, const char *passwd)
{
	int i=0;
	int iRet = 0;
	int cnt_tmp = 0;

	pair_result = 0;
	bt_connect = 0;
	iRet = OsBluetoothSetPairAuth(Auth, Mitm, passwd);
	if(iRet != 0) {
		OsLog(LOG_INFO,"OsBluetoothSetPairAuth error iret:%d\n",iRet);
		return iRet;
	}
	for(i=0; i<glScanCount; i++)
	{
		OsLog(LOG_INFO,"glScanResult[%d].Name=%s", i, glScanResult[i].Name);
		OsLog(LOG_INFO,"btName=%s", btName);
		OsLog(LOG_INFO,"strlen(glScanResult[i].Name))=%d", strlen(glScanResult[i].Name));
		if(0 == memcmp(glScanResult[i].Name, btName, strlen(glScanResult[i].Name)))
		{
			OsLog(LOG_INFO,"OsBluetoothStartPair pair with name=%s mac=%s", glScanResult[i].Name, glScanResult[i].Mac);
			iRet = OsBluetoothStartPair(glScanResult[i].Mac);
			if(0 != iRet) {
				OsLog(LOG_INFO,"OsBluetoothStartPair error iret:%d\n",iRet);
				return iRet;
			}

			cnt_tmp = 0;
			while( pair_result != 1 ) {
				if(cnt_tmp > 30 ) {
					break;
				}
				cnt_tmp ++;
				sleep(1);
			}

			if(pair_result != 1) {
				OsLog(LOG_INFO,"%s(%d) pair_result  error\n",__FILE__,__LINE__);
				return ERR_BT_PAIR_TIMEOUT;
			}

			//save info
			memcpy(glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.Mac, glScanResult[i].Mac, strlen(glScanResult[i].Mac));
			memcpy(glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.LinkKey, passwd, strlen(passwd));

			iRet = OsBluetoothStartSPPConnect(glScanResult[i].Mac);
			if (0 != iRet) {
				OsLog(LOG_INFO,"OsBluetoothStartSPPConnect error iret:%d\n",iRet);
				return iRet;
			}

			cnt_tmp = 0;
			while( bt_connect != 1 ) {
				if(cnt_tmp > 30 ) {
					break;
				}
				cnt_tmp ++;
				sleep(1);
			}
			if(bt_connect != 1) {
				OsLog(LOG_INFO,"%s(%d) bt_connect error\n",__FILE__,__LINE__);
				return BT_CONN_SDC_FAILED;
			}
			break;
		}
	}
	if(i == glScanCount)
	{
		return BT_CONN_SDC_FAILED;
	}

	return ERR_BT_NONE;
}

int BTPrn_InitSendRecv()
{
	int iRet = 0;

	iRet = tty_open();
	if(iRet < 0) {
		OsLog(LOG_INFO, "tty_open fail!");
		return -1;
	}
	tty_write("\x1B\x40", 2);
	tty_write("\x1B\x33\x10", 3);
	return ERR_BT_NONE;
}

int BTPrn_Send(const void *data, int len)
{
	int iRet = 0;

	iRet = tty_write(data, len);

	return iRet;
}

int BTPrn_Recv(void *RecvBuf, int RecvLen, int TimeoutMs)
{
	int iRet = 0;

	iRet = tty_read(RecvBuf, RecvLen, TimeoutMs);

	return iRet;
}

void BTPrn_Close()
{
	OsBluetoothClose();
	tty_close();
}

int BTPrn_AutoConnect()
{
	int i=0;
	int iRet = 0;
	int cnt_tmp = 0;

	pair_result = 0;
	bt_connect = 0;

	iRet = BTPrn_Open(glSysParam.stTxnCommCfg.stBlueToothPara.stScanResult.Name, 0);
	if(iRet != 0)
	{
		Gui_ClearScr();
		Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "OPEN ERROR", gl_stCenterAttr, GUI_BUTTON_OK, 0,NULL);
		return iRet;
	}

	OsLog(LOG_INFO, "key=%s", glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.LinkKey);
	iRet = OsBluetoothSetPairAuth(BT_PAIR_AUTH_DISPLAY_YESNO, 1, glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.LinkKey);
	if(iRet != 0) {
		OsLog(LOG_INFO,"OsBluetoothSetPairAuth error iret:%d\n",iRet);
		return iRet;
	}

	iRet = OsBluetoothStartPair(glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.Mac);
	if(0 != iRet) {
		OsLog(LOG_INFO,"OsBluetoothStartPair error iret:%d\n",iRet);
		return iRet;
	}

	cnt_tmp = 0;
	while( pair_result != 1 )
	{
		if(cnt_tmp > 20 )
		{
			break;
		}
		cnt_tmp ++;
		sleep(1);
	}

	if(pair_result != 1) {
		OsLog(LOG_INFO,"%s(%d) pair_result  error\n",__FILE__,__LINE__);

		iRet = OsBluetoothSetPairAuth(BT_PAIR_AUTH_DISPLAY_YESNO, 1, glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.LinkKey);
		if(iRet != 0) {
			OsLog(LOG_INFO,"OsBluetoothSetPairAuth error iret:%d\n",iRet);
			return iRet;
		}
		iRet = OsBluetoothStartPair(glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.Mac);
		if(0 != iRet) {
			OsLog(LOG_INFO,"OsBluetoothStartPair error iret:%d\n",iRet);
			return iRet;
		}

		cnt_tmp = 0;
		while( pair_result != 1 )
		{
			if(cnt_tmp > 10 )
			{
				break;
			}
			cnt_tmp ++;
			sleep(1);
		}
		if(pair_result != 1)
			return ERR_BT_PAIR_TIMEOUT;
	}

	iRet = OsBluetoothStartSPPConnect(glSysParam.stTxnCommCfg.stBlueToothPara.stPaired.Mac);
	if (0 != iRet) {
		OsLog(LOG_INFO,"OsBluetoothStartSPPConnect error iret:%d\n",iRet);
		return iRet;
	}

	cnt_tmp = 0;
	while( bt_connect != 1 ) {
		if(cnt_tmp > 30 ) {
			break;
		}
		cnt_tmp ++;
		sleep(1);
	}
	if(bt_connect != 1) {
		OsLog(LOG_INFO,"%s(%d) bt_connect error\n",__FILE__,__LINE__);
		return BT_CONN_SDC_FAILED;
	}

	return ERR_BT_NONE;
}

void BTPrn_ReconnectOp()
{
	int iRet = 0;

	Gui_ClearScr();
	Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT DOWN", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);

	while(1)
	{
		Gui_ClearScr();
		iRet = Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT?", gl_stCenterAttr, GUI_BUTTON_YandN, -1,NULL);
		if(GUI_OK == iRet)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECTING", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);
			iRet = BTPrn_AutoConnect();
			OsLog(LOG_INFO, "iRet=%d", iRet);
			if(iRet == 0)
			{
				Gui_ClearScr();
				Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT OK", gl_stCenterAttr, GUI_BUTTON_OK, 3,NULL);
				break;
			}
			else
			{
				Gui_ClearScr();
				Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT FAIL", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);
			}
		}
		if(GUI_ERR_USERCANCELLED == iRet)
		{
			BTPrn_Close();
			glSysParam.stEdcInfo.ucPrinterType = PRNMODE_NONE;
			SaveSysParam();
			break;
		}
	}
	Gui_ClearScr();
}


