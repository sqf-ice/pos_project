/*
 * ft.h
 *
 *  Created on: 2013-7-25
 *      Author: huanglei
 *
 *  Modified by Kim 
 *     2014-10-19	Modified FtPrnStr, this function will just update the matrix
 *					        Added FtPrn, this function will really copy the matrix to printer buffer
 *					        Added FtFontLoad back? I don't know why huanglei removed this interface
 *	   2014-7-10	Added FtFontDoubleSize			
 */

/*
 * V0.1 init
 * V0.2 add double size, just keep API for printing
 * V0.3 add FT_ALIGN_NONE,
 */

#ifndef FT_H_
#define FT_H_

enum{
    FT_ALIGN_NONE = 0,
    FT_ALIGN_LEFT,
    FT_ALIGN_CENTER,
    FT_ALIGN_RIGHT
};

#define DEFAULT_FONT_SIZE 32

#ifdef __cplusplus
extern "C"
{
#endif

int     FtFontLoad(const char* path);
int		FtFontLoadMem(const unsigned char*  file_base, unsigned long  file_size);
int		FtFontFree(void);
int		FtFontSize(unsigned char size);
int		FtFontDoubleSize(unsigned char bDoubleWidth, unsigned char bDoubleHeight);
int		FtFontStyle(unsigned char bold, unsigned char italic);
int		FtFontReverse(unsigned char reverse);
int		FtFontAlign(unsigned char align);
int		FtGetStrArea(const char* str, int* width, int* height);
unsigned char FtPrnStr(const char *str, ...);
unsigned char FtPrn(void);

const unsigned char *FtGetPrnBuffer(int *iBufferLen);

#ifdef __cplusplus
}
#endif

#endif /* FT_H_ */
