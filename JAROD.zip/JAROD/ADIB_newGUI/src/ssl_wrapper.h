/*
 ============================================================================
 Name        : ssl_wrapper.h
 Author      : PAX
 Version     : 
 Copyright   : PAX Computer Technology(Shenzhen) CO., LTD
 Description : PAX POS Shared Library
 ============================================================================
 */
 
 
#ifndef SHARED_LIBRARY_H_ssl_wrapper
#define SHARED_LIBRARY_H_ssl_wrapper

#ifdef __cplusplus
extern "C"
{
#endif

#include <openssl/ssl.h>

#define SSLERR          -100
#define SSLERR_CONNECT  -101
#define SSLERR_TIMEOUT  -102
#define SSLERR_READ     -103

#define CIPHERS_LIMIT   "ALL:!RC4"

typedef struct SSLCon {
    int socket;
    SSL *sslHandle;
    char szCA[255];
    char szCert[255];
    char szKey[255];
} SSLCon;

void sslLoadFile(SSLCon* con, const char *CA, const char *Cert, const char *Key);
int sslConnect(SSLCon* con, const char* ip, short port, int timeoutMs);
int sslRead(SSLCon* con, char *data, int expSize, int timeoutMs);
int sslWrite(SSLCon* con, const char *data, int len);
void sslClose(SSLCon *con);

#ifdef __cplusplus
};
#endif

#endif /* SHARED_LIBRARY_H_ssl_wrapper */

