/****************************************************************************
NAME
    TransClss.h - ���彻�״���ģ��

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    shengjx     2006.09.12      - created
****************************************************************************/

#ifndef _TRANCLSS_H
#define _TRANCLSS_H

/************************************************************************/

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
//koko start
//CLSS status added by kevinliu 2016/01/26
typedef enum clssLightStatus{
	CLSSLIGHTSTATUS_INIT,
	CLSSLIGHTSTATUS_NOTREADY,
	CLSSLIGHTSTATUS_IDLE,
	CLSSLIGHTSTATUS_READYFORTXN,
	CLSSLIGHTSTATUS_PROCESSING,
	CLSSLIGHTSTATUS_READCARDDONE,
	CLSSLIGHTSTATUS_REMOVECARD,
	CLSSLIGHTSTATUS_COMPLETE,
	CLSSLIGHTSTATUS_DIALING,
	CLSSLIGHTSTATUS_SENDING,
	CLSSLIGHTSTATUS_RECEIVING1,
	CLSSLIGHTSTATUS_RECEIVING2,
	CLSSLIGHTSTATUS_PRINTING,
	CLSSLIGHTSTATUS_ERROR,
} CLSSLIGHTSTATUS;

//PICC LED added by kevinliu 2016/01/26
#define PICC_LED_RED    0x01
#define PICC_LED_GREEN  0x02
#define PICC_LED_YELLOW 0x04
#define PICC_LED_BLUE   0x08
#define PICC_LED_CLSS   0x10
#define PICC_LED_ALL   0xFF
//koko end
int TransClssSale(void);
//koko start
void PiccLightOpen(void);
void PiccLightClose(void);
void SetClssLightStatus(CLSSLIGHTSTATUS status);
CLSSLIGHTSTATUS GetClssLightStatus(void);
void ClearClssLightCtrl();
int ClssVirtualLight(gui_callbacktype_t type, void *data, int *dataLen);
//koko end 

int nSetDETData(uchar *pucTag, uchar ucTagLen, uchar *pucData, uchar ucDataLen);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _TRANPROC_H

// end of file


