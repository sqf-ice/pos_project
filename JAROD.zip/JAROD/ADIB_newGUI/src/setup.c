
#include "global.h"

// Modified by Kim_LinHB 2014-7-9  Update GUI to new version

/********************** Internal macros declaration ************************/

/********************** Internal structure declaration *********************/

/********************** Internal functions declaration *********************/
static int SetSystemParam_EMP(void);
static void SetEMP_Comm(uchar ucCommType);

static int SetSystemParam(void);
static void SetSystemParamSub(uchar ucPermission, uchar isEMP);
static int  SetCommType(uchar ucMode);
static void SetSysCommParam(uchar ucPermission, uchar isEMP);
static int  SetCommDetails(uchar mode, uchar isEMP, uchar *pucCommType);
static int SetPabx_Standalone(void);
static int  SetPabx(uchar isStandalone);
static int  SetModemParam(uchar isEMP);
static int  SetTcpIpSharedPara(COMM_CONFIG *pstCommCfg);
static void SetAcqParam(uchar ucPermission);
static int SetNoPrinterPara(ACQUIRER *acq);
int SetBtPrinter();
static int  SetTcpIpParam_S80(TCPIP_PARA *pstParam);
int SetSMS(ACQUIRER *acq);//linzhao
static int  GetHostDNS(const uchar *pszPrompts, uchar bAllowNull, uchar *pszName);
static int  GetIPAddress(const uchar *pszPrompts, uchar bAllowNull, uchar *pszIPAddress);
static uchar IsValidIPAddress(const char *pszIPAddr);
static int  GetIPPort(const uchar *pszPrompts, uchar bAllowNull, uchar *pszPortNo);
static void SetIssuerParam(uchar ucPermission);
static int DispAcqPama(void);
static int  SetAcqTransComm(uchar ucCommType);
static int  SetAcqTransEncrypt(ACQUIRER *acq);
static int  SetAcqTransTelNo(void);
static int SetTel(uchar *pszTelNo, const uchar *pszPromptInfo);
static void SetEdcParam(uchar ucPermission);
static int  SetTermCurrency(uchar ucPermission);
static int  SetMerchantName(uchar ucPermission);
static int  SetGetSysTraceNo(uchar ucPermission);
static int  SetGetSysInvoiceNo(uchar ucPermission);
static int  SetPEDMode(void);
static int  SetAcceptTimeOut(void);
static int  SetPrinterType(void);
static int  SetNumOfReceipt(void);
static int  SetTabBatchDay(void);
//autosettl foura
static int SetTabSettleStart(void);
static int SetTabSettleMAX(void);
int SetTermID(void);
int SetMerchantID(void);
int SetNii(void) ;
static int  SetTabBatchEnable(void);
static int  SetCallInTime(void);
static uchar IsValidTime(const uchar *pszTime);
static int  ModifyOptList(uchar *psOption, uchar ucMode, uchar ucPermission);
static int ChangePassword(void);
static int SetSysTime(void);
static int SetEdcLang(void);
static int SetPowerSave(void);
static int TestMagicCard1(void);
static int TestMagicCard2(void);
static int TestMagicCard3(void);
static void TestMagicCard(int iTrackNum);
static int ToolsViewPreTransMsg(void);
static int ShowExchangePack(void);
static int PrnExchangePack(void);
static void DebugNacTxd(uchar ucPortNo, const uchar *psTxdData, ushort uiDataLen);

static int ClearReversal_Standalone();

int SetRs232Param(RS232_PARA *rs232);

/********************** Internal variables declaration *********************/

static const GUI_MENUITEM sgFuncMenuItem[] =
{
//=====================================================================
		{ _T_NOOP("1.AUDIT REPOR"),		1,TRUE,  PrnAllList},
		{ _T_NOOP("2.CHECK FONTS"),		2,TRUE,  EnumSysFonts},
		{ _T_NOOP("3.DISP VER"),			3,TRUE,  DispVersion},
		{ _T_NOOP("4.ECHO TEST"),			4,TRUE,  TransEchoTest},
	    { _T_NOOP("5.ECR"),				5,TRUE, SetEcr},
		{ _T_NOOP("6.INIT"),				6,TRUE,  DownLoadTMSPara_Manual},
		{ _T_NOOP("7.LANGUAGE"),			7,TRUE,  SetEdcLang},
		{ _T_NOOP("8.LOCK TERM"),			8,TRUE,  LockTerm},
		#ifdef ENABLE_EMV
		{ _T_NOOP("9.PRINT ERR LOG"),		9,TRUE,  PrintEmvErrLog},
		#endif
		{ _T_NOOP("10.PRINT PARA"),		10,TRUE,  PrintParam},
		{ _T_NOOP("11.PRINT TOTAL"),		11,TRUE,  PrnTotal},
		{ _T_NOOP("12.PRINTER TEST"),		12,TRUE,  PrintReceiptTest},
		{ _T_NOOP("13.POWER SAVING"),		13,TRUE,  SetPowerSave},
		{ _T_NOOP("14.RECONCILIATION"),	14,TRUE,  	 TransSettle},
		{ _T_NOOP("15.REPRINT DUPLICATE"),	15,TRUE,  PrnLastTrans},
		{ _T_NOOP("16.REPRINT RECEIPT NO"),16,TRUE,  RePrnSpecTrans},
		{ _T_NOOP("17.REPRINT SETTLE"),	17,TRUE,  RePrnSettle},
		{ _T_NOOP("18.SET PABX"),   		18,TRUE,  SetPabx_Standalone},
		{ _T_NOOP("19.SET TIME"),			19,TRUE,  SetSysTime},
		{ _T_NOOP("20.VIEW RECORD"),		20,TRUE,  ViewTranList},
		{ _T_NOOP("21.VIEW TOTAL"),		21,TRUE,  ViewTotal},
		{ "", -1,FALSE,  NULL},
//======================================================================

};

static const GUI_MENUITEM sgFuncMenuItemADMIN[] =
{
///================================================
		{ _T_NOOP("1.APP UPDATE"),				 1,TRUE,  DownLoadTMSPara_Auto},	// hidden, not for public use until confirm.
		{ _T_NOOP("2.CLEAR"),					 2,TRUE,  DoClear},
		{ _T_NOOP("3.CLEAR REVERSAL"),  		 3,TRUE,  ClearReversal_Standalone},
	    { _T_NOOP("4.ECR"),				 		 4, TRUE, SetEcr},
		{ _T_NOOP("5.INIT"),					 5,TRUE,  DownLoadTMSPara_Manual},
		{ _T_NOOP("6.KEY INJECTION TERM"),		 6,TRUE,  DoKeyInjectionTrust},
	    { _T_NOOP("7.KEY INJECTION PC"),   		 7,TRUE,  DoKeyInjection},
		#ifdef ENABLE_EMV
		{ _T_NOOP("8.LAST TSI TVR"),			 8,TRUE,  ViewTVR_TSI},
		#endif
		{ _T_NOOP("9.MODIFY PWD"),	     		9,TRUE,  ChangePassword},
		#ifdef ENABLE_EMV
		{ _T_NOOP("10.PRINT ERR LOG"),		 	10,TRUE,  PrintEmvErrLog},//38
		#endif
		{ _T_NOOP("11.PRINT PARA"),				11,TRUE,  PrintParam},
		{ _T_NOOP("12.REPRN SETTLE"),			12,TRUE,  RePrnSettle},
		{ _T_NOOP("13.SET COMM"),				13,TRUE,  SetSystemParam_EMP},
		{ _T_NOOP("14.SET PABX"),   		 	14,TRUE,  SetPabx_Standalone},
		{ _T_NOOP("15.SETUP"),				 	15,TRUE,  SetSystemParam},
		{ _T_NOOP("16.SHOW TRACE"), 			16,TRUE,  ToolsViewPreTransMsg},
		{ _T_NOOP("17.TXN REVIEW"),		 		17,TRUE,  ViewSpecList},
		{ _T_NOOP("18.VIEW PREAUTH RECORD"),	18,TRUE,  ViewTranList},
		{ "", -1,FALSE,  NULL},
////====================================================

};


static const GUI_MENUITEM sgInitMenuItem[] =
{
	{ _T_NOOP("0.INIT"),	0,FALSE,  DownLoadTMSPara_Manual},
//	{ _T_NOOP("2.SETUP"),	2,FALSE,  SetSystemParam},
	{ _T_NOOP("3.LANGUAGE"),	3,TRUE,  SetEdcLang},
	{ _T_NOOP("10.SET TIME"),	10,TRUE,  SetSysTime},
	{ _T_NOOP("60.CHECK FONTS"),	60,FALSE,  EnumSysFonts},
	{ _T_NOOP("87.TEST TRACK1"),	87,FALSE,  TestMagicCard1},
	{ _T_NOOP("88.TEST TRACK2"),	88,FALSE,  TestMagicCard2},
	{ _T_NOOP("89.TEST TRACK3"),	89,FALSE,  TestMagicCard3},
	{ _T_NOOP("90.MODIFY PWD"),	90,TRUE,  ChangePassword},
	{ _T_NOOP("91.DISP VER"),	91,TRUE,  DispVersion},
	{ _T_NOOP("98.KEY INJECTION"), 98,FALSE,  DoKeyInjection},
	{ _T_NOOP("99.CLEAR"),	99,FALSE,  DoClear},
	{ "", -1,FALSE,  NULL},
};

/********************** external reference declaration *********************/



/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/
void GetAllSupportFunc(char *pszBuff)
{
	int	ii;

	pszBuff[0] = 0;
	for (ii=0; ii<sizeof(sgFuncMenuItem)/sizeof(sgFuncMenuItem[0]); ii++)
	{
		if (sgFuncMenuItem[ii].szText[0]!=0)
		{
			if (strlen(pszBuff)!=0)
			{
				strcat(pszBuff, ",");
			}
			sprintf(pszBuff+strlen(pszBuff), "%lu", (unsigned long)sgFuncMenuItem[ii].nValue);
		}
	}
}

// 执行指定功能号的函数
// call function with a specific id
void FunctionExe(uchar bUseInitMenu, int iFuncNo)
{
	int			iCnt;
	GUI_MENUITEM	*pstMenu;

	pstMenu = (GUI_MENUITEM *)(bUseInitMenu ? sgInitMenuItem : sgFuncMenuItem);
	for(iCnt=0; pstMenu[iCnt].szText[0]!=0; iCnt++)
	{
	
		if( pstMenu[iCnt].nValue == iFuncNo)
		{
			if( !pstMenu[iCnt].vFunc )
			{
				break;
			}
			pstMenu[iCnt].vFunc();
			return;
		}
	}

	Gui_ClearScr();
	PubBeepErr();
	Gui_ShowMsgBox(NULL, gl_stTitleAttr, _T("FUNC NUMBER ERR"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL); // Modified by Kim_LinHB 2014-8-6 v1.01.0001 bug493
}

void FunctionMenu(void)
{
	GUI_MENU stMenu;
	Gui_BindMenu(_T("MERCHANT"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)sgFuncMenuItem, &stMenu);
	Gui_ClearScr();
	Gui_ShowMenuList(&stMenu, GUI_MENU_MANUAL_INDEX, USER_OPER_TIMEOUT, NULL);
}

void FunctionMenuADMIN(void)
{
	GUI_MENU stMenu;
	Gui_BindMenu(_T("ADMIN"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)sgFuncMenuItemADMIN, &stMenu);
	Gui_ClearScr();
	Gui_ShowMenuList(&stMenu, GUI_MENU_MANUAL_INDEX, USER_OPER_TIMEOUT, NULL);
}

void FunctionInit(void)
{
	int		iFuncNo;
	iFuncNo = FunctionInput();
	if( iFuncNo>=0 )
	{
		FunctionExe(TRUE, iFuncNo);
	}
}

// set communication parameters
int SetSystemParam_EMP()
{
    uchar ucPermission;

#ifdef FUN2_READ_ONLY
    ucPermission = PM_LOW;      // 低权限
#else
    ucPermission = PM_MEDIUM;   // 中等权限
#endif

    SetCurrTitle(_T("SET COMM"));
    if( PasswordBank()!=0 )
    {
        return ERR_NO_DISP;
    }
    SetSystemParamSub(ucPermission, TRUE);
    return 0;
}

static void SetEMP_Comm(uchar ucCommType)
{
    uchar ucCnt = 1;
    if( glSysParam.ucAcqNum==0 )
    {
        return;
    }
    SetCurAcq(0);

    if( SetAcqTransComm(ucCommType)!=0 )
    {
        return;
    }

    for(ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
    {
        memcpy(glSysParam.stAcqList[ucCnt].stStlGPRSInfo, glCurAcq.stStlGPRSInfo, sizeof(glCurAcq.stStlGPRSInfo));
        memcpy(glSysParam.stAcqList[ucCnt].stStlPhoneInfo, glCurAcq.stStlPhoneInfo, sizeof(glCurAcq.stStlPhoneInfo));
        memcpy(glSysParam.stAcqList[ucCnt].stStlTCPIPInfo, glCurAcq.stStlTCPIPInfo, sizeof(glCurAcq.stStlTCPIPInfo));
        memcpy(glSysParam.stAcqList[ucCnt].stTxnGPRSInfo, glCurAcq.stTxnGPRSInfo, sizeof(glCurAcq.stTxnGPRSInfo));
        memcpy(glSysParam.stAcqList[ucCnt].stTxnPhoneInfo, glCurAcq.stTxnPhoneInfo, sizeof(glCurAcq.stTxnPhoneInfo));
        memcpy(glSysParam.stAcqList[ucCnt].stTxnTCPIPInfo, glCurAcq.stTxnTCPIPInfo, sizeof(glCurAcq.stTxnTCPIPInfo));
    }

    if(CT_TCPIP == ucCommType ||
       CT_CDMA == ucCommType ||
       CT_GPRS == ucCommType ||
       CT_WIFI == ucCommType)
        if(SetAcqTransEncrypt(&glCurAcq) != 0) // Added By Kim 20150320
        {
            return;
        }

}

// 设置系统参数
// set system parameters
int SetSystemParam(void)
{
	uchar ucPermission;

#ifdef FUN2_READ_ONLY
	ucPermission = PM_LOW;		// 低权限
#else
	ucPermission = PM_MEDIUM;	// 中等权限
#endif

	SetCurrTitle(_T("TERM SETUP"));
	if( PasswordBank()!=0 )
	{
		return ERR_NO_DISP;
	}

	SetSystemParamSub(ucPermission, FALSE);
	return 0;
}
		
void SetSystemParamSub(uchar ucPermission, uchar isEMP)
{
    if(isEMP)
    {
        SetSysCommParam(ucPermission, isEMP);
    }
    else
    {
        int iSelected;
        GUI_MENU stMenu;
        GUI_MENUITEM stMenuItem[] = {
		{ _T_NOOP("1.COMM PARA"), 1,TRUE,  NULL},
		{ _T_NOOP("2.VIEW EDC"), 2,TRUE,  NULL},
		{ _T_NOOP("3.VIEW ISSUER"), 3,TRUE,  NULL},
		{ _T_NOOP("4.VIEW ACQUIRER"), 4,TRUE,  NULL},
            { "", -1,FALSE,  NULL},
        };

        Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stMenuItem, &stMenu);
        iSelected = 0;
        while( 1 )
        {
            Gui_ClearScr();

            if( GUI_OK != Gui_ShowMenuList(&stMenu, 0, USER_OPER_TIMEOUT, &iSelected))
            {
                return;
            }

            if( 1 == iSelected )
            {
                SetSysCommParam(ucPermission, isEMP);
            }
            else if( 2 == iSelected )
            {
                SetEdcParam(ucPermission);
            }
            else if( 3 == iSelected )
            {
                SetIssuerParam(ucPermission);
            }
            else if( 4 == iSelected )
            {
                SetAcqParam(ucPermission);
            }
        }
    }
}

void SetSystemParamAll(void)
{
	// 最高权限，可以修改所有参数
	// using the highest Permission
	SetSystemParamSub(PM_HIGH, FALSE);
}

int GetCommName(uchar ucCommType, uchar *pszText)
{
	switch(ucCommType)
	{
	case CT_RS232:
		sprintf((char *)pszText, "COM");
		return 0;
	case CT_MODEM:
		sprintf((char *)pszText, "MODEM");
	    return 0;
	case CT_TCPIP:
		sprintf((char *)pszText, "TCPIP");
	    return 0;
	case CT_CDMA:
		sprintf((char *)pszText, "CDMA");
		return 0;
	case CT_GPRS:
		sprintf((char *)pszText, "GPRS");
		return 0;
	case CT_WIFI:
		sprintf((char *)pszText, "WIFI");
	    return 0;
	case CT_DEMO:
		sprintf((char *)pszText, "DEMO");
	    return 0;	
	case CT_BLTH:
		sprintf((char *)pszText, "BLUETOOTH");
	    return 0;
	default:
		sprintf((char *)pszText, "DISABLED");
	    return -1;
	}
}

// ucForAcq : set custom comm type for ACQ
int SetCommType(uchar ucMode)
{
	int		iRet, iSelected;
	char	szTitle[32];
	uchar	*pucCommType;
	GUI_MENU	stSmDownMode;
	// Modified by Kim_LinHB 2014-8-6 v1.01.0001 bug492  remove static
	GUI_MENUITEM stDefCommMenu[] =
	{
		{ "DISABLE",	CT_NONE,TRUE, 	NULL}, //0
		{ "MODEM",	CT_MODEM,TRUE, 	NULL}, //1
		{ "TCPIP",	CT_TCPIP,TRUE, 	NULL}, //2
		{ "GPRS",	CT_GPRS,TRUE, 	NULL}, //3
		{ "CDMA",	CT_CDMA,FALSE, 	NULL}, //4
		{ "WIFI",	CT_WIFI, FALSE, 	NULL}, //5
		{ "RS232",	CT_RS232,TRUE, 	NULL}, //6
		{ "BLUETOOTH",	CT_BLTH,FALSE, 	NULL}, //7
		{ "DEMO ONLY",	CT_DEMO,TRUE, 	NULL}, //8
		{ "", -1,FALSE,  NULL},
	};// This menu does not provide translation
	GUI_MENUITEM stCommMenu[20];
	int iMenuItemNum = 0;

	//--------------------------------------------------
	memset(&stSmDownMode, 0, sizeof(stSmDownMode));

	if (ucMode!=0)
	{
	    memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[0], sizeof(GUI_MENUITEM));
	    sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[0].szText);
	    ++iMenuItemNum;
	}
	if (!(ChkHardware(HWCFG_MODEM, HW_NONE) ||
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_MODEM)))
	{
	    if(stDefCommMenu[1].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[1], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[1].szText);
            ++iMenuItemNum;
        }
	}
	if (!(ChkHardware(HWCFG_LAN, HW_NONE) ||									// If no LAN module
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_TCPIP)))	// and now is selecting 2nd comm && 1st comm already selected LAN
	{
	    if(stDefCommMenu[2].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[2], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[2].szText);
            ++iMenuItemNum;
        }
	}
	
	if (!(ChkHardware(HWCFG_GPRS, HW_NONE) ||
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_GPRS)))
	{
	    if(stDefCommMenu[3].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[3], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[3].szText);
            ++iMenuItemNum;
        }
	}
	if (!(ChkHardware(HWCFG_CDMA, HW_NONE) ||
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_CDMA)))
	{
	    if(stDefCommMenu[4].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[4], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[4].szText);
            ++iMenuItemNum;
        }
	}
	if (!(ChkHardware(HWCFG_WIFI, HW_NONE) ||
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_WIFI)))
	{
	    if(stDefCommMenu[5].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[5], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[5].szText);
            ++iMenuItemNum;
        }
	}
	if (!(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_RS232))
	{
	    if(stDefCommMenu[6].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[6], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[6].szText);
            ++iMenuItemNum;
        }
	}
	if(!(ChkHardware(HWCFG_BLTH, HW_NONE) ||
		(ucMode!=0 && glSysParam.stTxnCommCfg.ucCommType==CT_BLTH)))
	{
	    if(stDefCommMenu[7].bVisible)
        {
	        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[7], sizeof(GUI_MENUITEM));
            sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[7].szText);
            ++iMenuItemNum;
        }
	}
    if (ucMode==0)
    {
        // Only primary comm type can be "demo"
        memcpy(&stCommMenu[iMenuItemNum], &stDefCommMenu[8], sizeof(GUI_MENUITEM));
        sprintf(stCommMenu[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefCommMenu[8].szText);
        ++iMenuItemNum;
    }

    stCommMenu[iMenuItemNum].szText[0] = 0;

	memset(szTitle, 0, sizeof(szTitle));
	if (ucMode==0)
	{
		pucCommType = &glSysParam.stTxnCommCfg.ucCommType;
		strcpy(szTitle, "1st:");
	}
	else
	{
		pucCommType = &glSysParam.stTxnCommCfg.ucCommTypeBak;
		strcpy(szTitle, "2nd:");
	}

	GetCommName(*pucCommType, szTitle+strlen(szTitle));

	Gui_BindMenu(szTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stCommMenu, &stSmDownMode);
	Gui_ClearScr();
	iSelected = 0;
	iRet = Gui_ShowMenuList(&stSmDownMode, 0, USER_OPER_TIMEOUT, &iSelected);
	if (iRet != GUI_OK)
	{
		return ERR_USERCANCEL;
	}

	if (!ChkIfBatchEmpty() && (*pucCommType!=(uchar)iSelected))
	{
		CommOnHook(TRUE); // Added by Kim_LinHB 2014-08-18 v1.01.0004
		// Not allow to switch into/off demo mode unless batch empty
		if ((*pucCommType==CT_DEMO) || ((uchar)iSelected==CT_DEMO))
		{
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS SETTLE BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);
			return ERR_USERCANCEL;
		}
	}

#ifdef _PROLIN2_4_
	if((*pucCommType!=(uchar)iSelected))
	{
	    UnReg_CommIcon(*pucCommType);
	    Reg_CommIcon(iSelected, ucMode);
	}
	if(pucCommType == &glSysParam.stTxnCommCfg.ucCommType &&
	   iSelected == glSysParam.stTxnCommCfg.ucCommTypeBak)
	{
	    UnReg_CommIcon(glSysParam.stTxnCommCfg.ucCommTypeBak);
	}
#endif

	*pucCommType = (uchar)iSelected;
	return 0;
}

// 设置通讯参数
// set communication parameters
void SetSysCommParam(uchar ucPermission, uchar isEMP)
{
	SetCurrTitle("SETUP COMM");
	Gui_ClearScr();
	while (1)
	{
		if (SetCommType(0)!=0)
		{
			break;
		}

		if (SetCommDetails(0, isEMP, &glSysParam.stTxnCommCfg.ucCommType))
		{
			break;
		}

		if (ChkIfTrainMode())	// if demo mode, no need to set second one
		{
			break;
		}

		if (SetCommType(1)!=0)
		{
			break;
		}

		if (SetCommDetails(1, isEMP, &glSysParam.stTxnCommCfg.ucCommTypeBak))
		{
			break;
		}

		break;
	}
	SaveSysParam();
}

int SetMainCommType(void)
{
    int iRet;
    glSysParam.stTxnCommCfg.ucCommType = CT_GPRS;

    SetTcpIpSharedPara(&glSysParam.stTxnCommCfg);
    Reg_CommIcon(glSysParam.stTxnCommCfg.ucCommType, 0);

    CommOnHook(TRUE);
    DispWait();

    return 0;
}

int SetCommDetails(uchar mode, uchar isEMP, uchar *pucCommType)
{
	uchar	szDispBuff[32];
	int		iRet;

	sprintf((char *)szDispBuff, "SETUP ");
	GetCommName(*pucCommType, szDispBuff+strlen((char *)szDispBuff));
	SetCurrTitle(szDispBuff);

	iRet = 0;
	switch( *pucCommType )
	{
	case CT_RS232:
	    iRet = SetRs232Param(&glSysParam._TxnRS232Para);
		break;
		
	 case CT_BLTH:
#ifdef _PROLIN2_4_
		iRet = SetBTParam(&glSysParam._TxnBlueToothPara);
		if(iRet != 0)
			break;
		SyncBTParam(&glSysParam._TmsBlueToothPara, &glSysParam._TxnBlueToothPara);
#else
		iRet = SetBTParam(&glSysParam._TxnBlueToothPara.stConfig);
		if(iRet != 0)
			break;
		SyncBTParam(&glSysParam._TmsBlueToothPara.stConfig, &glSysParam._TxnBlueToothPara.stConfig);
#endif
		CommOnHook(TRUE);
		DispWait();
		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
		break;
		
	case CT_WIFI:
		iRet = SetWiFiApp(&glSysParam._TxnWifiPara);
		if(iRet != 0)
		{
			DispWifiErrorMsg(iRet);
			break;
		}
		DispWait();
		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
		if(iRet != 0){
			DispWifiErrorMsg(iRet);
			break;
		}
		SetTcpIpSharedPara(&glSysParam.stTxnCommCfg);
		SyncWifiParam(&glSysParam._TmsWifiPara, &glSysParam._TxnWifiPara);
	    break;

	case CT_MODEM:
		SetModemParam(isEMP);
		break;

	case CT_TCPIP:
		SetTcpIpSharedPara(&glSysParam.stTxnCommCfg);
		SetTcpIpParam(&glSysParam._TxnTcpIpPara, isEMP);
		SyncTcpIpParam(&glSysParam._TmsTcpIpPara, &glSysParam._TxnTcpIpPara);
		DispWait();
		CommInitModule(&glSysParam.stTxnCommCfg);
	    break;

	case CT_GPRS:
	case CT_CDMA:
		SetTcpIpSharedPara(&glSysParam.stTxnCommCfg);
		SetWirelessParam(&glSysParam._TxnWirlessPara, isEMP);
		SyncWirelessParam(&glSysParam._TmsWirlessPara, &glSysParam._TxnWirlessPara);
		CommOnHook(TRUE);
		DispWait();
		iRet = CommInitModule(&glSysParam.stTxnCommCfg);
		break;

	case CT_DEMO:
	default:
	    break;
	}

	return iRet;
}

static int SetPabx_Standalone(void)
{
    return SetPabx(TRUE);
}

// 输入PABX
// enter PABX
int SetPabx(uchar isStandalone)
{
	GUI_INPUTBOX_ATTR stInputBoxAttr;

    if(isStandalone)
        if( PasswordMerchant()!=0 )
        {
            return ERR_NO_DISP;
        }

	memset(&stInputBoxAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
	stInputBoxAttr.eType = GUI_INPUT_MIX;
	stInputBoxAttr.nMinLen = 0;
	stInputBoxAttr.nMaxLen = 10;
	stInputBoxAttr.bEchoMode = 1;

	Gui_ClearScr();
	if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "MODIFY PABX", gl_stLeftAttr, 
		glSysParam.stEdcInfo.szPabx, gl_stRightAttr, &stInputBoxAttr, USER_OPER_TIMEOUT)){
		return ERR_USERCANCEL;
	}

	if(isStandalone)
	    SaveSysParam();
	return 0;
}

int SetRs232Param(RS232_PARA *rs232)
{
    uchar   szPrompt[30], szBuff[50], ucCurBaud, ucTemp;

    GUI_MENU stBaudRateMenu;
    GUI_MENUITEM stBaudRateMenuItem[] = {
        { "1.9600", 0,TRUE,  NULL},
        { "2.38400", 1,TRUE,  NULL},
        { "3.57600", 2,TRUE,  NULL},
        { "4.115200", 3,TRUE,  NULL},
        { "", -1,FALSE,  NULL},
    };
    int iSelected = 0;

    GUI_INPUTBOX_ATTR stInputAttr;

    int i;
     //---------------------------------------------------
    for(i = 0; i < sizeof(stBaudRateMenuItem)/ sizeof(GUI_MENUITEM); ++i)
    {
        if(0 == memcmp(stBaudRateMenuItem[i].szText+2, rs232->szAttr, strlen(stBaudRateMenuItem[i].szText) - 2))
        {
            ucCurBaud = i;
            iSelected = ucCurBaud;
            break;
        }
    }

    Gui_BindMenu("BAUD RATE:", gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stBaudRateMenuItem, &stBaudRateMenu);
    Gui_ClearScr();
    if(GUI_OK == Gui_ShowMenuList(&stBaudRateMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iSelected))
    {
        char szAttr[21] = {0};
        sprintf(szAttr, "%s%s", stBaudRateMenuItem[iSelected].szText + 2, strchr(rs232->szAttr, ','));
        strcpy(rs232->szAttr, szAttr);
    }
    else
    {
        return ERR_USERCANCEL;
    }
    return 0;
}

// 修改Modem参数
// set Modem parameters
int SetModemParam(uchar isEMP)
{
	uchar	szPrompt[30], szBuff[50], ucCurBaud, ucTemp;

	GUI_MENU stBaudRateMenu;
	GUI_MENUITEM stBaudRateMenuItem[] = {
		{ "1.1200", 0,TRUE,  NULL},
		{ "2.2400", 1,TRUE,  NULL},
		{ "3.9600", 2,TRUE,  NULL},
		{ "4.14400", 3,TRUE,  NULL},
		{ "", -1,FALSE,  NULL},
	};
	int iSelected = 0;

	GUI_INPUTBOX_ATTR stInputAttr;

	 //---------------------------------------------------
    ucCurBaud = (glSysParam._TxnModemPara.SSETUP>>5) & 0x03;
    iSelected = ucCurBaud;

    Gui_BindMenu("BAUD RATE:", gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stBaudRateMenuItem, &stBaudRateMenu);
    Gui_ClearScr();
    if(GUI_OK == Gui_ShowMenuList(&stBaudRateMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iSelected))
    {
        ucCurBaud = (unsigned char)(iSelected % 0xFF);
        glSysParam._TxnModemPara.SSETUP &= 0x9F;    // 1001 1111
        glSysParam._TxnModemPara.SSETUP |= (ucCurBaud<<5);
    }
    else
    {
        return ERR_USERCANCEL;
    }

    if(isEMP)
    {
        SetEMP_Comm(CT_MODEM);
    }

	if( SetPabx(FALSE)!=0 )
	{
		return ERR_USERCANCEL;
	}

	int iValue = 0;

	if(!isEMP)
	{
	    iValue = glSysParam.stEdcInfo.bPreDial;
	   //---------------------------------------------------
        Gui_ClearScr();
        Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "PRE DIAL", gl_stCenterAttr,
                "ON", TRUE, "OFF", FALSE, USER_OPER_TIMEOUT, &iValue);
        glSysParam.stEdcInfo.bPreDial = iValue;
	}

    //---------------------------------------------------
	iValue = glSysParam._TxnModemPara.DP;
    Gui_ClearScr();
    Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "DIAL MODE", gl_stCenterAttr,
        "DTMF", 0, "PULSE", 1, USER_OPER_TIMEOUT, &iValue);
    glSysParam._TxnModemPara.DP = iValue;

     if(!isEMP)
     {
         //---------------------------------------------------
        iValue = glSysParam._TxnModemPara.CHDT;
        Gui_ClearScr();
        Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "DIAL TONE", gl_stCenterAttr,
            "DETECT", 0, "IGNORE", 1, USER_OPER_TIMEOUT, &iValue);
        glSysParam._TxnModemPara.CHDT = iValue;

        //---------------------------------------------------
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_NUM;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 2;
        stInputAttr.bEchoMode = 1;

        sprintf((char *)szPrompt, "DIAL WAIT:");
        sprintf((char *)szBuff, "OLD:%u(*100ms)", (uint)glSysParam._TxnModemPara.DT1);

        Gui_ClearScr();
        if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
            szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
        {
            return ERR_USERCANCEL;
        }
        glSysParam._TxnModemPara.DT1 = (uchar)atoi((char *)szBuff);

        //---------------------------------------------------
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_NUM;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 2;
        stInputAttr.bEchoMode = 1;

        sprintf((char *)szPrompt, "PABX PAUSE:");
        sprintf((char *)szBuff, "OLD:%u(*100ms)", (uint)glSysParam._TxnModemPara.DT2);

        Gui_ClearScr();
        if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
            szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
        {
            return ERR_USERCANCEL;
        }
        glSysParam._TxnModemPara.DT2 = (uchar)atoi((char *)szBuff);

        //---------------------------------------------------
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_NUM;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 3;
        stInputAttr.bEchoMode = 1;

        sprintf((char *)szPrompt, "ONE DTMF HOLD:");
        sprintf((char *)szBuff, "OLD:%u(*1ms)", (uint)glSysParam._TxnModemPara.HT);

        Gui_ClearScr();
        if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
            szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
        {
            return ERR_USERCANCEL;
        }
        glSysParam._TxnModemPara.HT = (uchar)atoi((char *)szBuff);


        //---------------------------------------------------
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_NUM;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 3;
        stInputAttr.bEchoMode = 1;

        sprintf((char *)szPrompt, "DTMF CODE SPACE:");
        sprintf((char *)szBuff, "OLD:%u(*10ms)", (uint)glSysParam._TxnModemPara.WT);

        Gui_ClearScr();
        if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
            szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
        {
            return ERR_USERCANCEL;
        }
        glSysParam._TxnModemPara.WT = (uchar)atoi((char *)szBuff);

        //---------------------------------------------------
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_NUM;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 3;
        stInputAttr.bEchoMode = 1;

        sprintf((char *)szPrompt, "SIGNAL LEVEL:");
        sprintf((char *)szBuff, "OLD:%u(0, 1~15)", (uint)glSysParam._TxnPSTNPara.ucSignalLevel);
        while (1)
        {
            Gui_ClearScr();
            if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
                szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
            {
                return ERR_USERCANCEL;
            }
            ucTemp = (uchar)atoi((char *)szBuff);
            if (ucTemp<16)
            {
                glSysParam._TxnPSTNPara.ucSignalLevel = ucTemp;
                break;
            }
        }
	}

	if(isEMP)
	{
        memset(&stInputAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
        stInputAttr.eType = GUI_INPUT_MIX;
        stInputAttr.nMinLen = 0;
        stInputAttr.nMaxLen = 5;
        stInputAttr.bEchoMode = 1;
	    sprintf((char *)szPrompt, "Country Code:");
	    strcpy((char *)szBuff, glSysParam._TxnPSTNPara.szCountryCode);

        Gui_ClearScr();
        if( GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
            szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
        {
            return ERR_USERCANCEL;
        }
        strcpy(glSysParam._TxnPSTNPara.szCountryCode, szBuff);
	}

	return 0;
}

int GetIpLocalSettings(void *pstParam)
{
	int		iRet;
	TCPIP_PARA *pstTcpipPara;

	pstTcpipPara = (TCPIP_PARA *)pstParam;

	iRet = GetIPAddress((uchar *)"LOCAL IP", TRUE, pstTcpipPara->szLocalIP);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetIPAddress((uchar *)"IP MASK", TRUE, pstTcpipPara->szNetMask);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetIPAddress((uchar *)"GATEWAY IP", TRUE, pstTcpipPara->szGatewayIP);
	if( iRet!=0 )
	{
		return iRet;
	}
	
	iRet = GetIPAddress((uchar *)"DNS", TRUE, pstTcpipPara->szDNSIP);
	if( iRet!=0 )
	{
		return iRet;
	}

	return 0;
}

int GetRemoteIp(const uchar *pszHalfText, uchar bAllowHostName, uchar bAllowNull, void *pstIPAddr)
{
	int		iRet;
	IP_ADDR	*pstIp;
	uchar	szBuff[51];

	pstIp = (IP_ADDR *)pstIPAddr;

	if(bAllowHostName)
	{
        sprintf((char *)szBuff, "%s Host", pszHalfText);
        iRet = GetHostDNS(szBuff, bAllowNull, pstIp->szIP);
        if( iRet!=0 )
        {
            return iRet;
        }
	}
	else
    {
        sprintf((char *)szBuff, "%s IP", pszHalfText);
        iRet = GetIPAddress(szBuff, bAllowNull, pstIp->szIP);
        if( iRet!=0 )
        {
            return iRet;
        }
    }

	sprintf((char *)szBuff, "%s PORT", pszHalfText);
	iRet = GetIPPort(szBuff, bAllowNull, pstIp->szPort);
	if( iRet<0 )
	{
		return iRet;
	}

	return 0;
}

int ChkIfValidIp(const uchar *pszIP)
{
	return ((pszIP[0]!=0) && (IsValidIPAddress(pszIP)));
}

int ChkIfValidPort(const uchar *pszPort)
{
	return ((pszPort[0]!=0) &&
			(atol((uchar *)pszPort)>0) &&
			(atol((uchar *)pszPort)<65536));
}

int SetTcpIpSharedPara(COMM_CONFIG *pstCommCfg)
{
#if 0 //no need for EMP
	int	iSel = pstCommCfg->ucTCPClass_BCDHeader;

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "TCP LENGTH", gl_stCenterAttr, 
		_T("BCD"), 1, _T("HEX"), 0, USER_OPER_TIMEOUT, &iSel))
	{
		return -1;
	}

	if(1 == iSel)
	{
		pstCommCfg->ucTCPClass_BCDHeader = TRUE;
	}
	else
	{
		pstCommCfg->ucTCPClass_BCDHeader = FALSE;
	}
#endif
	pstCommCfg->ucTCPClass_BCDHeader = FALSE;
	return 0;
}

// 设置TCP/IP参数
// set TCP/IP parameters
int SetTcpIpParam(void *pstParam, uchar isEMP)
{
	int		iRet;

	if(isEMP)
	{
	    SetEMP_Comm(CT_TCPIP);
	}

	// !!!! 需要应用到开机步骤
    iRet = SetTcpIpParam_S80((TCPIP_PARA *)pstParam);
	return iRet;
}

void SyncTcpIpParam(void *pstDst, const void *pstSrc)
{
	((TCPIP_PARA *)pstDst)->ucDhcp = ((TCPIP_PARA *)pstSrc)->ucDhcp;
	strcpy((char *)(((TCPIP_PARA *)pstDst)->szLocalIP),   (char *)(((TCPIP_PARA *)pstSrc)->szLocalIP));
	strcpy((char *)(((TCPIP_PARA *)pstDst)->szGatewayIP), (char *)(((TCPIP_PARA *)pstSrc)->szGatewayIP));
	strcpy((char *)(((TCPIP_PARA *)pstDst)->szNetMask),   (char *)(((TCPIP_PARA *)pstSrc)->szNetMask));
	strcpy((char *)(((TCPIP_PARA *)pstDst)->szDNSIP),     (char *)(((TCPIP_PARA *)pstSrc)->szDNSIP));
}

// Modified by Kim_LinHB 2014-5-31
// Added by Kim_LinHB 2014-5-31
int SetTcpIpParam_S80(TCPIP_PARA *pstParam)
{
	int		iRet;
	int iSelected = 0;
	uchar	szDispBuff[100];
	long	lTcpState;

	iRet = DhcpCheck();
	if (iRet==0)
	{
		sprintf((char *)szDispBuff, "DHCP: OK");
		iSelected = 1;
	}
	else
	{
		sprintf((char *)szDispBuff, "DHCP: STOPPED");
		iSelected = 0;
	}

	Gui_ClearScr();
	if(GUI_OK == Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, szDispBuff, gl_stCenterAttr,
		_T("START"), 1, _T("STOP"), 0, USER_OPER_TIMEOUT, &iSelected))
	{
		if(1 == iSelected)
		{
			pstParam->ucDhcp = 1;

			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("Getting IP..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
			if (SxxDhcpStart(FALSE, 30)==0)
			{
			    GUI_PAGE stPage;
			    GUI_PAGELINE stPageLines[4];
			    int iLines = 0;
				iRet = EthGet(pstParam->szLocalIP, pstParam->szNetMask, pstParam->szGatewayIP, pstParam->szDNSIP, &lTcpState);

				sprintf(stPageLines[iLines].szLine, "%s:%s", "LOCAL IP", pstParam->szLocalIP);
				stPageLines[iLines].stLineAttr.eAlign = GUI_ALIGN_LEFT;
				stPageLines[iLines].stLineAttr.eFontSize = GUI_FONT_NORMAL;
				stPageLines[iLines].stLineAttr.eStyle = GUI_FONT_STD;
				++iLines;

				sprintf(stPageLines[iLines].szLine, "%s:%s", "IP MASK", pstParam->szNetMask);
                stPageLines[iLines].stLineAttr.eAlign = GUI_ALIGN_LEFT;
                stPageLines[iLines].stLineAttr.eFontSize = GUI_FONT_NORMAL;
                stPageLines[iLines].stLineAttr.eStyle = GUI_FONT_STD;
                ++iLines;

				sprintf(stPageLines[iLines].szLine, "%s:%s", "GATEWAY IP", pstParam->szGatewayIP);
                stPageLines[iLines].stLineAttr.eAlign = GUI_ALIGN_LEFT;
                stPageLines[iLines].stLineAttr.eFontSize = GUI_FONT_NORMAL;
                stPageLines[iLines].stLineAttr.eStyle = GUI_FONT_STD;
                ++iLines;

				sprintf(stPageLines[iLines].szLine, "%s:%s", "DNS", pstParam->szDNSIP);
                stPageLines[iLines].stLineAttr.eAlign = GUI_ALIGN_LEFT;
                stPageLines[iLines].stLineAttr.eFontSize = GUI_FONT_NORMAL;
                stPageLines[iLines].stLineAttr.eStyle = GUI_FONT_STD;
                ++iLines;

                Gui_CreateInfoPage(GetCurrTitle(), gl_stTitleAttr, stPageLines, iLines, &stPage);
                Gui_ShowInfoPage(&stPage, 0, USER_OPER_TIMEOUT);
				return 0;
			}
		}
		else
		{
			pstParam->ucDhcp = 0;
		}
	}
	else
	{
		return -1;
	}
	

	// Manual setup
	if (iRet == 0)
	{
		DhcpStop();
	}

	if (pstParam->ucDhcp)
	{
		iRet = EthGet(pstParam->szLocalIP, pstParam->szNetMask, pstParam->szGatewayIP, pstParam->szDNSIP, &lTcpState);
	}

	iRet = GetIpLocalSettings(pstParam);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = EthSet(pstParam->szLocalIP, pstParam->szNetMask, pstParam->szGatewayIP, pstParam->szDNSIP);
	if (iRet < 0)
	{
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "SET STATIC IP\nFAILED.", gl_stCenterAttr, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);
		return -1;
	}

	return 0;
}

static int  GetHostDNS(const uchar *pszPrompts, uchar bAllowNull, uchar *pszName)
{
    uchar   szTemp[50 + 1];
    GUI_INPUTBOX_ATTR stInputBoxAttr;

    memset(&stInputBoxAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
    stInputBoxAttr.eType = GUI_INPUT_MIX;
    stInputBoxAttr.bEchoMode = 0;
    if(bAllowNull)
        stInputBoxAttr.nMinLen = 0;
    else
        stInputBoxAttr.nMinLen = 1;
    stInputBoxAttr.nMaxLen = sizeof(szTemp) - 1;

    sprintf((char *)szTemp, "%.50s", pszName);

    Gui_ClearScr();
    if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, pszPrompts, gl_stLeftAttr,
      szTemp, gl_stRightAttr, &stInputBoxAttr, USER_OPER_TIMEOUT))
    {
      return ERR_USERCANCEL;
    }

    if( bAllowNull && szTemp[0]==0 )
    {
      *pszName = 0;
    }
    else{
      sprintf((char *)pszName, "%.50s", szTemp);
    }
    return 0;
}

// 输入IP地址
// get Ip address
int GetIPAddress(const uchar *pszPrompts, uchar bAllowNull, uchar *pszIPAddress)
{
	uchar	szTemp[20];
	GUI_INPUTBOX_ATTR stInputBoxAttr;

	memset(&stInputBoxAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
	stInputBoxAttr.eType = GUI_INPUT_IPADDRESS;
	stInputBoxAttr.bEchoMode = 1;

	sprintf((char *)szTemp, "%.15s", pszIPAddress);

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, pszPrompts, gl_stLeftAttr, 
		szTemp, gl_stRightAttr, &stInputBoxAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	if( bAllowNull && szTemp[0]==0 )
	{
		*pszIPAddress = 0;
	}
	else{
		sprintf((char *)pszIPAddress, "%.15s", szTemp);
	}
	return 0;
}

// 检查IP地址
// verify the format of IP address
uchar IsValidIPAddress(const char *pszIPAddr)
{
	int		i;
	char	*p, *q, szBuf[5+1], szIp[16 + 1];

	sprintf(szIp, "%.*s",sizeof(szIp), pszIPAddr); // Modified by Kim_LinHB 2014-8-11 bug507

	PubTrimStr(szIp);
	if( *szIp==0 )
	{
		return FALSE;
	}

	p = strchr(szIp, ' ');
	if( p!=NULL )
	{
		return FALSE;
	}
	if( strlen(szIp)>15 )
	{
		return FALSE;
	}

	// 1st --- 3rd  part
	for(q=szIp, i=0; i<3; i++)
	{
		p = strchr(q, '.');
		if( p==NULL || p==q || p-q>3 )
		{
			return FALSE;
		}
		sprintf(szBuf, "%.*s", (int)(p-q), q);
		if( !IsNumStr(szBuf) || atoi(szBuf)>255 )
		{
			return FALSE;
		}
		q = p + 1;
	}

	// final part
	p = strchr((char *)q, '.');
	if( p!=NULL || !IsNumStr(q) || strlen(q)==0 || strlen(q)>3 || atoi(q)>255 )
	{
		return FALSE;
	}

	return TRUE;
}

// 输入端口
// get IP port
int GetIPPort(const uchar *pszPrompts, uchar bAllowNull, uchar *pszPortNo)
{
	int		iTemp;
	uchar	szTemp[15];

	GUI_INPUTBOX_ATTR stInputBoxAttr;

	memset(&stInputBoxAttr, 0, sizeof(GUI_INPUTBOX_ATTR));
	stInputBoxAttr.eType = GUI_INPUT_NUM;
	stInputBoxAttr.nMinLen = (bAllowNull ? 0 : 1);
	stInputBoxAttr.nMaxLen = 5;
	stInputBoxAttr.bEchoMode = 1;

	while( 1 )
	{
		sprintf((char *)szTemp, "%.5s", pszPortNo);
		Gui_ClearScr();
		
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, pszPrompts, gl_stLeftAttr, 
			szTemp, gl_stRightAttr, &stInputBoxAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		iTemp = atoi((char *)szTemp);
		if( iTemp>0 && iTemp<65535 )
		{
			sprintf((char *)pszPortNo, "%.5s", szTemp);
			break;
		}
		if (bAllowNull)
		{
			pszPortNo[0] = 0;
			break;
		}

		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INV PORT #"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 4, NULL);
	}

	return 0;
}

// 选择发卡行并修改参数
// select issuer and set its parameters
void SetIssuerParam(uchar ucPermission)
{
	int		iRet;
	uchar	ucIndex, szBuff[32], szBuff2[32];
#ifdef ENABLE_EMV
	int		iCnt;
	ulong	ulTemp;
	EMV_APPLIST	stEmvApp;
#endif

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;

	while (1)
	{
		iRet = SelectIssuer(&ucIndex);
		if( iRet!=0 )
		{
			return;
		}

		sprintf((char *)szBuff, "ISSUER: %-8.8s", (char *)glCurIssuer.szName);
		SetCurrTitle(szBuff);
		ModifyOptList(glSysParam.stIssuerList[ucIndex].sOption, 'I', ucPermission);

		if (ucPermission==PM_HIGH)
		{
			stInputAttr.nMinLen = 1;
			stInputAttr.nMaxLen = 2;
			sprintf((char *)szBuff2, "%lu", glSysParam.stIssuerList[ucIndex].ulFloorLimit);
			Gui_ClearScr();
			iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("NON-EMV FLOOR LIMIT"), gl_stLeftAttr,
					szBuff2, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
			if( GUI_OK == iRet )
			{
				glSysParam.stIssuerList[ucIndex].ulFloorLimit = (ulong)atoi(szBuff2);
			}

#ifdef ENABLE_EMV
			stInputAttr.nMinLen = 1;
			stInputAttr.nMaxLen = 4;
			memset(szBuff2, 0, sizeof(szBuff2));
			Gui_ClearScr();
			iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("EMV FLOOR LIMIT"), gl_stLeftAttr,
				szBuff2, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
			if( GUI_OK == iRet )
			{
				ulTemp = (ulong)atoi(szBuff2);
				for (iCnt=0;
					iCnt<glSysParam.stEdcInfo.stLocalCurrency.ucDecimal+glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit;
					iCnt++)
				{
					ulTemp *= 10;
				}

				for(iCnt=0; iCnt<MAX_APP_NUM; iCnt++)
				{
					memset(&stEmvApp, 0, sizeof(EMV_APPLIST));
					iRet = EMVGetApp(iCnt, &stEmvApp);
					if( iRet!=EMV_OK )
					{
						continue;
					}
					stEmvApp.FloorLimit = ulTemp;
					iRet = EMVAddApp(&stEmvApp);
				}
			}
#endif

			if (ChkEdcOption(EDC_TIP_PROCESS))
			{
				while (1)
				{
					stInputAttr.nMinLen = 1;
					stInputAttr.nMaxLen = 6;
					sprintf((char *)szBuff2, "%d", (int)(glSysParam.stIssuerList[ucIndex].ucAdjustPercent%100));
					Gui_ClearScr();
					iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("ADJUST PERCENT"), gl_stLeftAttr,
						szBuff2, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
					if( GUI_OK == iRet )
					{
						if (atoi(szBuff2)>50)
						{
							continue;
						}
						glSysParam.stIssuerList[ucIndex].ucAdjustPercent = (uchar)atoi(szBuff2);
						break;
					}
				}
			}

			if (ChkEdcOption(EDC_REFERRAL_DIAL))
			{
				stInputAttr.nMinLen = 1;
				stInputAttr.nMaxLen = 12;
				sprintf((char *)szBuff2, "%.12s", (char *)glSysParam.stIssuerList[ucIndex].szRefTelNo);
				Gui_ClearScr();
				iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("REFERRAL TEL"), gl_stLeftAttr,
					szBuff2, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
				if( GUI_OK == iRet )
				{
					sprintf((char *)glSysParam.stIssuerList[ucIndex].szRefTelNo, "%.12s", (char *)szBuff2);
				}
			}
		}

		SaveSysParam();
		if( glSysParam.ucIssuerNum<2 )
		{
			break;
		}
	}
}

// 设置收单行参数
// set acquirer's parameters
void SetAcqParam(uchar ucPermission)
{
	int		iRet;
	uchar	szTitle[16+1], szBuff[16+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.bEchoMode = 1;

	while (1)
	{
		sprintf((char *)szTitle, "%s", glSysParam.ucAcqNum>9 ? "SELECT ACQ:" : "SELECT ACQUIRER");
		iRet = SelectAcq(FALSE, szTitle, NULL);
		if( iRet!=0 )
		{
			return;
		}

		sprintf((char *)szTitle, "ACQ: %-10.10s ", (char *)glCurAcq.szName);


		while( 1 )
		{
			// Modified by Kim_LinHB 2014-7-30
			iRet = DispAcqPama();
			if(iRet != GUI_OK)
			{
				break;
			}

			// set all bit flag options
			SetCurrTitle(szTitle);
			if( ModifyOptList(glCurAcq.sOption, 'A', ucPermission)!=0 )
			{
				break;
			}

			if (ucPermission>PM_MEDIUM)
			{
				stInputAttr.eType = GUI_INPUT_MIX;
				stInputAttr.nMinLen = 3;
				stInputAttr.nMaxLen = 10;
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "ACQUIRER NAME", gl_stLeftAttr, 
					glCurAcq.szName, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					break;
				}
			}

			if (ucPermission>PM_LOW)
			{
				stInputAttr.eType = GUI_INPUT_MIX;//change for get alpha and num. linzhao 20151113
				stInputAttr.nMinLen = 8;
				stInputAttr.nMaxLen = 8;
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "TERMINAL ID", gl_stLeftAttr, 
					glCurAcq.szTermID, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					break;
				}

				stInputAttr.eType = GUI_INPUT_NUM;
				stInputAttr.nMinLen = 7;
				stInputAttr.nMaxLen = 15;
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "MERCHANT ID", gl_stLeftAttr, 
					glCurAcq.szMerchantID, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					break;
				}

				stInputAttr.eType = GUI_INPUT_NUM;
				stInputAttr.nMinLen = 3;
				stInputAttr.nMaxLen = 3;
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "NII", gl_stLeftAttr, glCurAcq.szNii, 
					gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					break;
				}

#ifdef ENABLE_DCC
			    int bEnableDcc = 0;
			    uchar szEnableDcc[120];
			    if(0 == GetEnv("E_DCC", szEnableDcc))
			    {
			        bEnableDcc = atoi(szEnableDcc);
			    }
				if(bEnableDcc != 0 && bEnableDcc != 1)
				    bEnableDcc = 0;
				Gui_ClearScr();
                if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "ENABLE DCC", gl_stCenterAttr,
                    "ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &bEnableDcc))
                {
                    break;
                }
                sprintf(szEnableDcc, "%d", bEnableDcc ? 1: 0);
                PutEnv("E_DCC", szEnableDcc);

                if(bEnableDcc)
                {
                    uchar szDccNii[120] = {"DCC NII\n"};
                    GetEnv("DCC_NII", szDccNii + strlen(szDccNii));
                    Gui_ClearScr();
                    if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDccNii,
                        gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
                    {
                        break;
                    }
                }
#endif
                int bEnableLoyalty = 0;
                uchar szEnableLoyalty[120];
                if(0 == GetEnv("E_LOY", szEnableLoyalty))
                {
                    bEnableLoyalty = atoi(szEnableLoyalty);
                }
                if(bEnableLoyalty != 0 && bEnableLoyalty != 1)
                    bEnableLoyalty = 0;
                Gui_ClearScr();
                if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "ENABLE LOYALTY", gl_stCenterAttr,
                    "ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &bEnableLoyalty))
                {
                    break;
                }
                sprintf(szEnableLoyalty, "%d", bEnableLoyalty ? 1: 0);
                PutEnv("E_LOY", szEnableLoyalty);

                if(bEnableLoyalty)
                {
                    uchar szLoyaltyNii[120] = {"Loyalty NII\n"};
                    GetEnv("LOY_NII", szLoyaltyNii + strlen(szLoyaltyNii));
                    Gui_ClearScr();
                    if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szLoyaltyNii,
                        gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
                    {
                        break;
                    }
                }

				stInputAttr.eType = GUI_INPUT_NUM;
				stInputAttr.nMinLen = 1;
				stInputAttr.nMaxLen = 6;
				sprintf((char *)szBuff, "%lu", glCurAcq.ulCurBatchNo);
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "BATCH NO.", gl_stLeftAttr, szBuff,
					gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					break;
				}
				if (glCurAcq.ulCurBatchNo!=(ulong)atoi(szBuff))
				{
					glCurAcq.ulCurBatchNo  = (ulong)atoi(szBuff);
					glCurAcq.ulNextBatchNo = GetNewBatchNo(glCurAcq.ulCurBatchNo);
				}

				if( SetAcqTransComm(glSysParam.stTxnCommCfg.ucCommType)!=0 )
				{
					break;
				}

				if( SetAcqTransComm(glSysParam.stTxnCommCfg.ucCommTypeBak)!=0 )
				{
					break;
				}

				if(CT_TCPIP == glSysParam.stTxnCommCfg.ucCommType ||
				   CT_CDMA == glSysParam.stTxnCommCfg.ucCommType ||
				   CT_GPRS == glSysParam.stTxnCommCfg.ucCommType ||
				   CT_WIFI == glSysParam.stTxnCommCfg.ucCommType ||
				   CT_TCPIP == glSysParam.stTxnCommCfg.ucCommTypeBak ||
                   CT_CDMA == glSysParam.stTxnCommCfg.ucCommTypeBak ||
                   CT_GPRS == glSysParam.stTxnCommCfg.ucCommTypeBak ||
                   CT_WIFI == glSysParam.stTxnCommCfg.ucCommTypeBak)
                    if(SetAcqTransEncrypt(&glCurAcq) != 0) // Added By Kim 20150320
                    {
                        break;
                    }
#ifndef TEST_SMS
				if(ChkHardware(HWCFG_PRINTER, 0))
#endif
				{ // NO Printer
				    SetNoPrinterPara(&glCurAcq);
				}
			}
			break;
		}

		memcpy(&glSysParam.stAcqList[glCurAcq.ucIndex], &glCurAcq, sizeof(ACQUIRER));
		SaveSysParam();
		if (glSysParam.ucAcqNum<2)
		{
			break;
		}
	}
}

static int SetNoPrinterPara(ACQUIRER *acq)
{
    int iRet;
    int iSelected;
    GUI_MENU stMenu;
    GUI_MENUITEM stDefMenuItem[] = {
        { _T_NOOP("Bluetooth Printer"), 1,TRUE,  NULL},
        { _T_NOOP("SMS"), 2,TRUE,  NULL},
        { _T_NOOP("EMAIL"), 3,FALSE,  NULL},
        { "", -1,FALSE,  NULL},
    };

    GUI_MENUITEM stMenuItem[4];
    int iMenuItemNum = 0;

    if(!ChkHardware(HWCFG_BLTH, HW_NONE) && stDefMenuItem[0].bVisible)
    {
        memcpy(&stMenuItem[iMenuItemNum], &stDefMenuItem[0], sizeof(GUI_MENUITEM));
        sprintf(stMenuItem[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefMenuItem[0].szText);
        ++iMenuItemNum;
    }

    if (!(ChkHardware(HWCFG_GPRS, HW_NONE) && ChkHardware(HWCFG_CDMA, HW_NONE)) &&
            stDefMenuItem[1].bVisible)
    {
        memcpy(&stMenuItem[iMenuItemNum], &stDefMenuItem[1], sizeof(GUI_MENUITEM));
        sprintf(stMenuItem[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefMenuItem[1].szText);
        ++iMenuItemNum;
    }

    if (!(ChkHardware(HWCFG_GPRS, HW_NONE) &&
         ChkHardware(HWCFG_CDMA, HW_NONE) &&
         ChkHardware(HWCFG_WIFI, HW_NONE)) &&
            stDefMenuItem[2].bVisible)
    {
        memcpy(&stMenuItem[iMenuItemNum], &stDefMenuItem[2], sizeof(GUI_MENUITEM));
        sprintf(stMenuItem[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefMenuItem[2].szText);
        ++iMenuItemNum;
    }

    if(!stMenuItem[0].bVisible && !stMenuItem[1].bVisible && !stMenuItem[2].bVisible)
        return 0;

    Gui_BindMenu(NULL, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stMenuItem, &stMenu);
    iSelected = 0;
    while( 1 )
    {
        Gui_ClearScr();

        iRet = Gui_ShowMenuList(&stMenu, 0, USER_OPER_TIMEOUT, &iSelected);
        if(iRet != GUI_OK)
        {
            break;
        }

        switch(iSelected)
        {
            case 1:
                iRet = SetBtPrinter();	//modified by Kevin 20150720
                if(iRet == GUI_OK)
                {
                	glSysParam.stEdcInfo.ucPrinterType = PRNMODE_BTPRNTER;
                	SaveSysParam();
                }
                break;
            case 2:
                iRet = SetSMS(acq);	//modified by Kevin 20150720
                if(iRet == GUI_OK)
				{
                	glSysParam.stEdcInfo.ucPrinterType = PRNMODE_SMS;
					SaveSysParam();
				}
                break;
            case 3:
                // SetEmail(smtpServer,port,username,password);
                break;
        }
    }
    return iRet;
}
//added by Kevin 20150720
int SetBtPrinter()
{
	int iRet = 0, i = 0, iFid = 0;
	ssize_t readSize;
	ST_BT_SCAN_RESULT scanResult[50];
	int scanCount = 0;
	char buf[10240] = "";
	uchar passwd[30] = "";
	GUI_MENU stBTPrinterMenu;
	GUI_MENUITEM stBTPrinterMenuItem[50];
	int iSelected = 0;
	uchar   szPrompt[30], szBuff[50], ucCurBaud, ucTemp;
	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 30;

	Gui_ClearScr();
	Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "BLUETOOTH OPENING", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

	//open POS bluetooth
	iRet = BTPrn_Open(glSysParam.stTxnCommCfg.stBlueToothPara.stScanResult.Name, 0);
	if(iRet != 0)
	{
		Gui_ClearScr();
		Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "OPEN ERROR", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);
		return iRet;
	}
	OsLog(LOG_INFO, "BTPrn_Open success!");
	Gui_ClearScr();
	Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "SCANNING", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);


	while(1)
	{
		memset(scanResult, 0, sizeof(scanResult));
		iRet = BTPrn_Scan(scanResult, &scanCount);
		if(iRet == ERR_BT_SCAN_DOING)
		{
			continue;
		}
		if(iRet != 0)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "SCAN ERROR", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);
			return iRet;
		}
		if(iRet == ERR_BT_NONE)
		{
			break;
		}
	}
	OsLog(LOG_INFO, "BTPrn_Scan success!");
	for(i=0;i<scanCount;i++)
	{
		OsLog(LOG_INFO, "BTPrn_Scan scanResult[%d]=%s!", i, scanResult[i].Name);
		memcpy(stBTPrinterMenuItem[i].szText, scanResult[i].Name, sizeof(stBTPrinterMenuItem[i].szText));
		stBTPrinterMenuItem[i].nValue = i;
		stBTPrinterMenuItem[i].bVisible = TRUE;
		stBTPrinterMenuItem[i].vFunc = NULL;
	}

	kbflush();
	Gui_BindMenu("BT DEVICE:", gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stBTPrinterMenuItem, &stBTPrinterMenu);
	Gui_ClearScr();
	if(GUI_OK == Gui_ShowMenuList(&stBTPrinterMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iSelected))
	{
		Gui_ClearScr();
		iRet = Gui_ShowInputBox("BlueTooth", gl_stTitleAttr, (char *)_T("INPUT PASSWORD(DEFAULT:1234)"), gl_stLeftAttr,
				passwd, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
		if(GUI_ERR_USERCANCELLED == iRet)
		{
			return iRet;
		}

		Gui_ClearScr();
		Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "PAIRING CONNECTING", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

		iRet = BTPrn_Pair(BT_PAIR_AUTH_DISPLAY_YESNO, 1, stBTPrinterMenuItem[iSelected].szText+3, passwd);
		if(iRet != 0)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "PAIR ERROR", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);
			return iRet;
		}
	}
	else
	{
		return ERR_USERCANCEL;
	}
	Gui_ClearScr();
	Gui_ShowMsgBox("BlueTooth", gl_stTitleAttr, "BT CONNECT OK", gl_stCenterAttr, GUI_BUTTON_OK, 3,NULL);

	kbflush();
	OsLog(LOG_INFO, "BTPrn_Pair success!");
	return GUI_OK;
}

int SetSMS(ACQUIRER *acq)
{
    int iRet;
    GUI_INPUTBOX_ATTR stInputAttr;

    memset(&stInputAttr, 0, sizeof(stInputAttr));
    stInputAttr.eType = GUI_INPUT_NUM;
    stInputAttr.bEchoMode = 1;
    stInputAttr.nMinLen = 3;
    stInputAttr.nMaxLen = 6;

    uchar   szCountryCallingCode[120]="";
    GetEnv("TELCODE", szCountryCallingCode);

    while(1){
        Gui_ClearScr();
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("COUNTRY CALLING CODES(00*)"), gl_stLeftAttr,
                szCountryCallingCode, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(GUI_ERR_USERCANCELLED == iRet)
            return iRet;
        if(memcmp(szCountryCallingCode, "00", 2))
        {
            OsBeep(4, 50);
            continue;
        }
        PutEnv("TELCODE", szCountryCallingCode);
        return GUI_OK;
    }
    return GUI_OK;
}

// 显示当前收单行参数信息
// display information of the current acquirer
// Modified by Kim_LinHB 2014-08-26 v1.01.0005 bug510
// Modified by Kim_LinHB 2014/9/16 v1.01.0009 bug510
int DispAcqPama(void)
{
	int		ii;
	uchar	ucShowComm;
	GUI_PAGELINE stBuff[20];
	GUI_PAGE stPage;
	unsigned char ucCnt = 0;

	sprintf(stBuff[ucCnt].szLine, "%-10.10s   %3.3s", glCurAcq.szName, glCurAcq.szNii);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	sprintf(stBuff[ucCnt].szLine, "TID:%s", glCurAcq.szTermID);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	strcpy(stBuff[ucCnt].szLine, "MID:");
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
	sprintf(stBuff[ucCnt].szLine, "%s", glCurAcq.szMerchantID);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	for (ii=0; ii<2; ii++)
	{
		ucShowComm = (ii ? glSysParam.stTxnCommCfg.ucCommTypeBak : glSysParam.stTxnCommCfg.ucCommType);

		if(1 == ii && ucShowComm != CT_NONE)
		{
			sprintf(stBuff[ucCnt].szLine, "SECONDARY COMM");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
		}

		switch(ucShowComm)
		{
		case CT_TCPIP:
		case CT_WIFI:
			sprintf(stBuff[ucCnt].szLine, "Transaction:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			if(strlen(glCurAcq.stTxnTCPIPInfo[0].szIP) > 0)
			{
				sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stTxnTCPIPInfo[0].szIP, glCurAcq.stTxnTCPIPInfo[0].szPort);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}

			if(strlen(glCurAcq.stTxnTCPIPInfo[1].szIP) > 0)
			{
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stTxnTCPIPInfo[1].szIP, glCurAcq.stTxnTCPIPInfo[1].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

			if(0 == strlen(glCurAcq.stTxnTCPIPInfo[0].szIP) && 0 == strlen(glCurAcq.stTxnTCPIPInfo[1].szIP))
			{
				sprintf(stBuff[ucCnt].szLine, "(NULL)");
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}

			sprintf(stBuff[ucCnt].szLine, "Settlement:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			if(strlen(glCurAcq.stStlTCPIPInfo[0].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stStlTCPIPInfo[0].szIP, glCurAcq.stStlTCPIPInfo[0].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(strlen(glCurAcq.stStlTCPIPInfo[1].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stStlTCPIPInfo[1].szIP, glCurAcq.stStlTCPIPInfo[1].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(0 == strlen(glCurAcq.stStlTCPIPInfo[0].szIP) && 0 == strlen(glCurAcq.stStlTCPIPInfo[1].szIP))
            {
                sprintf(stBuff[ucCnt].szLine, "(NULL)");
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }
			break;
		case CT_GPRS:
		case CT_CDMA:
			sprintf(stBuff[ucCnt].szLine, "Transaction:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

            if(strlen(glCurAcq.stTxnGPRSInfo[0].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stTxnGPRSInfo[0].szIP, glCurAcq.stTxnGPRSInfo[0].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(strlen(glCurAcq.stTxnGPRSInfo[1].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stTxnGPRSInfo[1].szIP, glCurAcq.stTxnGPRSInfo[1].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(0 == strlen(glCurAcq.stTxnGPRSInfo[0].szIP) && 0 == strlen(glCurAcq.stTxnGPRSInfo[1].szIP))
            {
                sprintf(stBuff[ucCnt].szLine, "(NULL)");
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

			sprintf(stBuff[ucCnt].szLine, "Settlement:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

            if(strlen(glCurAcq.stStlGPRSInfo[0].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stStlGPRSInfo[0].szIP, glCurAcq.stStlGPRSInfo[0].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(strlen(glCurAcq.stStlGPRSInfo[1].szIP) > 0)
            {
                sprintf(stBuff[ucCnt].szLine, "%s:%.5s", glCurAcq.stStlGPRSInfo[1].szIP, glCurAcq.stStlGPRSInfo[1].szPort);
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }

            if(0 == strlen(glCurAcq.stStlGPRSInfo[0].szIP) && 0 == strlen(glCurAcq.stStlGPRSInfo[1].szIP))
            {
                sprintf(stBuff[ucCnt].szLine, "(NULL)");
                stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
            }
			break;
		case CT_MODEM:
			sprintf(stBuff[ucCnt].szLine, "Transaction:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			if(strlen(glCurAcq.TxnTelNo1) > 0)
			{
				sprintf(stBuff[ucCnt].szLine, "%.21s", glCurAcq.TxnTelNo1);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
			if(strlen(glCurAcq.TxnTelNo2) > 0)
			{
				sprintf(stBuff[ucCnt].szLine, "%.21s", glCurAcq.TxnTelNo2);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
			if(0 == strlen(glCurAcq.TxnTelNo1) && 0 == strlen(glCurAcq.TxnTelNo2))
			{
				sprintf(stBuff[ucCnt].szLine, "(NULL)");
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}

			sprintf(stBuff[ucCnt].szLine, "Settlement:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			if(strlen(glCurAcq.StlTelNo1) > 0)
			{
				sprintf(stBuff[ucCnt].szLine, "%.21s", glCurAcq.StlTelNo1);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
			if(strlen(glCurAcq.StlTelNo2) > 0)
			{
				sprintf(stBuff[ucCnt].szLine, "%.21s", glCurAcq.StlTelNo2);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
			if(0 == strlen(glCurAcq.StlTelNo1) && 0 == strlen(glCurAcq.StlTelNo2))
			{
				sprintf(stBuff[ucCnt].szLine, "(NULL)");
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
			break;
		case CT_NONE:
		default:
			break;
		}
	}

	Gui_CreateInfoPage(NULL, gl_stTitleAttr, stBuff, ucCnt, &stPage);

	Gui_ClearScr();

	return Gui_ShowInfoPage(&stPage, FALSE, USER_OPER_TIMEOUT);
}

int SetAcqTransComm(uchar ucCommType)
{
	int		iRet;

	switch(ucCommType)
	{
	case CT_TCPIP:
	case CT_WIFI:
		iRet = GetRemoteIp("TRANS IP 1",  TRUE, TRUE, &glCurAcq.stTxnTCPIPInfo[0]);
		if (iRet)
		{
			break;
		}
		iRet = GetRemoteIp("TRANS IP 2",  TRUE, TRUE, &glCurAcq.stTxnTCPIPInfo[1]);
		//iRet = GetRemoteIp("SETTLE 1st", TRUE, &glCurAcq.stStlTCPIPInfo[0]);
		//iRet = GetRemoteIp("SETTLE 2nd", TRUE, &glCurAcq.stStlTCPIPInfo[1]);
		break;
	case CT_GPRS:
	case CT_CDMA:
		iRet = GetRemoteIp("TRANS IP 1",  TRUE, TRUE, &glCurAcq.stTxnGPRSInfo[0]);
		if (iRet)
		{
			break;
		}
		iRet = GetRemoteIp("TRANS IP 2",  TRUE, TRUE, &glCurAcq.stTxnGPRSInfo[1]);
		//iRet = GetRemoteIp("SETTLE 1st", TRUE, &glCurAcq.stStlGPRSInfo[0]);
		//iRet = GetRemoteIp("SETTLE 2nd", TRUE, &glCurAcq.stStlGPRSInfo[1]);
		break;
	case CT_MODEM:
		iRet = SetAcqTransTelNo();
        break;
	case CT_RS232:
	case CT_NONE:
	default:
		iRet = 0;
	    break;
	}

	return iRet;
}

static int  SetAcqTransEncrypt(ACQUIRER *acq)
{
    uchar szBuff[120] = {0};
    int bSSL = 0;
    uchar szSSL[120];
    if(0 == GetEnv("E_SSL", szSSL))
    {
        bSSL = atoi(szSSL);
    }

    int iRet = Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, _T("SSL"),
            gl_stLeftAttr, _T("No"), 0, _T("Yes"), 1,
            USER_OPER_TIMEOUT, &bSSL);
    if(iRet != GUI_OK)
        return iRet;

   sprintf(szSSL, "%d", bSSL? 1: 0);
   PutEnv("E_SSL", szSSL);

    if(bSSL){
        GUI_INPUTBOX_ATTR stInputAttr;

        memset(&stInputAttr, 0, sizeof(stInputAttr));
        stInputAttr.eType = GUI_INPUT_MIX;
        stInputAttr.bEchoMode = 1;
        stInputAttr.nMinLen = 1;
        stInputAttr.nMaxLen = 20;

        OsLog(LOG_ERROR, "%s--%d, CA_CRT", __FILE__, __LINE__ );//linzhao
        if(GetEnv("CA_CRT", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }

        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("CA File"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("CA_CRT", szBuff);

        if(GetEnv("CLI_CRT", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }

        OsLog(LOG_ERROR, "%s--%d, CLI_CRT:%s", __FILE__, __LINE__, szBuff );//linzhao
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Cert File"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        OsLog(LOG_ERROR, "%s--%d, CLI_CRT:%d", __FILE__, __LINE__ , iRet);//linzhao
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("CLI_CRT", szBuff);

        OsLog(LOG_ERROR, "%s--%d, CLI_KEY", __FILE__, __LINE__ );//linzhao
        if(GetEnv("CLI_KEY", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Private Key"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("CLI_KEY", szBuff);

        OsLog(LOG_ERROR, "%s--%d, NE_CA", __FILE__, __LINE__ );//linzhao
        if(GetEnv("NE_CA", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("NE CA File"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("NE_CA", szBuff);

        OsLog(LOG_ERROR, "%s--%d, NE_CCRT", __FILE__, __LINE__ );//linzhao
        if(GetEnv("NE_CCRT", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("NE Cert File"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("NE_CCRT", szBuff);

        OsLog(LOG_ERROR, "%s--%d, NE_CKEY", __FILE__, __LINE__ );//linzhao
        if(GetEnv("NE_CKEY", szBuff) != 0)
        {
            memset(szBuff, 0, sizeof(szBuff));
        }
        iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("NE Private Key"), gl_stLeftAttr, szBuff,gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if(iRet != GUI_OK)
            return iRet;
        PutEnv("NE_CKEY", szBuff);
    }
    return 0;
}

// 设置当前收单行交易电话号码
// set the transaction tel NO. of the current acquirer
int SetAcqTransTelNo(void)
{
	if( SetTel(glCurAcq.TxnTelNo1, _T("TRANS TELNO 1"))!=0 )
	{
		return ERR_USERCANCEL;
	}
	memcpy(&glSysParam.stAcqList[glCurAcq.ucIndex], &glCurAcq, sizeof(ACQUIRER));

	if( SetTel(glCurAcq.TxnTelNo2, _T("TRANS TELNO 2"))!=0 )
	{
		return ERR_USERCANCEL;
	}
	memcpy(&glSysParam.stAcqList[glCurAcq.ucIndex], &glCurAcq, sizeof(ACQUIRER));

	if( SetTel(glCurAcq.StlTelNo1, _T("SETTTLE TELNO 1"))!=0 )
	{
		return ERR_USERCANCEL;
	}
	memcpy(&glSysParam.stAcqList[glCurAcq.ucIndex], &glCurAcq, sizeof(ACQUIRER));

	if( SetTel(glCurAcq.StlTelNo2, _T("SETTTLE TELNO 2"))!=0 )
	{
		return ERR_USERCANCEL;
	}
	memcpy(&glSysParam.stAcqList[glCurAcq.ucIndex], &glCurAcq, sizeof(ACQUIRER));

	return 0;
}

// 设置电话号码
// set tel NO.
int SetTel(uchar *pszTelNo, const uchar *pszPromptInfo)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 24;
	stInputAttr.bEchoMode = 1;
   
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, pszPromptInfo, gl_stLeftAttr, 
		pszTelNo, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	return 0;
}

int SetWirelessParam(WIRELESS_PARAM *pstParam, uchar isEMP)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	if (pstParam==NULL)
	{
		return ERR_NO_DISP;
	}

	if(isEMP)
	{
	    SetEMP_Comm(CT_GPRS);
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.bEchoMode = 1;

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 32;
    Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP WIRELESS", gl_stTitleAttr, "APN", gl_stLeftAttr, pstParam->szAPN, 
		gl_stRightAttr, &stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}




	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 32;
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP WIRELESS", gl_stTitleAttr, "LOGIN NAME", gl_stLeftAttr, 
		pstParam->szUID, gl_stRightAttr, &stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 0;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 16;
	stInputAttr.bSensitive = 1;
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP WIRELESS", gl_stTitleAttr, "LOGIN PWD", gl_stLeftAttr, 
		pstParam->szPwd, gl_stRightAttr, &stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 16;
	stInputAttr.bSensitive = 1;
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP WIRELESS", gl_stTitleAttr, "SIM PIN", gl_stLeftAttr, pstParam->szSimPin, 
		gl_stRightAttr,&stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	return 0;
}

void SyncWirelessParam(WIRELESS_PARAM *pstDst, const WIRELESS_PARAM *pstSrc)
{
	strcpy((char *)(pstDst->szAPN),    (char *)(pstSrc->szAPN));
	strcpy((char *)(pstDst->szUID),    (char *)(pstSrc->szUID));
	strcpy((char *)(pstDst->szPwd),    (char *)(pstSrc->szPwd));
	strcpy((char *)(pstDst->szSimPin), (char *)(pstSrc->szSimPin));
	strcpy((char *)(pstDst->szDNS),    (char *)(pstSrc->szDNS));
}

//Added by Kim_LinHB 2014-8-16
//TODO Kim for now, ignore master case
#ifdef _PROLIN2_4_
int  SetBTParam(BT_PARAM *pstParam)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	if (pstParam==NULL)
	{
		return ERR_NO_DISP;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.bEchoMode = 1;

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = sizeof(pstParam->stScanResult.Name);
    Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP BULETOOTH", gl_stTitleAttr, "Name", gl_stLeftAttr, pstParam->stScanResult.Name,
		gl_stRightAttr, &stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = sizeof(pstParam->stPaired.LinkKey);
	stInputAttr.bSensitive = 1;
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP BULETOOTH", gl_stTitleAttr, "PIN", gl_stLeftAttr, pstParam->stPaired.LinkKey,
		gl_stRightAttr,&stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	return 0;
}
void SyncBTParam(BT_PARAM *pstDst, const BT_PARAM *pstSrc)
{
	//TODO Kim does it need to synchronize like monitor version, which will copy each parameter one by one.
	memcpy(pstDst, pstSrc, sizeof(BT_PARAM));
}
#else
int  SetBTParam(ST_BT_CONFIG *pstParam)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	if (pstParam==NULL)
	{
		return ERR_NO_DISP;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.bEchoMode = 1;

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = sizeof(pstParam->name);
    Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP BULETOOTH", gl_stTitleAttr, "Name", gl_stLeftAttr, pstParam->name, 
		gl_stRightAttr, &stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = sizeof(pstParam->pin);
	stInputAttr.bSensitive = 1;
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox("SETUP BULETOOTH", gl_stTitleAttr, "PIN", gl_stLeftAttr, pstParam->pin, 
		gl_stRightAttr,&stInputAttr,USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	return 0;
}
void SyncBTParam(ST_BT_CONFIG *pstDst, const ST_BT_CONFIG *pstSrc)
{
#ifdef _MIPS_
	pstDst->role = pstSrc->role;
	pstDst->baud = pstSrc->baud;
#endif
	strcpy((char *)(pstDst->name),   (char *)(pstSrc->name));
	strcpy((char *)(pstDst->pin),    (char *)(pstSrc->pin));
	strcpy((char *)(pstDst->mac),    (char *)(pstSrc->mac));
}
#endif
//Add End

// 设置EDC参数
// set EDC parameters
void SetEdcParam(uchar ucPermission)
{
	SetCurrTitle(_T("SETUP EDC"));
	
	while(1)
	{
		if (SetTermCurrency(ucPermission)!=0)
		{
			break;
		}
		if( SetMerchantName(ucPermission)!=0 )
		{
			break;
		}
		if( SetPEDMode()!=0 )
		{
			break;
		}

		if( SetAcceptTimeOut()!=0 )
		{
			break;
		}
		if( SetPrinterType()!=0 )
		{
			break;
		}
		if( SetNumOfReceipt()!=0 )
		{
			break;
		}
		// Add by lirz v1.02.0000
		if( SetTabBatchDay()!=0 )
		{
			break;
		}
		//autosettl foura
		if( SetTabSettleStart()!=0 )
		{
			break;
		}
		if( SetTabSettleMAX()!=0 )
		{
			break;
		}

		if( SetTermID()!=0 )
		{
			break;
		}

		if( SetMerchantID()!=0 )
		{
			break;
		}
		if( SetNii()!=0 )
		{
			break;
		}


//		uchar	szNii[3+1];
//		uchar	szTermID[8+1];
//		uchar	szMerchantID[15+1];


		if( SetTabBatchEnable()!=0 )
		{
			break;
		}
		// End add by lirz v1.02.0000
		if( SetGetSysTraceNo(ucPermission)!=0 )
		{
			break;
		}
		if( SetGetSysInvoiceNo(ucPermission)!=0 )
		{
			break;
		}

		ModifyOptList(glSysParam.stEdcInfo.sOption, 'E', ucPermission);
		ModifyOptList(glSysParam.stEdcInfo.sExtOption, 'e', ucPermission);
		break;
	}

	SaveEdcParam();

#ifdef ENABLE_EMV
	SyncEmvCurrency(glSysParam.stEdcInfo.stLocalCurrency.sCountryCode,
                    glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode,
					glSysParam.stEdcInfo.stLocalCurrency.ucDecimal);
#endif
}

// -1 : 值无改变 -2 : 超时或取消
// >=0 : 输入的合法值
// ucEdit      : 是否允许编辑
// pszFirstMsg : 标题下面第一行提示
// pszSecMsg   : 标题下面第二行提示
// ulMin,ulMax : 允许的取值范围
// lOrgValue   : 原值
// -1 : keeping -2 : timeout or cancel
// >=0 : valid input
// ucEdit      : if allowed to edit
// pszFirstMsg : the 1st line of prompt
// pszSecMsg   : the 2nd line of prompt
// ulMin,ulMax : value range
// lOrgValue   : original value
long ViewGetValue(uchar ucEdit, const void *pszFirstMsg, const void *pszSecMsg,
				  ulong ulMin, ulong ulMax, long lOrgValue)
{
	uchar	szBuff[32], szPrompt[200] = {0}, ucMinDigit, ucMaxDigit;
	ulong	ulTemp;
	int iRet;

	PubASSERT(ulMax<=0x07FFFFFF); // Modified by Kim_LinHB 2014-8-5 v1.01.0001
	//PubASSERT(ulMax<2147483648);

	ulTemp = ulMin;
	ucMinDigit = 0;
	do{ucMinDigit++;}while (ulTemp/=10);

	ulTemp = ulMax;
	ucMaxDigit = 0;
	do{ucMaxDigit++;}while (ulTemp/=10);

	memset(szBuff, 0, sizeof(szBuff));
	if (lOrgValue>=0)
	{
		sprintf((char *)szBuff, "%ld", lOrgValue);
	}

	if (pszFirstMsg!=NULL)
	{
		strcpy(szPrompt, _T(pszFirstMsg));
	}

	if (pszSecMsg!=NULL)
	{
		if(strlen(szPrompt) > 0){
			strcat(szPrompt, "\n");
		}
		strcat(szPrompt+strlen(szPrompt), _T(pszSecMsg));
	}

	if (ucEdit)
	{
		GUI_INPUTBOX_ATTR stInputAttr;

		memset(&stInputAttr, 0, sizeof(stInputAttr));
		stInputAttr.eType = GUI_INPUT_NUM;
		stInputAttr.nMinLen = ucMinDigit;
		stInputAttr.nMaxLen = ucMaxDigit;
		stInputAttr.bEchoMode = 1;

		while (1)
		{
			Gui_ClearScr();
			// Allow to modify 
			if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr, szBuff, 
				gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
			{
				return -2;
			}
			ulTemp = (ulong)atol((char *)szBuff);
			if ((ulTemp<ulMin) || (ulTemp>ulMax))
			{
				Gui_ClearScr();
				PubBeepErr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID VALUE"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
				continue;
			}

			if (ulTemp!=(ulong)lOrgValue)
			{
				return (long)ulTemp;
			}
			return -1;
		}
	}
	else
	{
		// Read only
		if(strlen(szPrompt) > 0){
			strcat(szPrompt, "\n");
			strcat(szPrompt, szBuff);
		}
		else{
			strcpy(szPrompt, szBuff);
		}
		Gui_ClearScr();
		iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
		
		if (iRet != GUI_OK)
		{
			return -2;
		}
		return -1;
	}
	return 0;
}

int SetTermCurrency(uchar ucPermission)
{
	uchar	szBuff[32];
	long	lTemp;
	CURRENCY_CONFIG	stCurrency;

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;

	stInputAttr.nMinLen = 3;
	stInputAttr.nMaxLen = 3;

	// Country Code
	PubBcd2Asc0(glSysParam.stEdcInfo.stLocalCurrency.sCountryCode, 2, szBuff);
    // Allow modify
	Gui_ClearScr();
    if (GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("AREA CODE"), gl_stLeftAttr, 
		szBuff+1, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
    {
        return ERR_USERCANCEL;
    }
        
    PubAsc2Bcd(szBuff, 3, glSysParam.stEdcInfo.stLocalCurrency.sCountryCode);

	// Currency
	PubBcd2Asc0(glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2, szBuff);
	memmove(szBuff, szBuff+1, 4);

	if (ucPermission<PM_HIGH)
	{
		// Modified by Kim_LinHB 2014-08-18 v1.01.0004
		int iRet;
		unsigned char szBuff_Temp[200];
		sprintf(szBuff_Temp, "%s\n%s", _T("CURRENCY CODE"), szBuff);
		// Read only
		Gui_ClearScr();
		iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff_Temp, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
		if (iRet != GUI_OK)
		{
			return ERR_USERCANCEL;
		}
	}
	else
	{
		while(1)
		{
			while (2)
			{
				PubBcd2Asc0(glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2, szBuff);
				memmove(szBuff, szBuff+1, 4);

				Gui_ClearScr();
				// Allow modify
				if (GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("CURRENCY CODE"), 
					gl_stLeftAttr, szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
				{
					return ERR_USERCANCEL;
				}
				if (FindCurrency(szBuff, &stCurrency)!=0)
				{   
					Gui_ClearScr();
					PubBeepErr();
					Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID CURRENCY"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
					continue;
				}
				break;
			}
       
			Gui_ClearScr();
			sprintf((char *)szBuff, "%.3s %02X%02X",
				stCurrency.szName, stCurrency.sCurrencyCode[0], stCurrency.sCurrencyCode[1]);
			if (GUI_ERR_USERCANCELLED == Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL))
			{
				continue;
			}
			break;
		}
		sprintf((char *)glSysParam.stEdcInfo.stLocalCurrency.szName, "%.3s", stCurrency.szName);
		memcpy(glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, stCurrency.sCurrencyCode, 2);
	}

	// Input decimal position value, 0<=x<=3
	// for JPY and KRW, x=0; for TWD, x=0 or x=2
	lTemp = ViewGetValue((uchar)(ucPermission>PM_MEDIUM), _T("DECIMAL POSITION"), NULL,
						0, 3, (long)glSysParam.stEdcInfo.stLocalCurrency.ucDecimal);
	if (lTemp==-2)
	{
		return ERR_USERCANCEL;
	}
	if (lTemp>=0)
	{
		glSysParam.stEdcInfo.stLocalCurrency.ucDecimal = (uchar)lTemp;
	}

	// Input ignore digit value, 0<=x<=3
	// for JPY and KRW, x=2; for TWD, when decimal=0, x=2; decimal=2, x=0;
	lTemp = ViewGetValue((uchar)(ucPermission>PM_MEDIUM), _T("IGNORE DIGIT"), NULL,
						0, 3, (long)glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit);
	if (lTemp==-2)
	{
		return ERR_USERCANCEL;
	}
	if (lTemp>=0)
	{
		glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit = (uchar)lTemp;
	}

	return 0;
}

int SetMerchantName(uchar ucPermission)
{
	uchar	szBuff[46+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	if (ucPermission<PM_HIGH)	// Not allow to set
	{
		return 0;
	}


	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	
	//NAME
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 23;
	sprintf((char *)szBuff, "%.23s", (char *)glSysParam.stEdcInfo.szMerchantName);
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("MERCHANT NAME"), gl_stLeftAttr, 
		szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}
	if (strcmp((char *)glSysParam.stEdcInfo.szMerchantName, (char *)szBuff)!=0)
	{
		sprintf((char *)glSysParam.stEdcInfo.szMerchantName, "%.23s", (char *)szBuff);
	}

	//ADDRESS
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 46;
	sprintf((char *)szBuff, "%.46s", (char *)glSysParam.stEdcInfo.szMerchantAddr);
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("MERCHANT ADDR"), gl_stLeftAttr, 
		szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}
	if (strcmp((char *)glSysParam.stEdcInfo.szMerchantAddr, (char *)szBuff)!=0)
	{
		sprintf((char *)glSysParam.stEdcInfo.szMerchantAddr, "%.23s", (char *)szBuff);
	}

	return 0;
}

int SetGetSysTraceNo(uchar ucPermission)
{
	uchar	szBuff[20];

	Gui_ClearScr();
	if (ucPermission>PM_LOW)
	{
		GUI_INPUTBOX_ATTR stInputAttr;

		memset(&stInputAttr, 0, sizeof(stInputAttr));
		stInputAttr.eType = GUI_INPUT_NUM;
		stInputAttr.bEchoMode = 1;

		//NAME
		stInputAttr.nMinLen = 1;
		stInputAttr.nMaxLen = 6;

		sprintf((char *)szBuff, "%06ld", glSysCtrl.ulSTAN);
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "S.T.A.N.", gl_stLeftAttr, szBuff, 
			gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		glSysCtrl.ulSTAN = (ulong)atol((char *)szBuff);
		SaveSysCtrlBase();
	} 
	else
	{
		sprintf(szBuff, "S.T.A.N.\n%06ld", glSysCtrl.ulSTAN);
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
	}

	return 0;
}

int SetGetSysInvoiceNo(uchar ucPermission)
{
	uchar	szBuff[20];

	Gui_ClearScr();
	if (ucPermission>PM_LOW)
	{
		GUI_INPUTBOX_ATTR stInputAttr;

		memset(&stInputAttr, 0, sizeof(stInputAttr));
		stInputAttr.eType = GUI_INPUT_NUM;
		stInputAttr.bEchoMode = 1;

		//NAME
		stInputAttr.nMinLen = 1;
		stInputAttr.nMaxLen = 6;

		sprintf((char *)szBuff, "%06ld", glSysCtrl.ulInvoiceNo);
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "TRACE NO", gl_stLeftAttr, szBuff, //TRACE NO
			gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		glSysCtrl.ulInvoiceNo = (ulong)atol((char *)szBuff);
		SaveSysCtrlBase();
	} 
	else
	{
		sprintf(szBuff, "TRACE NO\n%06ld", glSysCtrl.ulInvoiceNo);//TRACE NO
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
	}

	return 0;
}

// Select PED mode used.
int SetPEDMode(void)
{
	int	iSel = 0;

	GUI_MENU stPINPADMenu;
	GUI_MENUITEM stPINPADMenuItem[] = {
	    { "1.PCI PED", PED_INT_PCI, TRUE,  NULL},
		{ "2.PINPAD", PED_EXT_PP, TRUE,  NULL},
		{ "3.EXT PCI PINPAD", PED_EXT_PCI, TRUE,  NULL},
		{ "", -1, FALSE,  NULL},
	};

	iSel = glSysParam.stEdcInfo.ucPedMode;
	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stPINPADMenuItem, &stPINPADMenu);
	
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowMenuList(&stPINPADMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iSel))
	{
		return ERR_USERCANCEL;
	}

	glSysParam.stEdcInfo.ucPedMode = (uchar)iSel;
	return 0;
}

// 输入交易成功时确认信息显示时间
// set the timeout for display "TXN accepted" message
int SetAcceptTimeOut(void)
{
	uchar	szBuff[2+1];

	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 2;
	
	while( 1 )
	{
		sprintf((char *)szBuff, "%d", glSysParam.stEdcInfo.ucAcceptTimeout);
	   
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "Confirm Timeout", stPrompt, 
			szBuff, stContent, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}
		if( atoi((char *)szBuff)<=60 )
		{
			break;
		}

		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID INPUT"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
	}
	glSysParam.stEdcInfo.ucAcceptTimeout = (uchar)atoi((char *)szBuff);

	return 0;
}

int SetPrinterType(void)
{
	int 	iSel = glSysParam.stEdcInfo.ucPrinterType;

	// 仅适用于分离式打印机
	if (!ChkTerm(_TERMINAL_S60_))
	{
		return 0;
	}

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "PRINTER TYPE", gl_stCenterAttr, 
		"THERMAL", 1, "SPROCKET", 0, USER_OPER_TIMEOUT, &iSel))
	{
		return ERR_USERCANCEL;
	}

	glSysParam.stEdcInfo.ucPrinterType = iSel;
	return 0;
}

// 输入热敏打印单据张数
// set receipt numbers, just for thermal terminal
int SetNumOfReceipt(void)
{
	uchar 	ucNum, szBuff[1+1];
	int iCnt = 0;
	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	if( (!ChkIfThermalPrinter()) && (PRNMODE_BTPRNTER!=glSysParam.stEdcInfo.ucPrinterType) )
	{
		return 0;
	}

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 1;

	iCnt = NumOfReceipt();
	while( 1 )
	{
		sprintf((char *)szBuff, "%d", iCnt);
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "Receipt pages", stPrompt, 
			szBuff, stContent, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		ucNum = (uchar)atoi((char *)szBuff);
		if( ucNum>=1 && ucNum<=4 )
		{
			ucNum--;
			break;
		}
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID INPUT"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
	}

	glSysParam.stEdcInfo.sOption[EDC_NUM_PRINT_LOW/0x100]  &= (0xFF^(EDC_NUM_PRINT_LOW%0x100));
	glSysParam.stEdcInfo.sOption[EDC_NUM_PRINT_HIGH/0x100] &= (0xFF^(EDC_NUM_PRINT_HIGH%0x100));
	if( ucNum & 0x01 )
	{
		glSysParam.stEdcInfo.sOption[EDC_NUM_PRINT_LOW/0x100] |= (EDC_NUM_PRINT_LOW%0x100);
	}
	if( ucNum & 0x02 )
	{
		glSysParam.stEdcInfo.sOption[EDC_NUM_PRINT_HIGH/0x100] |= (EDC_NUM_PRINT_HIGH%0x100);
	}

	return 0;
}

// set check days for pre-auth transaction,range from 1 to 14 days
int SetTabBatchDay(void)
{
	uchar ucNum, szBuff[2+1];
	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 2;

int i=0 ;
	while( 1 )
	{
		sprintf((char *)szBuff, "%d", glSysCtrl.authCtrl.uiTabBatchDay);
		  Gui_ClearScr();
		  Gui_ShowMsgBox("Pre-auth check days", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
			break;

//		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, "Pre-auth check days(01-99)", stPrompt,
//			szBuff, stContent, &stInputAttr, USER_OPER_TIMEOUT))
//		{
//			return ERR_USERCANCEL;
//		}

//		ucNum = (uchar)atoi((char *)szBuff);
//		if( ucNum>=1 && ucNum<=99 )//linzhao 20160101
//		{
//			glSysCtrl.authCtrl.uiTabBatchDay = ucNum;
//			SaveSysCtrlBase();
//			break;
//		}
//		Gui_ClearScr();
//		PubBeepErr();
//		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID INPUT"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
	}

	return 0;
}


int SetTabSettleStart(void)
{
	uchar ucNum, szBuff[2+1];
	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 2;

int i=0 ;
	while( 1 )
	{
		sprintf((char *)szBuff, "%d", glSysCtrl.uSettlSTATR);
		  Gui_ClearScr();
		  Gui_ShowMsgBox("Start Settle Time", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
			break;

	}

	return 0;
}

int SetTabSettleMAX(void)
{
	uchar ucNum, szBuff[2+1];
	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 2;

int i=0 ;
	while( 1 )
	{
		sprintf((char *)szBuff, "%d", glSysCtrl.uSettlMAX);
		  Gui_ClearScr();
		  Gui_ShowMsgBox("Max Settle Attempt", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
			break;


	}

	return 0;
}




int SetTermID(void)
{
	uchar ucNum, szBuff[8+1];
	GUI_TEXT_ATTR stPrompt, stContent;
	GUI_INPUTBOX_ATTR stInputAttr;

	stPrompt = stContent = gl_stCenterAttr;
	stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
	stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
	stContent.eAlign = GUI_ALIGN_RIGHT;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 8;
	stInputAttr.nMaxLen = 8;

int i=0 ;
	while( 1 )
	{
		sprintf((char *)szBuff, "%s", glSysCtrl.szTermID_TEMP);
		  Gui_ClearScr();
		  Gui_ShowMsgBox("Terminal ID Temp", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
			break;


	}

	return 0;
}
int SetMerchantID(void)
{	uchar ucNum, szBuff[15+1];
GUI_TEXT_ATTR stPrompt, stContent;
GUI_INPUTBOX_ATTR stInputAttr;

stPrompt = stContent = gl_stCenterAttr;
stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
stContent.eAlign = GUI_ALIGN_RIGHT;

memset(&stInputAttr, 0, sizeof(stInputAttr));
stInputAttr.eType = GUI_INPUT_NUM;
stInputAttr.bEchoMode = 1;
stInputAttr.nMinLen = 8;
stInputAttr.nMaxLen = 15;

int i=0 ;
while( 1 )
{
	sprintf((char *)szBuff, "%s", glSysCtrl.szMerchantID_AMEX);
	  Gui_ClearScr();
	  Gui_ShowMsgBox("Merchant ID Amex", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
		break;


}

return 0;

}

int SetNii(void)
{	uchar ucNum, szBuff[3+1];
GUI_TEXT_ATTR stPrompt, stContent;
GUI_INPUTBOX_ATTR stInputAttr;

stPrompt = stContent = gl_stCenterAttr;
stPrompt.eAlign = GUI_ALIGN_LEFT;
#ifdef _Sxx_
stPrompt.eFontSize = GUI_FONT_SMALL;
#endif
stContent.eAlign = GUI_ALIGN_RIGHT;

memset(&stInputAttr, 0, sizeof(stInputAttr));
stInputAttr.eType = GUI_INPUT_NUM;
stInputAttr.bEchoMode = 1;
stInputAttr.nMinLen = 3;
stInputAttr.nMaxLen = 3;

int i=0 ;
while( 1 )
{
	sprintf((char *)szBuff, "%s", glSysCtrl.szNii_Temp);
	  Gui_ClearScr();
	  Gui_ShowMsgBox("Nii Temp", gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
		break;


}

return 0;

}
// enable or disable Tab Batch for pre-auth
int SetTabBatchEnable(void)
{
	int iOption = glSysCtrl.authCtrl.ucEnableTabBatch;
	if(GUI_OK == Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, "ENABLE TAB BATCH ?", gl_stCenterAttr,
									 "ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &iOption))
	{
		return ERR_USERCANCEL;
	}

	if(0 == iOption)
	{
		glSysCtrl.authCtrl.ucEnableTabBatch = 0;
	}
	else
	{
		glSysCtrl.authCtrl.ucEnableTabBatch = 1;
	}
	SaveSysCtrlBase();

	return 0;
}

// 输入参数自动更新时间
// set timer for update parameters automatically
int SetCallInTime(void)
{
	return 0;
}

// TRUE:判断时间是否合法
// TRUE:it is a valid time
uchar IsValidTime(const uchar *pszTime)
{
	int		i, iHour, iMinute;

	for(i=0; i<4; i++)
	{
		if( pszTime[i]<'0' || pszTime[i]>'9' )
		{
			return FALSE;
		}
	}

	iHour   = (int)PubAsc2Long(pszTime, 2);
	iMinute = (int)PubAsc2Long(pszTime+2, 2);
	if( iHour>24 || iMinute>59 )
	{
		return FALSE;
	}
	if( iHour==24 && iMinute!=0 )
	{
		return FALSE;
	}

	return TRUE;
}

// 修改或者查看开关选项
// modify or view options
// Modified by Kim_LinHB 2014-08-18 v1.01.0004
int ModifyOptList(uchar *psOption, uchar ucMode, uchar ucPermission)
{
	// 通过FUN2进入设置时，若定义了FUN2_READ_ONLY，则用户权限为PM_LOW，否则用户权限为PM_MEDIUM
	// 使用无下载方式初始化时，用户权限为PM_HIGH
	// when setting in Function #2, if activate the macro FUN2_READ_ONLY, then user permission is PM_LOW, otherwise it is PM_MEDIUM
	// if initiated with "load default", then user permission is PM_HIGH

	// Protims可控的issuer option列表
	// available issuer options list in Protims
	static OPTION_INFO stIssuerOptList[] =
	{
// 		{"CAPTURE CASH?",		ALLOW_EXTEND_PAY,			FALSE,	PM_MEDIUM},
		{"CAPTURE TXN",			ISSUER_CAPTURE_TXN,			FALSE,	PM_MEDIUM},
		{"ENABLE BALANCE?",		ISSUER_EN_BALANCE,			FALSE,	PM_MEDIUM},
		{"ENABLE ADJUST",		ISSUER_EN_ADJUST,			FALSE,	PM_MEDIUM},
		{"ENABLE OFFLINE",		ISSUER_EN_OFFLINE,			FALSE,	PM_MEDIUM},
		{"ALLOW (PRE)AUTH",		ISSUER_NO_PREAUTH,			TRUE,	PM_MEDIUM},
		{"ALLOW REFUND",		ISSUER_NO_REFUND,			TRUE,	PM_MEDIUM},
		{"ALLOW VOID",			ISSUER_NO_VOID,				TRUE,	PM_MEDIUM},
		{"ENABLE EXPIRY",		ISSUER_EN_EXPIRY,			FALSE,	PM_MEDIUM},
		{"CHECK EXPIRY",		ISSUER_CHECK_EXPIRY,		FALSE,	PM_MEDIUM},
//		{"CHKEXP OFFLINE",		ISSUER_CHECK_EXPIRY_OFFLINE,FALSE,	PM_MEDIUM},
		{"CHECK PAN",			ISSUER_CHKPAN_MOD10,		FALSE,	PM_MEDIUM},
// 		{"CHECK PAN11",			ISSUER_CHKPAN_MOD11,		FALSE,	PM_MEDIUM},
//		{"EN DISCRIPTOR",		ISSUER_EN_DISCRIPTOR,		FALSE,	PM_MEDIUM},
		{"ENABLE MANUAL",		ISSUER_EN_MANUAL,			FALSE,	PM_MEDIUM},
		{"ENABLE PRINT",		ISSUER_EN_PRINT,			FALSE,	PM_MEDIUM},
		{"VOICE REFERRAL",		ISSUER_EN_VOICE_REFERRAL,	FALSE,	PM_MEDIUM},
		{"PIN REQUIRED",		ISSUER_EN_PIN,				FALSE,	PM_HIGH},//
#ifdef ISSUER_EN_EMVPIN_BYPASS
		{"EMV PIN BYPASS",		ISSUER_EN_EMVPIN_BYPASS,	FALSE,	PM_MEDIUM},
#endif
//		{"ACCOUNT SELECT",		ISSUER_EN_ACCOUNT_SELECTION,FALSE,	PM_MEDIUM},
//		{"ROC INPUT REQ",		ISSUER_ROC_INPUT_REQ,		FALSE,	PM_MEDIUM},
//		{"DISP AUTH CODE",		ISSUER_AUTH_CODE,			FALSE,	PM_MEDIUM},
//		{"ADDTIONAL DATA",		ISSUER_ADDTIONAL_DATA,		FALSE,	PM_MEDIUM},
		{"4DBC WHEN SWIPE",		ISSUER_SECURITY_SWIPE,		FALSE,	PM_MEDIUM},
		{"4DBC WHEN MANUL",		ISSUER_SECURITY_MANUL,		FALSE,	PM_MEDIUM},
		{NULL, 0, FALSE, PM_DISABLE},
	};

	// Protims可控的acquirer option列表
	// available acquirer options list in Protims
	static OPTION_INFO stAcqOptList[] =
	{
		{"ONLINE VOID",			ACQ_ONLINE_VOID,			FALSE,	PM_MEDIUM},
		{"ONLINE REFUND",		ACQ_ONLINE_REFUND,			FALSE,	PM_MEDIUM},
		{"EN. TRICK FEED",		ACQ_DISABLE_TRICK_FEED,		TRUE,	PM_MEDIUM},
//		{"ADDTION PROMPT",		ACQ_ADDTIONAL_PROMPT,		FALSE,	PM_MEDIUM},
		{"AMEX ACQUIRER",		ACQ_AMEX_SPECIFIC_FEATURE,	FALSE,	PM_HIGH},
		{"DBS FEATURE",			ACQ_DBS_FEATURE,			FALSE,	PM_MEDIUM},
		{"BOC INSTALMENT",		ACQ_BOC_INSTALMENT_FEATURE,	FALSE,	PM_MEDIUM},
		{"CITI INSTALMENT",		ACQ_CITYBANK_INSTALMENT_FEATURE,FALSE,	PM_MEDIUM},
#ifdef ENABLE_EMV
		{"EMV ACQUIRER",		ACQ_EMV_FEATURE,			FALSE,	PM_HIGH},
#endif
		{NULL, 0, FALSE, PM_DISABLE},
	};

	// Protims不可控的acquirer option列表
	// invalid in Protims
	static OPTION_INFO stAcqExtOptList[] =
	{
		// 因为只能在且必须在POS上修改，因此权限设为PM_LOW
		// this options list can only be modified on POS, so user permission is set as PM_LOW
		{NULL, 0, FALSE, PM_DISABLE},
	};

	// Protims可控的edc option列表
	// available EDC options list in Protims
	static OPTION_INFO stEdcOptList[] =
	{
//		{"AUTH PAN MASKING",	EDC_AUTH_PAN_MASKING,	FALSE,	PM_LOW},
//		{"SELECT ACQ_CARD",		EDC_SELECT_ACQ_FOR_CARD,FALSE,	PM_LOW},
        {"ENABLE ECR",          EDC_ECR_ENABLE,         FALSE,  PM_LOW},
		{"FREE PRINT",			EDC_FREE_PRINT,			FALSE,  PM_LOW},
		{"EN. INSTALMENT?",		EDC_ENABLE_INSTALMENT,	FALSE,	PM_MEDIUM},
		{"CAPTURE CASH",		EDC_CASH_PROCESS,		FALSE,	PM_MEDIUM},
		{"REFERRAL DIAL",		EDC_REFERRAL_DIAL,		FALSE,	PM_MEDIUM},
		{"1.AUTH 0.PREAUTH",	EDC_AUTH_PREAUTH,		FALSE,	PM_MEDIUM},
//		{"PRINT TIME",			EDC_PRINT_TIME,			FALSE,	PM_MEDIUM},
		{"TIP PROCESSING",		EDC_TIP_PROCESS,		FALSE,	PM_MEDIUM},
//		{"USE PRINTER",			EDC_USE_PRINTER,		FALSE,	PM_MEDIUM},
		{"NEED ADJUST PWD",		EDC_NOT_ADJUST_PWD,		TRUE,	PM_HIGH},
		{"NEED SETTLE PWD",		EDC_NOT_SETTLE_PWD,		TRUE,	PM_HIGH},
		{"NEED REFUND PWD",		EDC_NOT_REFUND_PWD,		TRUE,	PM_HIGH},
		{"NEED VOID PWD",		EDC_NOT_VOID_PWD,		TRUE,	PM_HIGH},
		{"NEED MANUAL PWD",		EDC_NOT_MANUAL_PWD,		TRUE,	PM_HIGH},
//		{"LOCKED EDC",			EDC_NOT_KEYBOARD_LOCKED,TRUE,	PM_MEDIUM},
		{NULL, 0, FALSE, PM_DISABLE},
	};

	// Protims不可控的edc option列表
	// invalid in Protims
	static OPTION_INFO stEdcExtOptList[] =
	{
		// 因为只能在且必须在POS上修改，因此权限设为PM_LOW
		// this options list can only be modified on POS, so user permission is set as PM_LOW
		{NULL, 0, FALSE, PM_DISABLE},
	};

	OPTION_INFO		*pstCurOpt;
	uchar			ucCnt, ucOptIndex, ucOptBitNo;
	int             iOption = 0;

	switch(ucMode)
	{
	case 'I':
	case 'i':
		pstCurOpt = (OPTION_INFO *)stIssuerOptList;
		break;
	case 'E':
		pstCurOpt = (OPTION_INFO *)stEdcOptList;
		break;
	case 'e':
		pstCurOpt = (OPTION_INFO *)stEdcExtOptList;
		break;
	case 'A':
		pstCurOpt = (OPTION_INFO *)stAcqOptList;
		break;
	case 'a':
		pstCurOpt = (OPTION_INFO *)stAcqExtOptList;
		break;
	default:
		break;
	}

	if( pstCurOpt->pText==NULL )
	{
		return 0;
	}

	ucCnt = 0;
	while( 1 )
	{
		ucOptIndex = (uchar)(pstCurOpt[ucCnt].uiOptVal>>8);
		ucOptBitNo = (uchar)(pstCurOpt[ucCnt].uiOptVal & 0xFF);
		if (pstCurOpt[ucCnt].ucInverseLogic)
		{
		    iOption = (psOption[ucOptIndex] & ucOptBitNo) ? 0 : 1;
		}
		else
		{
		    iOption = (psOption[ucOptIndex] & ucOptBitNo) ? 1 : 0;
		}

		if (ucPermission>=pstCurOpt[ucCnt].ucPermissionLevel)
		{
			Gui_ClearScr();
			if(GUI_OK == Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, pstCurOpt[ucCnt].pText, gl_stCenterAttr,
				"ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &iOption))
			{
				if(1 == iOption)
				{
					if (pstCurOpt[ucCnt].ucInverseLogic)
					{
						psOption[ucOptIndex] &= ~ucOptBitNo;
					}
					else
					{
						psOption[ucOptIndex] |= ucOptBitNo;
					}
				}
				else
				{
					if (pstCurOpt[ucCnt].ucInverseLogic)
					{
						psOption[ucOptIndex] |= ucOptBitNo;
					}
					else
					{
						psOption[ucOptIndex] &= ~ucOptBitNo;
					}
				}
			}
			else
			{
				return ERR_USERCANCEL;
			}
		}
		else{
			unsigned char szBuff[100];
			sprintf(szBuff, "%s\n%s", (char *)pstCurOpt[ucCnt].pText, 1 == iOption ? "ON" : "OFF");
			Gui_ClearScr();
			if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL)){
				return ERR_USERCANCEL;
			}
		}

		if( pstCurOpt[ucCnt+1].pText==NULL )
		{
			return 0;
		}
		ucCnt++;
	}

	return 0;
}

// 修改口令
// change passwords
int ChangePassword(void)
{
	GUI_MENU stChgPwdMenu;
	GUI_MENUITEM stDefChgPwdMenuItem[] =
	{
		{ _T_NOOP("TERMINAL   PWD"), 1,TRUE,    ModifyPasswordTerm},
		{ _T_NOOP("BANK       PWD"), 2,FALSE,    ModifyPasswordBank},
		{ _T_NOOP("MERCHANT   PWD"), 3,TRUE,    ModifyPasswordMerchant},
		{ _T_NOOP("VOID       PWD"), 4,TRUE,    ModifyPasswordVoid},
		{ _T_NOOP("REFUND     PWD"), 5,TRUE,    ModifyPasswordRefund},
		{ _T_NOOP("ADJUST     PWD"), 6,TRUE,    ModifyPasswordAdjust},
		{ _T_NOOP("SETTLE     PWD"), 7,TRUE,    ModifyPasswordSettle},
		{ "", -1,FALSE,  NULL},
	};

	GUI_MENUITEM stChgPwdMenuItem[20];
	int iMenuItemNum = 0;
	int i;
	for(i = 0; i < sizeof(stDefChgPwdMenuItem)/sizeof(GUI_MENUITEM); ++i){
	    if(stDefChgPwdMenuItem[i].bVisible)
        {
	        memcpy(&stChgPwdMenuItem[iMenuItemNum], &stDefChgPwdMenuItem[i], sizeof(GUI_MENUITEM));
            sprintf(stChgPwdMenuItem[iMenuItemNum].szText, "%d.%s", iMenuItemNum+1, stDefChgPwdMenuItem[i].szText);
            ++iMenuItemNum;
        }
	}

	stChgPwdMenuItem[iMenuItemNum].szText[0] = 0;


	Gui_BindMenu(_T("CHANGE PWD"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stChgPwdMenuItem, &stChgPwdMenu);
	Gui_ClearScr();
	Gui_ShowMenuList(&stChgPwdMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, NULL);
	return 0;
}

// 手工设置系统时间
// set system time manually
int SetSysTime(void)
{
	uchar	szBuff[14+1], sInputTime[6];
	int iRet;

	memset(szBuff,0,sizeof(szBuff));
	strcpy(szBuff + 10, "00"); //ss

	Gui_ClearScr();
	memset(szBuff,0,sizeof(szBuff));
	iRet = Gui_ShowTimeBox(_T("SET TIME"), gl_stTitleAttr, szBuff, gl_stCenterAttr, 0, USER_OPER_TIMEOUT);
 
	if(GUI_OK == iRet)
	{
		Gui_ClearScr();
		iRet = Gui_ShowTimeBox(_T("SET TIME"), gl_stTitleAttr, szBuff + /*6*/8, gl_stCenterAttr, 1, USER_OPER_TIMEOUT);
	}
	else{
		return ERR_NO_DISP;
	}

	if (GUI_OK == iRet)
	{
		//fix the cannot modified time. linzhao
		PubAsc2Bcd(szBuff+2, 12, sInputTime);
		SetTime(sInputTime);
	}
	return 0;
}

// provide manual select and prompt message when pszLngName==NULL
// mode:
// 0--auto load the first available non-english language (if language file available)
// 1--auto load the last time used language
// 2--provide a menu for selection
// Modified by Kim_LinHB 2014-8-7 v1.01.0002
void SetSysLang(uchar ucSelectMode)
{
	int	iCnt, iTotal, iRet, iSel = 0;

	GUI_MENU stLangMenu;
	GUI_MENUITEM stLangMenuItem[32];

REDO_SELECT_LANG:
	if (ucSelectMode==0 || ucSelectMode==2)
	{
		// 搜寻已下载的语言文件，准备菜单
		// search the existed translation files, and prepare the menu list
		for (iCnt=0, iTotal=0;
			iCnt<sizeof(stLangMenuItem)/sizeof(stLangMenuItem[0])-1;
			iCnt++)
		{
			if (glLangList[iCnt].szDispName[0]==0)
			{
				break;
			}
			if ((iCnt==0) || (fexist((char *)glLangList[iCnt].szFileName)>=0
#ifdef _PROLIN2_4_
					&& fexist((char *)glLangList[iCnt].szFilePath)>=0
#endif
					))
			{
				sprintf(stLangMenuItem[iTotal].szText, "%d.%s", iTotal + 1, _T((char *)glLangList[iCnt].szDispName));
				stLangMenuItem[iTotal].bVisible = TRUE;
				stLangMenuItem[iTotal].nValue = iTotal + 1;
				stLangMenuItem[iTotal].vFunc = NULL;
				if(0 == strcmp(glLangList[iCnt].szDispName, glSysParam.stEdcInfo.stLangCfg.szDispName))
					iSel = iTotal;

				iTotal++;
			}
		}

		strcpy(stLangMenuItem[iTotal].szText, "");
		stLangMenuItem[iTotal].bVisible = FALSE;
		stLangMenuItem[iTotal].nValue = -1;
		stLangMenuItem[iTotal].vFunc = NULL;

		if (ucSelectMode==0)
		{
			// 首次加载
			// 如果有一个或多个非英文语言，自动选择第一个；否则选择英语
			// the first time loading 
			// if there are one or more than one translation files, then will select the first non-English language as default,
			// otherwise set English as default

			iSel = ((iTotal>1) ? 2 : 1);
		}
		else
		{
			// 菜单手动选择
			// display a language menu list to select manually
			Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stLangMenuItem, &stLangMenu);
			Gui_ClearScr();
			iRet = Gui_ShowMenuList(&stLangMenu, GUI_MENU_DIRECT_RETURN, 60, &iSel);
			if (iRet != GUI_OK)
			{
				return;
			}
		}
		if(iSel < 1)
			iSel = 1; //English

		for (iCnt=0; glLangList[iCnt].szDispName[0]!=0; iCnt++)
		{
			if (strcmp(_T((char *)glLangList[iCnt].szDispName),(char *)stLangMenuItem[iSel-1].szText)==0)
			{
				glSysParam.stEdcInfo.stLangCfg = glLangList[iCnt];
#ifdef _PROLIN2_4_
				FtFontFree();
				FtFontLoad(glSysParam.stEdcInfo.stLangCfg.szFilePath);
				Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);
				ChangeLangOrder();
#endif
				break;
			}
		}
	}

	// 设为英语
	// set with English
	if (strcmp(glSysParam.stEdcInfo.stLangCfg.szFileName, "")==0)
	{
		iRet = SetLng(NULL);
		glSysParam.stEdcInfo.stLangCfg = glLangList[0]; // Added by Kim_LinHB 9/9/2014 v1.01.0007 bug521
#ifdef _PROLIN2_4_
		FtFontFree();
		FtFontLoad(glSysParam.stEdcInfo.stLangCfg.szFilePath);
		Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);
		ChangeLangOrder();
#endif
		return;
	}

	if ((fexist((char *)glSysParam.stEdcInfo.stLangCfg.szFileName)>=0
#ifdef _PROLIN2_4_
			&& fexist((char *)glSysParam.stEdcInfo.stLangCfg.szFilePath)>=0
#endif
			))
		iRet = SetLng(glSysParam.stEdcInfo.stLangCfg.szFileName);
	else
		iRet = -1;
	if (iRet!=0)
	{
		glSysParam.stEdcInfo.stLangCfg = glLangList[0];
#ifdef _PROLIN2_4_
		FtFontFree();
		FtFontLoad(glSysParam.stEdcInfo.stLangCfg.szFilePath);
		Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);
		ChangeLangOrder();
#endif
		return;
	}

	if ((ucSelectMode==0) || (ucSelectMode==2))
	{
		// 在初次加载或者手动选择模式下，检查字库是否含有此内码
		// check if the character selected is included in the font lib
		if (CheckSysFont()!=0)
		{
			while(1)
			{
				int iKey;
				Gui_ClearScr();
				if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "DISPLAY/PRINT\nMAY HAVE PROBLEM\nSET ANYWAY ?", 
					gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, &iKey))
				{
					break;
				}
				if(KEYENTER == iKey)
				{
#ifdef _PROLIN2_4_
					Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);
					ChangeLangOrder();
#endif
					return;
				}
				else if(KEYCANCEL == iKey)
				{
					break;
				}
			}

			iRet = SetLng(NULL);
			glSysParam.stEdcInfo.stLangCfg = glLangList[0];
#ifdef _PROLIN2_4_
			FtFontFree();
			FtFontLoad(glSysParam.stEdcInfo.stLangCfg.szFilePath);
			Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);
			ChangeLangOrder();
#endif
			ucSelectMode = 2;
			goto REDO_SELECT_LANG;
		}
	}
}

// Set system language
int SetEdcLang(void)
{
	LANG_CONFIG	stLangBak;

	memcpy(&stLangBak, &glSysParam.stEdcInfo.stLangCfg, sizeof(LANG_CONFIG));

	SetCurrTitle(_T("SELECT LANG")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	SetSysLang(2);
#if defined(AREA_Arabia) && defined(_MONITOR_)
    CustomizeAppLibForArabiaLang( strcmp(LANGCONFIG, "Arabia")==0 );
#endif

	if (memcmp(&stLangBak, &glSysParam.stEdcInfo.stLangCfg, sizeof(LANG_CONFIG)) != 0)
	{
		SaveEdcParam();
	}
	return 0;
}

#ifndef APP_MANAGER_VER
void SetEdcLangExt(const char *pszDispName)
{
	int	ii;
	for (ii=0; glLangList[ii].szDispName[0]!=0; ii++)
	{
		if (PubStrNoCaseCmp((uchar *)glLangList[ii].szDispName, pszDispName)==0)
		{
			if ((ii==0) || (fexist((char *)glLangList[ii].szFileName)>=0))
			{
				glSysParam.stEdcInfo.stLangCfg = glLangList[ii];
				SetSysLang(1);
#if defined(AREA_Arabia) && defined(_MONITOR_)
                CustomizeAppLibForArabiaLang( strcmp(LANGCONFIG, "Arabia")==0 );
#endif
			}
		}
	}
}
#endif

int SetPowerSave(void)
{
    int iSel = glSysParam.stEdcInfo.ucIdleShutdown;
	uchar	ucTemp, szPrompt[100], szBuff[100];
	int		iRet;

	SetCurrTitle(_T("POWERSAVE OPTION")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	if (!ChkTerm(_TERMINAL_S90_))
	{
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);
		return ERR_NO_DISP;
	}
	else
	{
		GUI_INPUTBOX_ATTR stInputAttr;
		memset(&stInputAttr, 0, sizeof(stInputAttr));

		sprintf((char *)szBuff, _T("IDLE: SLEEP"));
		if (glSysParam.stEdcInfo.ucIdleShutdown)
		{
			sprintf((char *)szBuff, _T("IDLE: SHUTDOWN  "));
		}
		Gui_ClearScr();
		iRet = Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, 
			_T("SLEEP"), 0, _T("SHUTDOWN"), 1, USER_OPER_TIMEOUT, &iSel);
		
		if(GUI_OK == iRet){
		    glSysParam.stEdcInfo.ucIdleShutdown = iSel;
			if (1 == glSysParam.stEdcInfo.ucIdleShutdown &&
				glSysParam.stEdcInfo.ucIdleMinute<5)
			{
				glSysParam.stEdcInfo.ucIdleMinute = 5;
			}
			SaveSysParam();
		}
		else{
			return ERR_NO_DISP;
		}

		ucTemp = glSysParam.stEdcInfo.ucIdleMinute;

		stInputAttr.eType = GUI_INPUT_NUM;
		stInputAttr.nMinLen = 1;
		stInputAttr.nMaxLen = 2;
		stInputAttr.bEchoMode = 1;

		if (glSysParam.stEdcInfo.ucIdleShutdown)
		{
			sprintf(szPrompt, "%s[5-60mins]", _T("SHUTDOWN TIMEOUT"));
		}
		else
		{
			sprintf(szPrompt, "%s[1-60mins]", _T("PWR SAVE TIMEOUT"));
		}

		while (1)
		{
			Gui_ClearScr();
			sprintf((char *)szBuff, "%d", (int)ucTemp);
			iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szPrompt, gl_stLeftAttr,
				szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
			if (iRet !=GUI_OK)
			{
				return ERR_NO_DISP;
			}
			ucTemp = (uchar)atol((char *)szBuff);
			if (ucTemp>60 || ucTemp<1)
			{
				continue;
			}
			if (glSysParam.stEdcInfo.ucIdleShutdown && (ucTemp<5))
			{
				continue;
			}

			if (glSysParam.stEdcInfo.ucIdleMinute!=ucTemp)
			{
				glSysParam.stEdcInfo.ucIdleMinute = ucTemp;
				SaveSysParam();
			}
			break;
		}
	}
	return 0;
}

int TestMagicCard1(void)
{
	TestMagicCard(1);
	return 0;
}

int TestMagicCard2(void)
{
	TestMagicCard(2);
	return 0;
}

int TestMagicCard3(void)
{
	TestMagicCard(3);
	return 0;
}

void TestMagicCard(int iTrackNum)
{
	uchar	ucRet;
	uchar	szMagTrack1[79+1], szMagTrack2[40+1], szMagTrack3[104+1];
	uchar	szTitle[16+1], szBuff[200];

	MagClose();
	MagOpen();
	MagReset();
	while( 1 )
	{
		sprintf((char *)szTitle, "TRACK %d TEST", iTrackNum);
		Gui_ClearScr();
		Gui_ShowMsgBox(szTitle, gl_stTitleAttr, _T("PLS SWIPE CARD"), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
		while( 2 )
		{
			if( 0 == kbhit() && getkey()==KEYCANCEL )
			{
				MagClose();
				return;
			}

			if( MagSwiped()==0 )
			{
				break;
			}
		}

		memset(szMagTrack1, 0, sizeof(szMagTrack1));
		memset(szMagTrack2, 0, sizeof(szMagTrack2));
		memset(szMagTrack3, 0, sizeof(szMagTrack3));
		ucRet = MagRead(szMagTrack1, szMagTrack2, szMagTrack3);
		
		if( iTrackNum==1 )
		{
			sprintf(szBuff, "RET:%02X\n%.21s\n Length=[%d]", ucRet,
				szMagTrack1[0]==0 ? (uchar *)"NULL" : szMagTrack1, strlen((char *)szMagTrack1));
		}
		else if (iTrackNum == 2)
		{
			sprintf(szBuff, "RET:%02X\n%.21s\n Length=[%d]", ucRet,
				szMagTrack2[0]==0 ? (uchar *)"NULL" : szMagTrack2, strlen((char *)szMagTrack2));
		}
		else
		{
			sprintf(szBuff, "RET:%02X\n%.21s\n Length=[%d]", ucRet,
				szMagTrack3[0]==0 ? (uchar *)"NULL" : szMagTrack3, strlen((char *)szMagTrack3));
		}

		Gui_ClearScr();
		if(GUI_OK != Gui_ShowMsgBox(szTitle, gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, NULL))
		{
			return;
		}
	}
}

int ToolsViewPreTransMsg(void)
{
	GUI_MENU stViewMsgMenu;
	GUI_MENUITEM stViewMsgMenuItem[] =
	{
//		{ "1.OUTPUT SEND/RECV", 1,TRUE,  ShowExchangePack},//ktktktktk
//		{ "2.PRINT SEND/RECV", 2,TRUE,  PrnExchangePack},//ktktktktk

	    { "1.PRINT SEND/RECV", 1,TRUE, PrnExchangePack },//ktktktktk
		{ "2.OUTPUT SEND/RECV", 2,TRUE,ShowExchangePack  },//ktktktktk


		{ "", -1,FALSE,  NULL},
	};

	SetCurrTitle(_T("VIEW MSG"));
	if( PasswordBank()!=0 )
	{
		return ERR_NO_DISP;
	}

	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stViewMsgMenuItem, &stViewMsgMenu);
	Gui_ClearScr();
	Gui_ShowMenuList(&stViewMsgMenu, 0, USER_OPER_TIMEOUT, NULL);
	return 0;
}

// 发送通讯报文到COM1
// send comm package to COM1
int ShowExchangePack(void)
{
#if defined(WIN32) && defined(_Sxx_)
#define DEBUG_OUT_PORT	PINPAD
#else
#define DEBUG_OUT_PORT	0
#endif
	if (!glSendData.uiLength && !glRecvData.uiLength)
	{
		DispErrMsg(_T("NO DATA"), NULL, 5, 0);
		return ERR_NO_DISP;
	}
	
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("SENDING..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	DebugNacTxd(DEBUG_OUT_PORT, glSendData.sContent, glSendData.uiLength);
	DelayMs(2000);
	DebugNacTxd(DEBUG_OUT_PORT, glRecvData.sContent, glRecvData.uiLength);

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("SEND OK"), gl_stCenterAttr, GUI_BUTTON_OK, 2, NULL);
	return 0;
}

// 打印通讯报文
// Print comm package
int PrnExchangePack(void)
{
	SetCurrTitle(_T("VIEW MSG"));
	if (!glSendData.uiLength && !glRecvData.uiLength)
	{
		DispErrMsg(_T("NO DATA"), NULL, 5, 0);
		return ERR_NO_DISP;
	}

	
	// Modified by Kim_LinHB 2014-8-11 v1.01.0003
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

//	PubDebugOutput(_T("VIEW MSG"), glSendData.sContent, glSendData.uiLength,
//					DEVICE_PRN, ISO_MODE);
//	PubDebugOutput(_T("VIEW MSG"), glRecvData.sContent, glRecvData.uiLength,
//					DEVICE_PRN, ISO_MODE);
    PubDebugOutput(_T("VIEW MSG SEND"), glSendData.sContent, glSendData.uiLength,
                    DEVICE_PRN, HEX_MODE);
    PubDebugOutput(_T("VIEW MSG RECIVE"), glRecvData.sContent, glRecvData.uiLength,
                    DEVICE_PRN, HEX_MODE);

	Gui_ClearScr();
	return 0;
}

void DebugNacTxd(uchar ucPortNo, const uchar *psTxdData, ushort uiDataLen)
{
	uchar	*psTemp, sWorkBuf[LEN_MAX_COMM_DATA+10];
	uchar  ucInit = 0;
	
	if( uiDataLen>LEN_MAX_COMM_DATA )
	{
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID PACK"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 2, NULL);
		return;
	}

	sWorkBuf[0] = STX;
	sWorkBuf[1] = (uiDataLen/1000)<<4    | (uiDataLen/100)%10;	// convert to BCD
	sWorkBuf[2] = ((uiDataLen/10)%10)<<4 | uiDataLen%10;
	memcpy(&sWorkBuf[3], psTxdData, uiDataLen);
	sWorkBuf[3+uiDataLen]   = ETX;

	//sWorkBuf[3+uiDataLen+1] = PubCalcLRC(psTxdData, uiDataLen, (uchar)(sWorkBuf[1] ^ sWorkBuf[2] ^ ETX));
	PubCalcLRC(sWorkBuf + 1, (ushort)(uiDataLen+3), &ucInit);
	sWorkBuf[3+uiDataLen+1] = ucInit;
	//end
	uiDataLen += 5;

	PortClose(ucPortNo);
	PortOpen(ucPortNo, (void *)"9600,8,n,1");
	psTemp = sWorkBuf;
	while( uiDataLen-->0 )
	{
		if( PortSend(ucPortNo, *psTemp++)!=0 )
		{
			break;
		}
	}
	PortClose(ucPortNo);
}

static int ClearReversal_Standalone()
{
    SetCurrTitle(_T("CLEAR REVERSAL"));
    if( PasswordMerchant()!=0 )
    {
        return ERR_NO_DISP;
    }

    ClearReversal();
    return 0;
}


int GetIpLocalWifiSettings(void *pstParam)
{
	int 	iRet;
	ST_WIFI_PARAM *pstWifiPara;
	TCPIP_PARA stLocalInfo;

	pstWifiPara = (ST_WIFI_PARAM *)pstParam;
	memset(&stLocalInfo, 0, sizeof(TCPIP_PARA));

	iRet = GetIPAddress((uchar *)"LOCAL IP", TRUE, stLocalInfo.szLocalIP);
	if( iRet!=0 )
	{
		return iRet;
	}
	SplitIpAddress(stLocalInfo.szLocalIP, pstWifiPara->Ip);
	
	iRet = GetIPAddress((uchar *)"IP MASK", TRUE, stLocalInfo.szNetMask);
	if( iRet!=0 )
	{
		return iRet;
	}
	SplitIpAddress(stLocalInfo.szNetMask, pstWifiPara->Mask);
	
	iRet = GetIPAddress((uchar *)"GATEWAY IP", TRUE, stLocalInfo.szGatewayIP);
	if( iRet!=0 )
	{
		return iRet;
	}
	SplitIpAddress(stLocalInfo.szGatewayIP, pstWifiPara->Gate);
	
	iRet = GetIPAddress((uchar *)"DNS", TRUE, stLocalInfo.szDNSIP);
	if( iRet!=0 )
	{
		return iRet;
	}
	SplitIpAddress(stLocalInfo.szDNSIP, pstWifiPara->Dns);
	
	return 0;
}

// Modified by Kim_LinHB 2014-08-19 v1.01.0004
int SetWiFiApp(void* pstParam)
{
#ifdef _PROLIN2_4_
	int iRet = -1;
	int iAppNum;
	WIFI_PARA *pstWifiPara = (WIFI_PARA *)pstParam;
	ST_WifiApInfo *stWiFiApp;

	unsigned char szPWD[(2 * KEY_WEP_LEN_MAX ) > KEY_WPA_MAXLEN ? (2 * KEY_WEP_LEN_MAX ) : KEY_WPA_MAXLEN];
	
	int	iMenuNo;
	uchar ucCnt;
	int iSel;

	GUI_MENU	stWiFiAppsMenu;
	GUI_MENUITEM	stWiFiAppsMenuItem[MAX_WiFiApp+1];
	GUI_INPUTBOX_ATTR stInputAttr;

	// Modified by Kim for Prolin2.4.31 OsWifiCheck doesn't return not_conenct if the dev is not open,
	// so don't need to check before open it.
	WifiOpen(); // ignore the failed case

	WifiDisconnect();

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "WIFI SCANNING...", gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	iRet = OsWifiScan(&stWiFiApp);

	if(iRet < 0)
	{
		return iRet;
	}

	if(0 == iRet)
	{
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "NOT FIND APPS", gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_USERCANCEL;
	}

	//sort
	{
		int i,j;
		ST_WifiApInfo temp;
		for(j=0;j<iRet-1;j++)
			for(i=0;i<iRet-1-j;i++)
			{
				if(stWiFiApp[i].Rssi<stWiFiApp[i+1].Rssi)
				{
					memcpy(&temp, &stWiFiApp[i], sizeof(ST_WifiApInfo));
					memcpy(&stWiFiApp[i], &stWiFiApp[i+1], sizeof(ST_WifiApInfo));
					memcpy(&stWiFiApp[i+1], &temp, sizeof(ST_WifiApInfo));
				}
			}
	}

	memset(stWiFiAppsMenuItem,0,sizeof(stWiFiAppsMenuItem));
	for(ucCnt=0; ucCnt< iRet && ucCnt < MAX_WiFiApp; ucCnt++)
	{
		sprintf((char *)stWiFiAppsMenuItem[ucCnt].szText, "%s lv:%d", stWiFiApp[ucCnt].Essid, (99+stWiFiApp[ucCnt].Rssi)/20);
		stWiFiAppsMenuItem[ucCnt].bVisible = TRUE;
		stWiFiAppsMenuItem[ucCnt].nValue = ucCnt;
		stWiFiAppsMenuItem[ucCnt].vFunc = NULL;
	}

	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, stWiFiAppsMenuItem, &stWiFiAppsMenu);

	Gui_ClearScr();
	iMenuNo = 0;
	if(GUI_OK != Gui_ShowMenuList(&stWiFiAppsMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo))
	{
		return ERR_USERCANCEL;
	}

	memcpy(&pstWifiPara->stParam.stInfo, &stWiFiApp[iMenuNo], sizeof(ST_WifiApInfo));
	snprintf(pstWifiPara->stLastAP.Essid, 32, pstWifiPara->stParam.stInfo.Essid);
	strcpy(pstWifiPara->stLastAP.Bssid, pstWifiPara->stParam.stInfo.Bssid);
	pstWifiPara->stLastAP.Channel = pstWifiPara->stParam.stInfo.Channel;
	pstWifiPara->stLastAP.Mode = pstWifiPara->stParam.stInfo.Mode;
	pstWifiPara->stLastAP.AuthMode = pstWifiPara->stParam.stInfo.AuthMode;
	pstWifiPara->stLastAP.SecMode = pstWifiPara->stParam.stInfo.SecMode;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.bSensitive = 1;

	memset(szPWD, 0, sizeof(szPWD));
	memset(&pstWifiPara->stLastAP.KeyUnion, 0, sizeof(pstWifiPara->stLastAP.KeyUnion));
	if(pstWifiPara->stLastAP.AuthMode == AUTH_NONE_WEP)
	{   
		stInputAttr.nMinLen = 0;
		stInputAttr.nMaxLen = 2 * KEY_WEP_LEN_MAX;

		// Added by Kim_LinHB 2014-11-27
		do{
			int len;
			Gui_ClearScr();
			if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Enter PassWord:"), gl_stLeftAttr, 
				szPWD, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
			{
				return ERR_USERCANCEL;
			}
			len =strlen(szPWD);

			if(len != 10 && len != 24 && len != 32){
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "Wrong Length", gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
				memset(szPWD, 0 ,sizeof(szPWD));
			}
			else{
				break;
			}
		}while(1);
		PubAsc2Bcd(szPWD, strlen(szPWD), pstWifiPara->stLastAP.KeyUnion.WepKey.Key[0]);
		pstWifiPara->stLastAP.KeyUnion.WepKey.Idx = 0;
		pstWifiPara->stLastAP.KeyUnion.WepKey.KeyLen = strlen(szPWD);
	}

	// WLAN_SEC_WPA_WPA2 =2       WLAN_SEC_WPAPSK_WPA2PSK= 3
	if (pstWifiPara->stLastAP.AuthMode == AUTH_WPA_PSK ||
		pstWifiPara->stLastAP.AuthMode ==  AUTH_WPA_EAP ||
		pstWifiPara->stLastAP.AuthMode == AUTH_WPA_WPA2_PSK ||
		pstWifiPara->stLastAP.AuthMode == AUTH_WPA_WPA2_EAP ||
		pstWifiPara->stLastAP.AuthMode == AUTH_WPA2_PSK ||
		pstWifiPara->stLastAP.AuthMode == AUTH_WPA2_EAP)
	{
		stInputAttr.nMinLen = 0;
		stInputAttr.nMaxLen = KEY_WPA_MAXLEN;
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Enter PassWord:"), gl_stLeftAttr, 
			szPWD, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}
		if(pstWifiPara->stLastAP.AuthMode ==  AUTH_WPA_EAP ||
			pstWifiPara->stLastAP.AuthMode ==  AUTH_WPA_WPA2_EAP ||
			pstWifiPara->stLastAP.AuthMode ==  AUTH_WPA2_EAP)
		{
			memcpy(pstWifiPara->stLastAP.KeyUnion.EapKey.Pwd, szPWD, strlen(szPWD));
			//FIXME Kim if need to set Cert
		}
		else
		{
			memcpy(pstWifiPara->stLastAP.KeyUnion.PskKey.Key, szPWD, strlen(szPWD));
			pstWifiPara->stLastAP.KeyUnion.PskKey.KeyLen = strlen(szPWD);
		}
	}
	
	iSel = pstWifiPara->stParam.DhcpEnable;
	if(iSel > 1)
	    iSel = 1;

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, _T("DHCP ENABLE"), gl_stCenterAttr,
		"ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &iSel))
	{
		return ERR_USERCANCEL;
	}

	if(1 == iSel)
	{
		pstWifiPara->stParam.DhcpEnable = 1;
	}
	else
	{
		pstWifiPara->stParam.DhcpEnable = 0;
	}
	
	if(pstWifiPara->stParam.DhcpEnable == 0)
	{
		iRet = GetIpLocalWifiSettings(&pstWifiPara->stParam);
		if( iRet!=0 )
		{
			return iRet;
		}
	}
	return 0;
#else
	int iRet = -1;

	int iAppNum;
	WIFI_PARA *pstWifiPara = (WIFI_PARA *)pstParam;
	ST_WIFI_AP stWiFiApp[MAX_WiFiApp]; // list of SSID searched

#ifdef _MIPS_
	unsigned char szPWD[(2 * KEY_WEP_LEN ) > KEY_WPA_MAXLEN ? (2 * KEY_WEP_LEN ) : KEY_WPA_MAXLEN];
#else
	unsigned char szPWD[(2 * KEY_WEP_LEN_MAX ) > KEY_WPA_MAXLEN ? (2 * KEY_WEP_LEN_MAX ) : KEY_WPA_MAXLEN];
#endif

	int	iMenuNo;
	uchar ucCnt;
	int iSel;

	GUI_MENU	stWiFiAppsMenu;
	GUI_MENUITEM	stWiFiAppsMenuItem[MAX_WiFiApp+1];
	GUI_INPUTBOX_ATTR stInputAttr;

	iRet = WifiCheck(NULL);
	if (-3 == iRet)
	{
		WifiOpen();
	}

#ifdef _MIPS_
	WifiDisconAp();
#else
	WifiDisconnect();
#endif

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "WIFI SCANNING...", gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	// 期望扫描到15个
	// expect to scan 15 SSID at most
	iAppNum = 15;
	memset(stWiFiApp,0,sizeof(stWiFiApp));

#ifdef _MIPS_
	iRet = WifiScanAps(stWiFiApp,iAppNum);
#else
	iRet = WifiScan(stWiFiApp,iAppNum);
#endif

	if(iRet < 0)
	{
		return iRet;
	}

	if(0 == iRet)
	{
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "NOT FIND APPS", gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_USERCANCEL;
	}

	memset(stWiFiAppsMenuItem,0,sizeof(stWiFiAppsMenuItem));
	for(ucCnt=0; ucCnt< iRet && ucCnt < MAX_WiFiApp; ucCnt++)
	{
		sprintf((char *)stWiFiAppsMenuItem[ucCnt].szText, "%s", stWiFiApp[ucCnt].Ssid);  // seems sorted automatically
		stWiFiAppsMenuItem[ucCnt].bVisible = TRUE;
		stWiFiAppsMenuItem[ucCnt].nValue = ucCnt;
		stWiFiAppsMenuItem[ucCnt].vFunc = NULL;
	}

	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, stWiFiAppsMenuItem, &stWiFiAppsMenu);

	Gui_ClearScr();
	iMenuNo = 0;
	if(GUI_OK != Gui_ShowMenuList(&stWiFiAppsMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo))
	{
		return ERR_USERCANCEL;
	}

	memcpy(&pstWifiPara->stLastAP, &stWiFiApp[iMenuNo], sizeof(ST_WIFI_AP));

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.bEchoMode = 1;
	stInputAttr.bSensitive = 1;

	memset(szPWD, 0, sizeof(szPWD));
	if(pstWifiPara->stLastAP.SecMode == WLAN_SEC_WEP )
	{
		stInputAttr.nMinLen = 0;
#ifdef _MIPS_
		stInputAttr.nMaxLen = 2 * KEY_WEP_LEN;
#else
		stInputAttr.nMaxLen = 2 * KEY_WEP_LEN_MAX;
#endif

		// Added by Kim_LinHB 2014-11-27
		do{
			int len;
			Gui_ClearScr();
			if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Enter PassWord:"), gl_stLeftAttr,
				szPWD, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
			{
				return ERR_USERCANCEL;
			}
			len =strlen(szPWD);
			if(len != 10 && len != 24 && len != 32){
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "Wrong Length", gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
				memset(szPWD, 0 ,sizeof(szPWD));
			}
			else{
				break;
			}
		}while(1);
#ifdef _MIPS_
		memset(pstWifiPara->stParam.Wep, 0, sizeof(pstWifiPara->stParam.Wep)); // Added by Kim_LinHB 2014-11-26
		PubAsc2Bcd(szPWD, strlen(szPWD), pstWifiPara->stParam.Wep);
#else
		memset(pstWifiPara->stParam.Wep.Key[0], 0, sizeof(pstWifiPara->stParam.Wep.Key[0])); // Added by Kim_LinHB 2014-11-26
		PubAsc2Bcd(szPWD, strlen(szPWD), pstWifiPara->stParam.Wep.Key[0]);
#endif
	}

	// WLAN_SEC_WPA_WPA2 =2       WLAN_SEC_WPAPSK_WPA2PSK= 3
	if (pstWifiPara->stLastAP.SecMode == WLAN_SEC_WPA_WPA2 ||
		pstWifiPara->stLastAP.SecMode ==  WLAN_SEC_WPAPSK_WPA2PSK)
	{
		stInputAttr.nMinLen = 0;
		stInputAttr.nMaxLen = KEY_WPA_MAXLEN;
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("Enter PassWord:"), gl_stLeftAttr,
			szPWD, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		memset(pstWifiPara->stParam.Wpa, 0, sizeof(pstWifiPara->stParam.Wpa)); // Added by Kim_LinHB 2014-11-26
		memcpy(pstWifiPara->stParam.Wpa, szPWD, strlen(szPWD));
	}

	iSel = pstWifiPara->stParam.DhcpEnable;
	if(iSel > 1)
	    iSel = 1;

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, _T("DHCP ENABLE"), gl_stCenterAttr,
		"ON", 1, "OFF", 0, USER_OPER_TIMEOUT, &iSel))
	{
		return ERR_USERCANCEL;
	}

	if(1 == iSel)
	{
		pstWifiPara->stParam.DhcpEnable = 1;
	}
	else
	{
		pstWifiPara->stParam.DhcpEnable = 0;
	}

	if(pstWifiPara->stParam.DhcpEnable == 0)
	{
		iRet = GetIpLocalWifiSettings(&pstWifiPara->stParam);
		if( iRet!=0 )
		{
			return iRet;
		}
	}
	return 0;
#endif
}

// Modified by Kim_LinHB 2014-08-19 v1.01.0004
void SyncWifiParam(void *pstDst, const void *pstSrc)
{
	memcpy(&((WIFI_PARA *)pstDst)->stHost1,   &((WIFI_PARA *)pstSrc)->stHost1, sizeof(IP_ADDR));
	memcpy(&((WIFI_PARA *)pstDst)->stHost2,   &((WIFI_PARA *)pstSrc)->stHost2, sizeof(IP_ADDR));

	((WIFI_PARA *)pstDst)->stParam.DhcpEnable = ((WIFI_PARA *)pstSrc)->stParam.DhcpEnable;
	strcpy((char *)(((WIFI_PARA *)pstDst)->stParam.Ip),   (char *)(((WIFI_PARA *)pstSrc)->stParam.Ip));
	strcpy((char *)(((WIFI_PARA *)pstDst)->stParam.Mask),   (char *)(((WIFI_PARA *)pstSrc)->stParam.Mask));
	strcpy((char *)(((WIFI_PARA *)pstDst)->stParam.Gate),   (char *)(((WIFI_PARA *)pstSrc)->stParam.Gate));
	strcpy((char *)(((WIFI_PARA *)pstDst)->stParam.Dns),   (char *)(((WIFI_PARA *)pstSrc)->stParam.Dns));

#ifdef _PROLIN2_4_
	memcpy((char *)(&((WIFI_PARA *)pstDst)->stParam.stInfo), (char *)(&((WIFI_PARA *)pstSrc)->stParam.stInfo), sizeof(ST_WifiApInfo));

	strcpy((char *)(&((WIFI_PARA *)pstDst)->stLastAP),   (char *)(&((WIFI_PARA *)pstSrc)->stLastAP));
#else
	memcpy(&((WIFI_PARA *)pstDst)->stParam.Wep,   &((WIFI_PARA *)pstSrc)->stParam.Wep, sizeof(((WIFI_PARA *)pstSrc)->stParam.Wep));
	strcpy((char *)(((WIFI_PARA *)pstDst)->stParam.Wpa),   (char *)(((WIFI_PARA *)pstSrc)->stParam.Wpa));

	strcpy((char *)(((WIFI_PARA *)pstDst)->stLastAP.Ssid),   (char *)(((WIFI_PARA *)pstSrc)->stLastAP.Ssid));
	((WIFI_PARA *)pstDst)->stLastAP.SecMode = ((WIFI_PARA *)pstSrc)->stLastAP.SecMode;
	((WIFI_PARA *)pstDst)->stLastAP.Rssi = ((WIFI_PARA *)pstSrc)->stLastAP.Rssi;
#endif
}

void DispWifiErrorMsg( int Ret)
{
	unsigned char szBuff[100];
#ifdef _PROLIN2_4_
	sprintf(szBuff, "%d", Ret);
	OsWifiClose();
#else
	switch(Ret)
	{
		case 0:
			strcpy(szBuff, _T(" CONNECTED"));
			break;	
		case -1:
			strcpy(szBuff, _T(" DEVICE FAILED"));
			break;
		case -2:
			strcpy(szBuff, _T(" WIFI NO RESPOND"));
			break;
		case -3:
			strcpy(szBuff, _T(" WIFI NOT OPEN"));
			break;
		case -4:
			strcpy(szBuff, _T(" NOT CONNECTED"));
			break;
		case -5:
			strcpy(szBuff, _T(" PARAM EMPTY"));
			break;
		case -6:
			strcpy(szBuff, _T(" PWD ERROR"));
			break;
		case -7:
			strcpy(szBuff, _T(" BAN OPERATION"));
			break;
		default:
			strcpy(szBuff, _T(" CANCELED "));
			break;
	}
	WifiClose();
#endif
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
	return ;
}

// end of file

