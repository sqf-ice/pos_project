#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <fcntl.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <poll.h>
#include <sys/epoll.h>
#include <signal.h>
#include <openssl/bio.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <osal.h>

#include "ssl_wrapper.h"
#include "global.h"


#define isTrue(x, y, ...) if(x) do { OsLog( LOG_ERROR, __VA_ARGS__); return y; } while(0)
#define isFalse(x, y,...) if(!(x)) do { OsLog(LOG_ERROR,  __VA_ARGS__); return y;} while(0)

//#define isTrue(x, y, ...) if(x) do { printf(__VA_ARGS__); return y; } while(0)
//#define isFalse(x, y,...) if(!(x)) do { printf(__VA_ARGS__); return y;} while(0)

static SSL_CTX *sslContext;

static int setNonBlock(int fd, int value) {
    int flags = fcntl(fd, F_GETFL, 0);
    if (flags < 0) {
        return errno;
    }
    if (value) {
        return fcntl(fd, F_SETFL, flags | O_NONBLOCK);
    }
    return fcntl(fd, F_SETFL, flags & ~O_NONBLOCK);
}
// Establish a regular tcp connection
static int tcpConnect(const char* ip, short port) {
    int handle = socket(AF_INET, SOCK_STREAM, 0);
    isFalse(handle >= 0, SSLERR_CONNECT, "socket return error");
    setNonBlock(handle, 1);
    struct sockaddr_in server;
    bzero(&server, sizeof server);
    server.sin_family = AF_INET;
    server.sin_port = htons(port);
    inet_aton(ip, (struct in_addr *)&server.sin_addr.s_addr);
    OsLog( LOG_ERROR, "connecting to %s %d\n", ip, port);
    int r = connect(handle, (struct sockaddr *) &server, sizeof(struct sockaddr));
    if (r < 0 && (errno == EWOULDBLOCK || errno == EAGAIN)) {
        struct pollfd pfd;
        pfd.fd = handle;
        pfd.events = POLLOUT | POLLERR;
        while (r == 0) {
            r = poll(&pfd, 1, 100);
        }
        isFalse(pfd.revents == POLLOUT, SSLERR_CONNECT, "poll return error events: %d", pfd.revents);
    }
    //setNonBlock(handle, 0);
    return handle;
}

typedef struct pw_cb_data {
    const void *password;
    const char *prompt_info;
} PW_CB_DATA;

static int istext(int format)
{
    return (format & 0x8000) == 0x8000;
}

BIO *dup_bio_in(int format)
{
    return BIO_new_fp(stdin,
                      BIO_NOCLOSE | (istext(format) ? BIO_FP_TEXT : 0));
}

BIO *dup_bio_out(int format)
{
    BIO *b = BIO_new_fp(stdout,
                        BIO_NOCLOSE | (istext(format) ? BIO_FP_TEXT : 0));
    return b;
}

static const char *modestr(char mode, int format)
{
    OPENSSL_assert(mode == 'a' || mode == 'r' || mode == 'w');

    switch (mode) {
    case 'a':
        return istext(format) ? "a" : "ab";
    case 'r':
        return istext(format) ? "r" : "rb";
    case 'w':
        return istext(format) ? "w" : "wb";
    }
    /* The assert above should make sure we never reach this point */
    return NULL;
}

static const char *modeverb(char mode)
{
    switch (mode) {
    case 'a':
        return "appending";
    case 'r':
        return "reading";
    case 'w':
        return "writing";
    }
    return "(doing something)";
}


static BIO *bio_open_default_(const char *filename, char mode, int format,
                              int quiet)
{
    BIO *bio_err = NULL;
    BIO *ret;

    if (filename == NULL || strcmp(filename, "-") == 0) {
        ret = mode == 'r' ? dup_bio_in(format) : dup_bio_out(format);
        if (quiet) {
            ERR_clear_error();
            return ret;
        }
        if (ret != NULL)
            return ret;
        BIO_printf(bio_err,
                   "Can't open %s, %s\n",
                   mode == 'r' ? "stdin" : "stdout", strerror(errno));
    } else {
        ret = BIO_new_file(filename, modestr(mode, format));
        if (quiet) {
            ERR_clear_error();
            return ret;
        }
        if (ret != NULL)
            return ret;
        BIO_printf(bio_err,
                   "Can't open %s for %s, %s\n",
                   filename, modeverb(mode), strerror(errno));
    }
    ERR_print_errors(bio_err);
    return NULL;
}

BIO *bio_open_default(const char *filename, char mode, int format)
{
    return bio_open_default_(filename, mode, format, 0);
}

int password_callback(char *buf, int bufsiz, int verify, PW_CB_DATA *cb_tmp)
{
    int res = 0;
    const char *password = NULL;
    PW_CB_DATA *cb_data = (PW_CB_DATA *)cb_tmp;

    if (cb_data && cb_data->password) {
        password = cb_data->password;
    }

    if (password) {
        res = strlen(password);
        if (res > bufsiz)
            res = bufsiz;
        memcpy(buf, password, res);
        return res;
    }
    return res;
}


EVP_PKEY *load_key(const char *file, const char *pass)
{
    BIO *key = NULL;
    EVP_PKEY *pkey = NULL;
    PW_CB_DATA cb_data;

    cb_data.password = pass;
    cb_data.prompt_info = file;

    key = bio_open_default(file, 'r', 5 | 0x8000);
    if (key != NULL)
        pkey = PEM_read_bio_PrivateKey(key, NULL, (pem_password_cb *)password_callback, &cb_data);

    BIO_free(key);
    return (pkey);
}

X509 *load_cert(const char *file, const char *pass)
{
    X509 *x = NULL;
    BIO *cert;

    cert = bio_open_default(file, 'r', 5 | 0x8000);
    if (cert != NULL)
        x = PEM_read_bio_X509_AUX(cert, NULL, (pem_password_cb *)password_callback, NULL);

    BIO_free(cert);
    return (x);
}


void sslLoadFile(SSLCon* con, const char *CA, const char *Cert, const char *Key)
{
    if(!con)
        return;
    if(CA)
        strcpy(con->szCA, CA);
    if(Cert)
        strcpy(con->szCert, Cert);
    if(Key)
        strcpy(con->szKey, Key);
}

int sslConnect(SSLCon* con, const char* ip, short port, int timeoutMs) {
    int iRet;int iRet2;
    ST_TIMER timer = {0,0,0};
    EVP_PKEY *key = NULL;
    X509 *cert = NULL;

   // iRet2 = CommInitModule(&glSysParam.stTxnCommCfg);

     timeoutMs =timeoutMs +timeoutMs +(timeoutMs*0.5);
    OsLog(LOG_ERROR,"tttttttttttttttttt timeoutMs=%d",timeoutMs);
    SSL_library_init();
    OpenSSL_add_all_algorithms();
    SSL_load_error_strings();

    //读取证书文件
    if (con->szKey[0] != 0) {
        key = load_key(con->szKey, "");
    }
    if (con->szCert[0] != 0) {
        cert = load_cert(con->szCert, NULL);
    }


    sslContext = SSL_CTX_new(TLSv1_2_client_method()); // modified by Kim 20150506 to TLSv1.2
    isTrue(sslContext == NULL, SSLERR, "SSL_CTX_new error");

    SSL_CTX_set_options(sslContext, SSL_OP_ALL | SSL_OP_NO_SSLv2);

    /* Set flag in context to require peer (server) certificate verification */
    //SSL_CTX_set_verify(sslContext,SSL_VERIFY_PEER,NULL);
    //SSL_CTX_set_verify_depth(sslContext,2);
    //SSL_CTX_set_default_passwd_cb_userdata(sslContext, "");

    isTrue(SSL_CTX_use_certificate(sslContext, cert) <= 0, SSLERR, "SSL_CTX_use_certificate error");
    isTrue(SSL_CTX_use_PrivateKey(sslContext, key) <= 0, SSLERR, "SSL_CTX_use_PrivateKey error");
    isFalse(SSL_CTX_check_private_key(sslContext), SSLERR, "SSL_CTX_check_private_key error");
    isTrue(SSL_CTX_load_verify_locations(sslContext, con->szCA, NULL) == 0, SSLERR, "SSL_CTX_load_verify_locations error");

    bzero(con, sizeof *con);
    con->socket = tcpConnect(ip, port);
    con->sslHandle = SSL_new(sslContext);
    if (con->sslHandle == NULL ) {
        ERR_print_errors_fp(stderr);
        isFalse(0, SSLERR, "SSL_new failed");
    }
    if (!SSL_set_fd(con->sslHandle, con->socket)) {
        ERR_print_errors_fp(stderr);
        isFalse(0, SSLERR, "SSL_set_fd failed");
    }
    SSL_set_connect_state(con->sslHandle);
    int r = 0;
    int events = POLLIN | POLLOUT | POLLERR;
    OsTimerSet(&timer, timeoutMs);
    while ((r = SSL_do_handshake(con->sslHandle)) != 1 && OsTimerCheck(&timer) > 0) {
        int err = SSL_get_error(con->sslHandle, r);

        char buf[255];

        if (err == SSL_ERROR_WANT_WRITE) {
            events |= POLLOUT;
            events &= ~POLLIN;
            OsLog(LOG_ERROR, "return want write set events %d\n", events);
        }
        else if (err == SSL_ERROR_WANT_READ) {
            events |= EPOLLIN;
            events &= ~EPOLLOUT;
            OsLog( LOG_ERROR, "return want read set events %d\n", events);
        }
        else{
            OsLog( LOG_ERROR, "SSL_do_handshake return %d error %d errno %d msg %s\n", r, err, errno, strerror(errno));
            ERR_print_errors_fp(stderr);
            isFalse(0, SSLERR_CONNECT, "do handshake error");
        }
        struct pollfd pfd;
        pfd.fd = con->socket;
        pfd.events = events;
        do {
            r = poll(&pfd, 1, 20000);
        } while (r == 0);
        isFalse(r == 1, SSLERR_CONNECT, "poll return %d error events: %d errno %d %s\n", r, pfd.revents, errno, strerror(errno));
    }

    if(1 == r )
    {
        OsLog(LOG_ERROR, "ssl connected \n");
        return 0;
    }
    else if ( 0 == OsTimerCheck(&timer))
    {
        OsLog(LOG_ERROR, "%s %d, timeout", __FILE__, __LINE__);
        return SSLERR_TIMEOUT;
    }
    else
    {
       OsLog(LOG_ERROR, "%s %d, r:%d", __FILE__, __LINE__, r);
       return  SSLERR_CONNECT;
    }

}


int sslRead(SSLCon* con, char *data, int ExpSize, int timeoutMs) {
    char *buf=NULL;
    int rd = 0;
    int r = 1;



    ST_TIMER timer = {0,0,0};
    if(!con || !data || !ExpSize)
    {
        return SSLERR;
    }

    buf = (char *)malloc(ExpSize);
    OsTimerSet(&timer, timeoutMs);

    int flags = fcntl(con->socket, F_GETFL, 0);
    fcntl(con->socket, F_SETFL, flags | O_NONBLOCK);

    while (rd < ExpSize && r)
    {
        if(0 == OsTimerCheck(&timer))
        {
            free(buf);
            fcntl(con->socket, F_SETFL, flags &(~O_NONBLOCK));
            return SSLERR_TIMEOUT;
        }

        int iPending = SSL_pending(con->sslHandle);
        if(rd > 0 && iPending == 0)
            break;

        r = SSL_read(con->sslHandle, buf + rd, ExpSize);

        if (r <= 0) {
            int err = SSL_get_error(con->sslHandle, r);
            if (err == SSL_ERROR_WANT_READ ||
                err == SSL_ERROR_WANT_WRITE) {
                continue;
            }
            //ERR_print_errors_fp(stderr);
            OsLog(LOG_ERROR, "SSL_read ret %d true:%d errno:%ul socket:%d\n",
                r, SSL_get_error(con->sslHandle, r), ERR_get_error(), con->socket);
        }
        if(r < 0)
        {
            free(buf);
            fcntl(con->socket, F_SETFL, flags &(~O_NONBLOCK));
            return SSLERR;
        }

        OsLog(LOG_ERROR, "read %d bytes\n", r);

        rd += r;

        if(rd >= ExpSize)
            break;
    }
    OsLog(LOG_ERROR, "read %d bytes contents:\n%.*s\n", rd, rd, buf);

    memcpy(data, buf, rd);
    free(buf);
    fcntl(con->socket, F_SETFL, flags &(~O_NONBLOCK));
    return rd;
}

int sslWrite(SSLCon* con, const char *data, int len) {
    if(con && con->sslHandle)
        return SSL_write(con->sslHandle, data, len);
    return SSLERR;
}

void sslClose(SSLCon *con)
{
    if(con && con->sslHandle)
    {
        SSL_shutdown(con->sslHandle);
        SSL_free(con->sslHandle);
        close(con->socket);
    }
    if(sslContext)
        SSL_CTX_free(sslContext);
    con->sslHandle = NULL;
    con = NULL;
    sslContext = NULL;
}

