
/****************************************************************************
NAME
    fileoper.h - 定义所有文件操作的函数

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    shengjx     2006.09.12      - created
****************************************************************************/

#ifndef _FILEOPER_H
#define _FILEOPER_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int InitAuthLogFile(void);
int InitTranLogFile(void);
int LoadSysParam(void);
int SaveSysParam(void);
int SaveEdcParam(void);
int SavePassword(void);
int ExistSysFiles(void);
int ValidSysFiles(void);
void RemoveSysFiles(void);
int LoadSysCtrlAll(void);
int SaveSysAUTHCtrlAll(void);
int SaveSysCtrlAll(void);
int SaveSysCtrlBase(void);
int SaveSysCtrlNormal(void);
int SaveField56(void);
int SaveRevInfo(uchar bSaveRevInfo);
int SaveRePrnStlInfo(void);
int LoadTranLog(void *pstLog, ushort uiIndex);
int LoadAuthTranLog(void *pstLog, ushort uiIndex);
int UpdateTranLog(const void *pstLog, ushort uiIndex);
int UpdateAuthTranLog(const void *pstLog, ushort uiIndex);
int DeleteTranLog(ushort uiIndex);
int DeleteAuthTranLog(ushort uiIndex);
int DeleteLogByRRNandAuthCode(uchar *szRRN, uchar *szAuthCode);
int SaveTranLog(const void *pstLog);
int RecoverTranLog(void);
ushort GetTranLogNum(uchar ucAcqKey);
ushort GetTranLogNumOfPreAuth(uchar ucAcqKey);
ushort GetAuthTranLogNum(uchar ucAcqKey);
uchar AllowDuplicateTran(void);
int GetRecord(ushort uiStatus, void *pstOutTranLog);
int GetRecordByInvoice(ulong ulInvoiceNo, ushort uiStatus, void *pstOutTranLog);
int GetAuthRecord(ushort uiStatus, void *pstOutTranLog);
int GetRecordByRRNandAuthCode(ushort uiStatus, void *pstOutTranLog);
int WriteEPSPara(const void *pPara);
void CalcTotal(uchar ucAcqKey);

void CalcTotal_Details(uchar ucAcqKey);

int SaveEmvStatus(void);
int LoadEmvStatus(void);
int SaveEmvErrLog(void);
int LoadErrLog(ushort uiRecNo, void *pOutErrLog);
int SyncPassword(void);
int LastRecordIsFallback(void);

int SaveLoyaltyTxnId(const char* Id);
int LoadLoyaltyTxnId(char* Id);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _FILEOPER_H

// end of file
