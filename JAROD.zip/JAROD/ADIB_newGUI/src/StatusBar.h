/*
 ============================================================================
 Name        : StatusBarLib.h
 Author      : Kim.L
 Version     : 0.5
 Copyright   : PAX Computer Technology(Shenzhen) CO., LTD
 Description : PAX POS Shared Library

 0.1 init
 0.2 removed ICON_LOCK; Merge ICON_UP & ICON_DOWN to ICON_UP_DOWN; modified positions of icon in a slot
 0.3 fixed bugs of ETH_ICON, WIFI_ICON
 0.4 fixed bugs of WL_ICON will cost too many resources
 0.5 fixed a bug on S920 that Battery check will cause a crash
 ============================================================================
 */
 
 
#ifndef SHARED_LIBRARY_H_StatusBarLib
#define SHARED_LIBRARY_H_StatusBarLib

#include <xui.h>

#define SB_OK                           0
#define SB_ERR_COMMON       -1
#define SB_ERR_PARAM            -2
#define SB_ERR_RESOURCE       -3
#define SB_ERR_MEMORY         -4
#define SB_ERR_NEED_UNREG   -5

enum ICONTYPE{
    SB_ICON_START = 0,
    SB_ICON_UP_DOWN,
    SB_ICON_PRINTER,

    SB_ICON_MODEM,
    SB_ICON_ETHERNET,
    SB_ICON_WIRELESS,
    SB_ICON_WIFI,
    SB_ICON_BLUETOOTH,
    SB_ICON_CARDINSERTED,
    SB_ICON_BATTERY,
    SB_ICON_END,
};

#ifdef __cplusplus
extern "C"
{
#endif

/*-------------------------------------------------------------------------*/
/**
  @brief    bind an ini file which records resources & xui handle to lib
  @param    statusbar   a xui statusbar handle
  @param    cfg_ini   ini file which recorded paths of all icons.
  @return   0 ok; others error
 */
/*--------------------------------------------------------------------------*/
int SB_BindResource(XuiWindow *statusbar, const char *cfg_ini);

/*-------------------------------------------------------------------------*/
/**
  @brief    register an area for updating a specific icon
  @param    eType       type id
  @param    x               relative coordinates
  @param    y               relative coordinates
  @param    width
  @param    height
  @param    refreshFrequency_ms
                      the frequency of refreshing,
                      unit is millisecond,
                      if is -1, it can only be updated by call SB_ManuallyUpdate()
                      only affect the icon which's type id >= SB_ICON_MODEM
  @return       0 ok ; <0 error
 */
/*--------------------------------------------------------------------------*/
int SB_RegIcon(enum ICONTYPE eType, int x, int y, int width, int height, int refreshFrequency_ms);

/*-------------------------------------------------------------------------*/
/**
  @brief    refresh an icon manually
  @param    eType      type id
  @param    iconFile   if it is NULL, then will clear that icon area
  @return     0 ok; others error
 */
/*--------------------------------------------------------------------------*/
int SB_ManuallyRefresh(enum ICONTYPE eType, const char *iconFile);

/*-------------------------------------------------------------------------*/
/**
  @brief    un-register an icon
  @param    eType       icon type
  @return   0 ok; others error
 */
/*--------------------------------------------------------------------------*/
int SB_UnRegIcon(enum ICONTYPE eType);

#ifdef __cplusplus
};
#endif

#endif /* SHARED_LIBRARY_H_StatusBarLib */

