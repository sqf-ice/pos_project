
#include "global.h"

/********************** Internal macros declaration ************************/
/********************** Internal structure declaration *********************/
/********************** Internal functions declaration *********************/
static void ClearReversalSub(void);
static int  ViewTranSub(int iStartRecNo);

/********************** Internal variables declaration *********************/
/********************** external reference declaration *********************/

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/

void UnLockTerminal(void)
{
	if( ChkEdcOption(EDC_NOT_KEYBOARD_LOCKED) )
	{
		return;
	}

	while( !ChkEdcOption(EDC_NOT_KEYBOARD_LOCKED) )
	{
		SetCurrTitle(_T("TERMINAL  LOCKED")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
		// Modified by Kim_LinHB 2014-6-8
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("MERCHANT PWD"), gl_stCenterAttr, GUI_BUTTON_NONE, -1, NULL);
		if( PasswordMerchant()==0 )
		{
			glSysParam.stEdcInfo.sOption[EDC_NOT_KEYBOARD_LOCKED>>8] |= (EDC_NOT_KEYBOARD_LOCKED & 0xFF);
			SaveEdcParam();
			PubBeepOk();
#ifdef _MONITOR_
			ScrSetIcon(ICON_LOCK, CLOSEICON);
#endif
		}
	}
}

// Modified by Kim_LinHB 2014-6-8
int LockTerm(void)
{
	int iRet;
	SetCurrTitle(_T("LOCK TERM")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TERMINAL LOCK? "), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( GUI_OK == iRet)
	{
		glSysParam.stEdcInfo.sOption[EDC_NOT_KEYBOARD_LOCKED>>8] &= ~(EDC_NOT_KEYBOARD_LOCKED & 0xFF);
		SaveEdcParam();
		PubBeepOk();
		UnLockTerminal();
	}
	return 0;
}

int SetEcr(void)
{
    uchar   szBuff[32], szTitle[32];
    int iSelected, iRet;
    GUI_MENU stEcrMode;
    GUI_MENUITEM stEcrModeItem[4] = {
            {"1.DISABLE", 0, TRUE, NULL},
            {"2.McDonald's", 1, TRUE, NULL},//{"2.ENABLE", 1, TRUE, NULL},
            {"3.Carrefour", 2, TRUE, NULL},// {"3.ECR ONLY", 2, TRUE, NULL},
            {"", -1, FALSE, NULL},
    };

    SetCurrTitle(_T("ECR"));
    if( PasswordBank()!=0 )
    {
        return ERR_NO_DISP;
    }

    sprintf((char *)szTitle, "CUR: %.10s",
                (glSysParam.stECR.ucMode==ECRMODE_OFF) ? "DISABLE" : (glSysParam.stECR.ucMode==ECRMODE_ENABLED ? "ENABLE" : "ECR ONLY"));
    memset(&stEcrMode, 0, sizeof(stEcrMode));
    Gui_BindMenu(szTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stEcrModeItem, &stEcrMode);

    Gui_ClearScr();
    iSelected = 0;
    iRet = Gui_ShowMenuList(&stEcrMode, 0, USER_OPER_TIMEOUT, &iSelected);

    if(iRet != GUI_OK){
        return ERR_NO_DISP;
    }

    glSysParam.stECR.ucMode = iSelected;
    SaveSysParam();

    //-----------------------------------------------------
    if (glSysParam.stECR.ucMode > 0)
    {
        int iPort = glSysParam.stECR.ucPort;
        if(iPort != PORT_COM1 && iPort != PORT_PINPAD)
            iPort = PORT_COM1;
        Gui_ClearScr();
        if(ChkTerm(_TERMINAL_S800_))
        {
            iRet = Gui_ShowAlternative("ECR", gl_stTitleAttr, "SERIAL PORT", gl_stLeftAttr, "COM 1", PORT_COM1, "PIN PAD", PORT_PINPAD,
                    USER_OPER_TIMEOUT, &iPort);
        }
        else
        {
            iRet = Gui_ShowMsgBox("ECR", gl_stTitleAttr, "SERIAL PORT\nCOM 1", gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
        }
        if(iRet != GUI_OK)
        {
            return ERR_NO_DISP;
        }
        glSysParam.stECR.ucPort = iPort;
        SaveSysParam();

        int iSpeed = glSysParam.stECR.ucSpeed;
        if(iSpeed != ECRSPEED_9600 && iPort != ECRSPEED_115200)
            iSpeed = ECRSPEED_9600;
        Gui_ClearScr();
        iRet = Gui_ShowAlternative("ECR", gl_stTitleAttr, "BAUD RATE", gl_stLeftAttr, "9600", ECRSPEED_9600, "115200", ECRSPEED_115200,
                    USER_OPER_TIMEOUT, &iSpeed);

        if(iRet != GUI_OK)
        {
            return ERR_NO_DISP;
        }
        glSysParam.stECR.ucSpeed = iSpeed;
        SaveSysParam();

    }
    return 0;
    //-----------------------------------------------------
    // TODO : more settings
}

int DoKeyInjection(void)
{
    int iRet;
    uchar szBuffer[20];
    SetCurrTitle(_T("KEY INJECTION"));
    if( PasswordBank()!=0 )
    {
        return ERR_NO_DISP;
    }

    Mid_CloseDevice();
    XuiSuspend();   // XUI暂停
    iRet = OsRunApp((char *)"KMS", NULL, NULL, NULL, NULL);
    XuiResume();    // XUI恢复
    Mid_OpenDevice();

    if(iRet){
        sprintf(szBuffer, "%d", iRet);
        Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuffer, gl_stCenterAttr, GUI_BUTTON_OK, 5, NULL);
    }
    return 0;
}


int DoKeyInjectionTrust(void)
{
    int iRet;
    uchar szBuffer[150];




    //uchar szVALUEBCD[100];
   // uchar szKCVBCD[50];



    SetCurrTitle(_T("KEY INJECTION"));
    if( PasswordBank()!=0 )
    {
        return ERR_NO_DISP;
    }

    //send2ECR("TRUST=TMK");

   memset(szBuffer,0,sizeof(szBuffer));

   strcpy(szBuffer,"\xD6\x45\xDE\x6E\x7A\x5D\xCB\xB5\xA8\xCD\xDC\xA8\xFF\xCF\x54\x98\x82\x65");

   strcat(szBuffer,",");

   strcat(szBuffer,szSerialNumberTRM);

   strcat(szBuffer,",");







   memset(TMK_CLEAR_KEY,0,sizeof(TMK_CLEAR_KEY));
   memset(TMK_ENCREPTED_KEY,0,sizeof(TMK_ENCREPTED_KEY));


   OsGetRandom((uchar*)TMK_CLEAR_KEY, 16);

  // OsDES(TMK_CLEAR_KEY,TMK_ENCREPTED_KEY, TMK_MSTER_KEY,16,	1);//1 ENC  0 DEC

   OsAES(TMK_CLEAR_KEY,TMK_ENCREPTED_KEY, TMK_MSTER_KEY,16,	1);//1 ENC  0 DEC


   uchar szkey_sender[100];
   memset(szkey_sender,0,sizeof(szkey_sender));
   PubBcd2Asc0(TMK_ENCREPTED_KEY,16,szkey_sender);
   strcat(szBuffer,szkey_sender);



//	fffFOURA(szkey_sender);
//
//	hhhHasan(strlen(szkey_sender));






//	hhhHasan(strlen(szBuffer));









 send2ECR(szBuffer);


    return 0;
}

int ClearPreAuth(void)
{
	int iRet;
	SetCurrTitle(_T("CLEAR BATCH")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( iRet != GUI_OK)
	{
		return ERR_NO_DISP;
	}

	DispProcess();

	ClearPreAuthorization(ACQ_ALL);
	DispClearOk();
	return 0;
}
// Modified by Kim_LinHB 2014-6-8
int ClearAllRecord(void)
{
	int iRet;
	SetCurrTitle(_T("CLEAR BATCH")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( iRet != GUI_OK)
	{
		return ERR_NO_DISP;
	}

	DispProcess();

	ClearRecord(ACQ_ALL);
	DispClearOk();
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int ClearConfig(void)
{
	int iRet;
	SetCurrTitle(_T("CLEAR CONFIG")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( iRet != GUI_OK)
	{
		return ERR_NO_DISP;
	}
	
	DispProcess();

	LoadEdcDefault();

#ifdef ENABLE_EMV
	LoadEmvDefault();
#endif
  
	DispClearOk();
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int ClearPassword(void)
{
	int iRet;
	SetCurrTitle(_T("CLEAR PASSWORD")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( iRet != GUI_OK)
	{
		return ERR_NO_DISP;
	}

	DispProcess();

	ResetPwdAll();
	SavePassword();
	DispClearOk();
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int ClearPED(void)
{

	int iRet;
		SetCurrTitle(_T("CLEAR KEYS")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
		Gui_ClearScr();
		iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

		if( iRet != GUI_OK)
		{
			return ERR_NO_DISP;
		}

		DispProcess();

		OsPedEraseKeys();
		DispClearOk();

	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int ClearReversal(void)
{
	int iRet;
	SetCurrTitle(_T("CLEAR REVERSAL")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	Gui_ClearScr();
	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CONFIRM CLEAR"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);

	if( iRet != GUI_OK)
	{
		return ERR_NO_DISP;
	}

	DispProcess();

	ClearReversalSub();
	DispClearOk();
	return 0;
}

void ClearReversalSub(void)
{
	int		iCnt;

	for(iCnt=0; iCnt<(int)glSysParam.ucAcqNum; iCnt++)
	{
		glSysCtrl.stRevInfo[iCnt].bNeedReversal = FALSE;
		if( glSysCtrl.sAcqStatus[iCnt]==S_PENDING )	// 为何删除结算标志???
		{
			glSysCtrl.sAcqStatus[iCnt] = S_USE;
		}
	}
	SaveSysCtrlNormal();

	// glSysCtrl.stField56
}


void ClearPreAuthorization(uchar ucAcqKey)
{
	int		iCnt;

	if( ucAcqKey==ACQ_ALL )
	{
		glSysCtrl.uiLastRecNo = 0xFFFF;
		// 删除交易日志
		// Delete record
//		for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
//		{
//			glSysCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
//			glSysCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
//		}

		//linzhao 20160106
		if(glSysCtrl.authCtrl.ucEnableTabBatch)
		{
			for(iCnt=0; iCnt<MAX_AUTH_TRANLOG; iCnt++)
			{
				glSysCtrl.authCtrl.sAcqKeyList[iCnt] 	= INV_ACQ_KEY;
				glSysCtrl.authCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
				glSysCtrl.authCtrl.ulStart[iCnt] = 0;
			}
			glSysCtrl.authCtrl.uiTotalRec = 0;
		}

		// 恢复收单行状态及清除冲正标志
		// Reset status and reversal flag
		for(iCnt=0; iCnt<(int)glSysParam.ucAcqNum; iCnt++)
		{
			glSysCtrl.sAcqStatus[iCnt]         = S_USE;
			glSysCtrl.stRevInfo[iCnt].bNeedReversal = FALSE;
//			glSysCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
			//linzhao 20160106
			if(glSysCtrl.authCtrl.ucEnableTabBatch)
			{
				glSysCtrl.authCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
			}
			glSysCtrl.stField56[iCnt].uiLength = 0;	// erase bit 56
			if( !(glSysParam.stAcqList[iCnt].ulCurBatchNo>0 &&
				  glSysParam.stAcqList[iCnt].ulCurBatchNo<=999999L) )
			{
				glSysParam.stAcqList[iCnt].ulCurBatchNo = 1L;
			}
		}

		SaveSysAUTHCtrlAll();
	}
	else
	{
//		if( glSysCtrl.uiLastRecNo<MAX_TRANLOG &&
//			glSysCtrl.sAcqKeyList[glSysCtrl.uiLastRecNo]==ucAcqKey )
//		{
//			glSysCtrl.uiLastRecNo = 0xFFFF;
//		}
		//linzhao 20160106
		if( glSysCtrl.authCtrl.ucEnableTabBatch && glSysCtrl.authCtrl.uiLastRecNo<MAX_AUTH_TRANLOG &&
			glSysCtrl.authCtrl.sAcqKeyList[glSysCtrl.authCtrl.uiLastRecNo]==ucAcqKey )
		{
			glSysCtrl.authCtrl.uiLastRecNo = 0xFFFF;
		}

		// 删除交易日志
		// delete all transaction records
//		for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
//		{
//			if( glSysCtrl.sAcqKeyList[iCnt]==ucAcqKey )
//			{
//				glSysCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
//				glSysCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
//			}
//		}

		//linzhao 20160106
		if(glSysCtrl.authCtrl.ucEnableTabBatch)
		{
			for(iCnt=0; iCnt<MAX_AUTH_TRANLOG; iCnt++)
			{
				if( glSysCtrl.authCtrl.sAcqKeyList[iCnt]==ucAcqKey )
				{
					glSysCtrl.authCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
					glSysCtrl.authCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
					glSysCtrl.authCtrl.uiTotalRec--;
				}
			}
		}

		// 恢复收单行状态及清除冲正标志
		// reset statuses of all acquirers, and clear reversal flags
		for(iCnt=0; iCnt<(int)glSysParam.ucAcqNum; iCnt++)
		{
			if( glSysParam.stAcqList[iCnt].ucKey==ucAcqKey )
			{
				glSysCtrl.sAcqStatus[iCnt] = S_USE;
				glSysCtrl.stRevInfo[iCnt].bNeedReversal = FALSE;
				glSysCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
//				glSysCtrl.authCtrl.uiLastRecNoList[iCnt] = 0xFFFF; //linzhao 20160106
				if( glSysCtrl.stField56[iCnt].uiLength>0 )
				{
					glSysCtrl.stField56[iCnt].uiLength = 0;	// erase bit 56
					SaveField56();
				}

				// increase batch no
				glSysParam.stAcqList[iCnt].ulCurBatchNo = GetNewBatchNo(glSysParam.stAcqList[iCnt].ulCurBatchNo);

				break;
			}
		}
		SaveSysCtrlNormal();
	}

	SaveSysParam();
}
// 删除特定acquirer的交易记录
// Delete transaction records belonging to specific acquirer
void ClearRecord(uchar ucAcqKey)
{
	int		iCnt;

	if( ucAcqKey==ACQ_ALL )
	{
		glSysCtrl.uiLastRecNo = 0xFFFF;
		// 删除交易日志
		// Delete record
		for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
		{
			glSysCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
			glSysCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
		}

		//linzhao 20160106
//		if(glSysCtrl.authCtrl.ucEnableTabBatch)
//		{
//			for(iCnt=0; iCnt<MAX_AUTH_TRANLOG; iCnt++)
//			{
//				glSysCtrl.authCtrl.sAcqKeyList[iCnt] 	= INV_ACQ_KEY;
//				glSysCtrl.authCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
//				glSysCtrl.authCtrl.ulStart[iCnt] = 0;
//			}
//			glSysCtrl.authCtrl.uiTotalRec = 0;
//		}

		// 恢复收单行状态及清除冲正标志
		// Reset status and reversal flag
		for(iCnt=0; iCnt<(int)glSysParam.ucAcqNum; iCnt++)
		{
			glSysCtrl.sAcqStatus[iCnt]         = S_USE;
			glSysCtrl.stRevInfo[iCnt].bNeedReversal = FALSE;
			glSysCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
			//linzhao 20160106
//			if(glSysCtrl.authCtrl.ucEnableTabBatch)
//			{
//				glSysCtrl.authCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
//			}
			glSysCtrl.stField56[iCnt].uiLength = 0;	// erase bit 56
			if( !(glSysParam.stAcqList[iCnt].ulCurBatchNo>0 &&
				  glSysParam.stAcqList[iCnt].ulCurBatchNo<=999999L) )
			{
				glSysParam.stAcqList[iCnt].ulCurBatchNo = 1L;
			}
		}
		SaveSysCtrlAll();
	}
	else
	{
		if( glSysCtrl.uiLastRecNo<MAX_TRANLOG &&
			glSysCtrl.sAcqKeyList[glSysCtrl.uiLastRecNo]==ucAcqKey )
		{
			glSysCtrl.uiLastRecNo = 0xFFFF;
		}
		//linzhao 20160106
//		if( glSysCtrl.authCtrl.ucEnableTabBatch && glSysCtrl.authCtrl.uiLastRecNo<MAX_AUTH_TRANLOG &&
//			glSysCtrl.authCtrl.sAcqKeyList[glSysCtrl.authCtrl.uiLastRecNo]==ucAcqKey )
//		{
//			glSysCtrl.authCtrl.uiLastRecNo = 0xFFFF;
//		}

		// 删除交易日志
		// delete all transaction records
		for(iCnt=0; iCnt<MAX_TRANLOG; iCnt++)
		{
			if( glSysCtrl.sAcqKeyList[iCnt]==ucAcqKey )
			{
				glSysCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
				glSysCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
			}
		}

		//linzhao 20160106
//		if(glSysCtrl.authCtrl.ucEnableTabBatch)
//		{
//			for(iCnt=0; iCnt<MAX_AUTH_TRANLOG; iCnt++)
//			{
//				if( glSysCtrl.authCtrl.sAcqKeyList[iCnt]==ucAcqKey )
//				{
//					glSysCtrl.authCtrl.sAcqKeyList[iCnt]    = INV_ACQ_KEY;
//					glSysCtrl.authCtrl.sIssuerKeyList[iCnt] = INV_ISSUER_KEY;
//					glSysCtrl.authCtrl.uiTotalRec--;
//				}
//			}
//		}

		// 恢复收单行状态及清除冲正标志
		// reset statuses of all acquirers, and clear reversal flags
		for(iCnt=0; iCnt<(int)glSysParam.ucAcqNum; iCnt++)
		{
			if( glSysParam.stAcqList[iCnt].ucKey==ucAcqKey )
			{
				glSysCtrl.sAcqStatus[iCnt] = S_USE;
				glSysCtrl.stRevInfo[iCnt].bNeedReversal = FALSE;
				glSysCtrl.uiLastRecNoList[iCnt] = 0xFFFF;
//				glSysCtrl.authCtrl.uiLastRecNoList[iCnt] = 0xFFFF; //linzhao 20160106
				if( glSysCtrl.stField56[iCnt].uiLength>0 )
				{
					glSysCtrl.stField56[iCnt].uiLength = 0;	// erase bit 56
					SaveField56();
				}

				// increase batch no
				glSysParam.stAcqList[iCnt].ulCurBatchNo = GetNewBatchNo(glSysParam.stAcqList[iCnt].ulCurBatchNo);

				break;
			}
		}
		SaveSysCtrlNormal();
	}

	SaveSysParam();
}

// 清除终端数据界面
// Interface of "Clear". (FUNC99) 
// Modified by Kim_LinHB 2014-6-8
int DoClear(void)
{
	GUI_MENU	stClearMenu;
	GUI_MENUITEM stClearMenuItems[] =
	{
		{ "1.CLEAR CONFIG",	1,TRUE,  ClearConfig},
		{ "2.CLEAR BATCH",	2,TRUE,  ClearAllRecord},
		{ "3.CLEAR REVERSAL",	3,TRUE,  ClearReversal},
		{ "4.CLEAR PWD",	4,TRUE,  ClearPassword},
		{ "5.CLEAR PRE-AUTH",	5,TRUE,  ClearPreAuth},
		{ "6.CLEAR KEYS",	6,TRUE,  ClearPED},

		{ "",	-1,FALSE, NULL},
	};

	SetCurrTitle(_T("CLEAR"));
	if( PasswordBank()!=0 )
	{
		return ERR_NO_DISP;
	}

	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stClearMenuItems, &stClearMenu);
	Gui_ClearScr();
	Gui_ShowMenuList(&stClearMenu, 0, USER_OPER_TIMEOUT, NULL);
	return 0;
}

// 查看交易汇总
// View total. (glTransTotal)
int ViewTotal(void)
{
	CalcTotal(ACQ_ALL);
	DispTransTotal(TRUE);
	return 0;
}

// 查看所有交易记录
// View all transaction record
int ViewTranList(void)
{
	SetCurrTitle("TRANS REVIEW"); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493
	if( GetTranLogNum(ACQ_ALL)==0 )
	{
		// Modified by Kim_LinHB 2014-6-8
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_NO_DISP;
	}

	// 浏览所有交易
	// view all transaction records
	ViewTranSub(-1);
	return 0;
}

// 查看指定交易记录
// View specific record
// Modified by Kim_LinHB 2014-6-8
int ViewSpecList(void)
{
	int			iRet;
	TRAN_LOG	stLog;

	SetCurrTitle("TRANS REVIEW");

	while (1)
	{
		if( GetTranLogNum(ACQ_ALL)==0 )
		{
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
			return ERR_NO_DISP;
		}

		iRet = GetRecord(TS_ALL_LOG, &stLog);
		if( iRet!=0 )
		{
			return ERR_NO_DISP;
		}

		if (ViewTranSub((int)glProcInfo.uiRecNo)!=0)
		{
			break;
		}
	}
	return 0;
}

// 交易记录浏览控制
// View transaction records
// 返回：ERR_USERCANCEL--取消或超时退出；0--其它按键（或原因）退出
// return ERR_USERCANCEL--timeout or cancel
// Modified by Kim_LinHB 2014-6-8
int ViewTranSub(int iStartRecNo)
{
	int			iRecNo, iStep, iCnt, iActRecNo;
	TRAN_LOG	stLog;

	iRecNo = iStartRecNo;
	iStep  = iStartRecNo<0 ? 1 : 0;
	while( 1 )
	{
		iRecNo = iRecNo + iStep;
		if( iRecNo>=MAX_TRANLOG )
		{
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("END OF BATCH"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
			iRecNo = 0;
		}
		else if( iRecNo<0 )
		{
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("START OF BATCH"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
			iRecNo = MAX_TRANLOG-1;
		}
		if( glSysCtrl.sAcqKeyList[iRecNo]==INV_ACQ_KEY )
		{
			continue;
		}
		memset(&stLog, 0, sizeof(TRAN_LOG));
		LoadTranLog(&stLog, (ushort)iRecNo);
		for(iActRecNo=iCnt=0; iCnt<=iRecNo; iCnt++)
		{
			if( glSysCtrl.sAcqKeyList[iCnt]!=INV_ACQ_KEY )
			{
				iActRecNo++;
			}
		}

		{
			int		iRet;
			uchar	*pszTitle, szBuff[25], szTotalAmt[12+1], ucCnt = 0;
			GUI_PAGELINE stBuff[20];
			GUI_PAGE	 stPage;

			TRAN_LOG	*pstLog = (TRAN_LOG *)&stLog;

			sprintf(stBuff[ucCnt].szLine, "%03d/%03d", iActRecNo, GetTranLogNum(ACQ_ALL));
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug508
			iRet = GetStateText(pstLog->uiStatus, szBuff);
			if(0 == iRet)
			{
				pszTitle = glTranConfig[pstLog->ucTranType].szLabel;
			}
			else if(1 == iRet)
			{
				pszTitle = glTranConfig[pstLog->ucOrgTranType].szLabel;
			}

			sprintf(stBuff[ucCnt].szLine, "Status:%s", szBuff);
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			sprintf(stBuff[ucCnt].szLine, "TRACE:%06lu", pstLog->ulInvoiceNo);
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			if( !ChkIfDispMaskPan2() )
			{
				strcpy(stBuff[ucCnt].szLine, pstLog->szPan);
			}
			else
			{
				MaskPan(pstLog->szPan, szBuff);
				strcpy(stBuff[ucCnt].szLine, szBuff);
			}
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;


			PubAscAdd(pstLog->szAmount, pstLog->szTipAmount, 12, szTotalAmt);
			// add SurCharge, linzhao 20160113
			if (!ChkIfZeroAmt(pstLog->szSurFee))
			{
			    uchar szTotalAmt2[12+1];
			    strcpy(szTotalAmt2, szTotalAmt);
			    PubAscAdd(szTotalAmt2, pstLog->szSurFee, 12, szTotalAmt);
			}

			App_ConvAmountTran(szTotalAmt,	szBuff, GetTranAmountInfo(pstLog));
			strcpy(stBuff[ucCnt].szLine, szBuff);
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

#ifdef ENABLE_DCC
			if(pstLog->ucDccOption==DCC_TYPE_DCC)
			{
				memset(szBuff, 0x00, sizeof(szBuff));
				OsLog(LOG_DEBUG, "%s-%d, Save COMPLETION LOG : %s, %d, %d, %s", __FILE__, __LINE__,
						pstLog->stHolderCurrency.szName,
						pstLog->stHolderCurrency.ucDecimal,
						pstLog->stHolderCurrency.ucIgnoreDigit,
						pstLog->szFrnAmount);
				memcpy(&glProcInfo.stTranLog.stHolderCurrency, &pstLog->stHolderCurrency, sizeof(CURRENCY_CONFIG));
				App_ConvAmountDccTran(pstLog->stDccInfo.szAmount,	szBuff, GetTranAmountInfo(pstLog));
				strcpy(stBuff[ucCnt].szLine, szBuff);
				stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
			}
#endif // ENABLE_DCC
		
			strcpy(stBuff[ucCnt].szLine, "APPROVAL CODE:");
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			sprintf(stBuff[ucCnt].szLine, "%6.6s", pstLog->szAuthCode);
			stBuff[ucCnt++].stLineAttr = gl_stRightAttr;
			
			Conv2EngTime(pstLog->szDateTime, szBuff);
			sprintf(stBuff[ucCnt].szLine, "%s", szBuff);
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			sprintf(stBuff[ucCnt].szLine, "RRN:%12.12s", pstLog->szRRN);
			stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

			Gui_CreateInfoPage(_T(pszTitle), gl_stTitleAttr, stBuff, ucCnt, &stPage);
			Gui_ClearScr();

			iRet = Gui_ShowInfoPage(&stPage, iStartRecNo < 0 ? TRUE : FALSE, USER_OPER_TIMEOUT);

			// 查阅指定记录,不上下翻页
			// if viewing a specific record, then return directly
			if (iStartRecNo>=0)
			{
				return 0;
			}

			if(GUI_OK_NEXT == iRet)
			{
				iStep = 1;
			}
			else if(GUI_OK_PREVIOUS == iRet)
			{
				iStep = -1;
			}
			else
			{
				return ERR_USERCANCEL;
			}
		}
	}
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int PrnLastTrans(void)
{
	int			iRet;

	SetCurrTitle(_T("REPRINT"));

	OsLog(LOG_INFO, "%s-%d, LastRecNo=%d", __FILE__, __LINE__, glSysCtrl.uiLastRecNo);
	if( glSysCtrl.uiLastRecNo>=MAX_TRANLOG )
	{
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_NO_DISP;
	}

	InitTransInfo();
	iRet = LoadTranLog(&glProcInfo.stTranLog, glSysCtrl.uiLastRecNo);
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}

	Gui_ClearScr();
	// Modified by Kim_LinHB 2014-8-11 v1.01.0003
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	FindAcq(glProcInfo.stTranLog.ucAcqKey);
	FindIssuer(glProcInfo.stTranLog.ucIssuerKey);
	PrintReceipt(PRN_REPRINT);
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int RePrnSpecTrans(void)
{
	int			iRet;
	ulong       ulInvoice;

	SetCurrTitle(_T("REPRINT"));

	if( (GetTranLogNum(ACQ_ALL)-GetTranLogNumOfPreAuth(ACQ_ALL)) <= 0 )
	{
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"),gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_NO_DISP;
	}

    //InitTransInfo();  //Jason 2014.12.19 16:24
    //iRet = GetRecord(TS_ALL_LOG, &glProcInfo.stTranLog);//Jason 2014.12.19 16:25
    /*=======BEGIN: Jason 2014.12.19  16:25 modify===========*/
    //得到ECR 提供的交易流水
    ulInvoice = EcrGetTxnID();
    if ((glProcInfo.ucEcrCtrl==ECR_BEGIN) && (ulInvoice > 0))
    {
        iRet = GetRecordByInvoice(ulInvoice, TS_ALL_LOG, &glProcInfo.stTranLog);
    }
    else
    {
        iRet = GetRecord(TS_ALL_LOG, &glProcInfo.stTranLog);
    }
    /*====================== END======================== */
    if( iRet!=0 )
    {
        return ERR_NO_DISP;
    }

	if(PREAUTH == glProcInfo.stTranLog.ucTranType)
	{
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO RECORD"),gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		return ERR_NO_DISP;
	}

	Gui_ClearScr();
	// Modified by Kim_LinHB 2014-8-11 v1.01.0003
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	FindAcq(glProcInfo.stTranLog.ucAcqKey);
	FindIssuer(glProcInfo.stTranLog.ucIssuerKey);
	PrintReceipt(PRN_REPRINT);
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int PrnTotal(void)
{
	int		iRet;
	uchar	ucIndex;

	SetCurrTitle(_T("PRINT TOTAL"));

	Gui_ClearScr();
	iRet = SelectAcq(FALSE, GetCurrTitle(), &ucIndex);
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}
	CalcTotal(glCurAcq.ucKey);

	Gui_ClearScr();
	if (ChkIfZeroTotal(&glTransTotal))
	{
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(),  gl_stTitleAttr, _T("EMPTY BATCH"),
		               gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	PrnTotalAcq();
	return 0;
}

// Modified by Kim_LinHB 2014-6-8
int RePrnSettle(void)
{
	int		iRet;

	SetCurrTitle(_T("REPRINT SETTLE"));

	iRet = SelectAcq(FALSE, GetCurrTitle(), NULL);
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}

	if( !glSysCtrl.stRePrnStlInfo.bValid[glCurAcq.ucIndex] )
	{
		PubBeepErr();
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO RECEIPT"),gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	sprintf((char *)glProcInfo.szSettleMsg, "%s", glSysCtrl.stRePrnStlInfo.szSettleMsg[glCurAcq.ucIndex]);
	memcpy(&glTransTotal, &glSysCtrl.stRePrnStlInfo.stAcqTotal[glCurAcq.ucIndex], sizeof(TOTAL_INFO));
	memcpy(glIssuerTotal, glSysCtrl.stRePrnStlInfo.stIssTotal[glCurAcq.ucIndex], sizeof(glIssuerTotal));
	glCurAcq.ulCurBatchNo = glSysCtrl.stRePrnStlInfo.ulBatchNo[glCurAcq.ucIndex];

	DispPrinting();
	PrintSettleREP(PRN_REPRINT);
	return 0;
}

#ifdef ENABLE_EMV
// Print EMV error log message
int PrintEmvErrLog(void)
{
	// Modified by Kim_LinHB 2014-6-8
	SetCurrTitle(_T("PRINT ERROR LOG"));
	if( PasswordBank()!=0 )
	{
		return ERR_NO_DISP;
	}

	DispProcess();

	PrintEmvErrLogSub();
	return 0;
}
#endif

// end of file

