
/****************************************************************************
NAME
    ecrtrans.h - ����������¼�����ģ��

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    HeJJ     2010.09.20      - created
****************************************************************************/

#ifndef EDC_MAIN_HK_ECRTRANS_H
#define EDC_MAIN_HK_ECRTRANS_H

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

// TODO : add function declarations here.
int EcrTrans(void *pszEcrMsg);
int EcrGetAmount(unsigned char *pszAmount, unsigned char *pszTip);
unsigned long EcrGetTxnID(void);
unsigned long  EcrGetInvoice(void);
int EcrGetInstPlan(unsigned char *pucMonth);
int EcrSendAckStr(void);
int EcrSendTransSucceed(void);
int EcrSendTranFail(void);
int EcrSendAcqTotal(void);
/*=======BEGIN: Jason 2014.12.19  16:10 modify===========*/
int EcrGetRRN(unsigned char *szRRN);
int EcrGetPwd(unsigned char *pszPwd);
int EcrGetADJamt(unsigned char *pszADJAmount);
/*====================== END======================== */
int EcrGetDate(unsigned char *pszDate);//Jason 2015.03.26 11:5
int EcrGetAppCode(unsigned char *szAppCode); //Jason 2015.03.26 11:27
#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif  // EDC_MAIN_HK_ECRTRANS_H

// end of file
