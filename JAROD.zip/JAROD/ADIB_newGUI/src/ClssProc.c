﻿#include "global.h"

#ifdef ENABLE_CONTLESS

/********************** Internal macros declaration ************************/
// macros for analyze EMV TLV string
#define TAGMASK_CLASS			0xC0	// tag mask of tag class
#define TAGMASK_CONSTRUCTED		0x20	// tag mask of constructed/primitive data
#define TAGMASK_FIRSTBYTE		0x1F	// tag mask of first byte
#define TAGMASK_NEXTBYTE		0x80	// tag mask of next byte

#define LENMASK_NEXTBYTE		0x80	// length mask
#define LENMASK_LENBYTES		0x7F	// mask of bytes of lenght

#define TAG_NULL_1				0x00	// null tag
#define TAG_NULL_2				0xFF	// null tag

#define DE55_MUST_SET			0x10	// 必须存在
#define DE55_OPT_SET			0x20	// 可选择存在
#define DE55_COND_SET			0x30	// 根据条件存在
/********************** Internal structure declaration *********************/

// callback function for GetTLVItem() to save TLV value
typedef void (*SaveTLVData)(uint uiTag, const uchar *psData, int iDataLen);

typedef struct _tagDE55Tag
{
	ushort	uiEmvTag;
	uchar	ucOption;
	uchar	ucLen;	
}DE55ClSSTag;

typedef struct _tagClssData
{
	uchar ucCardType;
	uchar ucSchemeId;

}CLSSDATA;

//added by Gillian Chen 2015/9/25
typedef struct
{
	unsigned char aucProgramId[17]; //Application Program ID
	unsigned char ucPrgramIdLen;    //Application Program ID锟斤拷锟斤拷
	Clss_PreProcInfo tPreProcDRL;
}App_ProgramID;

extern uchar gl_aucOutcomeParamSet[8];
extern uchar gl_aucUserInterReqData[22];
extern uchar gl_aucErrIndication[6];
extern CLSS_DISC_DATA_MC gl_DiscretionayData;
static uchar gl_ucDRLSupportFlg = 1;

Clss_PreProcInfo	glPreProcInfo[MAX_APP_NUM];
Clss_ProgramID ptProgInfo;

#define MAX_WAVE_AID_NUM 10//support WAVE ID count
CLSS_OUTCOME_DATA  stOutComeData;

//added by Gillian Chen 2015/9/25
Clss_PreProcInfo glClss_PreProcInfoIn;
uchar aucProID[17];
int nProIDLen = 0;
uchar gl_ucRemovalTimeup = 0;

/********************** Internal functions declaration *********************/
int IsConstructedTag(uint uiTag);
static int  GetTLVItem(uchar **ppsTLVString, int iMaxLen, SaveTLVData pfSaveData, uchar bExpandAll);
int GetSpecTLVItem(uchar *psTLVString, int iMaxLen, uint uiSearchTag, uchar *psOutTLV, ushort *puiOutLen);
int IssScrCon(void);
int Clss_transmit(uchar kerId);
int Clss_SetTLVData(unsigned int tag,uchar *data,int datalen,uchar flag);
int Clss_GetTLVData(unsigned int tag, uchar *data, int *datalen, uchar flag);
int disp_clss_err(int err);
void ClssBaseParameterSet_WAVE();
void ClssBaseParameterSet_AE();
void SetAEAidParam_AE();
void ClssBaseParameterSet_wave();
int ClssTransInit();
int nSetDETData(uchar *pucTag, uchar ucTagLen, uchar *pucData, uchar ucDataLen);
int SetClSSDE55(uchar bForUpLoad, uchar *psOutData, int *piOutLen);
int SetStdDEClSS55(uchar bForUpLoad, DE55ClSSTag *pstList, uchar *psOutData, int *piOutLen);
//uchar SearchSpecTLV(ushort nTag, uchar *sDataIn, ushort nDataInLen, uchar *sDataOut, ushort *pnDataOutLen);
void BuildCLSSTLVString(ushort uiEmvTag, uchar *psData, int iLength, uchar **ppsOutData);
int GetPanFromTrack2(uchar *pszPAN, uchar *pszExpDate,int iLen);//hdadd少了参数
//added by Gillian  2015/9/25
int nAppFindMatchProID(unsigned char *pucProID, int ucProIDLen);
//added by Kevinliu 2015/11/28
int Clss_secondTapCard();
int ClssPreProcTxnParam();
int ClssCompleteTrans_WAVE(uchar ucInOnlineResult, uchar aucRspCode[], uchar aucAuthCode[], uchar aucIAuthData[], int nIAuthDataLen,  uchar aucScript[], int nScriptLen);

int nAppCompleteTrans_AE(uchar ucInOnlineResult, uchar aucRspCode[], uchar aucAuthCode[], uchar aucIAuthData[], int nIAuthDataLen,  uchar aucScript[], int nScriptLen);
int nAppSecondTap_Wave(uchar ucInOnlineResult, uchar aucRspCode[], uchar aucAuthCode[], uchar aucIAuthData[], int nIAuthDataLen,  uchar aucScript[], int nScriptLen);
/********************** Internal variables declaration *********************/

// 非接消费55域标签,目前与EMV的标签一致
// F55 TLV format  1111 sgStdClssTagList
static DE55ClSSTag sgStdClssTagList[] =
{
	{0x57,   DE55_OPT_SET,   0},
	{0x5A,   DE55_OPT_SET,   0},
	{0x5F24, DE55_OPT_SET,   0},
	{0x5F2A, DE55_MUST_SET,  0},
	{0x5F34, DE55_OPT_SET,   0},
	{0x82,   DE55_MUST_SET,  0},//2
	{0x84,   DE55_MUST_SET,  0},
	//{0x8A,  DE55_OPT_SET,  2},//NEW
	{0x95,   DE55_MUST_SET,  0},
	{0x9A,   DE55_MUST_SET,  0},
	{0x9B,   DE55_OPT_SET,   0},
	{0x9C,   DE55_MUST_SET,  0},
	{0x9F02, DE55_MUST_SET,  0},
	{0x9F03, DE55_MUST_SET,  0},//6
	{0x9F08, DE55_OPT_SET,   0},
	{0x9F09, DE55_OPT_SET,   0},
	{0x9F10, DE55_OPT_SET,   0},
	{0x9F1A, DE55_MUST_SET,  0},
	{0x9F1E, DE55_OPT_SET,   0},//8
//	{0x9F1F, DE55_OPT_SET,   0},
	{0x9F26, DE55_MUST_SET,  0},//8
	{0x9F27, DE55_MUST_SET,  0},//1
	{0x9F33, DE55_MUST_SET,  0},//3
	{0x9F34, DE55_MUST_SET,  0},//3
	{0x9F35, DE55_OPT_SET,   0},
	{0x9F36, DE55_MUST_SET,  0},//2
	{0x9F37, DE55_MUST_SET,  0},
	{0x9F41, DE55_OPT_SET,   0},
	{0x9F5B, DE55_OPT_SET,   0},
	//{0xDF01, DE55_OPT_SET, 0},//NEW
	{0},
};



// TC-UPLOAD, TLV format
static DE55ClSSTag sgTcClssTagList[] =
{
	{0x5A,   DE55_OPT_SET,   0},
	{0x5F24, DE55_OPT_SET,   0},
	{0x5F2A, DE55_MUST_SET,  0},
	{0x5F34, DE55_OPT_SET,   0},
	{0x82,   DE55_MUST_SET,  0},
	{0x84,   DE55_MUST_SET,  0},
	{0x8A,   DE55_OPT_SET,   0},
	{0x95,   DE55_MUST_SET,  0},
	{0x9A,   DE55_MUST_SET,  0},
	{0x9B,   DE55_OPT_SET,   0},
	{0x9C,   DE55_MUST_SET,  0},
	{0x9F02, DE55_MUST_SET,  0},
	{0x9F03, DE55_MUST_SET,  0},
	{0x9F08, DE55_OPT_SET,   0},
	{0x9F09, DE55_OPT_SET,   0},
	{0x9F10, DE55_OPT_SET,   0},
	{0x9F18, DE55_OPT_SET,   0},
	{0x9F1A, DE55_MUST_SET,  0},
	{0x9F1E, DE55_OPT_SET,   0},//8
	{0x9F26, DE55_MUST_SET,  0},
	{0x9F27, DE55_MUST_SET,  0},
	{0x9F33, DE55_MUST_SET,  0},
	{0x9F34, DE55_MUST_SET,  0},
	{0x9F35, DE55_OPT_SET,   0},
	{0x9F36, DE55_MUST_SET,  0},
	{0x9F37, DE55_MUST_SET,  0},
	{0x9F41, DE55_OPT_SET,   0},
	{0x9F5B, DE55_OPT_SET,   0},
	{0},
};

// 非接消费56域标签,目前与EMV的标签一致
// F56 TLV format 
static DE55ClSSTag sgStdClssField56TagList[] =
{
	{0x5A,   DE55_MUST_SET, 0},
	{0x95,   DE55_MUST_SET, 0},
	{0x9B,   DE55_MUST_SET, 0},
	{0x9F10, DE55_MUST_SET, 0},
	{0x9F26, DE55_MUST_SET, 0},
	{0x9F27, DE55_MUST_SET, 0},
	{0},
};

CLSSDATA sgClssData;

TLV_ELEMENT_MC tTempTLV;

EMV_CAPK glCAPKeyList[100] = {0};

static uchar sFinalAid[17];
static int sFinalAidLen;

static uchar sAuthData[16];			// authentication data from issuer
static uchar sIssuerScript[300];	// issuer script
static int sgAuthDataLen, sgScriptLen;
/********************** external reference declaration *********************/

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/
//----------------------------------------------------------------------------------
//                                 
//                                     L3回调函数 
//									   L3Callback functions
//
//-----------------------------------------------------------------------------------


int SetClSSDE55(uchar bForUpLoad, uchar *psOutData, int *piOutLen)
{
	if (bForUpLoad)
	{
		return SetStdDEClSS55(bForUpLoad, sgTcClssTagList, psOutData, piOutLen);//Visa Card Foura
	}
	else
	{
		return SetStdDEClSS55(bForUpLoad, sgStdClssTagList, psOutData, piOutLen);//Master Card Foura
	}
}


// set ADVT/TIP bit 55
int SetStdDEClSS55(uchar bForUpLoad, DE55ClSSTag *pstList, uchar *psOutData, int *piOutLen)
{
	int		iRet, iCnt;
	int 	iLength;
	uchar	*psTemp, sBuff[200];

	*piOutLen = 0;
	psTemp    = psOutData;

	if (sgClssData.ucSchemeId==CLSS_MC_MAG)
	{
		return 0;
	}

	for(iCnt=0; pstList[iCnt].uiEmvTag!=0; iCnt++)
	{
		memset(sBuff, 0, sizeof(sBuff));
		//在非接触L2 的qPBOC及payWave中,'终端性能(9F33)'数据元无法从这两个库中获取。
		//
		// L2 of the non-contact qPBOC and payWave, the 'terminal capability (9F33)' meta data can not be obtained from the two libraries.
		if (pstList[iCnt].uiEmvTag == 0x9F33)
		{
			EMVGetParameter(&glEmvParam);
			memcpy(sBuff, glEmvParam.Capability, 3);
			iLength = 3;
			BuildCLSSTLVString(pstList[iCnt].uiEmvTag, sBuff, iLength, &psTemp);
		}
		else
		{
			iRet = Clss_GetTLVData(pstList[iCnt].uiEmvTag, sBuff, &iLength, sgClssData.ucCardType);
			if( iRet==EMV_OK )
			{
				BuildCLSSTLVString(pstList[iCnt].uiEmvTag, sBuff, iLength, &psTemp);
			}
			else if( pstList[iCnt].ucOption==DE55_MUST_SET )
			{
				BuildCLSSTLVString(pstList[iCnt].uiEmvTag, NULL, 0, &psTemp);
			}
		}
	}

	if( glProcInfo.stTranLog.szPan[0]=='5' )
	{	// for master card TCC = "R" -- retail

		//adibfoura
		BuildCLSSTLVString(0x9F53, (uchar *)"R", 1, &psTemp);

		if (bForUpLoad)
		{
			memset(sBuff, 0, sizeof(sBuff));
			iRet = Clss_GetTLVData(0x91, sBuff, &iLength, sgClssData.ucCardType);
			if( iRet==EMV_OK )
			{
				BuildCLSSTLVString(0x91, sBuff, iLength, &psTemp);
			}
		}
	}

	*piOutLen = (psTemp-psOutData);

	return 0;
}

// Save Iuuser Authentication Data, Issuer Script.
void SaveRspICCData(uint uiTag, const uchar *psData, int iDataLen)
{
	int i=0;
	OsLog(LOG_INFO, "%s --- %d tag = %x", __FUNCTION__, __LINE__, uiTag);
//	for(i=0;i<iDataLen;i++)
//	{
//		OsLog(LOG_INFO, "psData[%d] = %x", i, psData[i]);
//	}
	switch( uiTag )
	{
	case 0x91:
		memcpy(sAuthData, psData, MIN(iDataLen, 16));
		sgAuthDataLen = MIN(iDataLen, 16);
		break;

	case 0x71:
	case 0x72:
		sIssuerScript[sgScriptLen++] = (uchar)uiTag;
		if( iDataLen>127 )
		{
			sIssuerScript[sgScriptLen++] = 0x81;
		}
		sIssuerScript[sgScriptLen++] = (uchar)iDataLen;
		memcpy(&sIssuerScript[sgScriptLen], psData, iDataLen);
		sgScriptLen += iDataLen;
		break;

	case 0x9F36:
//		memcpy(sATC, psData, MIN(iDataLen, 2));	// ignore
		break;

	default:
		break;
	}
}
// 
// //在数据中搜索指定Tag的Value
// uchar SearchSpecTLV(ushort nTag, uchar *sDataIn, ushort nDataInLen, uchar *sDataOut, ushort *pnDataOutLen)
// {
//     int i, j, iOneTag;
// 	ushort nLen;
// 	uchar *pDataEnd;
// 
// 	pDataEnd = sDataIn + nDataInLen;
//     while (sDataIn < pDataEnd) 
// 	{
//         iOneTag = *sDataIn++;
//         if (iOneTag == 0xFF || iOneTag == 0x00) continue;
//         if ((iOneTag & 0x1F) == 0x1F) 
// 		{
//             iOneTag <<= 8;
//             iOneTag += *sDataIn++;
//             if (iOneTag & 0x80) 
// 			{
//                 while (sDataIn < pDataEnd && (*sDataIn & 0x80)) sDataIn++;
//                 if (sDataIn >= pDataEnd) return 1;
//                 iOneTag = 0;
//             }
//         }
//         if (*sDataIn & 0x80) 
// 		{
//             i = (*sDataIn & 0x7F);
//             if (sDataIn + i > pDataEnd) return 1;
//             sDataIn++;
//             for (j = 0, nLen = 0; j < i; j++) 
// 			{
//                 nLen <<= 8;
//                 nLen += *sDataIn++;
//             }
//         }
//         else nLen = *sDataIn++;
// 		
//         if (iOneTag == nTag) 
// 		{
//             if (pnDataOutLen != NULL) *pnDataOutLen = nLen;
// 			memcpy(sDataOut, sDataIn, nLen);
//             return 0;
//         }
//         if (iOneTag & 0xFF00) 
// 		{
//             if (iOneTag & 0x2000) continue;
//         }
//         else if (iOneTag & 0x20) continue;
// 
// 		sDataIn += nLen;
//     }
//     return 1;
// }

// 只处理基本数据元素Tag,不包括结构/模板类的Tag
// Build Clss basic TLV data, exclude structure/template.
void BuildCLSSTLVString(ushort uiEmvTag, uchar *psData, int iLength, uchar **ppsOutData)
{
	uchar	*psTemp = NULL;

	if( iLength<0 )
	{
		return;
	}

	// 设置TAG
	// write tag
	psTemp = *ppsOutData;
	if( uiEmvTag & 0xFF00 )
	{
		*psTemp++ = (uchar)(uiEmvTag >> 8);
	}
	*psTemp++ = (uchar)uiEmvTag;

	// 设置Length
	// write length
	if( iLength<=127 )	// 目前数据长度均小余127字节,但仍按标准进行处理
	{
		*psTemp++ = (uchar)iLength;
	}
	else
	{	// EMV规定最多255字节的数据
		*psTemp++ = 0x81;
		*psTemp++ = (uchar)iLength;
	}

	// 设置Value
	// write value
	if( iLength>0 )
	{
		memcpy(psTemp, psData, iLength);
		psTemp += iLength;
	}

	*ppsOutData = psTemp;
}

// 从2磁道信息分析出卡号(PAN)
int GetPanFromTrack2(uchar *pszPAN, uchar *pszExpDate, int iLen)
{
	int		iPanLen = 0;
	char	*p = NULL, pszTemp[41]= {0};
	
	// 从2磁道开始到'D'
// 	iPanLen = glProcInfo.szTrack2;
// 	if( iPanLen>0 )
// 	{
// 		memset(pszTemp, 0, sizeof(pszTemp));
// 		PubBcd2Asc0(glProcInfo.szTrack2, iPanLen, pszTemp);
// 	}
// 	else
// 	{	// 2磁道都没有
// 		return ERR_SWIPECARD;
// 	}
	memset(pszTemp, 0, sizeof(pszTemp));
	memcpy(pszTemp, glProcInfo.szTrack2, iLen);

	
	p = strchr((char *)pszTemp, '=');
	if( p==NULL )
	{
		return ERR_SWIPECARD;
	}
	iPanLen = strlen(pszTemp) - strlen(p);
	if( iPanLen<13 || iPanLen>19 )
	{
		return ERR_SWIPECARD;
	}
	
	sprintf((char *)pszPAN, "%.*s", iPanLen, pszTemp);
	sprintf((char *)pszExpDate, "%.4s", p+1);
	
	return 0;
}

int ClssDetectTapCard(void)
{
	int iRet = 0, iTime = 0;
	uchar ucKey = 0;

	//tap card
	iRet = PiccOpen();
	if(iRet != 0)
	{
		SetClssLightStatus(CLSSLIGHTSTATUS_ERROR);
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("OPEN PICC ERR"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
		return ERR_NO_DISP;
	}
	TimerSet(3,500);
	kbflush();
	while(1)
	{
		iTime = TimerCheck(3);
		if(!iTime)
		{
			return ERR_USERCANCEL;
		}

		if(kbhit() != NOKEY)
		{
			ucKey = getkey();
			if(ucKey == KEYCANCEL)
			{
				return ERR_USERCANCEL;
			}
		}
		else	//modified by kevinliu 2015/12/09 It's hard to cancel before modified.
		{
			iRet = PiccDetect(0, NULL, NULL, NULL, NULL);
			OsLog(LOG_INFO, "%s - %d PiccDetect RET = %d", __FUNCTION__, __LINE__, iRet);
			if(iRet == 0)
			    break;
			else if(iRet == 3|| iRet==5 || iRet==6)
			{
				DelayMs(100);
				continue;
			}
			else if(iRet == 4)
			{
				SetClssLightStatus(CLSSLIGHTSTATUS_ERROR);
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TOO MANY CARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
				return ERR_NO_DISP;
			}
			else// if(iRet == 1 || iRet==2)
            {   dddoHentFMessage(1);
                return ERR_TRAN_FAIL;
            }
		}
	}
	return 0;
}

int ClssProcFlow_VISA(uchar *finalData, int finalDataLen, Clss_PreProcInterInfo ClssProcInterInfo)
{
#ifdef CLSS_DEBUG
Clss_SetDebug_Wave(1);
#endif
	OsLog(LOG_INFO, "%s--%d", __FUNCTION__, __LINE__);
	int iRet = 0;
	uchar ucAcType = 0, ucPathType = 0, ucTemp[100] = "";
	Clss_TransParam ClssTransParam;

	memset(&ClssTransParam, 0, sizeof(Clss_TransParam));
	GetClssTxnParam(&ClssTransParam);

	ClssBaseParameterSet_WAVE();
	vSetFinalSelectAID(finalData+1, finalData[0]);
	iRet = Clss_SetFinalSelectData_Wave(finalData, finalDataLen);
	if(iRet != EMV_OK)
	{
//		PiccClose();
//		ProcError_Picc(iRet);
//		return ERR_TRAN_FAIL;
		return iRet;
	}

	//added by Gillian Chen 2015/9/25
	iRet = Clss_SetTLVData_Wave(0x9F5A, "123", 10);
	if(gl_ucDRLSupportFlg == 1)
	{
		if (Clss_GetTLVData_Wave(0x9F5A, aucProID, &nProIDLen) == EMV_OK)
		{
			if (!nAppFindMatchProID(aucProID, nProIDLen))
			{
				if(Clss_SetDRLParam_Wave(ptProgInfo) != EMV_OK)
				{
					dddoHentFMessage(2);
//					PiccClose();
					return ERR_TRAN_FAIL;
				}
			}
			else
			{
				dddoHentFMessage(3);
//				PiccClose();
				return ERR_TRAN_FAIL;
			}
		}
		else
		{
			dddoHentFMessage(4);
//			PiccClose();
			return ERR_TRAN_FAIL;
		}
	}
	iRet = Clss_SetTransData_Wave(&ClssTransParam, &ClssProcInterInfo);
	if(iRet != EMV_OK)
	{
//		PiccClose();
//		ProcError_Picc(iRet);
//		return ERR_TRAN_FAIL;
		return iRet;
	}

	ucAcType = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_Proctrans_Wave(ucTemp, &ucAcType);
	sgClssData.ucSchemeId = ucTemp[0];
	ucPathType = ucTemp[0];
	if(iRet)
	{
		if(iRet == CLSS_RESELECT_APP)
		{
			iRet = Clss_DelCurCandApp_Entry();
			if (iRet)
			{
//				disp_clss_err(iRet);//not sure
//				ProcError_Picc(iRet);
//				PiccClose();
//				return ERR_TRAN_FAIL;
				return iRet;
			}
			return iRet;
		}
		//see phone
		else if((iRet == CLSS_REFER_CONSUMER_DEVICE) && ((ClssProcInterInfo.aucReaderTTQ[0] & 0x20) == 0x20))
		{
			Inter_DisplayMsg(MSG_SEE_PHONE);
			iRet= App_Try_Again;
			DelayMs(1200);
			return iRet;
		}
		else if(iRet == CLSS_USE_CONTACT)
		{
			Inter_DisplayMsg(MSG_TRY_ANOTHER_INTERFACE);
			return CLSS_USE_CONTACT;
		}
		else
		{
//			ProcError_Picc(iRet);
//			return ERR_TRAN_FAIL;
			return iRet;
		}
	}

	vAppSetTransPath(ucPathType);

	iRet = nAppTransProc_VISA(ucPathType, ucAcType);

	return iRet;
}

int ClssProcFlow_MC(uchar *finalData, int finalDataLen, Clss_PreProcInterInfo ClssProcInterInfo)
{
#ifdef CLSS_DEBUG
Clss_SetDebug_MC(1);
#endif
	OsLog(LOG_INFO, "%s--%d", __FUNCTION__, __LINE__);
	int iRet = 0;
	uchar ucAcType = 0, ucPathType = 0;

	Clss_SetCBFun_SendTransDataOutput_MC(cClssSendTransDataOutput_MC);
	vSetFinalSelectAID(finalData+1, finalData[0]);
//	SetTermParam_MC();
	ClssTermParamSet_MC();
	iRet = Clss_SetFinalSelectData_MC(finalData, finalDataLen);
	// 返回值的判断，If the return code is not EMV_OK, Application should get DF8129). [12/29/2014 jiangjy]
	if(iRet == CLSS_RESELECT_APP)
	{
		iRet = Clss_DelCurCandApp_Entry();
		if (iRet != 0)
		{
			vInitPaymentData();
			gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;
			gl_aucUserInterReqData[1]=MI_NOT_READY;
			memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

			gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
			gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
			gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
			gl_DiscretionayData.ucErrIndicFlg = 1;
			//					nSendTransDataOutput_MC(T_UIRD | T_OCPS | T_DISD);//S51.11 S51.12
//			return ERR_TRAN_FAIL;
			return iRet;
		}
		return iRet;
	}
	else if(iRet)
	{
//		disp_clss_err(iRet);
//		PiccClose();
//		return ERR_TRAN_FAIL;
		return iRet;
	}
	iRet = Clss_InitiateApp_MC();
	//返回值的判断 返回值的判断，If the return code is not EMV_OK, Application should get DF8129)
	if (iRet == CLSS_RESELECT_APP) // GPO
	{
		iRet = Clss_DelCurCandApp_Entry();
		if (iRet)
		{
			vInitPaymentData();// paypass 3.0.1 by zhoujie
			gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;//S51.11 for paypass 3.0.1 by zhoujie
			gl_aucUserInterReqData[1]=MI_NOT_READY;
			memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

			gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
			gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
			gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
			gl_DiscretionayData.ucErrIndicFlg = 1;
			//					nSendTransDataOutput_MC(T_UIRD | T_OCPS | T_DISD);//S51.11 S51.12
//			return ERR_TRAN_FAIL;
			return iRet;
		}
		return iRet;
	}
	else if(iRet)
	{
//		disp_clss_err(iRet);
//		PiccClose();
//		return ERR_TRAN_FAIL;
		return iRet;
	}
	ucPathType = 0;
	iRet = Clss_ReadData_MC(&ucPathType);
	//返回值的判断，If the return code is not EMV_OK, Application should get DF8129)
	if(iRet)
	{
		if(iRet == CLSS_RESELECT_APP)
		{
			iRet = Clss_DelCurCandApp_Entry();
			if (iRet)
			{
				vInitPaymentData();
				gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;
				gl_aucUserInterReqData[1]=MI_NOT_READY;
				memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

				gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
				gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
				gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
				gl_DiscretionayData.ucErrIndicFlg = 1;

//				return ERR_TRAN_FAIL;
				return iRet;
			}
			return iRet;
		}
		else
		{
//			ProcError_Picc(iRet);
//			return ERR_TRAN_FAIL;
			return iRet;
		}
	}

	vAppSetTransPath(ucPathType);

	iRet = nAppTransProc_MC(ucPathType, &ucAcType);
	if (gl_aucUserInterReqData[0] == MI_SEE_PHONE)
	{
		Inter_DisplayMsg(MSG_SEE_PHONE);
	}
	if (gl_aucOutcomeParamSet[0] == OC_TRY_AGAIN || gl_aucOutcomeParamSet[1] != OC_NA)
	{
		iRet = App_Try_Again;
	}

	return iRet;
}

//added by Kevinliu 2015-12-07
int ClssProcFlow_ALL()
{
	OsLog(LOG_INFO, "%s--%d", __FUNCTION__, __LINE__);
	int	 iRet = 0, iLen = 0;
	uchar ucTemp[300] = {0}, ucKernType = 0;
	Clss_PreProcInterInfo ClssProcInterInfo;
	Clss_TransParam ClssTransParam;
	uchar	szTotalAmt[12+1];

	GetClssTxnParam(&ClssTransParam);
	//display price and tap card prompt.
	memset(ucTemp, 0, sizeof(ucTemp));
	memset(szTotalAmt, 0, sizeof(szTotalAmt));
	PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	PubConvAmount(glSysParam.stEdcInfo.stLocalCurrency.szName, szTotalAmt,
				glProcInfo.stTranLog.stTranCurrency.ucDecimal,
				glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit,
				ucTemp, 0);


	strcat((char*)ucTemp, "\n");
	strcat((char*)ucTemp, _T("PLS TAP CARD"));

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, ucTemp, gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);
	SetClssLightStatus(CLSSLIGHTSTATUS_READYFORTXN);
	OsLog(LOG_INFO, "%s--%d", __FUNCTION__, __LINE__);

	//detect tap card
	iRet = ClssDetectTapCard();
	//returns ERR_USERCANCEL	ERR_TRAN_FAIL
	if(iRet)
	{
//		PiccClose();
		return iRet;
	}

	SetClssLightStatus(CLSSLIGHTSTATUS_PROCESSING);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS WAIT..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	glProcInfo.stTranLog.uiEntryMode = MODE_CONTACTLESS;
	Clss_SetMCVersion_Entry(3);// add for paypass 3.0 [12/29/2014 jiangjy]


	//app select
	iRet = Clss_AppSlt_Entry(0,0);
	//returns	EMV_OK	CLSS_PARAM_ERR	ICC_CMD_ERR	ICC_BLOCK	EMV_NO_APP	EMV_APP_BLOCK	EMV_NO_APP_PPSE_ERR

	if(iRet != EMV_OK)
	{
		vAppCreateOutcomeData_MC(iRet);
//		PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
//		disp_clss_err(iRet);
//		return ERR_TRAN_FAIL;
		return iRet;
	}

	while(1)
	{
		vAppInitPaymentData_MC();
		ucKernType = 0;
		iLen = 0;

		memset(ucTemp, 0, sizeof(ucTemp));
		iRet = Clss_FinalSelect_Entry(&ucKernType, ucTemp, &iLen);
		//returns	EMV_OK	CLSS_PARAM_ERR	ICC_CMD_ERR	EMV_RSP_ERR	EMV_NO_APP	EMV_APP_BLOCK	ICC_BLOCK
		//CLSS_USE_CONTACT	EMV_DATA_ERR	CLSS_RESELECT_APP
		if(iRet != EMV_OK)
		{
//			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
//			disp_clss_err(iRet);
//			return ERR_TRAN_FAIL;
			return iRet;
		}
		OsLog(LOG_INFO, "%s--%d Kernel Type = %d", __FUNCTION__, __LINE__, ucKernType);
		//VISA MASTERCARD AMERICANEXPRESS JCB DISCOVER
		if(ucKernType != KERNTYPE_VIS && ucKernType != KERNTYPE_MC)
		{
//			PiccClose();
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORT CTLS"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
			return ERR_TRAN_FAIL;
		}

		//modified by kevinliu 2015/12/09	set 9c tag by set TLV function.
		Clss_SetTLVData(0x9c, &ClssTransParam.ucTransType, 1, ucKernType);

		//get pre-process data
		memset(&ClssProcInterInfo, 0, sizeof(Clss_PreProcInterInfo));


		iRet = Clss_GetPreProcInterFlg_Entry(&ClssProcInterInfo);


		//returns	EMV_OK	CLSS_PARAM_ERR	CLSS_USE_CONTACT
		if(iRet != EMV_OK)
		{
//			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
//			disp_clss_err(iRet);
//			return ERR_TRAN_FAIL;
			return iRet;
		}
		OsLog(LOG_INFO, "%s--%d kernel = %d", __FUNCTION__, __LINE__, ucKernType);
		iLen = 0;
		memset(ucTemp, 0, sizeof(ucTemp));

		iRet = Clss_GetFinalSelectData_Entry(ucTemp, &iLen);

		//returns	EMV_OK	CLSS_PARAM_ERR
		if(iRet != EMV_OK)
		{
//			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
//			disp_clss_err(iRet);
//			return ERR_TRAN_FAIL;
			return iRet;
		}
		OsLog(LOG_INFO, "%s--%d kernel = %d", __FUNCTION__, __LINE__, ucKernType);

		iRet = nAppSetCurAppType(ucKernType);//CoreInit  //kernel type// scheme id

		OsLog(LOG_INFO, "%s--%d", __FUNCTION__, __LINE__);
		OsLog(LOG_INFO, "FinalData = %s, FinalDataLen = %d KernelType = %d", ucTemp, iLen, ucAppGetAppType());
		switch(ucAppGetAppType())
		{
		case KERNTYPE_VIS:
			OsLog(LOG_INFO, "%s--%d KERNTYPE_VIS", __FUNCTION__, __LINE__);
			iRet = ClssProcFlow_VISA(ucTemp, iLen, ClssProcInterInfo);
			break;
		case KERNTYPE_MC:
			OsLog(LOG_INFO, "%s--%d KERNTYPE_MC", __FUNCTION__, __LINE__);
			iRet = ClssProcFlow_MC(ucTemp, iLen, ClssProcInterInfo);
			break;
		default:
			OsLog(LOG_INFO, "%s--%d NOT SUPPORTED KERNEL", __FUNCTION__, __LINE__);
			break;
		}
		if(iRet == EMV_OK) {
		    break;
		}
		else if(iRet == CLSS_RESELECT_APP){
			continue;
		}
		else {
               appRemovePicc();
			break;
		}
	}
	return iRet;
}

int ClssPreProcTxnParam()
{
	int iRet = 0;
	Clss_TransParam ClssTransParam;

	//pre-process
	memset(&ClssTransParam, 0, sizeof(Clss_TransParam));
	ClssTransParam.ulAmntAuth = atol((char *)glProcInfo.stTranLog.szAmount);
	ClssTransParam.ulAmntOther = 0;
	ClssTransParam.ucTransType = 0x00;//EMV_GOODS;
	PubAsc2Bcd(glProcInfo.stTranLog.szDateTime+2, 6, ClssTransParam.aucTransDate);
	PubAsc2Bcd(glProcInfo.stTranLog.szDateTime+8, 6, ClssTransParam.aucTransTime);
	ClssTransParam.ulTransNo = glProcInfo.stTranLog.ulSTAN;
	SetClssTxnParam(&ClssTransParam);

	iRet = Clss_PreTransProc_Entry(&ClssTransParam);
	//returns EMV_OK	CLSS_PARAM_ERR		CLSS_USE_CONTACT
	if(iRet != EMV_OK)
	{
		if (iRet == CLSS_USE_CONTACT)
		{
			disp_clss_err(iRet);
		}
	}
	return iRet;

}



//For CLSS light control added by kevinliu
//*********************************************************************************************************
static CLSSLIGHTSTATUS gl_ucClssLightStatus;
static CLSSLIGHTSTATUS prevStatus;
static int gl_fd_blueLED=-1;
static int gl_fd_yellowLED=-1;
static int gl_fd_greenLED=-1;
static int gl_fd_redLED=-1;
static int gl_fd_logoLED=-1;

void SetClssLightStatus(CLSSLIGHTSTATUS status)
{
    gl_ucClssLightStatus = status;
}

CLSSLIGHTSTATUS GetClssLightStatus(void)
{
    return gl_ucClssLightStatus;
}

void PiccLightOpen(void)
{
    gl_fd_blueLED = ex_open("/sys/devices/platform/misc/rf_blue/power", O_WRONLY, S_IRWXU|S_IRWXG|S_IRWXO);
    gl_fd_yellowLED = ex_open("/sys/devices/platform/misc/rf_yellow/power", O_WRONLY, S_IRWXU|S_IRWXG|S_IRWXO);
    gl_fd_greenLED = ex_open("/sys/devices/platform/misc/rf_green/power", O_WRONLY, S_IRWXU|S_IRWXG|S_IRWXO);
    gl_fd_redLED = ex_open("/sys/devices/platform/misc/rf_red/power", O_WRONLY, S_IRWXU|S_IRWXG|S_IRWXO);
    gl_fd_logoLED = ex_open("/sys/devices/platform/misc/rf_logo/power", O_WRONLY, S_IRWXU|S_IRWXG|S_IRWXO);

    SetClssLightStatus(CLSSLIGHTSTATUS_INIT);
    OsLog(LOG_INFO, "%s - %d", __FUNCTION__, __LINE__);
}

void PiccLightClose(void)
{
    write(gl_fd_blueLED, "0", 1);
    write(gl_fd_yellowLED, "0", 1);
    write(gl_fd_greenLED, "0", 1);
    write(gl_fd_redLED, "0", 1);
    write(gl_fd_logoLED, "0", 1);

    close(gl_fd_blueLED);
    close(gl_fd_yellowLED);
    close(gl_fd_greenLED);
    close(gl_fd_redLED);
    close(gl_fd_logoLED);
    OsLog(LOG_INFO, "%s - %d", __FUNCTION__, __LINE__);
}

//added by kevinliu 20160719
//if call this function without setPrefixResPath, it will return incoming string.
const char *AddPrefixResPath(const char *pcucPerfixSer, const char *pcucStr)
{
    int addedPathLen=0;
    char *p=NULL;
    static char addedPath[48]={0};

    if (pcucPerfixSer == NULL || pcucStr == NULL)
    {
        return NULL;
    }
    addedPathLen = strlen(pcucPerfixSer) + strlen(pcucStr);
    if (addedPathLen >= 48)
    {
        return NULL;
    }
    memset(addedPath, 0, sizeof(addedPath));
    memcpy(addedPath, pcucPerfixSer, strlen(pcucPerfixSer));
    memcpy(addedPath + strlen(pcucPerfixSer), pcucStr, strlen(pcucStr));
    p = addedPath;

    return p;
}


static void PiccLight(uchar ucLedIndex,uchar ucOnOff)
{
    int i=0;
    unsigned int iPicXPercent[4]={0};
    int iImageWidth=0, iImageHeight=0, iGapLen=0;
    unsigned char *pucPrefix=NULL;
    unsigned char *pucPrefix1="./res/240x320/";
    unsigned char *pucPrefix2="./res/320x240/";

    //added by Kevinliu 20160719, just for EMP
    if(Gui_GetScrHeight() > Gui_GetScrWidth())
    	pucPrefix = pucPrefix1;
	else
		pucPrefix = pucPrefix2;

    Gui_GetImageSize(AddPrefixResPath(pucPrefix, "BlueOff.png"), &iImageWidth, &iImageHeight);
    for (i = 0; i < 4; i++)
    {
        iGapLen = (Gui_GetScrWidth() - 4 * iImageWidth) / 5;
        iPicXPercent[i] = (iGapLen * (i + 1) + iImageWidth * i) * 100 / Gui_GetScrWidth();
    }

    //leds control
    if ((ucLedIndex & PICC_LED_BLUE) && (ucOnOff == 1)) {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "BlueOn.png"), iPicXPercent[0], 2);
        if (gl_fd_blueLED > 0) {
            write(gl_fd_blueLED, "1", 1);
        }
    }
    else {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "BlueOff.png"), iPicXPercent[0], 2);
        if (gl_fd_blueLED > 0) {
            write(gl_fd_blueLED, "0", 1);
        }
    }


    if ((ucLedIndex & PICC_LED_YELLOW) && (ucOnOff == 1)) {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "YellowOn.png"), iPicXPercent[1], 2);
        if (gl_fd_yellowLED > 0) {
            write(gl_fd_yellowLED, "1", 1);
        }
    }
    else {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "YellowOff.png"), iPicXPercent[1], 2);
        if (gl_fd_yellowLED > 0) {
            write(gl_fd_yellowLED, "0", 1);
        }
    }

    if ((ucLedIndex & PICC_LED_GREEN) && (ucOnOff == 1)){
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "GreenOn.png"), iPicXPercent[2], 2);
        if (gl_fd_greenLED > 0) {
            write(gl_fd_greenLED, "1", 1);
        }
    }
    else {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "GreenOff.png"), iPicXPercent[2], 2);
        if (gl_fd_greenLED > 0) {
            write(gl_fd_greenLED, "0", 1);
        }
    }

    if ((ucLedIndex & PICC_LED_RED) && (ucOnOff == 1)) {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "RedOn.png"), iPicXPercent[3], 2);
        if (gl_fd_redLED > 0) {
            write(gl_fd_redLED, "1", 1);
        }
    }
    else {
        Gui_DrawImage(AddPrefixResPath(pucPrefix, "RedOff.png"), iPicXPercent[3], 2);
        if (gl_fd_redLED > 0) {
            write(gl_fd_redLED, "0", 1);
        }
    }

    if (ucLedIndex & PICC_LED_CLSS) {
        if (gl_fd_logoLED > 0) {
            if (ucOnOff == 1) {
                write(gl_fd_logoLED, "1", 1);
            }
            else {
                write(gl_fd_logoLED, "0", 1);
            }
        }
    }
}

//set callback function from GUI, when GUI is geting keys, when call this function after register.
int ClssVirtualLight(gui_callbacktype_t type, void *data, int *dataLen)
{
	CLSSLIGHTSTATUS curStatus=0;

	OsLog(LOG_INFO, "%s - %d", __FUNCTION__, __LINE__);

	curStatus = GetClssLightStatus();
	//if status has not change, return without doing anything.
	if(prevStatus == curStatus)
	{
		return GUI_OK;
	}
	OsLog(LOG_INFO, "%s - %d", __FUNCTION__, __LINE__);
	switch (GetClssLightStatus())
	{
		case CLSSLIGHTSTATUS_NOTREADY:
			PiccLight(PICC_LED_ALL, 0);
			break;
		case CLSSLIGHTSTATUS_IDLE:
			PiccLight(PICC_LED_BLUE | PICC_LED_CLSS, 1);
			break;
		case CLSSLIGHTSTATUS_READYFORTXN:
			PiccLight(PICC_LED_BLUE | PICC_LED_CLSS, 1);
			break;
		case CLSSLIGHTSTATUS_PROCESSING:
			PiccLight(PICC_LED_BLUE | PICC_LED_YELLOW | PICC_LED_CLSS, 1);
			break;
		case CLSSLIGHTSTATUS_READCARDDONE:
		case CLSSLIGHTSTATUS_REMOVECARD:
		case CLSSLIGHTSTATUS_DIALING:
		case CLSSLIGHTSTATUS_SENDING:
		case CLSSLIGHTSTATUS_RECEIVING1:
		case CLSSLIGHTSTATUS_RECEIVING2:
		case CLSSLIGHTSTATUS_PRINTING:
			PiccLight(PICC_LED_BLUE | PICC_LED_YELLOW | PICC_LED_GREEN | PICC_LED_CLSS, 1);
			break;
		case CLSSLIGHTSTATUS_COMPLETE:
			PiccLight(PICC_LED_BLUE | PICC_LED_YELLOW | PICC_LED_GREEN | PICC_LED_CLSS, 1);
			break;
		case CLSSLIGHTSTATUS_ERROR:
			PiccLight(PICC_LED_RED | PICC_LED_CLSS, 1);
			break;
		default:
			break;
	}

	prevStatus = curStatus;
	return GUI_OK;
}
//******************************************************************************************************
// Modified by Kim_LinHB 2014-6-8 v1.01.0000
//modified by kevinliu 2015/11/27

// Modified by Kim_LinHB 2014-6-8 v1.01.0000
int TransClssSale(void)
{
	int	 iRet = 0, iTime,  iLen = 0, i = 0;
	uchar ucKey, ucTemp[100] = {0}, ucTranAct = 0, ucKernType = 0, ucAcType = 0, ucMSDPath = 0;
	uchar szBuff[40]={0}, szTmpName[40]={0};
	unsigned short tag;
	EMV_CAPK ptCAPKey;
	uchar ucTransMode;
	uchar ucPathType = 0;
	uchar ucTempPAN[24]={0};

	//PICC_PARA PiccPara;
	Clss_TransParam ClssTransParam;///absent??
	Clss_PreProcInterInfo ClssProcInterInfo;///absent??

	iRet = TransInit(SALE);
	clssSale = TRUE ;
	if( iRet!=0 )
	{
		return iRet;
	}

	Gui_ClearScr();
	//init
	ClssTransInit();
	vAppInitSchemeId();

	//amt
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}
	//TODO
	memset(glCAPKeyList, 0, sizeof(glCAPKeyList));
	//read all CAPK, save into memory added by Kevin
	for(i=0; i<glSysParam.uiCapkNum; i++)
	{
		iRet = ReadCAPKFile(i, &glCAPKeyList[i]);
	}

	//pre-process
	memset(&ClssTransParam, 0, sizeof(Clss_TransParam));
	ClssTransParam.ulAmntAuth = atol((char *)glProcInfo.stTranLog.szAmount);
	ClssTransParam.ulAmntOther = 0;
	ClssTransParam.ucTransType = 0x00;//EMV_GOODS;
	PubAsc2Bcd(glProcInfo.stTranLog.szDateTime+2, 6, ClssTransParam.aucTransDate);
	PubAsc2Bcd(glProcInfo.stTranLog.szDateTime+8, 6, ClssTransParam.aucTransTime);
	ClssTransParam.ulTransNo = glProcInfo.stTranLog.ulSTAN;

	iRet = Clss_PreTransProc_Entry(&ClssTransParam);
	if(iRet != EMV_OK)
	{
		if (iRet == CLSS_USE_CONTACT)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "PLS USE CONTACT", gl_stCenterAttr, GUI_BUTTON_OK, 30, NULL);
		}
		return iRet;
	}

	memset(ucTemp, 0, sizeof(ucTemp));
	PubConvAmount(glSysParam.stEdcInfo.stLocalCurrency.szName, glProcInfo.stTranLog.szAmount,
				glProcInfo.stTranLog.stTranCurrency.ucDecimal,
				glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit,
				ucTemp, 0);

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, ucTemp, gl_stCenterAttr, GUI_BUTTON_NONE, 0 ,NULL);

DETECTCARD:
	//tap card
	while(1)
	{
		iRet = PiccOpen();
		if(iRet != 0)
		{
			PiccClose();
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "OPEN PICC ERR", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30,NULL);
			return iRet;
		}

//		//Leen
// 		iRet = ClssProcFlow_ALL();
//			if (iRet)
//			{
//			 OsLog(LOG_INFO, "%s - %d ClssProcFlow_ALL ret = %d", __FUNCTION__, __LINE__, iRet);
//					if (iRet == App_Try_Again)
//					{
//						DelayMs(1200);
//						continue;
//					}
//					ProcError_Picc(iRet);
//					PiccClose();
//					return ERR_TRAN_FAIL;
//			}



		TimerSet(3,500);
		kbflush();
		while(1)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "PLS TAP CARD", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

			iTime = TimerCheck(3);
			if(!iTime)
			{
				PiccClose();
				return ERR_USERCANCEL;
			}

			if(kbhit() != NOKEY)
			{
				ucKey = getkey();
				if(ucKey == KEYCANCEL)
				{
					PiccClose();
					return ERR_USERCANCEL;
				}
			}

			iRet = PiccDetect(0, NULL, NULL, NULL, NULL);
			if(iRet == 0) break;
			if(iRet == 1 || iRet==2)
			{
				dddoHentFMessage(5);
				PiccClose();
				return ERR_TRAN_FAIL;
			}
			if(iRet == 3|| iRet==5 || iRet==6)
			{
				DelayMs(100);
				continue;
			}
			if(iRet == 4)
			{
				PiccClose();
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "TOO MANY CARD", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30,NULL);

				return ERR_TRAN_FAIL;
			}
			//uchar CardType[100], SerialInfo[30], CID[30], Other[100];
			//iRet = PiccDetect(1, CardType, SerialInfo, CID, Other);
		}
		break;
	}

	kbflush();
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "PLS WAIT...", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

	glProcInfo.stTranLog.uiEntryMode = MODE_CONTACTLESS;
	Clss_SetMCVersion_Entry(3);// add for paypass 3.0 [12/29/2014 jiangjy]
	//app select
	iRet = Clss_AppSlt_Entry(0,0);
	if (iRet)
	{
		vAppCreateOutcomeData_MC(iRet);
	}
	if(iRet == EMV_NO_APP || iRet == ICC_BLOCK || iRet == EMV_APP_BLOCK)
	{
		PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
		return(disp_clss_err(iRet));
	}
	if(iRet != EMV_OK)
	{dddoHentFMessage(7);
		PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
		return ERR_TRAN_FAIL;
	}

	while(1)
	{
		vAppInitPaymentData_MC();
		//final select
		ucKernType = 0;
		iLen = 0;
		memset(ucTemp, 0, sizeof(ucTemp));
		iRet = Clss_FinalSelect_Entry(&ucKernType, ucTemp, &iLen);
		if(iRet == EMV_NO_APP || iRet == CLSS_USE_CONTACT)
		{
			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
			return(disp_clss_err(iRet));
		}
		if(iRet != EMV_OK)
		{dddoHentFMessage(8);
			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
			return ERR_TRAN_FAIL;
		}

		if(ucKernType != KERNTYPE_VIS && ucKernType != KERNTYPE_MC)
		{dddoHentFMessage(9);
			PiccClose();
			return ERR_TRAN_FAIL;
		}

		if(ucKernType == KERNTYPE_MC)
		{
			uchar tmp[3];
			memset(tmp,0,sizeof(tmp));
			memcpy(tmp,"\x9C\x01",2);
			memcpy(&tmp[2],&ClssTransParam.ucTransType,1);
			Clss_SetTLVDataList_MC(tmp,3);
		}

		if (ucKernType == KERNTYPE_VIS)
		{
			Clss_SetTLVData_Wave(0x9c, &ClssTransParam.ucTransType, 1);
		}

		sFinalAidLen = iLen;
		memcpy(sFinalAid, ucTemp, iLen);
		sgClssData.ucCardType = ucKernType;

		//get pre-process data
		memset(&ClssProcInterInfo, 0, sizeof(Clss_PreProcInterInfo));
		iRet = Clss_GetPreProcInterFlg_Entry(&ClssProcInterInfo);
		if(iRet == CLSS_USE_CONTACT)
		{
			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
			return(disp_clss_err(iRet));
		}
		if(iRet != EMV_OK)
		{dddoHentFMessage(10);
			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
			return ERR_TRAN_FAIL;
		}

		//get final-setect data
		iLen = 0;
		memset(ucTemp, 0, sizeof(ucTemp));
		iRet = Clss_GetFinalSelectData_Entry(ucTemp, &iLen);
		if(iRet != EMV_OK)
		{dddoHentFMessage(11);
			PiccClose();// modify v1.00.0018  [2/10/2015 jiangjy]
			return ERR_TRAN_FAIL;
		}
		iRet = nAppSetCurAppType(ucKernType);//CoreInit  //kernel type// scheme id

		if(ucAppGetAppType() == KERNTYPE_VIS)
		{
#ifdef CLSS_DEBUG
Clss_SetDebug_Wave(1);
#endif
			vSetFinalSelectAID(ucTemp+1, ucTemp[0]);
			iRet = Clss_SetFinalSelectData_Wave(ucTemp, iLen);
			if(iRet != EMV_OK)
			{dddoHentFMessage(12);
				PiccClose();
				return ERR_TRAN_FAIL;
			}

			//added by Gillian Chen 2015/9/25
			iRet = Clss_SetTLVData_Wave(0x9F5A, "123", 10);
			if(gl_ucDRLSupportFlg == 1)
			{
				if (Clss_GetTLVData_Wave(0x9F5A, aucProID, &nProIDLen) == EMV_OK)
				{
					if (!nAppFindMatchProID(aucProID, nProIDLen))
					{
						if(Clss_SetDRLParam_Wave(ptProgInfo) != EMV_OK)
						{dddoHentFMessage(13);
							OsLog(LOG_INFO, "%s - %s - %d", __FILE__, __FUNCTION__, __LINE__);
							PiccClose();
							return ERR_TRAN_FAIL;
						}
					}
					else
					{dddoHentFMessage(14);
						OsLog(LOG_INFO, "%s - %s - %d", __FILE__, __FUNCTION__, __LINE__);
						PiccClose();
						return ERR_TRAN_FAIL;
					}
				}
				else
				{
					dddoHentFMessage(15);
					OsLog(LOG_INFO, "%s - %s - %d", __FILE__, __FUNCTION__, __LINE__);
					PiccClose();
					return ERR_TRAN_FAIL;
				}
			}
			iRet = Clss_SetTransData_Wave(&ClssTransParam, &ClssProcInterInfo);
			if(iRet != EMV_OK)
			{
				dddoHentFMessage(16);
				PiccClose();
				return ERR_TRAN_FAIL;
			}

			ucAcType= 0;
			memset(ucTemp, 0, sizeof(ucTemp));
			iRet = Clss_Proctrans_Wave(ucTemp, &ucAcType);
			sgClssData.ucSchemeId = ucTemp[0];
			ucPathType = ucTemp[0];
			if (iRet == CLSS_RESELECT_APP) // GPO
			{
				iRet = Clss_DelCurCandApp_Entry();
				if (iRet)
				{dddoHentFMessage(17);
					disp_clss_err(iRet);//not sure
					PiccClose();
					return ERR_TRAN_FAIL;
				}
				continue;
			}
			//see phone
			else if (ucKernType == KERNTYPE_VIS && iRet == CLSS_REFER_CONSUMER_DEVICE &&
				((ClssProcInterInfo.aucReaderTTQ[0] & 0x20) == 0x20))
			{

//				Inter_DisplayMsg(Msg_SEE_PHONE);		//modified by kevinliu 2015/10/19
				Inter_DisplayMsg(MSG_SEE_PHONE);
				iRet= App_Try_Again;
				vAppDisplayMsgByRet(iRet);
				PiccClose();
				DelayMs(1200);
				goto DETECTCARD;
			}
			else
			{
				vAppSetTransPath(ucPathType);
				break;
			}

		}


		if (ucAppGetAppType() == KERNTYPE_MC)
		{
#ifdef CLSS_DEBUG
Clss_SetDebug_MC(1);
#endif
            vSetFinalSelectAID(ucTemp+1, ucTemp[0]);
			SetClssTxnParam(&ClssTransParam);
			SetTermParam_MC();
			iRet = Clss_SetFinalSelectData_MC(ucTemp, iLen);
			// 返回值的判断，If the return code is not EMV_OK, Application should get DF8129). [12/29/2014 jiangjy]
			if(iRet == CLSS_RESELECT_APP)
			{
				iRet = Clss_DelCurCandApp_Entry();
				if (iRet != 0)
				{
					vInitPaymentData();
					gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;
					gl_aucUserInterReqData[1]=MI_NOT_READY;
					memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

					gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
					gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
					gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
					gl_DiscretionayData.ucErrIndicFlg = 1;
					//					nSendTransDataOutput_MC(T_UIRD | T_OCPS | T_DISD);//S51.11 S51.12
					break;
				}
				continue;
			}
			else if(iRet)
			{dddoHentFMessage(18);
				disp_clss_err(iRet);
				PiccClose();
				return ERR_TRAN_FAIL;
			}
			iRet = Clss_InitiateApp_MC();
			//返回值的判断 返回值的判断，If the return code is not EMV_OK, Application should get DF8129)
			if (iRet == CLSS_RESELECT_APP) // GPO
			{
				iRet = Clss_DelCurCandApp_Entry();
				if (iRet)
				{
					vInitPaymentData();// paypass 3.0.1 by zhoujie
					gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;//S51.11 for paypass 3.0.1 by zhoujie
					gl_aucUserInterReqData[1]=MI_NOT_READY;
					memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

					gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
					gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
					gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
					gl_DiscretionayData.ucErrIndicFlg = 1;
					//					nSendTransDataOutput_MC(T_UIRD | T_OCPS | T_DISD);//S51.11 S51.12
					break;
				}
				continue;
			}
			else if(iRet)
			{
				break;
			}
			ucPathType = 0;
			iRet = Clss_ReadData_MC(&ucPathType);
			//返回值的判断，If the return code is not EMV_OK, Application should get DF8129)
			if(iRet == CLSS_RESELECT_APP)
			{
				iRet = Clss_DelCurCandApp_Entry();
				if (iRet)
				{
					vInitPaymentData();
					gl_aucUserInterReqData[0]=MI_ERROR_OTHER_CARD;
					gl_aucUserInterReqData[1]=MI_NOT_READY;
					memcpy(gl_aucUserInterReqData+2, MSG_HOLD_TIME_VALUE, 3);

					gl_aucErrIndication[5]=MI_ERROR_OTHER_CARD;
					gl_aucErrIndication[1] = L2_EMPTY_CANDIDATE_LIST;//S51.11
					gl_aucOutcomeParamSet[0] = OC_END_APPLICATION;
					gl_DiscretionayData.ucErrIndicFlg = 1;

					break;
				}
				continue;
			}
			else
			{
				vAppSetTransPath(ucPathType);
				break;
			}
		}
	}//end of while(2)

	if (iRet)
	{
		if (iRet == ICC_CMD_ERR)
		{
			uchar ucRet;
			ucRet = ucDetOtherCancelCmd();//add for check whether this should be a MSR trans  ???
			if (ucRet)
			{
				if (ucRet == CLSS_USE_CONTACT)
				{
					return 0;//Compatible EDC
				}
				return ucRet;
			}
		}

		if (iRet == CLSS_USE_CONTACT)//Paywave GPO return -23,exit   QVSDC53
		{
//			Inter_DisplayMsg(Msg_TRY_ANOTHER_INTERFACE);		//modified by kevinliu 2015/10/19
			Inter_DisplayMsg(MSG_TRY_ANOTHER_INTERFACE);

			return EMV_OK;
		}
		dddoHentFMessage(19);
		ProcError_Picc(iRet);
		return ERR_TRAN_FAIL;
	}
	//WAVE
	if (ucAppGetAppType() == KERNTYPE_VIS)
	{
		//return(Clss_transmit(iFlag));
		iRet = nAppTransProc_VISA(ucPathType, ucAcType);
	}
	//MC
	if (ucAppGetAppType() == KERNTYPE_MC)
	{
		iRet = nAppTransProc_MC(ucPathType, &ucAcType);

		if (gl_aucUserInterReqData[0] == MI_SEE_PHONE)
		{
//			Inter_DisplayMsg(Msg_SEE_PHONE);		//modified by kevinliu 2015/10/19
			Inter_DisplayMsg(MSG_SEE_PHONE);
		}
		if (gl_aucOutcomeParamSet[0] == OC_TRY_AGAIN || gl_aucOutcomeParamSet[1] != OC_NA)
		{
			iRet = App_Try_Again;
		}
	}

	//AC TYPE
	if (iRet == 0 && ucAppGetTransACType() == AC_AAC)
	{
		iRet = EMV_DENIAL;
	}
	//***********************outcome process*****************************//
	iRet = AppConv_CreateOutCome(iRet, ucAcType, &stOutComeData);
	if (iRet)
	{
		//除Declined之外的错误码
		vAppDisplayMsgByRet(iRet);
		PiccClose();
		DelayMs(1200);
	}
	if (iRet == App_Try_Again)
	{
		goto DETECTCARD;
	}

	//get track data
	memset(glProcInfo.szTrack1, 0, sizeof(glProcInfo.szTrack1));
	memset(glProcInfo.szTrack2, 0, sizeof(glProcInfo.szTrack2));
	//process data
	if(ucKernType == KERNTYPE_VIS)
	{
		//get MSD and Wave2 track 1 data(ASCII)
		Clss_nGetTrack1MapData_Wave (glProcInfo.szTrack1, &iLen);

		if(ucPathType == CLSS_VISA_MSD)
		{
			Clss_GetMSDType_Wave(&ucMSDPath);
			//get MSD track 2 data
			Clss_nGetTrack2MapData_Wave (glProcInfo.szTrack2, &iLen);
		}
		//chip or MSD without trk2map data
		if(strlen((char *)glProcInfo.szTrack2) == 0)
		{
			//get track 2 data from ICC
			iLen = 0;
			memset(ucTemp, 0, sizeof(ucTemp));
			iRet = Clss_GetTLVData(0x57, ucTemp, &iLen, ucKernType);
			if(iRet == EMV_OK)
			{
				memset(glProcInfo.szTrack2, 0, sizeof(glProcInfo.szTrack2));
				PubBcd2Asc0(ucTemp, iLen, glProcInfo.szTrack2);
				iLen = iLen*2;
				glProcInfo.szTrack2[iLen] = '\0';
			}
		}
	}
	else if(ucKernType == KERNTYPE_MC)
	{
		iLen = 0;
		memset(ucTemp, 0, sizeof(ucTemp));
		//get track 1 data only for paypass
		iRet = Clss_GetTLVData(0x56 , glProcInfo.szTrack1, &iLen, ucKernType);

		//get track 2 data for paypass
		iLen = 0;
		memset(ucTemp, 0, sizeof(ucTemp));
		if (ucPathType == CLSS_MC_MAG)
		{
			iRet = Clss_GetTLVData(0x9F6B, ucTemp, &iLen, ucKernType);
		}
		else if (ucPathType == CLSS_MC_MCHIP)
		{
			iRet = Clss_GetTLVData(0x57, ucTemp, &iLen, ucKernType);
		}
		if(iRet == EMV_OK)
		{
			memset(glProcInfo.szTrack2, 0, sizeof(glProcInfo.szTrack2));
			PubBcd2Asc0(ucTemp, iLen, glProcInfo.szTrack2);
			iLen = iLen*2;
			glProcInfo.szTrack2[iLen] = '\0';
		}
	}

	for(i=0;i<iLen;i++)
	{
		if(glProcInfo.szTrack2[i] == 'D')
		{
			glProcInfo.szTrack2[i] = '=';
			break;
		}
	}

	OsLog(LOG_INFO, "glProcInfo.szTrack1 = %s", glProcInfo.szTrack1);
	OsLog(LOG_INFO, "glProcInfo.szTrack2 = %s", glProcInfo.szTrack2);

	// get PAN from track 2 (PAN)
	iRet = GetPanFromTrack2(glProcInfo.stTranLog.szPan, glProcInfo.stTranLog.szExpDate, iLen);
	if( iRet!=0 )
	{
		DispMagReadErr();
		return ERR_NO_DISP;
	}

	OsLog(LOG_INFO, "glProcInfo.stTranLog.szPan = %s", glProcInfo.stTranLog.szPan);
	OsLog(LOG_INFO, "glProcInfo.stTranLog.szExpDate = %s", glProcInfo.stTranLog.szExpDate);

	//get issuer and acquirer from PAN
	iRet = MatchCardTable(glProcInfo.stTranLog.szPan);
	if( iRet!=0 )
	{
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED\nCARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 2, NULL);
		return ERR_NO_DISP;
	}

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	//Application Primary Account Number (PAN) Sequence Number
	iRet = Clss_GetTLVData(0x5f34, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		glProcInfo.stTranLog.ucPanSeqNo = ucTemp[0];
		glProcInfo.stTranLog.bPanSeqOK = TRUE;
	}

	OsLog(LOG_INFO, "glProcInfo.stTranLog.ucPanSeqNo = %d", glProcInfo.stTranLog.ucPanSeqNo);

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x50, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.szAppLabel, ucTemp, iLen);
		glProcInfo.stTranLog.szAppLabel[iLen]= '\0';
	}

	OsLog(LOG_INFO, "glProcInfo.stTranLog.szAppLabel = %s", glProcInfo.stTranLog.szAppLabel);

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x5f24, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		PubBcd2Asc(ucTemp, 2, glProcInfo.stTranLog.szExpDate);
		glProcInfo.stTranLog.szExpDate[4]= '\0';
	}

	OsLog(LOG_INFO, "glProcInfo.stTranLog.szExpDate = %s", glProcInfo.stTranLog.szExpDate);

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x95, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.sTVR, ucTemp, iLen);
	}

	for(i=0;i<iLen;i++)
	{
		OsLog(LOG_INFO, "glProcInfo.stTranLog.sTVR = %02x", glProcInfo.stTranLog.sTVR[i]);
	}

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x9b, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.sTSI,ucTemp,iLen);
	}

	for(i=0;i<iLen;i++)
	{
		OsLog(LOG_INFO, "glProcInfo.stTranLog.sTSI = %02x", glProcInfo.stTranLog.sTSI[i]);
	}

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x9f36, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.sATC,ucTemp,iLen);
	}

	for(i=0;i<iLen;i++)
	{
		OsLog(LOG_INFO, "glProcInfo.stTranLog.sATC = %02x", glProcInfo.stTranLog.sATC[i]);
	}
	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x9f26, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.sAppCrypto,ucTemp,iLen);  //szAppPreferName
	}

	iLen = 0;
	memset(ucTemp, 0, sizeof(ucTemp));
	iRet = Clss_GetTLVData(0x9f26, ucTemp, &iLen, ucKernType);
	if(iRet == EMV_OK)
	{
		memcpy(glProcInfo.stTranLog.szAppPreferName,ucTemp,iLen);
	}

//continue transaction according to AC type
	if(stOutComeData.ucTransRet == CLSS_ONLINE_REQUEST)
	{
//do CVM from CVM get result
		if(stOutComeData.ucCVMType == RD_CVM_ONLINE_PIN)
		{
			iRet = GetPIN(FALSE);
			if( iRet!=0 )
			{
				return iRet;
			}
		}
		memset(sAuthData, 0, sizeof(sAuthData));
		memset(sIssuerScript, 0, sizeof(sIssuerScript));
		sgAuthDataLen = 0;
		sgScriptLen = 0;

		iRet = Clss_transmit(ucKernType);
		if(iRet != EMV_OK)
		{
			dddoHentFMessage(20);
			return ERR_TRAN_FAIL;
		}
		//TODO second tap card
		Clss_secondTapCard();
	}
	else if(stOutComeData.ucTransRet == CLSS_APPROVE)
	{
		// save for upload
		iLen = 0;
		SetClSSDE55(TRUE, glProcInfo.stTranLog.sIccData, &iLen);
		glProcInfo.stTranLog.uiIccDataLen = (ushort)iLen;

		GetNewTraceNo();
		sprintf((char *)glProcInfo.stTranLog.szRspCode, "00");
		glProcInfo.stTranLog.ulInvoiceNo = glSysCtrl.ulInvoiceNo;
		sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%06lu", glSysCtrl.ulSTAN);

		SetOffBase(OffBaseDisplay);
		DispProcess();

		ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;

		if (ucTranAct & ACT_INC_TRACE)
		{
			GetNewTraceNo();
		}

		if( ucTranAct & WRT_RECORD )
		{
			glProcInfo.stTranLog.uiStatus |= TS_NOSEND;
			SaveTranLog(&glProcInfo.stTranLog);
		}

		if( ucTranAct & PRN_RECEIPT )	// print slip
		{
			CommOnHook(FALSE);
			GetNewInvoiceNo();
			PrintReceipt(PRN_NORMAL);
		}
		DispResult(0);
	}
	else
	{
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("Transaction\nDecline"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 2, NULL);
		iRet = ERR_TRAN_FAIL;
	}
	PiccClose();
	return iRet;
}

int Clss_secondTapCard()
{
	int iRet = 0, i = 0;
	unsigned char ucKernelType = 0, aucRspCode[3] = {0}, ucOnlineResult = 0;
	unsigned char aucAuthCode[7] = {0};

	if((sgAuthDataLen == 0) || (sgScriptLen == 0))
	{
		return EMV_OK;
	}

	ucKernelType = ucAppGetAppType();
	ucOnlineResult = glProcInfo.ucOnlineStatus;
	memcpy(aucRspCode, glProcInfo.stTranLog.szRspCode, 2);
	memcpy(aucAuthCode, glProcInfo.stTranLog.szAuthCode, 6);
	SetClssLightStatus(CLSSLIGHTSTATUS_READYFORTXN);

//	OsLog(LOG_INFO, "---second tap card---");
//	OsLog(LOG_INFO, "ucOnlineResult = %d", ucOnlineResult);
//
//	for(i=0;i<sizeof(aucRspCode);i++)
//	{
//		OsLog(LOG_INFO, "aucRspCode[%d] = %02x", i, aucRspCode[i]);
//	}
//	for(i=0;i<sizeof(aucAuthCode);i++)
//	{
//		OsLog(LOG_INFO, "aucAuthCode[%d] = %02x", i, aucAuthCode[i]);
//	}
//	for(i=0;i<sgAuthDataLen;i++)
//	{
//		OsLog(LOG_INFO, "sAuthData[%d] = %02x", i, sAuthData[i]);
//	}
//	for(i=0;i<sgScriptLen;i++);
//	{
//		OsLog(LOG_INFO, "sIssuerScript[%d] = %02x", i, sIssuerScript[i]);
//	}

	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("SECOND TAP CARD"), gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

	iRet = ClssDetectTapCard();
	if(iRet)
	{
		return iRet;
	}

	SetClssLightStatus(CLSSLIGHTSTATUS_PROCESSING);
	DispProcess();

	//OsLog(LOG_INFO, "%s--%d Second tap card KernelType = %d", __FUNCTION__, __LINE__, ucKernelType);

	SetClssLightStatus(CLSSLIGHTSTATUS_REMOVECARD);



	if (ucKernelType == KERNTYPE_VIS)
	{
		iRet = ClssCompleteTrans_WAVE(ucOnlineResult, aucRspCode, aucAuthCode, sAuthData, sgAuthDataLen, sIssuerScript, sgScriptLen);
		//iRet = nAppSecondTap_Wave(ucOnlineResult, aucRspCode, aucAuthCode, sAuthData, sgAuthDataLen, sIssuerScript, sgScriptLen);
	}

	if (iRet)
	{	Inter_DisplayMsg(MSG_DECLINED);
		return iRet;
	}
	Inter_DisplayMsg(MSG_APPROVED);
	return EMV_OK;
}

int ClssCompleteTrans_WAVE(uchar ucInOnlineResult, uchar aucRspCode[], uchar aucAuthCode[], uchar aucIAuthData[], int nIAuthDataLen,  uchar aucScript[], int nScriptLen)
{
	uchar aucBuff[256] = {0};
	uchar aucCTQ[32] = {0};
	int iCTQLen = 0, iLen = 0, iRet = 0;
	uchar ucKernType = 0;

	if (nIAuthDataLen == 0 && nScriptLen == 0)
	{
		return EMV_NO_DATA;
	}

	if (ucInOnlineResult != 0x00)
		return -1;

	memset(aucCTQ, 0, sizeof(aucCTQ));
	if ((glClss_PreProcInfoIn.aucReaderTTQ[2] & 0x80) == 0x80
		&& Clss_GetTLVData_Wave(0x9F6C, aucCTQ, &iCTQLen) == 0
		&& (aucCTQ[1] & 0x40) == 0x40)
	{
        memset(aucBuff, 0, sizeof(aucBuff));
        iRet = Clss_FinalSelect_Entry(&ucKernType, aucBuff, &iLen);
        if (iRet != 0)
        {
//				continue;
            appRemovePicc();
            return iRet;
        }

        if (ucKernType != KERNTYPE_VIS)
        {
            appRemovePicc();
            return -1;
        }

        iRet = Clss_IssuerAuth_Wave(aucIAuthData, nIAuthDataLen);
        if(iRet)
        {
            appRemovePicc();
            return iRet;
        }
        iRet = Clss_IssScriptProc_Wave(aucScript, nScriptLen);
        if(iRet)
        {
            appRemovePicc();
            return iRet;
        }
        appRemovePicc();
	}
	return EMV_OK;
}


int nAppSecondTap_Wave(uchar ucInOnlineResult, uchar aucRspCode[], uchar aucAuthCode[], uchar aucIAuthData[], int nIAuthDataLen,  uchar aucScript[], int nScriptLen)
{
	uchar aucBuff[256];
	uchar aucCTQ[32];
	int iCTQLen = 0, iLen=0, iRet=0, iTime=0;
	uchar ucKernType=0, ucKey=0;

	if (nIAuthDataLen == 0 && nScriptLen == 0)
	{
		return EMV_NO_DATA;
	}

	if (ucInOnlineResult != 0x00)
		return -1;

	memset(aucCTQ, 0, sizeof(aucCTQ));
	if ((glClss_PreProcInfoIn.aucReaderTTQ[2] & 0x80) == 0x80
		&& Clss_GetTLVData_Wave(0x9F6C, aucCTQ, &iCTQLen) == 0
		&& (aucCTQ[1] & 0x40) == 0x40)
	{
		while (1)
		{
			while(1)
			{
				iRet = PiccOpen();
				if(iRet != 0)
				{
					PiccClose();
					Gui_ClearScr();
					Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "OPEN PICC ERR", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30,NULL);
					return iRet;
				}
				TimerSet(3,500);
				kbflush();
				while(1)
				{
					Gui_ClearScr();
					Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "PLS TAP CARD", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);

					iTime = TimerCheck(3);
					if(!iTime)
					{
						PiccClose();
						return ERR_USERCANCEL;
					}

					if(kbhit() != NOKEY)
					{
						ucKey = getkey();
						if(ucKey == KEYCANCEL)
						{
							PiccClose();
							return ERR_USERCANCEL;
						}
					}

					iRet = PiccDetect(0, NULL, NULL, NULL, NULL);
					if(iRet == 0) break;
					if(iRet == 1 || iRet==2)
					{
						dddoHentFMessage(21);
						PiccClose();
						return ERR_TRAN_FAIL;
					}
					if(iRet == 3|| iRet==5 || iRet==6)
					{
						DelayMs(100);
						continue;
					}
					if(iRet == 4)
					{
						PiccClose();
						Gui_ClearScr();
						Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "TOO MANY CARD", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30,NULL);

						return ERR_TRAN_FAIL;
					}
					//uchar CardType[100], SerialInfo[30], CID[30], Other[100];
					//iRet = PiccDetect(1, CardType, SerialInfo, CID, Other);
				}
				break;
			}

			memset(aucBuff, 0, sizeof(aucBuff));
			iRet = Clss_FinalSelect_Entry(&ucKernType, aucBuff, &iLen);
			if (iRet != 0)
			{
//				continue;
				appRemovePicc();
				return iRet;
			}

			if (ucKernType != KERNTYPE_VIS)
			{
				appRemovePicc();
				return -1;
			}

			iRet = Clss_IssuerAuth_Wave(aucIAuthData, nIAuthDataLen);
			if(iRet)
			{
				appRemovePicc();
				return iRet;
			}
			iRet = Clss_IssScriptProc_Wave(aucScript, nScriptLen);
			if(iRet)
			{
				appRemovePicc();
				return iRet;
			}

			appRemovePicc();
			break;
		}
	}
	return 0;
}

int ClssTransInit()
{
	int i, iRet;
	EMV_APPLIST EMV_APP;

	Clss_SetCBFun_SendTransDataOutput_MC(cClssSendTransDataOutput_MC);
	Clss_DelAllAidList_Entry();
	Clss_DelAllPreProcInfo();
	memset(glCAPKeyList, 0, sizeof(glCAPKeyList));
	//read all CAPK, save into memory added by kevinliu
	for(i=0; i<glSysParam.uiCapkNum; i++)
	{
		iRet = ReadCAPKFile(i, &glCAPKeyList[i]);
	}

	vAppInitSchemeId();

	for (i=0; i<glSysParam.uiAidNum; i++)
	{
		memset(&EMV_APP, 0, sizeof(EMV_APPLIST));
//modified by Kevin 20150608
#ifdef _PROLIN2_4_
		iRet = ReadAIDFile(i, &EMV_APP);
#else
		iRet = EMVGetApp(i, &EMV_APP);
#endif
//end modified by Kevin
		if(iRet != EMV_OK)
		{
			continue;
		}

		iRet = Clss_AddAidList_Entry(EMV_APP.AID, EMV_APP.AidLen, EMV_APP.SelFlag, KERNTYPE_DEF);
		if(iRet != EMV_OK) 
		{
			continue;
		}

		memset(&glClss_PreProcInfoIn, 0, sizeof(Clss_PreProcInfo));

//		glClss_PreProcInfoIn.ulTermFLmt = 50000;	//Terminal Offline limit
//		glClss_PreProcInfoIn.ulRdClssTxnLmt = 1000000;	//Reader contactless transaction limit
//		glClss_PreProcInfoIn.ulRdCVMLmt = 10000;	//Reader CVM limit
//		glClss_PreProcInfoIn.ulRdClssFLmt = 50000;	//Reader contactless Offline limit

		glClss_PreProcInfoIn.ulTermFLmt = 00000;	//Terminal Offline limit
		glClss_PreProcInfoIn.ulRdClssTxnLmt = 100001;	//Reader contactless transaction limit
		glClss_PreProcInfoIn.ulRdCVMLmt = 35000;	//Reader CVM limit 10000
		glClss_PreProcInfoIn.ulRdClssFLmt = 50000;	//Reader contactless Offline limit


		memcpy(glClss_PreProcInfoIn.aucAID, EMV_APP.AID, EMV_APP.AidLen);
		glClss_PreProcInfoIn.ucAidLen = EMV_APP.AidLen;

		glClss_PreProcInfoIn.ucKernType = KERNTYPE_DEF;

		glClss_PreProcInfoIn.ucCrypto17Flg = 1;
		glClss_PreProcInfoIn.ucZeroAmtNoAllowed = 0;
		glClss_PreProcInfoIn.ucStatusCheckFlg = 0;
		memcpy(glClss_PreProcInfoIn.aucReaderTTQ, "\x36\x00\x80\x00", 4);	//Terminal Transaction Qualifiers

		glClss_PreProcInfoIn.ucTermFLmtFlg = 1;
		glClss_PreProcInfoIn.ucRdClssTxnLmtFlg = 1;
		glClss_PreProcInfoIn.ucRdCVMLmtFlg = 1;
		glClss_PreProcInfoIn.ucRdClssFLmtFlg=1;
		Clss_SetPreProcInfo_Entry(&glClss_PreProcInfoIn);
	}
	
	ClssBaseParameterSet_wave();

//end modified by Kevin
	return 0;
}


void ClssBaseParameterSet_wave()
{
	Clss_ReaderParam ClssParam;
	Clss_VisaAidParam tVisaAidParam;

//设置读卡器应用相关参数
	Clss_GetReaderParam_Wave(&ClssParam);
	memcpy(ClssParam.aucTmCap,"\xE0\xe1\xC8",3);
	memcpy(ClssParam.aucTmCapAd,"\xe0\x00\xf0\xa0\x01",5);
	ClssParam.ucTmType = 0x22;
	memcpy(ClssParam.aucTmCntrCode, glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2);
	memcpy(ClssParam.aucTmRefCurCode, glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2);
	memcpy(ClssParam.aucTmTransCur, glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2);	
	Clss_SetReaderParam_Wave(&ClssParam);
// move [1/8/2015 jiangjy]
// //设置WAVE应用相关参数
// 	memset(&ClssVisaAidParam,0,sizeof(Clss_VisaAidParam));
// 	ClssVisaAidParam.ulTermFLmt = 0;
// 	Clss_SetVisaAidParam_Wave(&ClssVisaAidParam);

	//设置WAVE应用相关参数
	memset(&tVisaAidParam,0,sizeof(Clss_VisaAidParam));
	tVisaAidParam.ucCvmReqNum = 2;
	tVisaAidParam.aucCvmReq[0] = RD_CVM_REQ_SIG;
	tVisaAidParam.aucCvmReq[1] = RD_CVM_REQ_ONLINE_PIN;

	tVisaAidParam.ucDomesticOnly = 0x00; // 01(default):only supports domestic cl transaction
	tVisaAidParam.ucEnDDAVerNo = 0;// fDDA ver 00 & 01 are all supported
	tVisaAidParam.ulTermFLmt = 50000;
	Clss_SetVisaAidParam_Wave(&tVisaAidParam);

}

// Modified by Kim_LinHB 2014-6-8 v1.01.0000
/*int disp_clss_err(int err)
{
	Gui_ClearScr();
	if(err == EMV_NO_APP)
	{
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "NO SUPPORT APP\nNot Accepted", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
	}
	else if(err == CLSS_USE_CONTACT)
	{
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "PLS USE CONTACT\nFOR TRANSACTION", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
	}
	else if(err == ICC_BLOCK)
	{
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "CARD LOCKED", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
	}
	else if(err == EMV_APP_BLOCK)
	{
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "APP LOCKED", gl_stCenterAttr, GUI_BUTTON_CANCEL, 30, NULL);
	}
	return ERR_USERCANCEL;
}*/

int nSetDETData(uchar *pucTag, uchar ucTagLen, uchar *pucData, uchar ucDataLen)
{ 	int iRet = 0;
	uchar aucBuff[256] ="",ucBuffLen = 0;

	if (pucTag == NULL || pucData == NULL)
	{
		return CLSS_PARAM_ERR;
	}

	memset(aucBuff, 0, sizeof(aucBuff));
	memcpy(aucBuff, pucTag, ucTagLen);//Terminal Country Code
	ucBuffLen = ucTagLen;
	aucBuff[ucBuffLen++] = ucDataLen;
	memcpy(aucBuff+ucBuffLen, pucData, ucDataLen);
	ucBuffLen += ucDataLen;

	if(ucAppGetAppType() == KERNTYPE_MC)
	{
		iRet = Clss_SetTLVDataList_MC(aucBuff, ucBuffLen);
		OsLog(LOG_INFO, "Clss_SetTLVDataList_MC ret = %d", iRet);
	}
	return iRet;

}

int Clss_GetTLVData(unsigned int tag, uchar *data, int *datalen, uchar flag)
{
	int iRet = 0, iLen = 0;
	uchar ucTagList[3] = {0};
	uchar ucTagListLen = 0;
	uchar ucDataOut[100] = {0};
	uint uiActualDataOutLen = 0;


	if(flag == KERNTYPE_VIS)
	{
		iRet = Clss_GetTLVData_Wave(tag,data,&iLen);
	}

	else if(flag == KERNTYPE_MC)
	{
//modified by Kevin 20150605
		if(tag < 0xFF)
		{
			ucTagListLen = 1;
		}
		else if((tag > 0xFF) && (tag < 0xFFFF))
		{
			ucTagListLen = 2;
		}
		else
		{
			ucTagListLen = 3;
		}

		memset(ucTagList, 0 ,sizeof(ucTagList));
		PubLong2Char(tag, ucTagListLen, ucTagList);

		if(flag == KERNTYPE_MC) {
		iRet = Clss_GetTLVDataList_MC(ucTagList, ucTagListLen,
				sizeof(ucDataOut), ucDataOut, &uiActualDataOutLen);
		}

		if(RET_OK == iRet)
		{
			memcpy(data, ucDataOut, uiActualDataOutLen);
		}
		else
		{
			OsLog(LOG_ERROR, "getTLV fail,err=%d", iRet);
		}
		iLen = uiActualDataOutLen;
//end modified by Kevin
	}

	*datalen = iLen;

	return iRet;
}

int Clss_SetTLVData(unsigned int tag,uchar *data,int datalen,uchar flag)
{
	int iRet = 0 ;
	uchar ucTagList[3] = {0};
	uchar ucTagListLen = 0;

	if(flag == KERNTYPE_VIS)
	{
		iRet = Clss_SetTLVData_Wave(tag,data,datalen);
	}

	else if(flag == KERNTYPE_MC)
	{
		if(tag < 0xFF)
		{
			ucTagListLen = 1;
		}
		else if((tag > 0xFF) && (tag < 0xFFFF))
		{
			ucTagListLen = 2;
		}
		else
		{
			ucTagListLen = 3;
		}
		OsLog(LOG_INFO, "tag=%d", tag);

		memset(ucTagList, 0 ,sizeof(ucTagList));
		PubLong2Char(tag, ucTagListLen, ucTagList);

		iRet = nSetDETData(ucTagList, ucTagListLen,data, datalen);

	}
	return iRet;
}


int Clss_transmit(uchar kerId)
{
	int	iRet = 0, iRetryPIN = 0;
	int result,len =0;
	uchar tmp[100];
	ulong	ulICCDataLen = 0;
	uchar	*psICCData = NULL, *psTemp = NULL;
/*
	ASCToBCD(tmp,pos_com.log.AID,strlen(pos_com.log.AID));
	if(memcmp(tmp,"\xA0\x00\x00\x03\x33\x01\x01\x06",8) == 0)
	{
		Lcd_ScrClrLine(2,7);
		disp_Lcdinfo("纯电子钱包卡",3,LEFT,0,0,0);
		disp_Lcdinfo("无法联机",5,LEFT,0,0,1000);
		com232_sendbuf[0] = EC_ONLY;
		return NO_DISP;
	}
*/
//	result = Clss_GetTLVData(0x9f36,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
//		memcpy(glProcInfo.stTranLog.sATC,tmp,len);
//	}
//
//	result = Clss_GetTLVData(0x9f26,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
//		memcpy(glProcInfo.stTranLog.szAppPreferName,tmp,len);
//	}
//
//	result = Clss_GetTLVData(0x9b,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
//		memcpy(glProcInfo.stTranLog.sTSI,tmp,len);
//	}
//
//	result = Clss_GetTLVData(0x95,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
//		memcpy(glProcInfo.stTranLog.sTVR,tmp,len);
//	}
//
//	result = Clss_GetTLVData(0x50,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
//		memcpy(glProcInfo.stTranLog.szAppLabel,tmp,len);
//		glProcInfo.stTranLog.szAppLabel[len]=0;
//	}
//
//	result = Clss_GetTLVData(0x5f24,tmp,&len,kerId);
//	if(result == EMV_OK)
//	{
////		PubBcd2Asc(tmp, len, glProcInfo.stTranLog.szExpDate);
////		glProcInfo.stTranLog.szExpDate[4]=0;
//		memset(glProcInfo.stTranLog.szExpDate, 0x00, sizeof(glProcInfo.stTranLog.szExpDate));
//		PubBcd2Asc0(tmp, 2, glProcInfo.stTranLog.szExpDate);
//	}
	Clss_SetTLVData(0x9f27,"\x80",1,kerId);

	//处理交易返回
	SetCommReqField();	
	// prepare online DE55 data
	iRet = SetClSSDE55(FALSE, &glSendPack.sICCData[2], &len);
	if( iRet!=0 )
	{
		glProcInfo.ucOnlineStatus = ST_ONLINE_FAIL;
		return ONLINE_FAILED;
	}

	PubASSERT( len<LEN_ICC_DATA );
	PubLong2Char((ulong)len, 2, glSendPack.sICCData);
	memcpy(glProcInfo.stTranLog.sIccData, &glSendPack.sICCData[2], len);	// save for batch upload
	glProcInfo.stTranLog.uiIccDataLen = (ushort)len;
	
	// 判断上次交易是否需要进行冲正等
	iRet = TranReversal();
	if( iRet!=0 )
	{
		glProcInfo.ucOnlineStatus = ST_ONLINE_FAIL;
		return ONLINE_FAILED;
//		return iRet;
	}
	
	// Some banks may want TC to be sent prior to sale
	iRetryPIN = 0;
	while( 1 )
	{
		if (ChkIfAmex() || ChkCurAcqName("AMEX", FALSE))
		{
			GetNewInvoiceNo();
		}
		
		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			glProcInfo.ucOnlineStatus = ST_ONLINE_FAIL;
			break;
		}

		if( memcmp(glRecvPack.szRspCode, "55", 2)!=0 || ++iRetryPIN>3 || !ChkIfNeedPIN() )
		{
			break;
		}
		
		// 重新输入PIN
		iRet = GetPIN(GETPIN_RETRY);
		if( iRet!=0 )
		{
//			return ONLINE_DENIAL;
			return iRet;
		}
		sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN);
		memcpy(&glSendPack.sPINData[0], "\x00\x08", 2);
		memcpy(&glSendPack.sPINData[2], glProcInfo.sPinBlock, 8);
	}

	glProcInfo.ucOnlineStatus = ST_ONLINE_APPV;
	
	if( memcmp(glRecvPack.szRspCode, "00", LEN_RSP_CODE)!=0 )
	{dddoHentFMessage(22);
		return ERR_TRAN_FAIL;
	}
	
	ulICCDataLen = PubChar2Long(glRecvPack.sICCData, 2);
	psICCData = &glRecvPack.sICCData[2];
	if (ulICCDataLen != 0)
	{
		IssScrCon();
	}

	if( (glProcInfo.ucOnlineStatus == ST_ONLINE_APPV) && (memcmp(glProcInfo.stTranLog.szRspCode, "00", 2)==0) && (iRet == 0))
	{
		// update for reversal(maybe have script result)
		SetClSSDE55(FALSE, &glSendPack.sICCData[2], &len);
		PubLong2Char((ulong)len, 2, glSendPack.sICCData);
		glProcInfo.stTranLog.uiIccDataLen = (ushort)len;
		SaveRevInfo(TRUE);	// update reversal information
	}
	//get Issuer Authentication Data and Issuer script
	for(psTemp=psICCData; psTemp<psICCData+ulICCDataLen; )
	{
		iRet = GetTLVItem(&psTemp, psICCData+ulICCDataLen-psTemp, SaveRspICCData, FALSE);
	}
	
	// 交易失败处理
	if (iRet)
	{
		SaveRevInfo(FALSE);
		DispResult(iRet);
		return ERR_NO_DISP;
	}	
	if (memcmp(glProcInfo.stTranLog.szRspCode, "00", 2)!=0 )
	{
		SaveRevInfo(FALSE);
		DispResult(ERR_HOST_REJ);
		return ERR_NO_DISP;
	}
	
	if( ChkIfSaveLog() )
	{
		SaveTranLog(&glProcInfo.stTranLog);
	}
	if( ChkIfPrnReceipt() )
    {
        if( glProcInfo.stTranLog.ucTranType!=VOID )
        {
            GetNewInvoiceNo();
        }
	}
	SaveRevInfo(FALSE);
	
	
	if( glProcInfo.stTranLog.ucTranType!=RATE_BOC &&
        glProcInfo.stTranLog.ucTranType!=RATE_SCB &&
        glProcInfo.stTranLog.ucTranType!=LOAD_CARD_BIN )
    {
		if(ChkIfCiti())
		{
			OfflineSend(OFFSEND_TRAN);
		}
		else
		{
			OfflineSend(OFFSEND_TC | OFFSEND_TRAN);
		}
    }
	
	if(ChkIfPrnReceipt())
	{
		PrintReceipt(PRN_NORMAL);
	}
	DispResult(0);

	return 0;
}


int IssScrCon(void)
{
	uchar mode=0,outActype[256],key, *sScriptData;
	int time,len, iLen;
	int ret;
	//iss_scrstrc iss_scrs;
	APDU_SEND send_com;
	APDU_RESP recv_com;

	Gui_ClearScr();
	Gui_ShowMsgBox("SALE", gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

	while(1)
	{
		if(PiccOpen() != 0)
		{dddoHentFMessage(23);
			return ERR_TRAN_FAIL;
		}
// 		PiccSetup('R',&PiccPara);
// 		PiccPara.wait_retry_limit_w = 1;
// 		PiccPara.wait_retry_limit_val = 0;
// 		PiccPara.card_buffer_w = 1;
// 		PiccPara.card_buffer_val = 64;
// 		PiccSetup('W',&PiccPara);
		TimerSet(3,500);
		kbflush();
		while(1)
		{
			time = TimerCheck(3);
			if(!time)
			{dddoHentFMessage(24);
				PiccClose();
				return ERR_TRAN_FAIL;
			}
			if(kbhit() != NOKEY)
			{
				key = getkey();
				PiccClose();
				if(key == KEYCANCEL)
					{dddoHentFMessage(25);return ERR_TRAN_FAIL;}
			}

			ret = PiccDetect(mode,NULL,NULL,NULL,NULL);
			if(ret == 0) break;
			if(ret == 1 ||ret==2){dddoHentFMessage(26); return ERR_TRAN_FAIL;}
			if(ret == 3||ret==5||ret==6)
			{
				PiccClose();
				DelayMs(100);
				continue;
			}
			if(ret == 4)
			{dddoHentFMessage(27);
				PiccClose();
				return ERR_TRAN_FAIL;
			}
		}
		break;
	}
	

	memcpy(send_com.Command,"\x00\xA4\x04\x00",4);
	send_com.Lc = 14;
	memcpy(send_com.DataIn,"1PAY.SYS.DDF01",14);
	send_com.Le = 256;
	ret = PiccIsoCommand(0,&send_com,&recv_com);
	if(ret != 0){dddoHentFMessage(28); return ERR_TRAN_FAIL;}
	if(recv_com.SWA != 0x90 ||recv_com.SWB != 0x00){dddoHentFMessage(29); return ERR_TRAN_FAIL;}
	
	
	memcpy(send_com.Command,"\x00\xA4\x04\x00",4);
	memcpy(send_com.DataIn, glProcInfo.stTranLog.sAID, strlen(glProcInfo.stTranLog.sAID));
	send_com.Le = 256;
	ret = PiccIsoCommand(0,&send_com,&recv_com);
	if(ret != 0){dddoHentFMessage(30); return ERR_TRAN_FAIL;}
	if(recv_com.SWA != 0x90 ||recv_com.SWB != 0x00){dddoHentFMessage(31); return ERR_TRAN_FAIL;}
	
	iLen = PubChar2Long(glRecvPack.sICCData, 2);
	sScriptData = &glRecvPack.sICCData[2];
	if (ChkIfAmex())
	{
		sScriptData += 6;
	}

	memset(outActype, 0, sizeof(outActype));
	len = 0;
	ret = GetSpecTLVItem(sScriptData, iLen, 0x91, outActype, (ushort *)&len);
	if (ret==0)
	{
		ret = Clss_IssuerAuth_Wave (outActype, len);
	}
	memset(outActype, 0, sizeof(outActype));
	len = 0;
	ret = GetSpecTLVItem(sScriptData, iLen, 0x71, outActype, (ushort *)&len);
	if (ret==0)
	{
		ret = Clss_IssScriptProc_Wave (outActype, len);
	}
	memset(outActype, 0, sizeof(outActype));
	len = 0;
	ret = GetSpecTLVItem(sScriptData, iLen, 0x72, outActype, (ushort *)&len);
	if (ret==0)
	{
		ret = Clss_IssScriptProc_Wave (outActype, len);
	}
	if(ret!= EMV_OK) 
	{dddoHentFMessage(32);
		return ERR_TRAN_FAIL;
	}

	return EMV_OK;
}

int GetTLVItem(uchar **ppsTLVString, int iMaxLen, SaveTLVData pfSaveData, uchar bExpandAll)
{
	int			iRet;
	uchar		*psTag, *psSubTag;
	uint		uiTag, uiLenBytes;
	ulong		lTemp;

	// skip null tags
	for(psTag=*ppsTLVString; psTag<*ppsTLVString+iMaxLen; psTag++)
	{
		if( (*psTag!=TAG_NULL_1) && (*psTag!=TAG_NULL_2) )
		{
			break;
		}
	}
	if( psTag>=*ppsTLVString+iMaxLen )
	{
		*ppsTLVString = psTag;
		return 0;	// no tag available
	}

	// process tag bytes
	uiTag = *psTag++;
	if( (uiTag & TAGMASK_FIRSTBYTE)==TAGMASK_FIRSTBYTE )
	{	// have another byte
		uiTag = (uiTag<<8) + *psTag++;
	}
	if( psTag>=*ppsTLVString+iMaxLen )
	{
		return -1;
	}

	// process length bytes
	if( (*psTag & LENMASK_NEXTBYTE)==LENMASK_NEXTBYTE )
	{
		uiLenBytes = *psTag & LENMASK_LENBYTES;
		lTemp = PubChar2Long(psTag+1, uiLenBytes);
	}
	else
	{
		uiLenBytes = 0;
		lTemp      = *psTag & LENMASK_LENBYTES;
	}
	psTag += uiLenBytes+1;
	if( psTag+lTemp>*ppsTLVString+iMaxLen )
	{
		return -2;
	}
	*ppsTLVString = psTag+lTemp;	// advance pointer of TLV string

	// save data
	(*pfSaveData)(uiTag, psTag, (int)lTemp);
	if( !IsConstructedTag(uiTag) || !bExpandAll )
	{
		return 0;
	}

	// constructed data
	for(psSubTag=psTag; psSubTag<psTag+lTemp; )
	{
		iRet = GetTLVItem(&psSubTag, psTag+lTemp-psSubTag, pfSaveData, TRUE);
		if( iRet<0 )
		{
			return iRet;
		}
	}

	return 0;
}

int GetSpecTLVItem(uchar *psTLVString, int iMaxLen, uint uiSearchTag, uchar *psOutTLV, ushort *puiOutLen)
{
	uchar		*psTag, *psTagStr, szBuff[10];
	uint		uiTag, uiLenBytes;
	ulong		lTemp;
	
	// skip null tags
    for (psTag=psTLVString; psTag<psTLVString+iMaxLen; psTag++)
    {
        if ((*psTag!=0x00) && (*psTag!=0xFF))
        {
            break;
        }
    }
    if ( psTag>=psTLVString+iMaxLen )
    {
        return -1;	// no tag available
    }
    
    while (1)
    {
        psTagStr = psTag;
        // process tag bytes
        uiTag = *psTag++;
        if ((uiTag & 0x1F)==0x1F)
        {	// have another byte
            uiTag = (uiTag<<8) + *psTag++;
        }
        if (psTag>=psTLVString+iMaxLen)
        {
            return -2;	// specific tag not found
        }
        
        // process length bytes
        if ((*psTag & 0x80)==0x80)
        {
            uiLenBytes = *psTag & 0x7F;
			//atoi
			memset(szBuff, 0, sizeof(szBuff));
			memcpy(szBuff, psTag+1, uiLenBytes);
			lTemp = atoi((char *)szBuff);
            //PubChar2Long(psTag+1, uiLenBytes, &lTemp);
        }
        else
        {
            uiLenBytes = 0;
            lTemp      = *psTag & 0x7F;
        }
        psTag += uiLenBytes+1;
        if (psTag+lTemp>psTLVString+iMaxLen)
        {
            return -2;	// specific tag not found also
        }
        
        // Check if tag needed
        if (uiTag==uiSearchTag)
        {
            *puiOutLen = (ushort)(psTag-psTagStr+lTemp);
            memcpy(psOutTLV, psTagStr, *puiOutLen);
            return 0;
        }
        
        if (IsConstructedTag(uiTag))
        {
            if (GetSpecTLVItem(psTag, (int)lTemp, uiSearchTag, psOutTLV, puiOutLen)==0)
            {
                return 0;
            }
        }
        
        psTag += lTemp;	// advance pointer of TLV string
        if (psTag>=psTLVString+iMaxLen)
        {
            return -2;
        }
    }
    return 0;
}

int IsConstructedTag(uint uiTag)
{
	int		i;
	
	for(i=0; (uiTag&0xFF00) && i<2; i++)
	{
		uiTag >>= 8;
	}
	
	return ((uiTag & 0x20)==0x20);
}

//added by Gillian Chen 2015/9/25
int nAppFindMatchProID(unsigned char *pucProID, int ucProIDLen)
{
	EMV_APPLIST EMV_APP;
	int i, iRet;

	if ( pucProID == NULL)
	{
		return EMV_PARAM_ERR;
	}
	else
	{
		// modify v1.00.0018  [23/09/2015 chenyy]
		for (i=0; i<MAX_APP_NUM; i++)
		{
			memset(&EMV_APP, 0, sizeof(EMV_APPLIST));
			iRet = EMVGetApp(i, &EMV_APP);
			if(iRet != EMV_OK)
			{
				continue;
			}
			iRet = Clss_AddAidList_Entry(EMV_APP.AID, EMV_APP.AidLen, EMV_APP.SelFlag, KERNTYPE_DEF);
			if(iRet != EMV_OK)
			{
				continue;
			}
			memset(&ptProgInfo, 0, sizeof(Clss_ProgramID));
		 	ptProgInfo.ulTermFLmt = glClss_PreProcInfoIn.ulTermFLmt;
		 	ptProgInfo.ulRdClssTxnLmt = glClss_PreProcInfoIn.ulRdClssTxnLmt;
		 	ptProgInfo.ulRdCVMLmt = glClss_PreProcInfoIn.ulRdCVMLmt;
		 	ptProgInfo.ulRdClssFLmt =  glClss_PreProcInfoIn.ulRdClssFLmt;
			memcpy(ptProgInfo.aucProgramId, pucProID, 17);
			ptProgInfo.ucPrgramIdLen = ucProIDLen;
		 	ptProgInfo.ucAmtZeroNoAllowed = 0;
		 	ptProgInfo.ucStatusCheckFlg = glClss_PreProcInfoIn.ucStatusCheckFlg;
		 	ptProgInfo.ucTermFLmtFlg = glClss_PreProcInfoIn.ucTermFLmtFlg;
		 	ptProgInfo.ucRdClssTxnLmtFlg = glClss_PreProcInfoIn.ucRdClssTxnLmtFlg;
		 	ptProgInfo.ucRdCVMLmtFlg = glClss_PreProcInfoIn.ucRdCVMLmtFlg;
		 	ptProgInfo.ucRdClssFLmtFlg = glClss_PreProcInfoIn.ucRdClssFLmtFlg;
		}
		return EMV_OK;
	}
}


#else
int TransClssSale(void)
{
	return 0;
}
#endif



