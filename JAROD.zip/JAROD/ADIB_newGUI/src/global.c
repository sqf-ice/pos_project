
// 定义全局变量、常量等
#include "global.h"

// Added by Kim_LinHB 2014-4-4
#if defined(AREA_Arabia) && defined(_MONITOR_)
unsigned int gl_AR_FONT_ID = AR_OPENFILE_ERROR;
#endif

SYS_PARAM		glSysParam, glSysParamBak;		// sys config parameters
SYS_CONTROL		glSysCtrl;						// sys control parameters
SYS_PROC_INFO	glProcInfo;						// transaction processing information

COMM_DATA		glSendData, glRecvData;			// communication data
STISO8583		glSendPack;						// transaction sending package
STISO8583		glRecvPack;						// transaction receiving package 

STTMS8583		glTMSSend;						// TMS sending package
STTMS8583		glTMSRecv;						// TMS receiving package

ST_EVENT_MSG   *glEdcMsgPtr;					// manager event

ACQUIRER		glCurAcq;						// current acquirer
ISSUER			glCurIssuer;					// current issuer

COMM_CONFIG		glCommCfg;						// current communication config

TOTAL_INFO		glAcqTotal[MAX_ACQ];			// transaction totals of all acquirers
TOTAL_INFO		glIssuerTotal[MAX_ISSUER];		// transaction totals of all issuers
TOTAL_INFO		glEdcTotal;						// transaction totals of this terminal 
TOTAL_INFO		glTransTotal;					// transaction totals of this terminal for display
TOTAL_INFO		glPrnTotal;						// transaction totals of this terminal for printing

#ifdef ENABLE_EMV
EMV_PARAM		glEmvParam;
EMV_STATUS		glEmvStatus;
#endif

// supported languages list
#ifdef _PROLIN2_4_
//FIXME Please set path for the font you need
const LANG_CONFIG glLangList[] = {
	{ _T_NOOP("English"),      "",    "/usr/font/paxfont.ttf",			"UTF-8"},
	{ _T_NOOP("Chinese Simp"), "./data/CHS.LNG", "/data/opt/fonts/simyou.ttf", "GBK"},
	{ _T_NOOP("Chinese Trad"), "./data/CHT.LNG",  "/data/opt/fonts/",			"BIG5"},
	{ _T_NOOP("Vietnamese"),   "./data/VIETNAMESE.LNG", "/data/opt/fonts/",	"UTF-8"},
	{ _T_NOOP("Thai"),         "./data/THAI.LNG",       "/data/opt/fonts/",	"UTF-8"},
	{ _T_NOOP("Japanese"), 	"./data/JAPANESE.LNG", "/data/opt/fonts/",			"UTF-8"},
	{ _T_NOOP("Korea"),       "./data/KOREA.LNG",    "/data/opt/fonts/", 		"UTF-8"},
	{ _T_NOOP("Arabic"),      "./data/ARABIC.LNG",	  "/data/opt/fonts/arial.ttf",	"cp1256"},
	{"", "", "", ""},
	// need pending
};
#else
const LANG_CONFIG glLangList[] = {
	{"English",      "",               CHARSET_WEST},
	{"Chinese Simp", "CHS.LNG",        CHARSET_GB2312},
	{"Chinese Trad", "CHT.LNG",        CHARSET_BIG5},
	{"Vietnamese",   "VIETNAMESE.LNG", CHARSET_VIETNAM},
	{"Thai",         "THAI.LNG",       CHARSET_WEST},
	{"Japanese",     "JAPANESE.LNG",   CHARSET_SHIFT_JIS},
	{"Korea",        "KOREA.LNG",      CHARSET_KOREAN},
	{"Arabic",       "ARABIC.LNG",	   CHARSET_ARABIA},
	{"", "", 0},
	// need pending
};
#endif

// AREA JOR & MAR point out the max currency number : 50
const CURRENCY_CONFIG glCurrency[MAX_CURRENCY] =
{
	{"HKD", "\x03\x44", "\x03\x44", 2, 0}, // 1.Hong Kong Dollars
	{"HK",  "\x03\x44", "\x03\x44", 2, 0}, // 2.
	{"HK$", "\x03\x44", "\x03\x44", 2, 0}, // 3.
	{"CNY", "\x01\x56", "\x01\x56", 2, 0}, // 4.Chinese Yuan
	{"RMB", "\x01\x56", "\x01\x56", 2, 0}, // 5.
	{"JPY", "\x03\x92", "\x03\x92", 0, 2}, // 6.Japanese Yen				// special
	{"EUR", "\x09\x78", "\x00\x00", 2, 0}, // 7.Euro -- Country not determined
	{"MOP", "\x04\x46", "\x04\x46", 2, 0}, // 8.Macao Pataca
	{"MYR", "\x04\x58", "\x04\x58", 2, 0}, // 9.Malaysian Ringgit
	{"PHP", "\x06\x08", "\x06\x08", 2, 0}, // 10.Philippine Pesos
	{"SGD", "\x07\x02", "\x07\x02", 2, 0}, // 11.Singapore Dollars
	{"THB", "\x07\x64", "\x07\x64", 2, 0}, // 12.Thai Baht
	{"TWD", "\x09\x01", "\x01\x58", 2, 0}, // 13.New Taiwanese Dollars
	{"NT",  "\x09\x01", "\x01\x58", 2, 0}, // 14.
	{"NT$", "\x09\x01", "\x01\x58", 2, 0}, // 15.
	{"USD", "\x08\x40", "\x08\x40", 2, 0}, // 16.US Dollars
	{"VND", "\x07\x04", "\x07\x04", 0, 2}, // 17.Vietnam DONG				// special
	{"AED", "\x07\x84", "\x07\x84", 2, 0}, // 18.United Arab Durham
	{"AUD", "\x00\x36", "\x00\x36", 2, 0}, // 19.Australian Dollars
	{"CAD", "\x01\x24", "\x01\x24", 2, 0}, // 20.Canadian Dollars
	{"CYP", "\x01\x96", "\x01\x96", 2, 0}, // 21.Cypriot Pounds
	{"CHF", "\x07\x56", "\x07\x56", 2, 0}, // 22.Swiss Francs
	{"DKK", "\x02\x08", "\x02\x08", 2, 0}, // 23.Danish Krone
	{"GBP", "\x08\x26", "\x08\x26", 2, 0}, // 24.British Pounds Sterling
	{"IDR", "\x03\x60", "\x03\x60", 0, 0}, // 25.Indonesia Rupiah			// special
	{"INR", "\x03\x56", "\x03\x56", 2, 0}, // 26.Indian Rupee
	{"ISK", "\x03\x52", "\x03\x52", 2, 0}, // 27.Icelandic krone
	{"KRW", "\x04\x10", "\x04\x10", 0, 2}, // 28.South Korean Won			// special
	{"LKR", "\x01\x44", "\x01\x44", 2, 0}, // 29.Sri-Lanka Rupee
	{"MTL", "\x04\x70", "\x04\x70", 2, 0}, // 30.Maltese Lira
	{"NOK", "\x05\x78", "\x05\x78", 2, 0}, // 31.Norwegian Krone
	{"NZD", "\x05\x54", "\x05\x54", 2, 0}, // 32.New Zealand Dollars
	{"RUB", "\x06\x43", "\x06\x43", 2, 0}, // 33.Russian Ruble
	{"SAR", "\x06\x82", "\x06\x82", 2, 0}, // 34.Saudi Riyal
	{"SEK", "\x07\x52", "\x07\x52", 2, 0}, // 35.Swedish krone
	{"TRL", "\x07\x92", "\x07\x92", 2, 0}, // 36.Turkey Lira
	{"VEF", "\x09\x37", "\x08\x62", 2, 0}, // 37.Bolivar Fuerte (Venezuela)
	{"ZAR", "\x07\x10", "\x07\x10", 2, 0}, // 38.South African Rand
	{"KWD", "\x04\x14", "\x04\x14", 3, 0}, // 39.Kuwaiti Dinar			// special
	{"CLP", "\x01\x52", "\x01\x52", 0, 2}, // 40.Chilean Piso				// special
	{"JOD", "\x04\x00", "\x04\x00", 3, 0}, // 41.Jordanian Dinar(JOR)
	{"MAD", "\x05\x04", "\x05\x04", 3, 0}, // 42.Morocco Dirham(MAR)
	{"", "", "", 0, 0} // maximum number of currencies per terminal is 50 
};

// !!!! Here must be one-one and accordant to the sequence of enum{PREAUTH,AUTH,...}
// !!!! See definition of "SALE","PREAUTH", ...
TRAN_CONFIG		glTranConfig[] =
{      //ZOZO
		//linzhao 20151231
	{_T_NOOP("PRE-AUTH"),       "0100", "300000", PRN_RECEIPT+ACT_INC_TRACE+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // Modified by lirz v1.02.0000
	{_T_NOOP("PRE-AUTH"),           "0100", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 00000 to 3000 1, linzhao
	{_T_NOOP("PURCHASE"),           "0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 2
	{_T_NOOP("INSTAL"),         "0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 3
	{_T_NOOP("ENQUIRE"),        "0800", "970000", ACT_INC_TRACE},							// 4
	{_T_NOOP("ENQUIRE"),        "0100", "000000", ACT_INC_TRACE},							// 5
	{_T_NOOP("UPLOAD"),         "0320", "000000", ACT_INC_TRACE},							// 6
	{_T_NOOP("LOGON"),          "0800", "920000", ACT_INC_TRACE},							// 7
	{_T_NOOP("REFUND"),         "0200", "200000", PRN_RECEIPT+ACT_INC_TRACE+IN_REFUND_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},	// 8
	{_T_NOOP("REVERSAL"),       "0400", "000000", NO_ACT},									// 9
	{_T_NOOP("SETTLEMENT"),     "0500", "920000", ACT_INC_TRACE},							// 10
	{_T_NOOP("INITIALIZATION"), "0800", "920000", ACT_INC_TRACE},							// 11
	{_T_NOOP("VOID"),           "0200", "020000", PRN_RECEIPT+NEED_REVERSAL+ACT_INC_TRACE},	// 12
	{_T_NOOP("UPLOAD OFFLINE"), "0220", "000000", PRN_RECEIPT+ACT_INC_TRACE},				// 13
	{_T_NOOP("OFFLINE"),        "0220", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+WRT_RECORD+VOID_ALLOW},					// 14
	{_T_NOOP("SALECOMP"),       "0220", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 15
	{_T_NOOP("CASH"),           "0200", "010000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 16
	{_T_NOOP(""),			"0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 17.SALE_OR_AUTH // Modified by Kim_LinHB 2014-08-18 v1.01.0004
	{_T_NOOP("TC-ADVICE"),      "0320", "940000", ACT_INC_TRACE},							// 18
	{_T_NOOP("ECHO-TEST"),      "0800", "990000", NO_ACT},									// 19
	{_T_NOOP("ENQUIRE"),        "0800", "930000", ACT_INC_TRACE},							// 20
	{_T_NOOP("BIN DOWNLOAD"),   "0900", "000000", ACT_INC_TRACE},							// 21
	{_T_NOOP("DCC RATE INQUIRY"),   	"0904", "970000", ACT_INC_TRACE},							// 22
	{_T_NOOP("BALANCE"),    	"0100", "310000", ACT_INC_TRACE},							// 23
	{_T_NOOP("COMPLETION"),     "0220", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 24
    {_T_NOOP("LOYALTY INQUIRY"),     "0100", "830000", PRN_RECEIPT+ACT_INC_TRACE},     // 25
    {_T_NOOP("SALE INQUIRY"),     "0100", "860000", ACT_INC_TRACE},     // 26
    {_T_NOOP("COUPON"),     "0200", "860000", ACT_INC_TRACE},     // 27
    {_T_NOOP("GIFT INQUIRY"),     "0100", "850000", ACT_INC_TRACE},     // 28
    {_T_NOOP("GIFT REDEEM"),     "0200", "850000", PRN_RECEIPT+ACT_INC_TRACE},     //  29
	{_T_NOOP("AUTH_COMPLETE"),  "0220", "000000", IN_SALE_TOTAL+WRT_RECORD+VOID_ALLOW},	//30
	{_T_NOOP("VOID AUTH"),      "0100", "190000", PRN_RECEIPT+NEED_REVERSAL+ACT_INC_TRACE},	// 31
	{_T_NOOP("REDEEM INQUIRY"),      "0100", "840000", ACT_INC_TRACE},	// 32
	{_T_NOOP("REDEEM POINT"),      "0200", "840000", ACT_INC_TRACE},	// 33
	//=============================================================

	{_T_NOOP("PURCHASE"),           "0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 34

	{_T_NOOP("OFFLINE REFUND"),           "0220", "200000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 35, linzhao
	{_T_NOOP("CASH ADVANCE"),           "0100", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 36, linzhao
	{_T_NOOP("SINGLE TIP"),           "0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW},		// 37

	{_T_NOOP("F&B PURCHASE"),           "0100", "300000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 38, linzhao
	{_T_NOOP("TIP COMPLETION"),           "0220", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 39, linzhao
	{_T_NOOP("EXPRESS CHECKOUT"),           "0100", "340000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 40, linzhao
	{_T_NOOP("MOTO"),           "0200", "000000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 41, linzhao
	{_T_NOOP("VOID REFUND"),           "0200", "220000", PRN_RECEIPT+ACT_INC_TRACE+IN_SALE_TOTAL+NEED_REVERSAL+WRT_RECORD+VOID_ALLOW}, // 42, linzhao


};

HOST_ERR_MSG	glHostErrMsg[] =
{
	{"00", _T_NOOP("Approved")},
	{"01", _T_NOOP("Refer to card issuer")},
	{"02", _T_NOOP("Referral")},
	{"03", _T_NOOP("Invalid Merchant")},
	{"04", _T_NOOP("Pick Up Card")},
	{"05", _T_NOOP("Do not honour")},
	{"06", _T_NOOP("Error")},
	{"07", _T_NOOP("Pickup card")},
	{"09", _T_NOOP("Invalid Transaction")},
	{"10", _T_NOOP("Partial Approval")},
	{"11", _T_NOOP("V.I.P Approval")},
	{"12", _T_NOOP("Invalid Transaction")},
	{"13", _T_NOOP("Invalid Amount")},
	{"14", _T_NOOP("Invalid account number")},
	{"15", _T_NOOP("No such issuer")},
	{"19", _T_NOOP("Reenter transaction")},
	{"25", _T_NOOP("Unable to Locate Record On File")},
	{"30", _T_NOOP("Format error")},
	{"31", _T_NOOP("Bank not supported by switch")},
	{"40", _T_NOOP("Function Not Supported")},
	{"41", _T_NOOP("Please Call-Lost Card")},
	{"43", _T_NOOP("PickUp Card-Stolen card")},
	{"51", _T_NOOP("Not sufficient funds")},
	{"54", _T_NOOP("Expired Card")},
	{"55", _T_NOOP("Incorrect PIN")},
	{"57", _T_NOOP("Transaction not permitted to Card Holder")},
	{"58", _T_NOOP("Transaction not permitted to terminal")},
	{"59", _T_NOOP("Suspected fraud")},
	{"61", _T_NOOP("Activity amount limit exceeded")},
	{"62", _T_NOOP("Restricted card")},
	{"63", _T_NOOP("Security violation")},
	{"64", _T_NOOP("Txn does not fulfil AML requirement")},
	{"65", _T_NOOP("Activity count limit exceeded")},
	{"66", _T_NOOP("Invalid Matching Amount")},
	{"75", _T_NOOP("Allowable number of PIN tries exceeded")},
	{"76", _T_NOOP("Original not found")},
	{"77", _T_NOOP("Repeat/reversal:inconsistent data with orig msg")},
	{"78", _T_NOOP("Blocked, first used")},
	{"79", _T_NOOP("Declined-CVV2")},
	{"80", _T_NOOP("Credit issuer unavailable/Invalid date")},
	{"81", _T_NOOP("Invalid Pin Block")},
	{"82", _T_NOOP("Negative online CAM,dcVV,iCVV,CVV results")},
	{"83", _T_NOOP("No susp.soc slots")},
	{"85", _T_NOOP("Batch not found")},
	{"86", _T_NOOP("Cannot verify PIN")},
	{"89", _T_NOOP("Bad Terminal Id'")},
	{"90", _T_NOOP("Cash Back Not allowed")},
	{"91", _T_NOOP("issuer or switch inoperative")},
	{"92", _T_NOOP("Destination cannot be found for routing")},
	{"93", _T_NOOP("Txn cannot be completed")},
	{"94", _T_NOOP("Duplicate transmission")},
	{"95", _T_NOOP("Reconcile Error")},
	{"96", _T_NOOP("System malfuntion")},
	{"97", _T_NOOP("APPROVED")},//<!-- Unable to go Online ,Approved Offline --
	{"98", _T_NOOP("DECLINED")},// <!-- Unable to go Online, Declined Offline --
	{"99", _T_NOOP("DECLINED BY CARD")},// <!--  Approved Online, Declined by Card --
	{"A0", _T_NOOP("Pin Time out")},
	{"C0", _T_NOOP("Transaction failed")},
	{"C1", _T_NOOP("Card removed")},
	{"C2", _T_NOOP("Transaction Cancelled")},
	{"DC", _T_NOOP("DECLINED OFFLINE")},
	{"N3", _T_NOOP("Cash service not available")},
	{"N4", _T_NOOP("Cashback request exeeds user limit")},
	{"N7", _T_NOOP("Decline for CVV2 failure")},
	{"P2", _T_NOOP("Invalid Biller information")},
	{"P5", _T_NOOP("PIN Change/Unblock request declined")},
	{"P6", _T_NOOP("Unsafe PIN")},
	{"R0", _T_NOOP("Stop Payment Order")},
	{"R1", _T_NOOP("Revocation of Authorization order")},
	{"R3", _T_NOOP("Revocation of all Auth order")},
	{"XA", _T_NOOP("Forward to issuer")},
	{"XD", _T_NOOP("Forward to issuer")},
	{"Q1", _T_NOOP("Card authentication failed")},
	{"**", _T_NOOP("DECLINED")},//<!--  ** Response Code from Host --
	{"Q2", _T_NOOP("DECLINED")},//<!--  ** Response Code from Amex Host --
	{"A1", _T_NOOP("Please call Issuer")},//<!--  ** Response Code from Amex Host --
	{"A2", _T_NOOP("Invalid Service Est")},//<!--  ** Response Code from amex Host --
	{"A3", _T_NOOP("Invalid Account")},//<!--  ** Response Code from Amex Host --
	{"A4", _T_NOOP("Card Issuer TimeOut")},//<!--  ** Response Code from Amex Host --
	{"A5", _T_NOOP("Host Unavaiable")},//<!--  ** Response Code from Amex Host --
	{"E0", _T_NOOP("EMV Process Error")},//<!--  EMV Process Error SG Response code --
	{"IA", _T_NOOP("Invalid Auth Code")},//<!-- SG Response code --
	{"T0", _T_NOOP("Transmission Failed")},//<!-- SG Response code --
	{"\0\0", _T_NOOP("Decline")},
};

// 终端错误信息
// error message for internal error.
TERM_ERR_MSG	glTermErrMsg[] = 
{
	{ERR_COMM_MODEM_OCCUPIED,  _T_NOOP("PHONE OCCUPIED")},
	{ERR_COMM_MODEM_NO_LINE,   _T_NOOP("TRY AGAIN - NC")},
	{ERR_COMM_MODEM_LINE,      _T_NOOP("TRY AGAIN - CE")},
	{ERR_COMM_MODEM_NO_ACK,    _T_NOOP("NO ACK")},
	{ERR_COMM_MODEM_LINE_BUSY, _T_NOOP("LINE BUSY")},
	{ERR_NO_TELNO,             _T_NOOP("NO TEL NO")},
	{ERR_USERCANCEL,           _T_NOOP("USER CANCELED")},
	{ERR_TRAN_FAIL,            _T_NOOP("PROCESS FAILED")},
	{0, ""},
};

GUI_TEXT_ATTR gl_stTitleAttr = {GUI_FONT_NORMAL, GUI_ALIGN_CENTER, 0/*GUI_FONT_REVERSAL|GUI_FONT_OPAQUE*/};
GUI_TEXT_ATTR gl_stLeftAttr = {GUI_FONT_NORMAL, GUI_ALIGN_LEFT, 0};
GUI_TEXT_ATTR gl_stCenterAttr = {GUI_FONT_NORMAL, GUI_ALIGN_CENTER, 0};
GUI_TEXT_ATTR gl_stRightAttr = {GUI_FONT_NORMAL, GUI_ALIGN_RIGHT, 0};

unsigned char gl_szCurrTitle[50];
char gl_szTerminalType[20];
// Add End

// Added by Kim_LinHB 2014-8-8 v1.01.0002
#ifdef _MONITOR_
#if defined(_Sxxx_)
ST_FONT gl_Font_Def[3] = {
	{CHARSET_WEST, 8, 16, 0,0},
	{CHARSET_WEST, 15, 30,0,0},
	{CHARSET_WEST, 20, 40, 0,0},
};
#elif defined(_Dxxx_)
#ifdef _MIPS_
ST_FONT gl_Font_Def[3] = {
	{CHARSET_WEST, 8, 15, 0,0},
	{CHARSET_WEST, 16, 30,0,0},
	{CHARSET_WEST, 20, 48, 0,0},
};
// Added by Kim_LinHB 2014-08-14 v1.01.0003
#elif defined(_ARM_)
ST_FONT gl_Font_Def[3] = {
	{CHARSET_WEST, 8, 16, 0,0},
	{CHARSET_WEST, 15, 30,0,0},
	{CHARSET_WEST, 20, 40, 0,0},
};
#endif
#else
ST_FONT gl_Font_Def[3] = {
	{CHARSET_WEST, 6, 8, 0,0},
	{CHARSET_WEST, 8, 16,0,0},
	{CHARSET_WEST, 12, 24, 0,0},
};
#endif
#endif

// end of file

