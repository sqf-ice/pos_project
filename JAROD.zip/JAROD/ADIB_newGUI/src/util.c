
#include "global.h"

// Modified by Kim_LinHB 2014-7-11		Update GUI to new version

/********************** Internal macros declaration ************************/
#define TIMER_TEMPORARY		4
/********************** Internal structure declaration *********************/

/********************** Internal functions declaration *********************/
static uchar ChkAcqRestrictForCard(const uchar *pszPan);
static int  MatchCardTableForInstalment(uchar acq_index);
static int  SelectAcqForCard(const uchar *psAcqMatchFlag, uchar *pucCardIndex);
static int	AutoAcqForCard(const uchar *psAcqMatchFlag, uchar *pucCardIndex);
static void GetHolderNameFromTrack1(uchar *pszHolderName);
static void ConvertHolderName(const uchar *pszOrgName, uchar *pszNormalName);
static int  GetEmvTrackData(void);
static int  GetPanFromTrack(uchar *pszPAN, uchar *pszExpDate);
static int  MatchTrack2AndPan(const uchar *pszTrack2, const uchar *pszPan);
static int  MatchCardBin(const uchar *pszPAN);
static int  GetSecurityCode(void);
static int  DetectCardEvent(uchar ucMode);
static void DispFallBackPrompt(void);
static int  InputAmount(uchar ucAmtType);
static int  VerifyManualPan(void);
static int  GetTipAmount(void);
static int  ExtractPAN(const uchar *pszPAN, uchar *pszOutPan);
static void DispWelcomeOnPED(void);
static int  GetExpiry(void);


/********************** Internal variables declaration *********************/

/********************** external reference declaration *********************/

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/

#if defined(AREA_Arabia) && defined(_MONITOR_)
// Modified by Kim_LinHB 2014-8-7 v1.01.0002
// Modified by Kim_LinHB 2014-08-26 v1.01.0005
int CustomizeAppLibForArabiaLang(uchar bSetToArabia)
{
	unsigned char sTermInfo[30];

    if (bSetToArabia)
    {
#if !defined(_Sxx_)
		ST_FONT stFont[3] = {
			{CHARSET_ARABIA, 8, 16, 0,0},
			{CHARSET_ARABIA, 16, 32,0,0},
			{CHARSET_ARABIA, 24, 40, 0,0},
		};
#else
		ST_FONT stFont[3] = {
			{CHARSET_ARABIA, 6, 8, 0,0},
			{CHARSET_ARABIA, 8, 16,0,0},
			{CHARSET_ARABIA, 12, 24, 0,0},
		};
#endif

		gl_AR_FONT_ID = ArFontOpen("PAXARFA.FONT");
		if (gl_AR_FONT_ID > AR_ERROR_CODE_MIN)  //arabic
		{
			MirroringSendEcr("Error:PAX_ARFA.FONT error\nPls download ParamFile");
			Gui_ClearScr();
			Gui_ShowMsgBox(NULL, gl_stTitleAttr, "Error:PAX_ARFA.FONT error\nPls download ParamFile", gl_stCenterAttr, GUI_BUTTON_CANCEL, -1, NULL);
			return -1;
		}
		Gui_Init(WHITE, _RGB_INT_(0, 20,255), "PAXARFA.FONT");
		
		GetTermInfo(sTermInfo);
		memcpy(stFont, gl_Font_Def, sizeof(gl_Font_Def));
#ifdef _Sxxx_
		if ((sTermInfo[0] != _TERMINAL_S300_) && (sTermInfo[0] != _TERMINAL_S900_))
		{
			if(_TERMINAL_S800_ == sTermInfo[0]){
				stFont[1].Width  = 12;
				stFont[1].Height = 24;
			}
			else{
				stFont[0].Width  = 6;
				stFont[0].Height = 8;

				stFont[1].Width  = 8;
				stFont[1].Height = 16;
			}
		}
#endif

		Gui_LoadFont(GUI_FONT_SMALL,  &stFont[0], NULL);
		Gui_LoadFont(GUI_FONT_NORMAL, &stFont[1], NULL);
		Gui_LoadFont(GUI_FONT_LARGE,  &stFont[2], NULL );

        return 0;
    } 
    else
	{
		ST_FONT stFont[3];

		ArFontClose(gl_AR_FONT_ID);
		gl_AR_FONT_ID = AR_OPENFILE_ERROR;

		Gui_Init(WHITE, _RGB_INT_(0, 20,255), NULL);

		GetTermInfo(sTermInfo);
		memcpy(stFont, gl_Font_Def, sizeof(gl_Font_Def));
#ifdef _Sxxx_
		if ((sTermInfo[0] != _TERMINAL_S300_) && (sTermInfo[0] != _TERMINAL_S900_))
		{
			if(_TERMINAL_S800_ == sTermInfo[0]){
				stFont[1].Width  = 12;
				stFont[1].Height = 24;
			}
			else{
				stFont[0].Width  = 6;
				stFont[0].Height = 8;

				stFont[1].Width  = 8;
				stFont[1].Height = 16;
			}
		}
#endif

		Gui_LoadFont(GUI_FONT_SMALL,  &stFont[0], NULL);
		Gui_LoadFont(GUI_FONT_NORMAL, &stFont[1], NULL);
		Gui_LoadFont(GUI_FONT_LARGE,  &stFont[2], NULL );
        return 0;
    }
}
#endif

// هˆ‌ه§‹هŒ–ن؛¤وک“هڈ‚و•°
// initiate transaction parameters
void InitTransInfo(void)
{
	memset(&glProcInfo, 0, sizeof(SYS_PROC_INFO));
	glProcInfo.uiRecNo     = 0xFFFF;
	glProcInfo.bIsFirstGAC = TRUE;
	sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%012ld", 0L);

	// set initial transaction currency to local currency at first
	glProcInfo.stTranLog.stTranCurrency = glSysParam.stEdcInfo.stLocalCurrency;		// initial currency
	glProcInfo.stTranLog.uiEntryMode = MODE_NO_INPUT;
	glProcInfo.stTranLog.bPanSeqOK   = FALSE;
    glProcInfo.ucEcrCtrl             = ECR_NONE;
	glProcInfo.stTranLog.ulInvoiceNo = glSysCtrl.ulInvoiceNo;
	GetDateTime(glProcInfo.stTranLog.szDateTime);	// set default txn time

	memcpy(&glCommCfg, &glSysParam.stTxnCommCfg, sizeof(COMM_CONFIG));
}

// èژ·ه¾—و–°çڑ„وµپو°´هڈ·
// generate a new trace NO.
ulong GetNewTraceNo(void)
{
	glSysCtrl.ulSTAN++;
	if( !(glSysCtrl.ulSTAN>0 && glSysCtrl.ulSTAN<=999999L) )
	{
		glSysCtrl.ulSTAN = 1L;
	}
	SaveSysCtrlBase();

	return (glSysCtrl.ulSTAN);
}

// calculate new batch number
ulong GetNewBatchNo(ulong ulCurBatchNo)
{
	ulCurBatchNo++;
	if( !(ulCurBatchNo>0 && ulCurBatchNo<=999999L) )
	{
		return 1L;
	}

	return ulCurBatchNo;
}

// èژ·ه¾—و–°çڑ„ç¥¨وچ®هڈ·
// generata a new invoice NO.
ulong GetNewInvoiceNo(void)
{
	glSysCtrl.ulInvoiceNo++;
	if( !(glSysCtrl.ulInvoiceNo>0 && glSysCtrl.ulInvoiceNo<=999999L) )
	{
		glSysCtrl.ulInvoiceNo = 1L;
	}
	SaveSysCtrlBase();

	return (glSysCtrl.ulInvoiceNo);
}

// وڈگç¤؛و‹”ه‡؛ICهچ،
// prompt to remove IC card
void PromptRemoveICC(void)
{
	unsigned char szName[16+1];
	if( !ChkIfEmvEnable() )
	{
		return;
	}

	IccClose(ICC_USER);
	if( IccDetect(ICC_USER)!=0 )
	{
		// ه¦‚و‍œICهچ،ه·²و‹”ه‡؛ï¼Œç›´وژ¥è؟”ه›‍
		// if removed IC card, return directly
		return;
	}

	// وک¾ç¤؛ه¹¶ç­‰ه¾…ICهچ،و‹”ه‡؛
	// Display Prompt and wait until removed IC card
	MirroringSendEcr("PLS REMOVE CARD");
//	MirroringSendEcrEND("");

	Gui_ClearScr();
	GetTransName(szName);
	Gui_ShowMsgBox(szName, gl_stTitleAttr, _T("PLS REMOVE CARD"), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
	while( IccDetect(ICC_USER)==0 )
	{
		Beep();
		DelayMs(500);
	}
	Gui_ClearScr(); // Added by Kim_LinHB 2014-08-14 v1.01.0003 bug512
}

#ifdef ENABLE_EMV
// هˆ é™¤è؟‡وœںCAPK
// erase expired CAPK
void EraseExpireCAPK(void)
{
	int			iRet, iCnt;
	EMV_CAPK	stCAPK;

	for(iCnt=0; iCnt<MAX_KEY_NUM; iCnt++)
	{
		memset(&stCAPK, 0, sizeof(EMV_CAPK));
		iRet = EMVCheckCAPK(&stCAPK.KeyID, stCAPK.RID);
		if( iRet==EMV_OK )
		{
			break;
		}
		EMVDelCAPK(stCAPK.KeyID, stCAPK.RID);
	}
}
#endif

static int DispMainLogo(void)
{
#if defined(_Sxx_) || defined(_SP30_)
	uchar	*psLogoData;
	int		iWidth, iHeigh;

	psLogoData = NULL;
	GetNowDispLogo(&psLogoData);
	if (psLogoData!=NULL)
	{
		iWidth = 0;
		iHeigh = 0;
		GetLogoWidthHeigh(psLogoData, &iWidth, &iHeigh);
		Gui_DrawLogo(psLogoData, ((128-iWidth)/2), 16);
		return 0;
	}
#elif defined(_Sxxx_) || defined(_Dxxx_)
	int iScrW, iScrH, iLogoW, iLogoH;
#ifdef _PROLIN2_4_
	char *pLogo = "./res/logo.png";
	if(ChkTerm(_TERMINAL_S800_) ){

	    pLogo = "./data/logo_normal.png";
	}
	else
	    	 pLogo = "./data/logo_large.png";
#else
	char *pLogo = "LOGO.PNG";
#endif
	// Modified by Kim_LinHB 2014-08-13 v1.01.0003
	iScrW = Gui_GetScrWidth();
	iScrH = Gui_GetScrHeight();
	



	if (GUI_OK == Gui_GetImageSize(pLogo, &iLogoW, &iLogoH) && iScrW >= iLogoW && iScrH >= iLogoH)
	{
		//Gui_DrawImage(pLogo, (iScrW - iLogoW)*100 / 2 / iScrW, (iScrH - iLogoH)*100 / 3 / iScrH);

		if(ChkTerm(_TERMINAL_S800_) ){

			 Gui_DrawImage(pLogo, (iScrW - iLogoW)*100 / 2 / iScrW, 4);
			}
			else
			{
				Gui_DrawImage(pLogo, (iScrW - iLogoW)*100 / 2 / iScrW, 4);
			}

	}
	else
	{
 		Gui_DrawImage(pLogo, 0, 25);
	}
//	 Gui_DrawImage(pLogo, gl_stCenterAttr, 5);
	return 0;
#endif

	return -1;
}

static void DispIndicator(void)
{
	GUI_TEXT_ATTR stTextAttr = gl_stLeftAttr;
	stTextAttr.eFontSize = GUI_FONT_SMALL;
#ifdef APP_DEBUG
	//linzhao 20150916
//	Gui_DrawText("DEBUG", stTextAttr, 0, 30);
#endif

#if defined(EMV_TEST_VERSION) && defined(ENABLE_EMV)
//	Gui_DrawText("EMVTEST", stTextAttr, 0, 45);
#endif

	if (ChkIfTrainMode())
	{
		Gui_DrawText("DEMO", stTextAttr, 0, 60);
	}

    if (glSysParam.stECR.ucMode)
    {
       // Gui_DrawText("ECR", gl_stRightAttr, 50, 85);//REMOVE ECR WORD
    }
}

// وک¾ç¤؛هˆ·هچ،/وڈ’هچ،ç•Œé‌¢
// Display "swipe/insert" prompt
void DispSwipeCard(uchar bShowLogo)
{

	uchar *pszStr = NULL;
	if (bShowLogo)
	{
		if (DispMainLogo()!=0)
		{
			bShowLogo = FALSE;
		}
	}
	if ((!MirroringCheckEcr()) &&  (!CheckCarrfour() ) )
	{
			if( ChkIfEmvEnable() )//rEMOVE WORD
			{
//				 pszStr = _T_NOOP("SWIPE/INSERT ...");///yyyyyyyy

				 pszStr = _T_NOOP("");///yyyyyyyy
			}
			else
			{

//				 pszStr = _T_NOOP("PLS SWIPE CARD");
				 pszStr = _T_NOOP("");

			}
	}
	DispIndicator();

	   uchar szHelpPhone[25];
memset(szHelpPhone,0,sizeof(szHelpPhone));
strcpy(szHelpPhone,"MHD-");
strcat(szHelpPhone,(char *)glSysParam.stEdcInfo.szHelpTelNo);

	  if(  (0 == strcmp(gl_szTerminalType, "s900") ) || (0 == strcmp(gl_szTerminalType, "s920") )        )
	        {
				  pszStr = _T_NOOP("ADIB");///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 40);
				 pszStr = _T_NOOP("IMG BESTLOCKER-SIT");///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 50);
				 pszStr = _T_NOOP(glSysCtrl.szMerchantID_AMEX);///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 65);
				// pszStr = _T_NOOP("MHD-065170000");///yyyyyyyy
				  pszStr = _T_NOOP(szHelpPhone);///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 75);

	        }


	  else if(0 == strcmp(gl_szTerminalType, "s800"))
	        {
//				  pszStr = _T_NOOP("ADIB");///yyyyyyyy
//				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 40);
				 pszStr = _T_NOOP("IMG BESTLOCKER-SIT");///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 40);
				 pszStr = _T_NOOP(glSysCtrl.szMerchantID_AMEX);///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 60);
				// pszStr = _T_NOOP("MHD-065170000");///yyyyyyyy
				  pszStr = _T_NOOP(szHelpPhone);///yyyyyyyy
				 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 75);
	        }
	  else
	  {
		  pszStr = _T_NOOP("?????");///yyyyyyyy
		 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 40);
	  }






// 	if (bShowLogo)
//	{
//		 Gui_DrawText(pszStr, gl_stCenterAttr, 0, 75);
//	}
//	else
//	{
//		Gui_DrawText(pszStr, gl_stCenterAttr, 0, 50);
//	}
}

void DispBlockFunc(void)
{
	MirroringSendEcr("TRANS NOT ALLOW");
	Gui_ClearScr();
	PubBeepErr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TRANS NOT ALLOW"), gl_stCenterAttr, GUI_BUTTON_NONE, 3, NULL);
}

void DispProcess(void)
{
	MirroringSendEcr("PROCESSING....");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PROCESSING...."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispWait(void)
{
	MirroringSendEcr("PLEASE WAIT...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLEASE WAIT..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispDial(void)
{
	MirroringSendEcr("DIALING...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("DIALING..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispSend(void)
{
	MirroringSendEcr("SENDING...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("SENDING..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispReceive(void)
{
	MirroringSendEcr("RECEIVING...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("RECEIVING..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispPrinting(void)
{
	MirroringSendEcr("PRINTING...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PRINTING..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
}

void DispClearOk(void)
{
	Gui_ClearScr();
	DispOperOk(_T("CLEARED"));
}


int DispVersion(void)
{
	GUI_PAGE stVersionPage;
	GUI_PAGELINE	stBuff[30];
	unsigned int nCnt = 0;

	SetCurrTitle(_T("VERSION")); // Added by Kim_LinHB 2014/9/16 v1.01.0009 bug493

	strcpy(stBuff[nCnt].szLine, APP_NAME);
	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;

	strcpy(stBuff[nCnt].szLine, EDC_VER_PUB);
	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;
	
#ifdef ENABLE_EMV
	// Show EMV lib version (EMV lib updates sometimes)
	strcpy(stBuff[nCnt].szLine, "EMV :");
	stBuff[nCnt].stLineAttr = gl_stLeftAttr;
	if (ChkIfEmvEnable() && (EMVReadVerInfo(stBuff[nCnt].szLine + 5)==EMV_OK))
	{
		if (strstr(stBuff[nCnt].szLine + 5, " ")!=NULL)
		{
			*(strstr(stBuff[nCnt].szLine + 5, " ")) = 0;
		}
	}
	++nCnt;
#endif

	sprintf(stBuff[nCnt].szLine, "%s:%-8ld", _T("FREE"), freesize());
	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;

	// Downloaded terminal ID
	sprintf(stBuff[nCnt].szLine, "%s:%.8s", _T("TERM ID"), glSysParam.stEdcInfo.szDownLoadTID);

	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;


    //--------------------------------------------------
	// Internal version
	strcpy(stBuff[nCnt].szLine, "DETAIL VERSION");
	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;

	strcpy(stBuff[nCnt].szLine, EDC_VER_INTERN);
#ifdef APP_DEBUG
	stBuff[nCnt].szLine[strlen(stBuff[nCnt].szLine)] = 'D';
	stBuff[nCnt].szLine[strlen(stBuff[nCnt].szLine)+1] = '\0';
#endif
	stBuff[nCnt].szLine[strlen(stBuff[nCnt].szLine)] = 'N';
	stBuff[nCnt].szLine[strlen(stBuff[nCnt].szLine)+1] = '\0';

	stBuff[nCnt++].stLineAttr = gl_stRightAttr;

#ifdef APP_DEBUG
    strcpy(stBuff[nCnt].szLine, "EDC VERSION");
    stBuff[nCnt++].stLineAttr = gl_stLeftAttr;
    strcpy(stBuff[nCnt].szLine, EDC_BASE_VER_INTERN);
    stBuff[nCnt++].stLineAttr = gl_stRightAttr;
#endif

    if (glSysParam.ucTermStatus!=INIT_MODE)
    {
		strcpy(stBuff[nCnt].szLine, "PARA INIT DATE");
		stBuff[nCnt++].stLineAttr = gl_stLeftAttr;

		strcpy(stBuff[nCnt].szLine, glSysParam.stEdcInfo.szInitTime);
		stBuff[nCnt++].stLineAttr = gl_stRightAttr;
    }

    //linzhao
	uchar szBuff[32];
	sprintf(szBuff, "Amex Floor Limit:%ld", g_ulAmexFloorLimit);
    strcpy(stBuff[nCnt].szLine, szBuff);
	stBuff[nCnt++].stLineAttr = gl_stLeftAttr;

	Gui_CreateInfoPage(GetCurrTitle(), gl_stTitleAttr, stBuff, nCnt, &stVersionPage);
	Gui_ClearScr();
	Gui_ShowInfoPage(&stVersionPage, FALSE, USER_OPER_TIMEOUT);
	return 0;
}

// وژ¥و”¶ç­‰ه¾…ه›‍è°ƒه‡½و•°
// callback function for receiving
void DispWaitRspStatus(ushort uiLeftTime)
{
	uchar szBuff[10];
	sprintf(szBuff, "%-3u", uiLeftTime);
	Gui_DrawText(szBuff, gl_stCenterAttr, 75, 50); // Modified by Kim_LinHB 2014-8-5 v1.01.0001 bug497
}


// è¾“ه…¥هٹںèƒ½هڈ·ç پ
// for entering function id
int FunctionInput(void)
{
	uchar szFuncNo[2+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 0;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = 2;

	memset(szFuncNo, 0, sizeof(szFuncNo));
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(NULL, gl_stTitleAttr, _T("FUNCTION ?"), gl_stLeftAttr, szFuncNo, 
		gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return -1;
	}

	return  atoi((char *)szFuncNo);
}

void SysHalt(void)
{
	unsigned char szBuff[200];
	sprintf(szBuff, "%s\n%s", _T("HALT FOR SAFETY "), _T("PLS RESTART POS "));
	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(NULL, gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, -1, NULL);
	while(1);
}

void SysHaltInfo(const void *pszDispInfo, ...)
{
	uchar		szBuff[1024+1];
	va_list		pVaList;

	if( pszDispInfo==NULL || *(uchar *)pszDispInfo==0 )
	{
		return;
	}

	sprintf(szBuff, "%s\n", _T("HALT FOR SAFETY "));

	va_start(pVaList, pszDispInfo);
	vsprintf((char*)szBuff + strlen(szBuff), (char*)pszDispInfo, pVaList);
	va_end(pVaList);
	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(NULL, gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, -1, NULL);
	while(1);
}

void DispMagReadErr(void)
{
	MirroringSendEcr("READ CARD ERR.");
	Gui_ClearScr();
	PubBeepErr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("READ CARD ERR."), gl_stCenterAttr, GUI_BUTTON_OK, 2, NULL);
}

void GetTransName(unsigned char *szName)
{
	if( glProcInfo.stTranLog.ucTranType==SALE_OR_AUTH )
	{
		unsigned char szTitle[16+1];
		GetEngTime(szTitle);
		sprintf(szName, "%s", szTitle);
	}
	else
	{
		sprintf(szName, "%s", _T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel));
	}
}


void DispAccepted(void)
{
	MirroringSendEcr("TXN ACCEPTED");
	Gui_ClearScr();
	PubBeepOk();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TXN ACCEPTED"), gl_stCenterAttr, GUI_BUTTON_OK, glSysParam.stEdcInfo.ucAcceptTimeout, NULL);
}

void DispErrMsg(const char *pFirstMsg, const char *pSecondMsg, short sTimeOutSec, ushort usOption)
{
	// DERR_BEEP     : error beep
	unsigned char szBuff[200];
	PubASSERT(pFirstMsg!=NULL);

	if (pSecondMsg==NULL)
	{
		strcpy(szBuff, pFirstMsg);
	}
	else
	{
		sprintf(szBuff, "%s\n%s", pFirstMsg, pSecondMsg);
	}

	if (usOption & DERR_BEEP)
	{
		PubBeepErr();
	}

	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, sTimeOutSec, NULL);
}

void PrintOne(void)
{
#ifndef _PROLIN2_4_
	static uchar sPrinterLogo[137] =
	{
		0x04,
		0x00,0x20,
		0x0,0xf8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,
		0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0xf8,

		0x00,0x20,
		0x0,0xff,0x0,0x0,0x0,0x0,0x80,0x40,0x20,0x70,0x4c,0x44,0x54,0x54,0x54,0x54,
		0x54,0x54,0x44,0x44,0x44,0x74,0x2c,0x20,0xa0,0xe0,0xe0,0x0,0x0,0x0,0x0,0xff,

		0x00,0x20,
		0x0,0xff,0x0,0x0,0x0,0x3f,0x21,0xe1,0x21,0x21,0x21,0x21,0x21,0x21,0x21,0x21,
		0x21,0x21,0x21,0x25,0x25,0xe1,0xe1,0x7f,0x1f,0xf,0x7,0x0,0x0,0x0,0x0,0xff,

		0x00,0x20,
		0x0,0xf,0x8,0x8,0x8,0x8,0x8,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,0x9,
		0x9,0x9,0x9,0x9,0x9,0x9,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0x8,0xf
	};

 	Gui_DrawLogo(sPrinterLogo, 86, 30);
#endif
}

int SelectTransCurrency(void)
{
	// TODO: implement currency selection
	// let  glProcInfo.stTranLog.stTranCurrency = selected currency
	// ...

#ifdef ENABLE_EMV
	EMVGetParameter(&glEmvParam);
	memcpy(glEmvParam.TransCurrCode, glProcInfo.stTranLog.stTranCurrency.sCurrencyCode, 2);
	glEmvParam.TransCurrExp = glProcInfo.stTranLog.stTranCurrency.ucDecimal;
	EMVSetParameter(&glEmvParam);
	// Only in this trasaction, so DON'T back up
#endif

	return 0;
}

// و ¹وچ®Issuer Keyè®¾ç½®glCurIssuer
// set current issuer by key
void FindIssuer(uchar ucIssuerKey)
{
	uchar	ucIndex;

	for(ucIndex=0; ucIndex<glSysParam.ucIssuerNum; ucIndex++)
	{
		if( glSysParam.stIssuerList[ucIndex].ucKey==ucIssuerKey )
		{
			SetCurIssuer(ucIndex);
			glProcInfo.stTranLog.ucIssuerKey = ucIssuerKey;
			break;
		}
	}
}

// و ¹وچ®Keyè®¾ç½®glCurAcq
// set current acquirer by key.
void FindAcq(uchar ucAcqKey)
{
	uchar	ucIndex;

	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
	{
		if( glSysParam.stAcqList[ucIndex].ucKey==ucAcqKey )
		{
			SetCurAcq(ucIndex);
			glProcInfo.stTranLog.ucAcqKey = ucAcqKey;
			break;
		}
	}
}

// و ¹وچ®pszAcqNameوں¥و‰¾Acq
// Find acquirer by name. Return index if found, else return MAX_ACQ
uchar FindAcqIdxByName(char *pszAcqName, uchar bFullMatch)
{
	uchar	ucIndex;

	for(ucIndex=0; ucIndex<glSysParam.ucAcqNum; ucIndex++)
	{
		if (bFullMatch)
		{
			if( strcmp(glSysParam.stAcqList[ucIndex].szName, pszAcqName)==0 )
			{
				return ucIndex;
			}
		}
		else
		{
			if( strstr(glSysParam.stAcqList[ucIndex].szName, pszAcqName)!=NULL )
			{
				return ucIndex;
			}
		}
	}

	return MAX_ACQ;
}

// è®¾ç½®ه½“ه‰چو”¶هچ•è،Œن؟،وپ¯
// set current acquirer by index
void SetCurAcq(uchar ucAcqIndex)
{
	memcpy(&glCurAcq, &glSysParam.stAcqList[ucAcqIndex], sizeof(ACQUIRER));
	glCurAcq.ucIndex = ucAcqIndex;
}

// è®¾ç½®ه½“ه‰چهڈ‘هچ،è،Œن؟،وپ¯
// set current issuer by index
void SetCurIssuer(uchar ucIssuerIndex)
{
	memcpy(&glCurIssuer, &glSysParam.stIssuerList[ucIssuerIndex], sizeof(ISSUER));
}

// è¯»هڈ–ç£پهچ،ç£پéپ“هڈٹPAN
int ReadMagCardInfo(void)
{
	int		iRet;

	if( glEdcMsgPtr->MsgType == MAGCARD_MSG )
	{
		glProcInfo.stTranLog.uiEntryMode = MODE_SWIPE_INPUT;
		sprintf((char *)glProcInfo.szTrack1, "%.*s", LEN_TRACK1, glEdcMsgPtr->MagMsg.track1);
		sprintf((char *)glProcInfo.szTrack2, "%.*s", LEN_TRACK2, glEdcMsgPtr->MagMsg.track2);
		sprintf((char *)glProcInfo.szTrack3, "%.*s", LEN_TRACK3, glEdcMsgPtr->MagMsg.track3);
	}
	else
	{
		glProcInfo.stTranLog.uiEntryMode = MODE_SWIPE_INPUT;
		MagRead(glProcInfo.szTrack1, glProcInfo.szTrack2, glProcInfo.szTrack3);
	}

	iRet = GetPanFromTrack(glProcInfo.stTranLog.szPan, glProcInfo.stTranLog.szExpDate);
	if( iRet!=0 )
	{
		DispMagReadErr();
		return ERR_NO_DISP;
	}
	Beep();

	return 0;
}

// ن»ژç£پéپ“ن؟،وپ¯هˆ†و‍گه‡؛هچ،هڈ·(PAN)
// get PAN from track
int GetPanFromTrack(uchar *pszPAN, uchar *pszExpDate)
{
	int		iPanLen;
	char	*p, *pszTemp;

	// ن»ژ2ç£پéپ“ه¼€ه§‹هˆ°'ï¼‌'
	// read data from the start of track #2 to '-'
	if( strlen((char *)glProcInfo.szTrack2)>0 )
	{
		pszTemp = (char *)glProcInfo.szTrack2;
	}
	else if( strlen((char *)glProcInfo.szTrack3)>0 )
	{
		pszTemp = (char *)&glProcInfo.szTrack3[2];
	}
	else
	{	// 2م€پ3ç£پéپ“éƒ½و²،وœ‰
		// track #2 and #3 are not existed
		return ERR_SWIPECARD;
	}

	p = strchr((char *)pszTemp, '=');
	if( p==NULL )
	{
		return ERR_SWIPECARD;
	}
	iPanLen = p - pszTemp;
	if( iPanLen<13 || iPanLen>19 )
	{
		return ERR_SWIPECARD;
	}

	sprintf((char *)pszPAN, "%.*s", iPanLen, pszTemp);
	if( pszTemp==(char *)glProcInfo.szTrack2 )
	{
		sprintf((char *)pszExpDate, "%.4s", p+1);
	}
	else
	{
		sprintf((char *)pszExpDate, "0000");
	}

	return 0;
}

// و£€وµ‹ç£پéپ“ن؟،وپ¯وک¯هگ¦ن¸؛ICهچ،ç£پéپ“ن؟،وپ¯
// Check service code in track 2, whther it is 2 or 6
uchar IsChipCardSvcCode(const uchar *pszTrack2)
{
	char	*pszSeperator;

	if( *pszTrack2==0 )
	{
		return FALSE;
	}

	pszSeperator = strchr((char *)pszTrack2, '=');
	if( pszSeperator==NULL )
	{
		return FALSE;
	}
	if( (pszSeperator[5]=='2') || (pszSeperator[5]=='6') )
	{
		return TRUE;
	}

	return FALSE;
}

// و ،éھŒهچ،هڈ·
// verify PAN NO.
int ValidPanNo(const uchar *pszPanNo)
{
	uchar	bFlag, ucTemp, ucResult;
	uchar	*pszTemp;

	// وک¯هگ¦و£€وں¥هچ،هڈ·
	// if need to check
	if( !ChkIssuerOption(ISSUER_CHKPAN_MOD10) )
	{
		return 0;
	}

	// (2121 algorithm)
	bFlag    = FALSE;
	pszTemp  = (uchar *)&pszPanNo[strlen((char *)pszPanNo)-1];
	ucResult = 0;
	while( pszTemp>=pszPanNo )
	{
		ucTemp = (*pszTemp--) & 0x0F;
		if( bFlag )    ucTemp *= 2;
		if( ucTemp>9 ) ucTemp -= 9;
		ucResult = (ucTemp + ucResult) % 10;
		bFlag = !bFlag;
	}

	if( ucResult!=0 )
	{
		MirroringSendEcr("INVALID CARD");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("INVALID CARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	return 0;
}

// و£€وں¥هچ،çڑ„وœ‰و•ˆوœں(YYMM)
// verify the expiry (YYMM)
int ValidCardExpiry(void)
{
	uchar	szDateTime[14+1];
	ulong	ulCardYear, ulCardMonth;
	ulong	ulCurYear, ulCurMonth;
	uchar	ucInvalidFormat;

	glProcInfo.bExpiryError = FALSE;
	ucInvalidFormat = FALSE;

	ulCardYear  = PubAsc2Long(glProcInfo.stTranLog.szExpDate, 2);
	ulCardYear += (ulCardYear>80) ? 1900 : 2000;
	ulCardMonth = PubAsc2Long(glProcInfo.stTranLog.szExpDate+2, 2);

	GetDateTime(szDateTime);
	ulCurYear  = PubAsc2Long(szDateTime, 4);
	ulCurMonth = PubAsc2Long(szDateTime+4, 2);

	if( ulCardMonth>12 || ulCardMonth<1 )
	{
		ucInvalidFormat = TRUE;
		glProcInfo.bExpiryError = TRUE;
	}
	if (//ulCardYear>ulCurYear+20 ||	// وک¯هگ¦éœ€è¦پهˆ¤و–­وœ‰و•ˆوœںه¤ھé•؟çڑ„هچ،?
		ulCardYear<ulCurYear || 
		(ulCurYear==ulCardYear && ulCurMonth>ulCardMonth) )
	{
		glProcInfo.bExpiryError = TRUE;
	}

	if (glProcInfo.bExpiryError)
	{
		if( ChkIssuerOption(ISSUER_EN_EXPIRY) && ChkIssuerOption(ISSUER_CHECK_EXPIRY) )
		{
			int nTimeout = 3;

			if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT ){	
				nTimeout = 2;
			}
			else{
				nTimeout = 3;
				PubBeepErr();
			}

			Gui_ClearScr();
			if (ucInvalidFormat)
			{
				MirroringSendEcr("ERR EXP. FORMAT");
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("ERR EXP. FORMAT"), gl_stCenterAttr, GUI_BUTTON_CANCEL, nTimeout, NULL);
			} 
			else
			{
				MirroringSendEcr("CARD EXPIRED");
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CARD EXPIRED"), gl_stCenterAttr, GUI_BUTTON_OK, nTimeout, NULL);
			}

			if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
			{	// if EMV expired card, let core to continue process(based upon TACs/IACs)
				return 0;
			}
			else
			{
				return ERR_NO_DISP;
			}
		}
	}

	return 0;
}

// èژ·هڈ–ç»ˆç«¯ه½“ه‰چو—¶é—´,و ¼ه¼ڈ:YYYYMMDDhhmmss
// format : YYYYMMDDhhmmss
void GetDateTime(uchar *pszDateTime)
{
	uchar	sCurTime[7];

	GetTime(sCurTime);
	sprintf((char *)pszDateTime, "%02X%02X%02X%02X%02X%02X%02X",
			(sCurTime[0]>0x80 ? 0x19 : 0x20), sCurTime[0], sCurTime[1],
			sCurTime[2], sCurTime[3], sCurTime[4], sCurTime[5]);
}

int UpdateLocalTime(const uchar *pszNewYear, const uchar *pszNewDate, const uchar *pszNewTime)
{
	uchar	szLocalTime[14+1], sBuffer[16];

	if ((pszNewDate!=0) && (pszNewTime!=0))
	{
		if (pszNewYear==NULL)
		{
			memset(szLocalTime, 0, sizeof(szLocalTime));
			GetDateTime(szLocalTime);

			if ((memcmp(szLocalTime+4, "12", 2)==0) &&		// local month is DECEMBER
				(memcmp(pszNewDate, "01", 2)==0))			// received month is JANUARY. local clock slower
			{
				PubAscInc(szLocalTime, 4);		// increase local year
			}
			if ((memcmp(szLocalTime+4, "01", 2)==0) &&		// local month is JANUARY
				(memcmp(pszNewDate, "12", 2)==0))			// received month is DECEMBER. local clock faster
			{
				PubAscDec(szLocalTime, 4);		// increase local year
			}
		}
		else
		{
			memcpy(szLocalTime, pszNewYear, 4);
		}

		memcpy(szLocalTime+4, pszNewDate, 4);	// MMDD
		memcpy(szLocalTime+8, pszNewTime, 6);	// hhmmss

		memset(sBuffer, 0, sizeof(sBuffer));
		PubAsc2Bcd(szLocalTime+2, 12, sBuffer);
		return SetTime(sBuffer);
	}

	return -1;
}

// è‹±و–‡ن¹ وƒ¯çڑ„و—¥وœںو—¶é—´(16 bytes, eg: "OCT07,2006 11:22")
void GetEngTime(uchar *pszCurTime)
{
	uchar	Month[12][5] = {"Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
	uchar	sCurTime[7], ucMonth;

	GetTime(sCurTime);

	ucMonth = (sCurTime[1]>>4) * 10 + (sCurTime[1] & 0x0F) - 1;



	uchar champm[3];
	uchar ch2[3];
	memset(champm,0,sizeof(champm));
	memset(ch2,0,sizeof(ch2));


	sprintf(ch2 ,"%x",sCurTime[3]);
	int iTemp= atoi(ch2);

	if (iTemp == 0 ){
		strcpy( champm,"am");
		sCurTime[3]='\x12';
	}
	else if ((iTemp >0) && (iTemp <12))
	{
		strcpy( champm,"am");

	}
	else if (iTemp == 12)
	{
		strcpy( champm,"pm");
	}
	else if ((iTemp >12)  && (iTemp <=23))
	{
		strcpy( champm,"pm");
		iTemp =  iTemp - 12 ;

		 switch(iTemp){
		 case 1:	sCurTime[3]='\x01';break;
		 case 2:	sCurTime[3]='\x02';break;
		 case 3:	sCurTime[3]='\x03';break;
		 case 4:	sCurTime[3]='\x04';break;
		 case 5:	sCurTime[3]='\x05';break;
		 case 6:	sCurTime[3]='\x06';break;
		 case 7:	sCurTime[3]='\x07';break;
		 case 8:	sCurTime[3]='\x08';break;
		 case 9:	sCurTime[3]='\x09';break;
		 case 10:	sCurTime[3]='\x10';break;
		 case 11:	sCurTime[3]='\x11';break;
         }






	}

	if(strcmp(LANGCONFIG, "Arabic") == 0) //added by Kim_LinHB 2014-6-7
		sprintf((char *)pszCurTime, "%02X%02X,%s%02X %02X:%02X %s", (sCurTime[0]>0x80 ? 0x19 : 0x20), sCurTime[0],
				Month[ucMonth], sCurTime[2],  
				sCurTime[3], sCurTime[4],champm);
	else
		sprintf((char *)pszCurTime, "%s%02X,%02X%02X %02X:%02X %s", Month[ucMonth],
				sCurTime[2], (sCurTime[0]>0x80 ? 0x19 : 0x20),
				sCurTime[0], sCurTime[3], sCurTime[4],champm);


	//strcat((char *)pszCurTime,champm);

//	sprintf((char *)pszCurTime, "%.3s %02X,%02X  %02X:%02X", Month[ucMonth],
//		sCurTime[2], sCurTime[0], sCurTime[3], sCurTime[4]);

}

// è½¬وچ¢YYYYMMDDhhmmss هˆ° OCT 07, 2006  11:22
// Convert from ... to ...
void Conv2EngTime(const uchar *pszDateTime, uchar *pszEngTime)
{
    uchar   Month[12][5] = {"Jan", "Feb", "Mar", "Apr", "May", "June", "July", "Aug", "Sept", "Oct", "Nov", "Dec"};
    uchar	ucMonth;

	ucMonth = (uchar)((PubAsc2Long(&pszDateTime[4], 2)-1) % 12);
	sprintf((char *)pszEngTime, "%s %2.2s, %4.4s  %2.2s:%2.2s", Month[ucMonth],
			pszDateTime+6, pszDateTime, pszDateTime+8, pszDateTime+10);
}

// و£€وں¥هچ،هڈ·,ه¹¶ç،®ه®ڑو”¶هچ•è،Œ/هڈ‘هچ،è،Œ(ه؟…é،»هœ¨è¯»ه‡؛هچ،هڈ·هگژè°ƒç”¨)
// Check PAN, and determine Issuer/Acquirer.
int ValidCard(void)
{
	int		iRet;
	uchar	pinEntyFesible,pinEntyReq;
		pinEntyFesible  = FALSE;
		pinEntyReq		= FALSE;
		uchar	szServiceCode[3+1];





//	if((glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT)||
//			(glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE))
//		{
//
//		SaveSvcCode(glProcInfo.szTrack2,szServiceCode);
//
//
//
//
//		iRet = CheckSrvCode(szServiceCode, &pinEntyReq, &pinEntyFesible);
//		if(iRet != 0)
//			{
//				return ERR_NO_DISP;
//			}
//			if(pinEntyReq == TRUE)
//			{
//				glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
//			}
//			else if (pinEntyFesible == TRUE)
//			{
//				glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
//			}
//			else
//			{
//				glProcInfo.stTranLog.uiEntryMode |= MODE_SIGNATURE_REQ;
//			}
//		}
//		else;

	iRet = MatchCardTable(glProcInfo.stTranLog.szPan);
	if( iRet!=0 )
	{
		MirroringSendEcr("UNSUPPORTED\nCARD");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED\nCARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	if((glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT)||
				(glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE))
			{

			SaveSvcCode(glProcInfo.szTrack2,szServiceCode);




			iRet = CheckSrvCode(szServiceCode, &pinEntyReq, &pinEntyFesible);
			if(iRet != 0)
				{
					return ERR_NO_DISP;
				}
				if(pinEntyReq == TRUE)
				{
					glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
				}
				else if (pinEntyFesible == TRUE)
				{
					glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
				}
				else
				{
					glProcInfo.stTranLog.uiEntryMode |= MODE_SIGNATURE_REQ;
				}
			}
			else;
#ifdef ENABLE_EMV
	if( !ChkAcqOption(ACQ_EMV_FEATURE) )
	{
		// é‌‍EMV Acquirerن¸چه…پè®¸Fallbackهڈٹوڈ’هچ،
		if( (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) ||
			(glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
			(glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
		{
			MirroringSendEcr("EMV IS NOT\nALLOWED");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMV IS NOT\nALLOWED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
			//PubDispString(_T("NOT EMV ENABLE"), 4|DISP_LINE_LEFT);
			return ERR_NO_DISP;
		}
	}
#endif

	iRet = ValidPanNo(glProcInfo.stTranLog.szPan);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = ValidCardExpiry();
	if( iRet!=0 )
	{
		return iRet;
	}

	CheckCapture();

	if( glProcInfo.stTranLog.ucTranType==INSTALMENT )
	{
		if( glProcInfo.bIsFallBack || glEdcMsgPtr->MsgType == ICCARD_MSG )
		{
			MirroringSendEcr("PLS SWIPE AGAIN");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS SWIPE AGAIN"), gl_stCenterAttr, GUI_BUTTON_OK, 5, NULL);
			return ERR_NEED_SWIPE;
		}
	}

	GetCardHolderName(glProcInfo.stTranLog.szHolderName);
	iRet = ConfirmPanInfo();
	if( iRet!=0 )
	{
		CommOnHook(FALSE);
		return iRet;
	}

	iRet = GetSecurityCode();
	if( iRet!=0 )
	{
		return iRet;
	}

	return 0;
}

// èژ·ه¾—وŒپهچ،ن؛؛ه§“هگچ(ه·²ç»ڈè½¬وچ¢ن¸؛و‰“هچ°و ¼ه¼ڈ)
// Read and convert holder name to printable format.
void GetCardHolderName(uchar *pszHolderName)
{
#ifdef ENABLE_EMV
	int		iRet, iTagLen;
	uchar	szBuff[40];
#endif
	uchar	szTempName[40];

	*pszHolderName = 0;

#ifdef ENABLE_EMV
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
		memset(szBuff, 0, sizeof(szBuff));
		iRet = EMVGetTLVData(0x5F20, szBuff, &iTagLen);
		if( iRet!=EMV_OK )
		{
			return;
		}
		ConvertHolderName(szBuff, szTempName);
	}
	else	// other entry mode, just get it from track 1 data
#endif
	{
		GetHolderNameFromTrack1(szTempName);
	}

	sprintf((char *)pszHolderName, "%.26s", szTempName);
}

// get holder name form track 1, which is identified by '^'
void GetHolderNameFromTrack1(uchar *pszHolderName)
{
	char	*p, *q;
	uchar	szOrgName[50];
	int		iLen;

	*pszHolderName = 0;
	if( glProcInfo.szTrack1[0]==0 )
	{
		return;
	}

	p = strchr((char *)glProcInfo.szTrack1, '^');
	if( p==NULL )
	{
		return;
	}
	p++;
	iLen = strlen(p);

	q = strchr(p, '^');
	if( q!=NULL )
	{
		iLen = MIN(q-p, iLen);
	}

	sprintf((char *)szOrgName, "%.*s", (int)MIN(sizeof(szOrgName)-1, iLen), p);
	ConvertHolderName(szOrgName, pszHolderName);
}

// è½¬وچ¢ISO7813و ¼ه¼ڈن؛؛هگچن¸؛و‰“هچ°و ¼ه¼ڈ
// "Amex/F D.Mr" --> "Mr F D Amex"
void ConvertHolderName(const uchar *pszOrgName, uchar *pszNormalName)
{
	char	*pszTitle, *pszMidName, *pszTemp, szBuff[50];

	sprintf((char *)pszNormalName, "%s", pszOrgName);
	if( *pszOrgName==0 )
	{
		return;
	}
	pszTemp = (char *)pszNormalName;

	pszMidName = strchr((char *)pszOrgName, '/');
	if( pszMidName==NULL )
	{
		return;
	}

	pszTitle = strrchr((char *)pszOrgName, '.');
	if( pszTitle!=NULL )
	{
		sprintf(szBuff, "%s ", pszTitle+1);
		PubTrimStr((uchar *)szBuff);
		pszTemp += sprintf(pszTemp, "%s ", szBuff);

		sprintf(szBuff, "%.*s ", (int)(pszTitle-pszMidName-1), pszMidName+1);
		PubTrimStr((uchar *)szBuff);
		pszTemp += sprintf(pszTemp, "%s ", szBuff);
	}
	else
	{
		sprintf(szBuff, "%s", pszMidName+1);
		PubTrimStr((uchar *)szBuff);
		pszTemp += sprintf(pszTemp, "%s ", szBuff);
	}
	sprintf(pszTemp, "%.*s", (int)(pszMidName-(char *)pszOrgName), pszOrgName);
}

// check whether really match to specific acquirer, due to customized conditions
uchar ChkAcqRestrictForCard(const uchar *pszPan)
{
	//if (ChkIfxxx())

	//...

	return TRUE;
}

// و ¹وچ®هچ،هڈ·هŒ¹é…چهچ،è،¨,ه¹¶وœ€ç»ˆç،®ه®ڑو”¶هچ•è،Œ(glCurAca)ه’Œهڈ‘هچ،è،Œ(glCurIssuer)
// determine glCurAcq and glCurIssuer, due to ACQ-ISS-CARD matching table.
int MatchCardTable(const uchar *pszPAN)
{
	int			iRet;
	uchar		ucCnt, ucPanLen, ucAcqNum, ucLastAcqIdx;
	uchar		sPanHeader[5], sCardIndex[MAX_ACQ], sAcqMatchFlag[MAX_ACQ];
	CARD_TABLE	*pstCardTbl;

	memset(sCardIndex,    0, sizeof(sCardIndex));
	memset(sAcqMatchFlag, 0, sizeof(sAcqMatchFlag));

	// ه»؛ç«‹و”¶هچ•è،Œهˆ—è،¨
	// create a list of matched acquirer.
	ucPanLen = strlen((char *)pszPAN);
	PubAsc2Bcd(pszPAN, 10, sPanHeader);
	for(ucAcqNum=ucCnt=0; ucCnt<glSysParam.ucCardNum; ucCnt++)
	{
		pstCardTbl = &glSysParam.stCardTable[ucCnt];
		if( (memcmp(pstCardTbl->sPanRangeLow,  sPanHeader, 5)<=0  &&
			 memcmp(pstCardTbl->sPanRangeHigh, sPanHeader, 5)>=0) &&
			(pstCardTbl->ucPanLength==0 || pstCardTbl->ucPanLength==ucPanLen) )
		{
			FindIssuer(pstCardTbl->ucIssuerKey);
			FindAcq(pstCardTbl->ucAcqKey);

			if (!ChkAcqRestrictForCard(pszPAN))
			{
				continue;
			}

			sCardIndex[glCurAcq.ucIndex] = ucCnt;
			if( glSysCtrl.sAcqStatus[glCurAcq.ucIndex]==S_USE  ||
				glSysCtrl.sAcqStatus[glCurAcq.ucIndex]==S_PENDING )
			{
				if( sAcqMatchFlag[glCurAcq.ucIndex]==0 )
				{
					sAcqMatchFlag[glCurAcq.ucIndex] = 1;
					ucAcqNum++;
					ucLastAcqIdx = glCurAcq.ucIndex;
				}
			}
		}
	}

	// None card table bingo
	if( ucAcqNum==0 )
	{
		return ERR_UNSUPPORT_CARD;
	}

	//judge NE card, linzhao
	if( (memcmp("\x58\x94\x17\x00\x00",  sPanHeader, 5)<=0  &&
		 memcmp("\x58\x94\x17\x99\x99", sPanHeader, 5)>=0 ) ||
		(memcmp("\x60\x32\x18\x00\x00",  sPanHeader, 5)<=0  &&
		 memcmp("\x60\x32\x18\x99\x99", sPanHeader, 5)>=0 )   )
	{
		glSysParam.bNECard = TRUE;

	}
	else
	{
		glSysParam.bNECard = FALSE;
	}

	OsLog(LOG_ERROR, "%s--%d, bNECard:%d", __FILE__, __LINE__, glSysParam.bNECard);//linzhao

	// Only one card table bingo
	if( ucAcqNum==1 )
	{
		pstCardTbl = &glSysParam.stCardTable[sCardIndex[ucLastAcqIdx]];
		FindIssuer(pstCardTbl->ucIssuerKey);
		FindAcq(pstCardTbl->ucAcqKey);
		return 0;
	}

	// More than one bingo
	if( ChkEdcOption(EDC_SELECT_ACQ_FOR_CARD) &&
		(glProcInfo.stTranLog.ucTranType!=INSTALMENT))
	{
		// é‌‍installmentو—¶ï¼Œو‰‹ه·¥é€‰و‹©و”¶هچ•è،Œ
		// if it is not an installment, select acquirer manually 
		iRet = SelectAcqForCard(sAcqMatchFlag, &ucCnt);
	}
	else
	{
		// è‡ھهٹ¨é€‰و‹©ن¸€ن¸ھو”¶هچ•è،Œ
		// Select automatically. 
		iRet = AutoAcqForCard(sAcqMatchFlag, &ucCnt);
	}
	if( iRet!=0 )
	{
		return iRet;
	}

	pstCardTbl = &glSysParam.stCardTable[sCardIndex[ucCnt]];
	FindIssuer(pstCardTbl->ucIssuerKey);
	FindAcq(pstCardTbl->ucAcqKey);

	return 0;
}

int MatchCardTableForInstalment(uchar ucIndex)
{
	uchar		ucCnt, ucPanLen, ucAcqNum;
	uchar		sPanHeader[5], sCardIndex[MAX_ACQ], sAcqMatchFlag[MAX_ACQ];
	CARD_TABLE	*pstCardTbl;

	memset(sCardIndex,    0, sizeof(sCardIndex));
	memset(sAcqMatchFlag, 0, sizeof(sAcqMatchFlag));

	// ه»؛ç«‹و”¶هچ•è،Œهˆ—è،¨
	// create a list of matched acquirer.
	ucPanLen = strlen((char *)glProcInfo.stTranLog.szPan);
	PubAsc2Bcd(glProcInfo.stTranLog.szPan, 10, sPanHeader);

	for(ucAcqNum=ucCnt=0; ucCnt<glSysParam.ucCardNum; ucCnt++)
	{
		pstCardTbl = &glSysParam.stCardTable[ucCnt];
		if( (memcmp(pstCardTbl->sPanRangeLow,  sPanHeader, 5)<=0  &&
			 memcmp(pstCardTbl->sPanRangeHigh, sPanHeader, 5)>=0) &&
			(pstCardTbl->ucPanLength==0 || pstCardTbl->ucPanLength==ucPanLen) )
		{
			FindIssuer(pstCardTbl->ucIssuerKey);
			FindAcq(pstCardTbl->ucAcqKey);
			
			if (glCurAcq.ucIndex != ucIndex)
			{
				continue;	
			}
			
			if( glSysCtrl.sAcqStatus[glCurAcq.ucIndex]==S_USE  ||
				glSysCtrl.sAcqStatus[glCurAcq.ucIndex]==S_PENDING )
			{
				return 0;
			}
		}
	}

	return ERR_UNSUPPORT_CARD;
}

// و ¹وچ®هچ،هڈ·هŒ¹é…چçڑ„و”¶هچ•è،Œن؟،وپ¯,وڈگç¤؛ç”¨وˆ·é€‰و‹©و”¶هچ•è،Œ
// Select acquirer for card. only select in already matched acquirers.
int SelectAcqForCard(const uchar *psAcqMatchFlag, uchar *pucCardIndex)
{
	int			iRet, iMenuNo, iValidAcqCnt;
	uchar		ucCnt, ucAcqNum, szPrompt[16+1];
	GUI_MENU		stAcqMenu;
	GUI_MENUITEM	stAcqMenuItem[MAX_ACQ+1];

	// build menu from candidate acquirer's list
	memset(stAcqMenuItem, 0, sizeof(stAcqMenuItem));
	for(ucAcqNum=ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		if( psAcqMatchFlag[ucCnt]==0 )
		{
			continue;
		}
		sprintf(stAcqMenuItem[ucAcqNum].szText, "%d.%.10s", ucAcqNum+1, glSysParam.stAcqList[ucCnt].szName);
		stAcqMenuItem[ucAcqNum].bVisible = TRUE;
		stAcqMenuItem[ucAcqNum].nValue = ucAcqNum;
		stAcqMenuItem[ucAcqNum].vFunc = NULL;
		ucAcqNum++;
	}
	strcpy(stAcqMenuItem[ucAcqNum].szText, "");
	stAcqMenuItem[ucAcqNum].bVisible = FALSE;
	stAcqMenuItem[ucAcqNum].nValue = -1;
	stAcqMenuItem[ucAcqNum].vFunc = NULL;

	// prompt use select acquirer
	sprintf((char *)szPrompt, _T("SELECT  HOST"));
	
	Gui_BindMenu(szPrompt, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stAcqMenuItem, &stAcqMenu);
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stAcqMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
	if( iRet != GUI_OK )
	{
		return (GUI_ERR_USERCANCELLED == iRet) ? ERR_USERCANCEL : ERR_SEL_ACQ;
	}

	// search selected acquirer index
	for(iValidAcqCnt=0,ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		if( psAcqMatchFlag[ucCnt]==0 )
		{
			continue;
		}
		if( iValidAcqCnt==iMenuNo )
		{
			*pucCardIndex = ucCnt;
			return 0;
		}
		iValidAcqCnt++;
	}

	return ERR_SEL_ACQ;
}

// و ¹وچ®ç‰¹ه®ڑçڑ„è§„هˆ™هŒ¹é…چوœ€ن¼کو”¶هچ•è،Œ
// match the most suitable acquirer based on a specific rule
int AutoAcqForCard(const uchar *psAcqMatchFlag, uchar *pucCardIndex)
{
	uchar	ucCnt;

	// هœ¨è؟™é‡Œو·»هٹ ه…¶ه®ƒهŒ¹é…چè§„هˆ™
	// add other match rule

	// è‡ھهٹ¨é€‰و‹©ن¸€ن¸ھو”¶هچ•è،Œ
	// Select automatically. 
	// if no special regulation, select the first matched.
	// installmentو—¶ç¨چه€™ن¼ڑé‡چو–°ه†³ه®ڑacquirerï¼Œه› و­¤çژ°هœ¨هڈ¯ن»¥éڑڈن¾؟ه…ˆه®ڑن¸€ن¸ھ
	// will re-select the acquirer later, so just pick the first options temporarily 
	for(ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		if( psAcqMatchFlag[ucCnt]!=0 )
		{
			*pucCardIndex = ucCnt;
			return 0;
		}
	}

	return ERR_SEL_ACQ;
}

/************************************************************************
* هˆ·هچ،ن؛‹ن»¶ه¤„çگ†ه‡½و•°
* bCheckICC:    TRUE  و£€وں¥2ç£پéپ“çڑ„service code(ه¯¹EMVç»ˆç«¯وœ‰و•ˆ)
*               FALSE ن¸چو£€وں¥
************************************************************************/
int SwipeCardProc(uchar bCheckICC)
{
	int		iRet;
	
	iRet = ReadMagCardInfo();
	if( iRet!=0 )
	{
		return iRet;
	}

	// ن؛¤وک“ن¸چè¦پو±‚هˆ¤و–­هچ،ç‰‡ç±»ه‍‹وˆ–è€…ن¸؛é‌‍EMVç»ˆç«¯,ç›´وژ¥è؟”ه›‍
	// if don't require to check the card type or it is a non-EMV terminal, return directly
	if( !bCheckICC || !ChkIfEmvEnable() )
	{
		return 0;
	}

	// EMVç»ˆç«¯,ç»§ç»­و£€وں¥
	// it is an EMV terminal, continue checking
	if( glProcInfo.bIsFallBack==TRUE )
	{
		if( IsChipCardSvcCode(glProcInfo.szTrack2) )
		{	// fallbackه¹¶ن¸”وک¯ICهچ،,هˆ™è؟”ه›‍وˆگهٹں
			// when it is a IC card and it needs fallback, return success
			glProcInfo.stTranLog.uiEntryMode = MODE_FALLBACK_SWIPE;
			return 0;
		}
		else
		{
			uchar szName[16+1];
			GetTransName(szName);
			MirroringSendEcr("NON EMV,RE-SWIPE");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(szName, gl_stTitleAttr, _T("NON EMV,RE-SWIPE"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			return ERR_NO_DISP;
		}
	}
	else if( IsChipCardSvcCode(glProcInfo.szTrack2) )
	{
		if( glProcInfo.stTranLog.ucTranType!=OFF_SALE &&
			glProcInfo.stTranLog.ucTranType!=REFUND   &&
			glProcInfo.stTranLog.ucTranType!=INSTALMENT )
		{
			MirroringSendEcr("PLS INSERT CARD");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS INSERT CARD"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			return ERR_NEED_INSERT;
		}
	}

	return 0;
}

#ifdef ENABLE_EMV
// ICCوڈ’هچ،ن؛‹ن»¶ه¤„çگ†ه‡½و•°
// Process insertion event.
int InsertCardProc(void)
{
	int		iRet;
	uchar	szTotalAmt[12+1], sTemp[6];

	// ه¦‚و‍œه·²ç»ڈFALLBACK,ه؟½ç•¥ICهچ،وڈ’هچ،و“چن½œ
	// if did fallback, will ignore the coming inserting processing
	if( glProcInfo.bIsFallBack==TRUE )
	{
		return ERR_NEED_FALLBACK;
	}

	//!!!! deleted: it is fixed and not allowed to modify after GPO.
	//ModifyTermCapForPIN();

	glProcInfo.stTranLog.uiEntryMode = MODE_CHIP_INPUT;

	DispProcess();

#ifdef ENABLE_EMV
	InitTransEMVCfg();
#endif

	// ه؛”ç”¨é€‰و‹©
	// EMV application selection. This is EMV kernel API
	iRet = EMVAppSelect(ICC_USER, glSysCtrl.ulSTAN);
	if( iRet==EMV_DATA_ERR || iRet==ICC_RESET_ERR || iRet==EMV_NO_APP ||
		iRet==ICC_CMD_ERR  || iRet==EMV_RSP_ERR )
	{

			glProcInfo.bIsFallBack = TRUE;
			glProcInfo.iFallbackErrCode = iRet;
			return ERR_NEED_FALLBACK;
	}
	if( iRet==EMV_TIME_OUT || iRet==EMV_USER_CANCEL )
	{
		return ERR_USERCANCEL;
	}
	if( iRet!=EMV_OK )
	{
	    if(iRet == ICC_BLOCK)
	        return iRet;
		dddoHentFMessage(39);
		return ERR_TRAN_FAIL;
	}

	// Clear log to avoid amount accumulation for floor limit checking
#ifndef _PROLIN2_4_  // Sxxx Prolin software platform does not support this API
    iRet = EMVClearTransLog();
#endif

	// Read Track 2 and/or Pan
	iRet = GetEmvTrackData();
	if( iRet!=0 )
	{
		return iRet;
	}
    
    // Display app prefer name
	//linzhao
	Gui_ClearScr();
    if (strlen(glProcInfo.stTranLog.szAppPreferName)!=0)
    {
    	MirroringSendEcr( glProcInfo.stTranLog.szAppPreferName);
  if (! MirroringCheckEcr())
    	    {
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, glProcInfo.stTranLog.szAppPreferName, gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
         }
    }
    else if (strlen(glProcInfo.stTranLog.szAppLabel)!=0)
    {
	  if (! MirroringCheckEcr())
    	    {
    	MirroringSendEcr( glProcInfo.stTranLog.szAppLabel);
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, glProcInfo.stTranLog.szAppLabel, gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
	    }
    }

	iRet = ValidCard();
	if( iRet!=0 )
	{
		return iRet;
	}
	UpdateEMVTranType();

#ifdef ENABLE_EMV
	// EMVSetMCKParam to set bypass PIN
	AppSetMckParam(ChkIssuerOption(ISSUER_EN_EMVPIN_BYPASS));
	//end
#endif

	// è¾“ه…¥ن؛¤وک“é‡‘é¢‌
	// enter transaction amount Remove AMOUNT
	if( glProcInfo.stTranLog.ucTranType!=RATE_BOC &&
		glProcInfo.stTranLog.ucTranType!=RATE_SCB &&
		glProcInfo.stTranLog.ucTranType!=VOID 	  &&
		glProcInfo.stTranLog.ucTranType!=VOID_AUTH &&
		glProcInfo.stTranLog.ucTranType!=COMPLETION &&
		glProcInfo.stTranLog.ucTranType!=BALANCE &&
		glProcInfo.stTranLog.ucTranType!=LOYALTY_INQUIRY &&
		glProcInfo.stTranLog.ucTranType!=SALE_INQUIRY)
	{
//		hhhHasan(glProcInfo.stTranLog.ucTranType);
		iRet = GetAmount();
		if( iRet!=0 )
		{
			return ERR_USERCANCEL;
		}
		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
		//PubAddHeadChars(szTotalAmt, 12, '0');  no need: already 12 digits
		PubAsc2Bcd(szTotalAmt, 12, sTemp);
		EMVSetTLVData(0x9F02, sTemp, 6);
		PubLong2Char((ulong)atol((char *)szTotalAmt), 4, sTemp);
		EMVSetTLVData(0x81, sTemp, 4);
	}

	DispProcess();

#ifdef _PROLIN2_4_
	//inject CAPK
	{
	    uchar sRID[20];
	    uchar sKidx[2];
	    int iLen = 0;
	    int iRet = EMVGetTLVData(0x4F, sRID, &iLen);
	    if(iRet != EMV_OK)
	    {
	        EMVGetTLVData(0x84, sRID, &iLen);
	    }
	    EMVGetTLVData(0x8F, sKidx, &iLen);
	    //OsLog(LOG_ERROR, "kidx:%d, %rid: %02x %02x %02x %02x %02x", sKidx[0], sRID[0], sRID[1], sRID[2], sRID[3], sRID[4]);
	    AddCAPKIntoEmvLib(sKidx[0], sRID);
	}
#endif

	// هچ،ç‰‡و•°وچ®è®¤è¯پ
	// Card data authentication
	if( glProcInfo.stTranLog.ucTranType==SALE ||
		glProcInfo.stTranLog.ucTranType==AUTH ||
		glProcInfo.stTranLog.ucTranType==PREAUTH )
	{
		iRet = EMVCardAuth();
		if( iRet!=EMV_OK )
		{
			dddoHentFMessage(40);
			return ERR_TRAN_FAIL;
		}
	}

	return 0;
}
#endif

#ifdef ENABLE_EMV
// è¯»هڈ–ICهچ،ç£پéپ“ن؟،وپ¯/هچ،هڈ·ن؟،وپ¯ç­‰
// read track information from IC card
int GetEmvTrackData(void)
{
	int		iRet, iLength;
	uchar	sTemp[50], szCardNo[20+1];
	int		i, bReadTrack2, bReadPan;

	// è¯»هڈ–ه؛”ç”¨و•°وچ®
	// read application data
	DispProcess();
	iRet = EMVReadAppData();
	if( iRet==EMV_TIME_OUT || iRet==EMV_USER_CANCEL )
	{
		return ERR_USERCANCEL;
	}
	if( iRet!=EMV_OK )
	{
		dddoHentFMessage(41);
		return ERR_TRAN_FAIL;
	}

	// Read Track 2 Equivalent Data
	bReadTrack2 = FALSE;
	memset(sTemp, 0, sizeof(sTemp));
	iRet = EMVGetTLVData(0x57, sTemp, &iLength);
	if( iRet==EMV_OK )
	{
		bReadTrack2 = TRUE;
		PubBcd2Asc0(sTemp, iLength, glProcInfo.szTrack2);
		PubTrimTailChars(glProcInfo.szTrack2, 'F');	// erase padded 'F' chars
		for(i=0; glProcInfo.szTrack2[i]!='\0'; i++)		// convert 'D' to '='
		{
			if( glProcInfo.szTrack2[i]=='D' )
			{
				glProcInfo.szTrack2[i] = '=';
				break;
			}
		}
	}

	// read PAN
	bReadPan = FALSE;
	memset(sTemp, 0, sizeof(sTemp));
	iRet = EMVGetTLVData(0x5A, sTemp, &iLength);
	if( iRet==EMV_OK )
	{
		PubBcd2Asc0(sTemp, iLength, szCardNo);
		PubTrimTailChars(szCardNo, 'F');		// erase padded 'F' chars
		if( bReadTrack2 && !MatchTrack2AndPan(glProcInfo.szTrack2, szCardNo) )
		{
			// ه¦‚و‍œTrack2 & PAN هگŒو—¶ه­کهœ¨,هˆ™ه؟…é،»هŒ¹é…چ
			// if Track2 & PAN exist at the same time, must match
			MirroringSendEcr("CARD ERROR");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CARD ERROR"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
			PromptRemoveICC();
			return ERR_NO_DISP;
//			return ERR_TRAN_FAIL;
		}
		sprintf((char *)glProcInfo.stTranLog.szPan, "%.19s", szCardNo);
		bReadPan = TRUE;
	}
	else if ( !bReadTrack2 )
	{
		// ه¦‚و‍œTrack 2 ه’Œ PAN éƒ½و²،وœ‰,هˆ™ن؛¤وک“ه¤±è´¥
		// no track #2, no PAN, no transaction
		dddoHentFMessage(42);
		return ERR_TRAN_FAIL;
	}
	if( !bReadPan )
	{
		// و²،وœ‰è¯»هڈ–PANï¼Œن½†وک¯وœ‰track 2
		// have not got PAN, but got track #2
		iRet = GetPanFromTrack(glProcInfo.stTranLog.szPan, glProcInfo.stTranLog.szExpDate);
		if( iRet!=0 )
		{
			dddoHentFMessage(43);
			return ERR_TRAN_FAIL;
		}
	}

	// read PAN sequence number
	glProcInfo.stTranLog.bPanSeqOK = FALSE;
	iRet = EMVGetTLVData(0x5F34, &glProcInfo.stTranLog.ucPanSeqNo, &iLength);
	if( iRet==EMV_OK )
	{
		glProcInfo.stTranLog.bPanSeqOK = TRUE;
	}

	// read Application Expiration Date
	if( bReadPan )
	{
		memset(sTemp, 0, sizeof(sTemp));
		iRet = EMVGetTLVData(0x5F24, sTemp, &iLength);
		if( iRet==EMV_OK )
		{
			PubBcd2Asc0(sTemp, 2, glProcInfo.stTranLog.szExpDate);
		}
	}

    // application label
	EMVGetTLVData(0x50, glProcInfo.stTranLog.szAppLabel, &iLength);	// application label
    // Issuer code table
    iRet = EMVGetTLVData(0x9F11, sTemp, &iLength);
    if ((iRet==0) && (sTemp[0]==0x01))
    {
	    EMVGetTLVData(0x9F12, glProcInfo.stTranLog.szAppPreferName, &iLength);  // Application prefer name
    }
    // Application ID
	iRet = EMVGetTLVData(0x4F, glProcInfo.stTranLog.sAID, &iLength);	// AID
	if( iRet==EMV_OK )
	{
		glProcInfo.stTranLog.ucAidLen = (uchar)iLength;
	}

	// read cardholder name
	memset(sTemp, 0, sizeof(sTemp));
	iRet = EMVGetTLVData(0x5F20, sTemp, &iLength);
	if( iRet==EMV_OK )
	{
		sprintf((char *)glProcInfo.stTranLog.szHolderName, "%.20s", sTemp);
	}

	return 0;
}
#endif

// و¯”è¾ƒ2ç£پéپ“ن؟،وپ¯ه’ŒPANوک¯هگ¦ن¸€è‡´(For ICC)
// Check whether track2 (from ICC) and PAN (from ICC) are same.
int MatchTrack2AndPan(const uchar *pszTrack2, const uchar *pszPan)
{
	int		i;
	uchar	szTemp[19+1];

	for(i=0; i<19 && pszTrack2[i]!='\0'; i++)
	{
		if( pszTrack2[i]=='=' )
		{
			break;
		}
		szTemp[i] = pszTrack2[i];
	}
	szTemp[i] = 0;

	if( strcmp((char *)szTemp, (char *)pszPan)==0 )
	{
		return TRUE;
	}

	return FALSE;
}

// ç،®è®¤هچ،هڈ·ن؟،وپ¯
// confirm PAN information
// Modified by Kim_LinHB 2014-08-18 v1.01.0004 from msgbox to infopage
// Modified by Kim_LinHB 2014/9/11 v1.01.0008 add msgbox for Sxx bug517
int ConfirmPanInfo(void)
{
#if defined(_Sxx_) || defined(_SP30_)
	int i;
	uchar szInfo[300] = "";
	uchar ucKey;
#else
	GUI_PAGE		stHexMsgPage;
#endif
	int		iIndex;
	uchar	szIssuerName[10+1];
	GUI_PAGELINE	stBuff[10];

	uchar			ucLines = 0;

	if( glProcInfo.stTranLog.ucTranType==SALE_OR_AUTH ||
		glProcInfo.stTranLog.ucTranType==SALE         ||
		glProcInfo.stTranLog.ucTranType==AUTH         ||
		glProcInfo.stTranLog.ucTranType==PREAUTH )
	{
		MirroringSendEcr("PLEASE WAIT...");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLEASE WAIT..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
		PreDial();
	}

	memset(stBuff, 0, sizeof(stBuff));

	iIndex = MatchCardBin(glProcInfo.stTranLog.szPan);
	if( iIndex>=0 )
	{
		sprintf(stBuff[ucLines].szLine, "%s", glSysParam.stIssuerNameList[iIndex].szEnglishName);
	}
	else
	{
		ConvIssuerName(glCurIssuer.szName, szIssuerName);
		sprintf(stBuff[ucLines].szLine, "%s", szIssuerName);
	}
	stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

	// Modified by Kim_LinHB 9/9/2014 v1.01.0007
	sprintf(stBuff[ucLines].szLine, "%s", glProcInfo.stTranLog.szHolderName);
	OsLog(LOG_ERROR, "%s--%d, stBuff[%d].szline:%s",
			__FILE__, __LINE__, ucLines, stBuff[ucLines].szLine);//linzhao
	stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

	// Modified by Kim_LinHB 2014-8-5 v1.01.0001 bug489
 	if(ChkIfDispMaskPan2())
 	{
 		MaskPan(glProcInfo.stTranLog.szPan, stBuff[ucLines].szLine);
 	}
 	else
	{
		strcpy(stBuff[ucLines].szLine, glProcInfo.stTranLog.szPan); // Modified by Kim_LinHB 2014-8-7 v1.01.0001 bug502-504
	}
 	stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

	if( ChkIssuerOption(ISSUER_EN_EXPIRY) )
	{
		sprintf(stBuff[ucLines].szLine, "EXP DATE:%2.2s/%2.2s", &glProcInfo.stTranLog.szExpDate[2], &glProcInfo.stTranLog.szExpDate[0]);
		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;
	}
#if defined(_Sxx_) || defined(_SP30_)
	for (i = 0; i < ucLines; ++i)
	{
		strcat(szInfo, stBuff[i].szLine);
		strcat(szInfo, "\n");
	}
	stBuff[0].stLineAttr.eFontSize = GUI_FONT_SMALL;
	
	while(1)
	{

		MirroringSendEcr(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel);
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowMsgBox(_T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), gl_stTitleAttr, szInfo, stBuff[0].stLineAttr, GUI_BUTTON_NONE, USER_OPER_TIMEOUT, &ucKey))
		{
			return ERR_USERCANCEL;
		}
		if(KEYENTER == ucKey)
			break;
	}
#else
	//linzhao
//	Gui_CreateInfoPage((char *)_T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), gl_stTitleAttr, stBuff, ucLines, &stHexMsgPage);
//	// Display message
//	Gui_ClearScr();
//	if(GUI_OK != Gui_ShowInfoPage(&stHexMsgPage, FALSE, USER_OPER_TIMEOUT))
//	{
//		return ERR_USERCANCEL;
//	}
#endif

#ifdef ENABLE_EMV
	// set EMV library parameters
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
		EMVGetParameter(&glEmvParam);
		memcpy(glEmvParam.MerchId, glCurAcq.szMerchantID, 15);
		memcpy(glEmvParam.TermId, glCurAcq.szTermID, 8);
		EMVSetParameter(&glEmvParam);
		// Only in this trasaction, so DON'T back up
	}
#endif

	return 0;
}

// RFU for HK
int MatchCardBin(const uchar *pszPAN)
{
	uchar	szStartNo[20+1], szEndNo[20+1];
	ushort	i;

	for(i=0; i<glSysParam.uiCardBinNum; i++)
	{
		PubBcd2Asc(glSysParam.stCardBinTable[i].sStartNo, 10, szStartNo);
		PubBcd2Asc(glSysParam.stCardBinTable[i].sEndNo,   10, szEndNo);
		if( memcmp(pszPAN, szStartNo, glSysParam.stCardBinTable[i].ucMatchLen)>=0 &&
			memcmp(pszPAN, szEndNo,   glSysParam.stCardBinTable[i].ucMatchLen)<=0 )
		{
			return (int)glSysParam.stCardBinTable[i].ucIssuerIndex;
		}
	}

	return -1;
}

void ConvIssuerName(const uchar *pszOrgName, uchar *pszOutName)
{
	char	*p;

	sprintf((char *)pszOutName, "%.10s", pszOrgName);
	p = strchr((char *)pszOutName, '_');
	if( p!=NULL )
	{
		*p = 0;
	}
}

// input CVV2 or 4DBC
int GetSecurityCode(void)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	if( !ChkIfNeedSecurityCode() )
	{
		return 0;
	}

	if( !ChkIfAmex() && ChkAcqOption(ACQ_ASK_CVV2) )
	{
		MirroringSendEcr("ENTER\nSECURITY CODE?");
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "ENTER\nSECURITY CODE?", gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
		{
			return 0;
		}
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = stInputAttr.nMaxLen = ChkIfAmex() ? 4 : 3;

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, ChkIfAmex() ? _T("ENTER 4DBC") : _T("SECURITY CODE"),
		gl_stLeftAttr, glProcInfo.szSecurityCode, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	glProcInfo.stTranLog.uiEntryMode |= MODE_SECURITYCODE;
	return 0;
}

// و ¹وچ®هڈ‚و•°è؟›è،Œ,هˆ·هچ،/وڈ’هچ،/è¾“ه…¥هچ،هڈ·
// Accept different entry mode due to input:ucMode
// ucMode: bit 8: 1=skipping check track 2 service code, 0=check
//         bit 7: 1=fallback swipe
//         bit 6: 1=skip detect ICC
int GetCard(uchar ucMode)
{
	int		iRet, iEventID;
	uchar	bCheckICC, ucKey;
	uchar 	ucNeedFallBack = FALSE;
	uchar ucInsertTimes = 0;

	if( (glProcInfo.stTranLog.uiEntryMode & 0x0F)!=MODE_NO_INPUT )
	{
		return 0;
	}

	if( ucMode & FALLBACK_SWIPE )
	{
		ucMode &= ~(SKIP_CHECK_ICC|CARD_INSERTED);	// clear bit 8, force to check service code
	}

	bCheckICC = !(ucMode & SKIP_CHECK_ICC);

	while( 1 )
	{
		iEventID = DetectCardEvent(ucMode);
		if( iEventID==CARD_KEYIN )
		{
			ucKey = getkey();
			if( ucKey==KEYCANCEL )
			{
				return ERR_USERCANCEL;
			}
			if( (ucMode & CARD_KEYIN) && ucKey>='0' && ucKey<='9' )
			{
				return ManualInputPan(ucKey);
			}
		}
		else if( iEventID==CARD_SWIPED )
		{

			iRet = SwipeCardProc(bCheckICC);
			if( iRet==0 )
			{
				return ValidCard();
			}
			else if( iRet==ERR_SWIPECARD )
			{
				DispMagReadErr();
			}
			else if( iRet==ERR_NEED_INSERT )
			{
				// وک¯èٹ¯ç‰‡هچ،
				// IC card
				if( !(ucMode & CARD_INSERTED) )
				{	
					// وœ¬è؛«ن؛¤وک“ن¸چه…پè®¸وڈ’هچ،
					// not allowed IC card
					return iRet;
				}
				// هژ»وژ‰هˆ·هچ،و£€وں¥
				// remove flag for check swiping
				ucMode &= ~CARD_SWIPED;
			}
			else
			{
				return iRet;
			}
		}
#ifdef ENABLE_EMV
		else if( iEventID==CARD_INSERTED )
		{
#if defined(ENABLE_EMV) && defined(_PROLIN2_4_)
		    // different from Monitor, on Prolin2.4, the EMV kernel will not store all AID, CAPK
		    // so application needs to store by itself, and re-load into the kernel for every EMV TXN
		    LoadEmvDefault();
#endif
			iRet = InsertCardProc();
			if( iRet==0 )
			{
				return 0;
			}
			else if( iRet==ERR_NEED_FALLBACK )
			{
				uchar szBuff[32];
				//add insert twice then fallback. linzhao
				if (FALSE == ucNeedFallBack)
				{
					ucMode = CARD_INSERTED;
					glProcInfo.bIsFallBack = FALSE;
					ucInsertTimes++;
					if (2 == ucInsertTimes)
					{
						ucNeedFallBack = TRUE;
					}
					DispFallBackInsertAgain();
					continue;
				}
				else
				{
					ucNeedFallBack = FALSE;
					DispFallBackPrompt();
					PromptRemoveICC();
					ucMode = CARD_SWIPED|FALLBACK_SWIPE;	// Now we don't support fallback to manual-PAN-entry
				}
			}
			else if( iRet==ERR_TRAN_FAIL )
			{
				MirroringSendEcr("NOT ACCEPTED");
				Gui_ClearScr();
				PubBeepErr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ACCEPTED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
				PromptRemoveICC();
				return ERR_NO_DISP;
			}
            else if( iRet==ICC_BLOCK )
            {
            	MirroringSendEcr("CARD BLOCKED");
                Gui_ClearScr();
                PubBeepErr();
                Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CARD BLOCKED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
                PromptRemoveICC();
                return ERR_NO_DISP;
            }
			else
			{
				return iRet;
			}
		}
#endif
	}

	return 0;
}

// ç”¨وˆ·è¾“ه…¥ن؛‹ن»¶و£€وµ‹(وŒ‰é”®/هˆ·هچ،/وڈ’هچ،)
// detect event from user(press key/ swipe card/ insert card)
int DetectCardEvent(uchar ucMode)
{
	unsigned char szPrompt[100];
	unsigned char szPrompt2[100];
	// ç£په¤´ن¸ٹç”µم€پو‰“ه¼€م€پو¸…ç¼“ه†²
	// reset magnetic module
	if( ucMode & CARD_SWIPED )
	{
		MagClose();
		MagOpen();
		MagReset();
	}

	Gui_ClearScr(); // Added by Kim_LinHB 2014-8-12 1.01.0003 bug513



	if( ucMode & FALLBACK_SWIPE )
	{
		sprintf(szPrompt, "%s\n%s", _T("PLS SWIPE CARD"), _T("FALL BACK"));
	}
	else if( (ucMode & CARD_SWIPED) && (ucMode & CARD_INSERTED) )
	{
		DispIndicator();

		if( ChkIfEmvEnable() )
		{
			sprintf(szPrompt, "%s", _T("SWIPE/INSERT ..."));
		}
		else
		{
			sprintf(szPrompt, "%s", _T("PLS SWIPE CARD"));
		}
	}
	else if( (ucMode & CARD_INSERTED)  )
	{
		if( !(ucMode & SKIP_DETECT_ICC) )
		{
			sprintf(szPrompt, "%s", _T("PLS INSERT CARD"));
		}
	}
	else
	{
		sprintf(szPrompt, "%s", _T("PLS SWIPE CARD"));
	}


	memset(szPrompt2,0,sizeof(szPrompt2));
	if (MirroringCheckEcr())
	{

		sprintf(szPrompt2, "AED %s\n\n%s", szAmountRMZI, szPrompt);//rmrmrrm ramzi JOD


	}else
	{
		sprintf(szPrompt2, "%s", szPrompt);
	}

	if (   (glProcInfo.stTranLog.ucTranType==MOTO) ) //EXPRESS_CHECKOUT
	{
		MirroringSendEcr("ENTER CARD NO");
		 SetCurrTitle("MOTO");
		 Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "ENTER CARD NO", gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);


	}

	else if (   (glProcInfo.stTranLog.ucTranType==EXPRESS_CHECKOUT) ) //EXPRESS_CHECKOUT
	{
		MirroringSendEcr("ENTER CARD NO");
		 SetCurrTitle("EXPRESS CHECKOUT");
		 Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "ENTER CARD NO", gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);


	}
	else
	{
		MirroringSendEcr(szPrompt2);
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szPrompt2, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
	}

	//  Add by lirz v1.02.0000 2014-11-27 !!!fix bug(because glEdcMsgPtr->MsgType=MAGCARD_MSG,fail to read Mag. card info.)
	glEdcMsgPtr->MsgType  = 0;
    kbflush();


	while( 1 )
	{
		if( 0 == kbhit() )
		{
			// وœ‰وŒ‰é”®ن؛‹ن»¶
			// pressed a key
			return CARD_KEYIN;
		}
		if( (ucMode & CARD_SWIPED) && (MagSwiped()==0) )
		{
			// وœ‰هˆ·هچ،ن؛‹ن»¶
			// swiped a card
			return CARD_SWIPED;
		}
		if( (ucMode & CARD_INSERTED) && ChkIfEmvEnable() )
		{
			if( ucMode & SKIP_DETECT_ICC )
			{
				// وœ‰وڈ’ه…¥ICهچ،ن؛‹ن»¶
				// inserted a card
				return CARD_INSERTED;
			}
			else if( IccDetect(ICC_USER)==0 )
			{
				// وœ‰وڈ’ه…¥ICهچ،ن؛‹ن»¶
				// inserted an IC card
				return CARD_INSERTED;	
			}
		}
	}

	return 0;
}

// وک¾ç¤؛Fallbackوڈگç¤؛ç•Œé‌¢
// display fallback prompt
void DispFallBackPrompt(void)
{
	uint	iCnt;
	unsigned char szBuff[100], szBuff2[100];

	sprintf(szBuff, "%s\n   %.*s", _T("PLS SWIPE CARD"), strlen(_T("PULL OUT")), "         ");
	sprintf(szBuff2, "%s\n   %s", _T("PLS SWIPE CARD"), _T("PULL OUT"));

	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
	iCnt = 0;
	while( IccDetect(0)==0 )
	{
		iCnt++;
		if( iCnt>4 )
		{
			//Gui_ClearScr(); // Removed by Kim_LinHB 2014-08-13 v1.01.0003 bug512
			Beep();
			if(iCnt%2)
			{
				MirroringSendEcr(szBuff2);
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff2, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
			}

			else
			{
				MirroringSendEcr(szBuff);
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
			}
		}
		DelayMs(500);
	}
}

void DispFallBackInsertAgain(void)
{
	uint	iCnt;
	unsigned char szBuff[100], szBuff2[100];

	sprintf(szBuff, "%s\n   %.*s", _T("PLS INSERT AGAIN"), strlen(_T("PULL OUT")), "         ");
	sprintf(szBuff2, "%s\n   %s", _T("PLS INSERT AGAIN"), _T("PULL OUT"));

	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
	iCnt = 0;
	while( IccDetect(0)==0 )
	{
		iCnt++;
		if( iCnt>4 )
		{
			Beep();
			if(iCnt%2)
			{
				MirroringSendEcr(szBuff2);
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff2, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
			}
			else
			{
				MirroringSendEcr(szBuff);
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
			}
		}
		DelayMs(500);
	}
}

// è¾“ه…¥é‡‘é¢‌هڈٹه°ڈè´¹
// Get amount and tips.
// Modified by lirz v1.02.0000
int GetAmount(void)
{
	int		iRet;
	uchar	szTotalAmt[12+1];

	if( glProcInfo.stTranLog.szAmount[0]!=0 )
	{
		return 0;
	}
	
	if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
    {
        if (0==EcrGetAmount(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount))
        {
            if (!ChkIfZeroAmt(glProcInfo.stTranLog.szAmount) ||
                !ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
            {
                memcpy(glProcInfo.stTranLog.szInitialAmount, glProcInfo.stTranLog.szAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
                PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
                if (!ValidBigAmount(szTotalAmt))
                {
                    return ERR_NO_DISP;
                }

    			glProcInfo.stTranLog.ucDccOption = DCC_TYPE_NODCC;
    #ifdef ENABLE_DCC
    			uchar szDcc[120];
    			//E_DCC is for all transaction but preauth.
    			if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
    			{
    				if(SALE == glProcInfo.stTranLog.ucTranType ||
    					AUTH == glProcInfo.stTranLog.ucTranType ||
    					OFF_SALE == glProcInfo.stTranLog.ucTranType ||
    					AUTH_COMPLETE == glProcInfo.stTranLog.ucTranType|| //linzhao 20160101
    					COMPLETION == glProcInfo.stTranLog.ucTranType)
    				{
    					//fix the bug:cannot exit when press cancel key. linzhao 20151125
    					iRet = TransDccRate();
    					if (0!=iRet)
    					{
    						return iRet;
    					}
    				}
    			}

    			//this auth will be change to preauth in the future. linzhao 20151229
    			if(0 ==GetEnv("H_DCC", szDcc) && '1' == szDcc[0])
    			{
    				if(	PREAUTH == glProcInfo.stTranLog.ucTranType )
    				{
    					//fix the bug:cannot exit when press cancel key. linzhao 20151125
    					iRet = TransDccRate();
    					if (0!=iRet)
    					{
    						return iRet;
    					}
    				}
    			}


    #endif // ENABLE_DCC

    			if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
    			{
    			    uchar szDCCTotal[12+1];

    			    sprintf(szDCCTotal, "%s", glProcInfo.stTranLog.stDccInfo.szAmount);

    	            if( !ConfirmAmount(NULL, szDCCTotal) )
    	            {
    	            	return ERR_USERCANCEL;
    	            }
    			}
    			else
    			{
    				if( !ConfirmAmount(NULL, szTotalAmt) )
    				{
    					return ERR_USERCANCEL;
    				}
    			}

                if (!AllowDuplicateTran())
                {
                    return ERR_USERCANCEL;
                }
                return 0;
            }
        }
    }

	while( 1 )
	{
		iRet = InputAmount(AMOUNT);
		if( iRet!=0 )
		{
			return iRet;
		}





		//del force sale without tip
		iRet = GetTipAmount();




		if( iRet!=0 )
		{
			return iRet;
		}

		iRet = GetSurchangeAmt();
		if (0!=iRet)
		{
		    return iRet;
		}
        uchar szEnableFee[8];

        if ((0==GetEnv("E_FEE", szEnableFee)) && (0!=atoi(szEnableFee)))
        {
            ConfirmSurChangeAmt("Service Charge:", glProcInfo.stTranLog.szSurFee);
        }

		memcpy(glProcInfo.stTranLog.szInitialAmount, glProcInfo.stTranLog.szAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);

		if ((0==GetEnv("E_FEE", szEnableFee)) && (0!=atoi(szEnableFee)))
		{
		    uchar szTotalAmt2[12+1];
		    strcpy(szTotalAmt2, szTotalAmt);
		    PubAscAdd(szTotalAmt2, glProcInfo.stTranLog.szSurFee, 12, szTotalAmt);
		}
		if (!ValidBigAmount(szTotalAmt))
		{
			// Modified by Kim_LinHB 2014-8-12 v1.01.0003 bug511
			MirroringSendEcr("EXCEED LIMIT");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("EXCEED LIMIT"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			memset(glProcInfo.stTranLog.szAmount, 0, sizeof(glProcInfo.stTranLog.szAmount));
			memset(glProcInfo.stTranLog.szTipAmount, 0, sizeof(glProcInfo.stTranLog.szTipAmount));
			continue;
		}
		if (AUTH_COMPLETE == glProcInfo.stTranLog.ucTranType)
		{
			if (DCC_TYPE_DCC == glProcInfo.stTranLog.ucDccOption)
			{
	            iRet = TransDccRate();
	            if (0!=iRet)
	            {
	            	return iRet;
	            }
			}

		}
		else
		{
        // Add by lirz v1.02.0000
			glProcInfo.stTranLog.ucDccOption = DCC_TYPE_NODCC;
#ifdef ENABLE_DCC
			uchar szDcc[120];
			if(0 ==GetEnv("E_DCC", szDcc) && '1' == szDcc[0])
			{
				if((SALE == glProcInfo.stTranLog.ucTranType ||
					AUTH == glProcInfo.stTranLog.ucTranType ||
                    OFF_SALE == glProcInfo.stTranLog.ucTranType ||
                    AUTH_COMPLETE == glProcInfo.stTranLog.ucTranType|| //linzhao 20160101
					COMPLETION == glProcInfo.stTranLog.ucTranType))
				{
					//fix the bug:cannot exit when press cancel key. linzhao 20151125
					iRet = TransDccRate();
					if (0!=iRet)
					{
						return iRet;
					}
				}
    			//this auth will be change to preauth in the future. linzhao 20151230
    			if(0 ==GetEnv("H_DCC", szDcc) && '1' == szDcc[0])
    			{
    				if(	PREAUTH == glProcInfo.stTranLog.ucTranType )
    				{
    					//fix the bug:cannot exit when press cancel key. linzhao 20151125
    					iRet = TransDccRate();
    					if (0!=iRet)
    					{
    						return iRet;
    					}
    				}
    			}

			}
#endif // ENABLE_DCC
		   // End add by lirz
		}

//		iRet = GetTipAmount();
//		if( iRet!=0 )
//		{
//			return iRet;
//		}
//
//		memcpy(glProcInfo.stTranLog.szInitialAmount, glProcInfo.stTranLog.szAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
//		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
//		if (!ValidBigAmount(szTotalAmt))
//		{
//			// Modified by Kim_LinHB 2014-8-12 v1.01.0003 bug511
//			Gui_ClearScr();
//			PubBeepErr();
//			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("EXCEED LIMIT"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
//			memset(glProcInfo.stTranLog.szAmount, 0, sizeof(glProcInfo.stTranLog.szAmount));
//			memset(glProcInfo.stTranLog.szTipAmount, 0, sizeof(glProcInfo.stTranLog.szTipAmount));
//			continue;
//		}
		
		if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
		{
		    uchar szDCCTotal[12+1];
//		    if(!ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
//		    {
//		        int iAmountOffset = 0;
//		        uchar szExchangeRate[12+1];
//
//                sprintf(szExchangeRate, "%012ld",
//                        PubAsc2Long(glProcInfo.stTranLog.stDccInfo.szDccExRate+1, glProcInfo.stTranLog.stHolderCurrency.ucDecimal + 1));
//
//                PubAscMul(szTotalAmt, szExchangeRate, szDCCTotal);
//
//                memset(glProcInfo.stTranLog.stDccInfo.szAmount, '0', sizeof(glProcInfo.stTranLog.stDccInfo.szAmount) - 1);
//                glProcInfo.stTranLog.stDccInfo.szAmount[sizeof(glProcInfo.stTranLog.stDccInfo.szAmount) - 1] = 0;
//                iAmountOffset = sizeof(glProcInfo.stTranLog.stDccInfo.szAmount) - 1 - (glProcInfo.stTranLog.stHolderCurrency.ucDecimal + 1);
//                memcpy(glProcInfo.stTranLog.stDccInfo.szAmount + iAmountOffset, szDCCTotal, glProcInfo.stTranLog.stHolderCurrency.ucDecimal + 1);
//		    }
		    sprintf(szDCCTotal, "%s", glProcInfo.stTranLog.stDccInfo.szAmount);

            if( ConfirmAmount(NULL, szDCCTotal) )
            {
                break;
            }
		}
		else
		{
			if( ConfirmAmount(NULL, szTotalAmt) )
			{
				break;
			}
		}
	}

	if( !AllowDuplicateTran() )
	{
		return ERR_USERCANCEL;
	}

	return 0;
}

// وٹٹن¸چهگ«ه°ڈو•°ç‚¹ï¼Œن¸چهگ«ignore digitçڑ„و•°ه­—ن¸²è½¬وچ¢ن¸؛ISO8583 bit4و ¼ه¼ڈçڑ„12ن½چASCIIو•°ه­—ن¸²
// convert the format of transaction amount
void AmtConvToBit4Format(uchar *pszStringInOut, uchar ucIgnoreDigit)
{
	uint	uiLen;

	if (pszStringInOut == NULL)
	{
		return;
	}
	
	uiLen = (uint)strlen((char *)pszStringInOut);
	if( uiLen>=(uint)(12-ucIgnoreDigit) )
	{
		return;
	}

	// ه‰چè،¥0
	// left pad with 0
	memmove(pszStringInOut+12-uiLen-ucIgnoreDigit, pszStringInOut, uiLen+1);
	memset(pszStringInOut, '0', 12-uiLen-ucIgnoreDigit);

	// هگژè،¥ignore digitن¸ھ0
	// right pad with 0, number of 0 equals to ucIgnoreDigit
	for (uiLen=0; uiLen<ucIgnoreDigit; uiLen++)
	{
		strcat((char *)pszStringInOut, "0");
	}
}

int GetInstalPlan(void)
{
	int				ii, iRet;
	ulong			ulAmt;
	uchar			ucTemp, sBuff[200];
	GUI_MENU		stPlanMenu;
 	GUI_MENUITEM	stPlanMenuItems[MAX_PLAN+1];
	INSTALMENT_PLAN	stPlanList[MAX_PLAN+1];

TAG_SELECT_PLAN:
	if (glProcInfo.stTranLog.ucTranType!=INSTALMENT)
	{
		return 0;
	}
	
	if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
    {
        if (0==EcrGetInstPlan(&ucTemp))
        {
            for (ii=0; ii<glSysParam.ucPlanNum; ii++)
            {
                if (glSysParam.stPlanList[ii].ucMonths==ucTemp)
                {
                    glProcInfo.stTranLog.ucInstalment = ucTemp;
//                    strcpy((char *)glProcInfo.stTranLog.szInstalProgID,    (char *)glSysParam.stPlanList[ii].szProgID);
//                    strcpy((char *)glProcInfo.stTranLog.szInstalProductID, (char *)glSysParam.stPlanList[ii].szProductID);
                    break;
                }
            }
            if (glProcInfo.stTranLog.ucInstalment)  // if found
            {
                ulAmt = atol(glProcInfo.stTranLog.szAmount);

                if (glSysParam.stPlanList[ii].ulBottomAmt > ulAmt)
                {
                    strcpy(sBuff, _T("LOWER THAN \nLIMIT AMOUNT\n"));
                    App_ConvAmountLocal(glProcInfo.stTranLog.szAmount, sBuff + strlen(sBuff), 0);
                    PubBeepErr();
                    MirroringSendEcr(sBuff);
                    Gui_ClearScr();
                    Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, sBuff, gl_stCenterAttr, GUI_BUTTON_OK, 5, NULL);
                    return ERR_NO_DISP;
                }

                iRet = MatchCardTableForInstalment(glSysParam.stPlanList[ii].ucAcqIndex);  // é‡چو–°ه†³ه®ڑACQ
                if (iRet!=0)
                {
                	MirroringSendEcr("UNSUPPORTED\nCARD");
                    Gui_ClearScr();
                    PubBeepErr();
                    Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED\nCARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
                    return ERR_NO_DISP;
                }

                return 0;
            }
        }
    }

	// ç”ںوˆگinstallment planèڈœهچ•
	// generate installment plan menu list
	memset(stPlanMenuItems, 0, sizeof(stPlanMenuItems));
	memset(stPlanList,  0, sizeof(stPlanList));
	for (ii=0; ii<glSysParam.ucPlanNum; ii++)
	{
		sprintf((char *)stPlanMenuItems[ii].szText, "%d.%s", ii + 1, (char *)glSysParam.stPlanList[ii].szName);
		stPlanMenuItems[ii].bVisible = TRUE;
		stPlanMenuItems[ii].nValue = ii;
		stPlanMenuItems[ii].vFunc = NULL;
		stPlanList[ii] = glSysParam.stPlanList[ii];
	}
	strcpy((char *)stPlanMenuItems[ii].szText, "");
	stPlanMenuItems[ii].bVisible = FALSE;
	stPlanMenuItems[ii].nValue = -1;
	stPlanMenuItems[ii].vFunc = NULL;

	Gui_BindMenu(_T("SELECT PLAN"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stPlanMenuItems, &stPlanMenu);

	Gui_ClearScr();
	ii = 0;
	iRet = Gui_ShowMenuList(&stPlanMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &ii);
	if (iRet<0)
	{
		return ERR_USERCANCEL;
	}

	ulAmt = atol(glProcInfo.stTranLog.szAmount);
	if (stPlanList[ii].ulBottomAmt > ulAmt)
	{
		sprintf(sBuff, "%s\n%s\n", _T("LOWER THAN"), _T("LIMIT AMOUNT"));
		PubConvAmount(NULL, glProcInfo.stTranLog.szAmount,
					glProcInfo.stTranLog.stTranCurrency.ucDecimal,
					glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit,
					sBuff+strlen(sBuff), 0);

		Gui_ClearScr();
		PubBeepErr();
#ifdef _Sxxx
		MirroringSendEcr(sBuff); //beback
		Gui_ShowMsgBox(GetCurrTitle(),gl_stTitleAttr, sBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
#else
		MirroringSendEcr(sBuff);
		Gui_ShowMsgBox(GetCurrTitle(),gl_stTitleAttr, sBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 5, NULL);
#endif
		goto TAG_SELECT_PLAN;
	}

 	glProcInfo.stTranLog.ucInstalment = stPlanList[ii].ucMonths;
 	
	// é‡چو–°ه†³ه®ڑACQ
	// re-select ACQ
	iRet = MatchCardTableForInstalment(stPlanList[ii].ucAcqIndex);
	if (iRet!=0)
	{
		MirroringSendEcr("UNSUPPORTED\nCARD");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED\nCARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}
 	
 	return 0;
}

// Use local currency to call PubConvAmount
void App_ConvAmountLocal(const uchar *pszIn, uchar *pszOut, uchar ucMisc)
{
	uchar	szBuff[12];

	memset(szBuff, 0, sizeof(szBuff));
	strcpy((char *)szBuff, (char *)glSysParam.stEdcInfo.stLocalCurrency.szName);
	if ((glSysParam.stEdcInfo.ucCurrencySymbol!=' ')
		&& (glSysParam.stEdcInfo.ucCurrencySymbol!=0) )
	{
		szBuff[strlen(szBuff)] = glSysParam.stEdcInfo.ucCurrencySymbol;
	}

	PubConvAmount(szBuff, pszIn,
				glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
				glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit,
				pszOut, ucMisc);
}

// Use transaction currency to call PubConvAmount (MAYBE different form local currency)
void App_ConvAmountTran(const uchar *pszIn, uchar *pszOut, uchar ucMisc)
{
	uchar	szBuff[12];

	memset(szBuff, 0, sizeof(szBuff));

	strcpy((char *)szBuff, (char *)glProcInfo.stTranLog.stTranCurrency.szName);
	PubConvAmount(szBuff, pszIn,
				glProcInfo.stTranLog.stTranCurrency.ucDecimal,
				glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit,
				pszOut, ucMisc);
}

// Use transaction currency to call PubConvAmount (for foreign currency)
void App_ConvAmountDccTran(const uchar *pszIn, uchar *pszOut, uchar ucMisc)
{
	uchar	szBuff[12];

	memset(szBuff, 0, sizeof(szBuff));
	sprintf((char *)szBuff, "%s", (char *)glProcInfo.stTranLog.stHolderCurrency.szName);

	PubConvAmount(szBuff, pszIn,
		glProcInfo.stTranLog.stHolderCurrency.ucDecimal,
		glProcInfo.stTranLog.stHolderCurrency.ucIgnoreDigit,
		pszOut, ucMisc);
}

// è¾“ه…¥ن؛¤وک“é‡‘é¢‌
// enter transaction amount
int InputAmount(uchar ucAmtType)
{
	uchar	*pszAmt;
	uchar	szBuff[100];
	
	GUI_INPUTBOX_ATTR stInputAttr;

	//28.11.2016 add Visa eord in mag and fullback inaudit Reoprt
	 if (strcmp(glProcInfo.stTranLog.szAppLabel,"")==0)
	 {

		 memset( glProcInfo.stTranLog.szAppLabel,0,sizeof( glProcInfo.stTranLog.szAppLabel));
		  strcpy( glProcInfo.stTranLog.szAppLabel, glCurIssuer.szName);
	 }


	PubASSERT( ucAmtType==AMOUNT    || ucAmtType==RFDAMOUNT ||
			   ucAmtType==ORGAMOUNT || ucAmtType==TIPAMOUNT);

	switch( ucAmtType )
	{
	case AMOUNT:
		if( ChkIfNeedTip() )
		{
			strcpy(szBuff, _T("BASE AMOUNT"));
		}
		else
		{
			strcpy(szBuff, _T("ENTER AMOUNT"));
		}
		break;

	case RFDAMOUNT:	// RFU
		strcpy(szBuff, _T("REFUND AMOUNT"));
		break;

	case ORGAMOUNT:	// RFU
		strcpy(szBuff, _T("ORIGINAL AMOUNT"));
		break;

	case TIPAMOUNT:
		strcpy(szBuff, _T("ENTER TIP"));
		break;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_AMOUNT;
	stInputAttr.bEchoMode = 1;

	stInputAttr.ucDeciPos = glProcInfo.stTranLog.stTranCurrency.ucDecimal;
	sprintf(stInputAttr.szPrefix, "%.3s", glSysParam.stEdcInfo.stLocalCurrency.szName);
// 	sprintf((char *)szCurrName, "%.3s%1.1s", glSysParam.stEdcInfo.szCurrencyName, &glSysParam.stEdcInfo.ucCurrencySymbol);
	stInputAttr.nMinLen = (ucAmtType==TIPAMOUNT) ? 0 : 1;
	stInputAttr.nMaxLen = MIN(glSysParam.stEdcInfo.ucTranAmtLen, 10);
	if( glProcInfo.stTranLog.ucTranType==REFUND || ucAmtType==RFDAMOUNT )
	{
		strcat(stInputAttr.szPrefix, "-");
	}


//	if (  (glProcInfo.stTranLog.ucTranType == SINGLE_TIP) || (glProcInfo.stTranLog.ucTranType == FandB_PURCHASE)  )
//				{
//					ucAmtType=TIPAMOUNT;
//				}




	while(1)
	{
		if( ucAmtType==TIPAMOUNT )
		{
//			if (  (glProcInfo.stTranLog.ucTranType == SINGLE_TIP) || (glProcInfo.stTranLog.ucTranType == FandB_PURCHASE)  )
//			{
//			  pszAmt = glProcInfo.stTranLog.szTipAmount;
//			}
//			else
//			{
//				break ;
//			}
			  pszAmt = glProcInfo.stTranLog.szTipAmount;
		}
		else
		{
			pszAmt = glProcInfo.stTranLog.szAmount;
		}
		
		Gui_ClearScr();
		int iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stLeftAttr, pszAmt,
			gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
        if( GUI_OK != iRet)
		{
			return ERR_USERCANCEL;
		}

		if (ucAmtType != TIPAMOUNT) // Added by Kim_LinHB 9/9/2014 v1.01.0007 bug520
		{
			if(0 == atoi(pszAmt))
			{
				Beep();
				continue;
			}
		}
		// Use transaction currency to do conversion
		AmtConvToBit4Format(pszAmt, glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit);
		return 0;
	}
	return 0;
}

// è¾“ه…¥TIPé‡‘é¢‌
// enter tip
int GetTipAmount(void)
{
	int		iRet;
	uchar	szTotalAmt[12+1];

	if( !ChkIfNeedTip() )
	{
		return 0;
	}

	while( 1 )
	{



		iRet = InputAmount(TIPAMOUNT);




		if( iRet!=0 )
		{
			return iRet;
		}

		int iTip =atoi(glProcInfo.stTranLog.szTipAmount);
		 if (iTip==0)
		 {
			 continue ;
		 }


		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
		if( ValidAdjustAmount(glProcInfo.stTranLog.szAmount, szTotalAmt) )
		{
			break;
		}
	}

	return 0;
}


int GetSurchangeAmt()
{
    uchar szEnableFee[8], szFeeVal[24], szPercent[16], *pDotLoc = NULL, szResult[12+1], szResult2[12+1];
    uchar szFeeValP[24],szFeeValN[24];//
    int iResult2=0;//
    double uTransAmt, uFeeVal, uPercent;
    uchar szTransAmt[12+1];
    int iResult=0;

    if(0==GetEnv("E_FEE", szEnableFee))
    {
        if (0==GetEnv("FEE_VAL", szFeeVal) && 0!=atoi(szEnableFee))
        {
            setFeePN(szFeeVal,&szFeeValP,&szFeeValN);
            OsLog(LOG_ERROR, "%s--%d, szEnableFee:%s, szFeeVal:%s", __FILE__, __LINE__, szEnableFee, szFeeVal);//linzhao
            OsLog(LOG_ERROR, "%s--%d--szFeeValN=%s--szFeeValP=%s", __FILE__, __LINE__,szFeeValN,szFeeValP);//hasan fee value

            int i;
            for (i=0; i<strlen(szFeeValP); i++)
            {
                if('%'==szFeeValP[i])
                                {
                                    uTransAmt = atoi(glProcInfo.stTranLog.szAmount);

                                    szFeeValP[i] = 0;
                                    uPercent = atof(szFeeValP);
                                    uFeeVal =  uPercent * uTransAmt / 100;

                                    sprintf(szResult, "%f", uFeeVal);

                                    pDotLoc = strchr(szResult, '.');
                                    if (NULL!=pDotLoc)
                                    {
                                        *pDotLoc = '\0';
                                    }
                                    iResult2 = atoi(szResult);
                                    OsLog(LOG_ERROR,"%s=%d",szResult,iResult2);
                                   // sprintf(glProcInfo.stTranLog.szSurFee,"%.12d", iResult);

                                    //return 0;
                                }//if('%'==szFeeVal[i])

                            }//for (i=0; i<strlen(szFeeVal); i++)


                            uFeeVal = atof(szFeeValN);
                            uFeeVal *= 1000;
                            sprintf(szResult, "%f", uFeeVal);

                            pDotLoc = strchr(szResult, '.');
                            if (NULL!=pDotLoc)
                            {
                                *pDotLoc = '\0';
                            }

                            iResult = atoi(szResult);

                            iResult =iResult+iResult2;


                            OsLog(LOG_ERROR, "%s--%d--szResult=%s--iResult=%d--iResult2=%d", __FILE__, __LINE__,szResult,iResult,iResult2);//hasan fee value
                            sprintf(glProcInfo.stTranLog.szSurFee,"%.12d", iResult);
                        }//if (0==GetEnv("FEE_VAL", szFeeVal) && 0!=atoi(szEnableFee))
                    }//if(0==GetEnv("E_FEE", szEnableFee))

                    return 0;
}


// و£€وں¥è°ƒو•´é‡‘é¢‌وک¯هگ¦هگˆو³•(TRUE: هگˆو³•, FALSE: é‌‍و³•)
// é‡‘é¢‌ه؟…é،»ن¸؛12و•°ه­—
// check if the amount adjusted is valid, amount must be a 12 digits string number
uchar ValidAdjustAmount(const uchar *pszBaseAmt, uchar *pszTotalAmt)
{
	uchar	szMaxAmt[15+1], szAdjRate[3+1];


	if( memcmp(pszTotalAmt, pszBaseAmt, 12)<0 )
	{
		MirroringSendEcr("AMOUNT ERROR");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(_T("ADJUST"), gl_stTitleAttr, _T("AMOUNT ERROR"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return FALSE;
	}

	if( glCurIssuer.ucAdjustPercent==0 || memcmp(pszTotalAmt, pszBaseAmt, 12)==0 )
	{
		return TRUE;
	}

	sprintf((char *)szAdjRate, "%ld", (ulong)(glCurIssuer.ucAdjustPercent+100));
	PubAscMul(pszBaseAmt, szAdjRate, szMaxAmt);
	PubAddHeadChars(szMaxAmt, 15, '0');

	// ignore the last 2 digits
	if( memcmp(pszTotalAmt, &szMaxAmt[1], 12)>0 )
	{
		MirroringSendEcr("OVER LIMIT");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(_T("ADJUST"), gl_stTitleAttr, _T("OVER LIMIT"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return FALSE;
	}

	return TRUE;
}

// amount should be less than 4294967296 (max of unsigned long)
uchar ValidBigAmount(const uchar *pszAmount)
{
	int	iLen;

	iLen = strlen(pszAmount);
	if (iLen<10)
	{
		return TRUE;
	}
	if (iLen>12)
	{
		return FALSE;
	}
	if (PubAsc2Long(pszAmount, iLen-3)>4294966)
	{
		return FALSE;
	}
	return TRUE;
}

// ç،®è®¤é‡‘é¢‌ç•Œé‌¢ه¤„çگ†
// confirm transaction amount
// Modified by Kim_LinHB 2014-08-13 v1.01.0003
uchar ConfirmAmount(const char *pszDesignation, uchar *pszAmount)
{
	uchar szDispBuff[200];
	uchar szDccAmout[100];
	GUI_TEXT_ATTR stTextAttr = gl_stCenterAttr;

	OsLog(LOG_ERROR, "%s--%d--%s", __FILE__, __LINE__, __FUNCTION__);
	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
		uchar szTotalAmt[12 + 1];
		sprintf(szDccAmout, "%s\n", "DCC AMOUNT");
		sprintf(szDispBuff, "%s", szDccAmout);
		//linzhao 20160101
        PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTotalAmt);
        OsLog(LOG_ERROR, "%s--%d, szTotalAmt:%s", __FILE__, __LINE__, szTotalAmt);//linzhao 20160101
		GetDispDccAmount(szTotalAmt, szDispBuff+strlen(szDccAmout));
	}
	else
	{
		if(pszDesignation!=NULL && pszDesignation[0]!=0)
		{
			sprintf(szDispBuff, "%s\n", pszDesignation);
			GetDispAmount(pszAmount, szDispBuff+strlen(pszDesignation));
		}
		else
		{
			GetDispLocalAmount(pszAmount, szDispBuff);
		}
	}
	
	strcat(szDispBuff, "\n");

	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
		strcat(szDispBuff, _T("MARKUP ON EXC RATE\n"));
		strcat(szDispBuff,  glProcInfo.stTranLog.stDccInfo.szDccMarginRate);
		strcat(szDispBuff,  "%\n");
	}
	else
		strcat(szDispBuff, _T("CORRECT ?"));

	Gui_ClearScr();

    if(!ChkTerm(_TERMINAL_D200_))
        stTextAttr.eFontSize = GUI_FONT_NORMAL;

 if (! MirroringCheckEcr())
   	    {
    //linzhao 20150909
    MirroringSendEcr(szDispBuff);
	if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispBuff, stTextAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
	{
		return FALSE;
	}
	return TRUE;

	}
    else
    {
    	return TRUE;
    }
}

uchar ConfirmSurChangeAmt(const char *pszDesignation, uchar *pszAmount)
{
       uchar szDispBuff[200];
       uchar szDccAmout[100];
       GUI_TEXT_ATTR stTextAttr = gl_stCenterAttr;

       OsLog(LOG_ERROR, "%s--%d--%s", __FILE__, __LINE__, __FUNCTION__);
       if(pszDesignation!=NULL && pszDesignation[0]!=0)
       {
           sprintf(szDispBuff, "%s\n", pszDesignation);
           GetDispAmount(pszAmount, szDispBuff+strlen(pszDesignation));
       }
       else
       {
           GetDispLocalAmount(pszAmount, szDispBuff);
       }

       strcat(szDispBuff, "\n");

//       if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
//       {
//           strcat(szDispBuff, _T("MARKUP ON EXC RATE\n"));
//           strcat(szDispBuff,  glProcInfo.stTranLog.stDccInfo.szDccMarginRate);
//           strcat(szDispBuff,  "%\n");
//       }
//       else
//           strcat(szDispBuff, _T("CORRECT ?"));
//
       Gui_ClearScr();

       if(!ChkTerm(_TERMINAL_D200_))
           stTextAttr.eFontSize = GUI_FONT_NORMAL;

       //linzhao 20150909
       MirroringSendEcr(szDispBuff);
       if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispBuff, stTextAttr, GUI_BUTTON_OK, USER_OPER_TIMEOUT, NULL))
       {
           return FALSE;
       }
       return TRUE;
}


// هœ¨وŒ‡ه®ڑè،Œوک¾ç¤؛و ¼ه¼ڈهŒ–çڑ„é‡‘é¢‌ن؟،وپ¯م€‚و³¨و„ڈé‡‘é¢‌وک¯bit4و ¼ه¼ڈï¼Œهچ³هڈ¯èƒ½هگ«وœ‰ignore digit
// Get formatted amount
void GetDispAmount(uchar *pszAmount, uchar *pszDispBuff)
{
	uchar	ucFlag, szOutAmt[30];

	ucFlag = 0;
	if( glProcInfo.stTranLog.ucTranType==VOID || glProcInfo.stTranLog.ucTranType==REFUND ||
		VOID_AUTH==glProcInfo.stTranLog.ucTranType || *pszAmount=='D' )
	{
		ucFlag |= GA_NEGATIVE;
		if( *pszAmount=='D' )
		{
			*pszAmount = '0';
		}
	}
	App_ConvAmountTran(pszAmount, szOutAmt, ucFlag);
	if(pszDispBuff){
		sprintf(pszDispBuff, "%.21s", szOutAmt);
	}
}

// هœ¨وŒ‡ه®ڑè،Œوک¾ç¤؛و ¼ه¼ڈهŒ–çڑ„é‡‘é¢‌ن؟،وپ¯م€‚و³¨و„ڈé‡‘é¢‌وک¯bit4و ¼ه¼ڈï¼Œهچ³هڈ¯èƒ½هگ«وœ‰ignore digit
// Get formatted amount
void GetDispLocalAmount(uchar *pszAmount, uchar *pszDispBuff)
{
	uchar	ucFlag, szOutAmt[30];

	ucFlag = 0;
	if( glProcInfo.stTranLog.ucTranType==VOID || glProcInfo.stTranLog.ucTranType==REFUND ||
			VOID_AUTH==glProcInfo.stTranLog.ucTranType || *pszAmount=='D' )
	{
		ucFlag |= GA_NEGATIVE;
		if( *pszAmount=='D' )
		{
			*pszAmount = '0';
		}
	}
	App_ConvAmountLocal(pszAmount, szOutAmt, ucFlag);
	if(pszDispBuff){
		sprintf(pszDispBuff, "%.21s", szOutAmt);
	}
}

void GetDispDccAmount(uchar *pszAmount, uchar *pszDispBuff)
{
	uchar	ucFlag, szOutAmt[30];

	ucFlag = 0;
	if( glProcInfo.stTranLog.ucTranType==VOID || glProcInfo.stTranLog.ucTranType==REFUND ||
		VOID_AUTH==glProcInfo.stTranLog.ucTranType || *pszAmount=='D' )
	{
		ucFlag |= GA_NEGATIVE;
		if( *pszAmount=='D' )
		{
			*pszAmount = '0';
		}
	}

	App_ConvAmountDccTran(pszAmount, szOutAmt, ucFlag);
	if(pszDispBuff)
	{
		sprintf(pszDispBuff, "%.21s", szOutAmt);
	}
}

// ن»ژUsrMsgهڈ–ه¾—هچ،هڈ·
// Format: "CARDNO=4333884001356283"
int GetManualPanFromMsg(const void *pszUsrMsg)
{
	sprintf(glProcInfo.stTranLog.szPan, "%.19s", (char *)pszUsrMsg);
	if (!IsNumStr(glProcInfo.stTranLog.szPan))
	{
		return ERR_NO_DISP;
	}

	return VerifyManualPan();
}

// و‰‹ه·¥è¾“ه…¥PANهڈٹه…¶ç›¸ه…³ن؟،وپ¯
// enter PAN manually
int ManualInputPan(uchar ucInitChar)
{
	int indexTry=0;
	GUI_INPUTBOX_ATTR stInputAttr;
	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType	= GUI_INPUT_NUM;
	stInputAttr.nMinLen = 13;
	stInputAttr.nMaxLen = LEN_PAN;


 for (indexTry=1;indexTry<=3;indexTry++)
 {


	memset(glProcInfo.stTranLog.szPan, 0, sizeof(glProcInfo.stTranLog.szPan));

	if (indexTry==1)
	{
		if( ucInitChar>='0' && ucInitChar<='9' )
		{
			glProcInfo.stTranLog.szPan[0] = ucInitChar;
		}


	}
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(NULL, gl_stTitleAttr, _T("ENTER CARD NO"), gl_stLeftAttr,
		glProcInfo.stTranLog.szPan, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_NO_DISP;
	}

	////============================================luhn
  // fffFOURA(glProcInfo.stTranLog.szPan);
	if (  ! ((glProcInfo.stTranLog.szPan[0]=='6') &&  (glProcInfo.stTranLog.szPan[1]=='2')  )     )
	{



				if (  !luhnFoura(glProcInfo.stTranLog.szPan)  ){

				   if (	indexTry>=3)
				   {
					   return ERR_NO_DISP;
				   }


			}else
			{
				break ;
			}


	}else
	{
		break;
	}

 }
	//==================================================
	if (glProcInfo.bIsFallBack==TRUE)
	{
		glProcInfo.stTranLog.uiEntryMode = MODE_FALLBACK_MANUAL;
	}

	return VerifyManualPan();
}

int VerifyManualPan(void)
{
	int		iRet;

	glProcInfo.stTranLog.uiEntryMode = MODE_MANUAL_INPUT;

	iRet = MatchCardTable(glProcInfo.stTranLog.szPan);
	if( iRet!=0 )
	{
		MirroringSendEcr("UNSUPPORTED\nCARD");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("UNSUPPORTED\nCARD"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	if( !ChkIssuerOption(ISSUER_EN_MANUAL) )
	{
		MirroringSendEcr("NOT ALLOW MANUL");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ALLOW MANUL"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}

	iRet = ValidPanNo(glProcInfo.stTranLog.szPan);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetExpiry();
	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkEdcOption(EDC_NOT_MANUAL_PWD) )
	{
		if( PasswordMerchant()!=0 )
		{
			return ERR_USERCANCEL;
		}
	}

	CheckCapture();
	iRet = ConfirmPanInfo();
	if( iRet!=0 )
	{
		CommOnHook(FALSE);
		return iRet;
	}

	iRet = GetSecurityCode();
	if( iRet!=0 )
	{
		return iRet;
	}

	return 0;
}

// è¾“ه…¥وœ‰و•ˆوœں
// enter expiry date
int GetExpiry(void)
{
	int		iRet;
	uchar	szExpDate[4+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	if( !ChkIssuerOption(ISSUER_EN_EXPIRY) )
	{
		sprintf((char *)glProcInfo.stTranLog.szExpDate, "1111");
		return 0;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.nMinLen = 4;
	stInputAttr.nMaxLen = 4;

	memset(szExpDate, 0, sizeof(szExpDate)); // Added by Kim_LinHB 2014-8-5 v1.01.0001 bug488

	while( 1 )
	{
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("EXP DATE: MMYY"), gl_stLeftAttr, 
			szExpDate, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		sprintf((char *)glProcInfo.stTranLog.szExpDate, "%.2s%.2s", &szExpDate[2], szExpDate);
		iRet = ValidCardExpiry();
		if( iRet==0 )
		{
			break;
		}
	}

	return 0;
}

// in COMPLETION transaction, get pre-transaction date
int GetPreTransDate(uchar *pszOutPreDate)
{
	int		iRet;
	uchar	szPreDate[8+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType   = GUI_INPUT_NUM;
	stInputAttr.nMinLen = 8;
	stInputAttr.nMaxLen = 8;

	memset(szPreDate, 0, sizeof(szPreDate));

	while( 1 )
	{
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("TRANS DATE:\nYYYYMMDD"), gl_stLeftAttr,
				     szPreDate, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
		{
			return ERR_USERCANCEL;
		}

		sprintf((char *)pszOutPreDate, "%8.8s", szPreDate);
		iRet = PubIsValidTime(szPreDate, "YYYYMMDD");
		if( iRet==0 )
		{
			break;
		}
		MirroringSendEcr("ERR DATE FORMAT");
		iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("ERR DATE FORMAT"), gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
		if(GUI_OK != iRet)
		{
			return ERR_USER_CANCEL;
		}
	}

	return 0;
}

// è¾“ه…¥ه•†ه“پوڈڈè؟°ن؟،وپ¯
int GetDescriptor(void)
{
	uchar	ucCnt, ucTotal = 0, bInputDesc = FALSE;
	GUI_INPUTBOX_ATTR stInputAttr;
	unsigned char szBuff[10];
	unsigned char szDesc[200];

	if( !ChkIssuerOption(ISSUER_EN_DISCRIPTOR) )
	{
		return 0;
	}

	if( glSysParam.ucDescNum==0 )
	{
		return 0;
	}
	if( glSysParam.ucDescNum==1 )
	{
		glProcInfo.stTranLog.szDescriptor[0] = '0';
		glProcInfo.stTranLog.ucDescTotal     = 1;
		return 0;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_NUM;
	stInputAttr.bEchoMode = 1;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = MAX_GET_DESC;

	memset(szBuff, 0, sizeof(szBuff));
	memset(szDesc, 0, sizeof(szDesc));
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("PRODUCT CODE?"), gl_stLeftAttr,
		szBuff, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	for (ucCnt = 0; ucCnt < strlen(szBuff); ++ucCnt)
	{
		if( strchr((char *)glProcInfo.stTranLog.szDescriptor, szBuff[ucCnt])==NULL &&
			szBuff[ucCnt]<glSysParam.ucDescNum+'0' )
		{
			glProcInfo.stTranLog.szDescriptor[ucTotal] = szBuff[ucCnt];
			ucTotal++;
			bInputDesc = TRUE;
		}
	}

	glProcInfo.stTranLog.ucDescTotal = ucTotal;
	if( bInputDesc )
	{
		GUI_TEXT_ATTR stDescAttr = gl_stCenterAttr;
		uchar ucDesc;
		for(ucCnt=0; ucCnt<ucTotal; ucCnt++)
		{
			ucDesc = glProcInfo.stTranLog.szDescriptor[ucCnt] - '0';
			sprintf(szDesc + strlen(szDesc), "%.21s\n", glSysParam.stDescList[ucDesc].szText);
		}
		if(strlen(szDesc) > ucTotal)
			szDesc[strlen(szDesc) - 1] = 0; // remove the last '\n'
		else
			szDesc[0] = '\n';

		MirroringSendEcr(szDesc);
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDesc, stDescAttr, GUI_BUTTON_OK, USER_OPER_TIMEOUT, NULL);
	}
	return 0;
}

// è¾“ه…¥é™„هٹ ن؟،وپ¯
// enter additional message.
int GetAddlPrompt(void)
{
	GUI_INPUTBOX_ATTR stInputAttr;

	if( !ChkAcqOption(ACQ_ADDTIONAL_PROMPT) && !ChkAcqOption(ACQ_AIR_TICKET) )
	{
		return 0;
	}

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 0;
	stInputAttr.nMaxLen = 16;

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, glSysParam.stEdcInfo.szAddlPrompt, gl_stLeftAttr,
		glProcInfo.stTranLog.szAddlPrompt, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	return 0;
}

// è¾“ه…¥PIN, ucFlag: bit 8, ICC online PIN
// enter PIN,ucFlag: bit 8, ICC online PIN
int GetPIN(uchar ucFlag)
{
	int		iRet;
	uchar	szPAN[16+1], szTotalAmt[12+1], szDispAmt[100];
	uchar	ucPinKeyID;
	uchar	ucAmtFlag, szBuff[25];
	GUI_TEXT_ATTR st_Small_Left = gl_stLeftAttr;
	OsLog(LOG_ERROR,"LOLO:zz%czz:%d:zz%x",ucFlag,ucFlag,ucFlag);



	// é‌‍EMV PINçڑ„و¨،ه¼ڈن¸‹ï¼Œه¦‚و‍œوک¯chipهˆ™ç›´وژ¥è؟”ه›‍ï¼Œن¸چوک¯chipهˆ™و£€وں¥ISSUER
	// in non-EMV-PIN mode, if it is chip transaction then return directly


	if(  !(ucFlag & GETPIN_EMV) )

	{





		if ( (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) && (ucFlag != GETPIN_RETRY))
		{

			return 0;
		}

		if ( (glProcInfo.stTranLog.uiEntryMode & MODE_SIGNATURE_REQ) && (!ChkIssuerOption(ISSUER_EN_PIN)) )//hasan 18.12.2016 add PIN REQUIRED
		{
			return 0;
		}

		if(!(glProcInfo.stTranLog.uiEntryMode & MODE_PIN_INPUT) && !(glProcInfo.stTranLog.uiEntryMode & MODE_PIN_SIGNATURE_REQ) &&    (!ChkIssuerOption(ISSUER_EN_PIN)))//hasan 18.12.2016 add PIN REQUIRED
		{
			return 0;
		}
// 		else if( !ChkIssuerOption(ISSUER_EN_PIN) )
// 		{
// 			return 0;
// 		}



//
//
//			if ( (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) )
//				{
//					return 0;
//				}
//				else if( !ChkIssuerOption(ISSUER_EN_PIN) )
//				{
//					return 0;
//				}
//

}




	// !!!! : é¢„ç•™و‰©ه±•ï¼ڑACQUIRERهڈ¯ه®ڑن¹‰è‡ھه·±ن½؟ç”¨çڑ„ID
	// extended, enable to use acquirer's own ID
	ucPinKeyID = DEF_PIN_KEY_ID;

	iRet = ExtractPAN(glProcInfo.stTranLog.szPan, szPAN);

	if( iRet!=0 )
	{
		return iRet;
	}


	ucFlag &= (uchar)(0xFF-GETPIN_EMV);
	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{

		uchar   szDisp[100];
		sprintf(szDisp, "%s          %s ", "AMOUNT", glProcInfo.stTranLog.stHolderCurrency.szName);
		GetDispDccAmount(glProcInfo.stTranLog.stDccInfo.szAmount, szDispAmt+strlen(szDisp));
	}
	else
	{

	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	    GetDispAmount(szTotalAmt, szDispAmt);
	}
	strcat(szDispAmt, "\n");

	if( ucFlag==0 )
	{
		strcat(szDispAmt, _T("PLS ENTER PIN"));
	}
	else
	{
		//return ONLINE_DENIAL;
		strcat(szDispAmt, _T("PIN ERR, RETRY"));//PIN ONLINE foura

	}
	strcat(szDispAmt, "\n");
	MirroringSendEcr(szDispAmt);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispAmt, st_Small_Left, GUI_BUTTON_NONE, 0, NULL);

	// show prompt message on PINPAD
	if (ChkTermPEDMode(PED_EXT_PP))
	{
		ucAmtFlag = 0;
		if( glProcInfo.stTranLog.ucTranType==VOID || glProcInfo.stTranLog.ucTranType==REFUND ||
			VOID_AUTH==glProcInfo.stTranLog.ucTranType )
		{
			ucAmtFlag |= GA_NEGATIVE;
		}
		App_ConvAmountTran(szTotalAmt, szBuff, ucFlag);
		// show amount on PINPAD
		MirroringSendEcr("(PLS USE PINPAD)");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "(PLS USE PINPAD)", gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
		PPScrCls();
		PPScrPrint(0, 0, szBuff);
	}

	if (ChkTermPEDMode(PED_INT_PCI))
	{
#ifdef _MONITOR_
		ScrGotoxy(32, 6); // FIXME: it should base on screen size Kim_LinHB
#endif
	}

	memset(glProcInfo.sPinBlock, 0, sizeof(glProcInfo.sPinBlock));


	//determin issuer TPK from TMK


	if (NULL != strstr(glCurIssuer.szName, "CUP"))//1
		{
		  ucPinKeyID = PIN_KEY_ID_CUP;
		}
	else if (NULL != strstr(glCurIssuer.szName, "MASTER"))//2
	{
	  ucPinKeyID = PIN_KEY_ID_MASTER ;
	}

	else if (NULL != strstr(glCurIssuer.szName, "MAESTRO"))//3
		{
		  ucPinKeyID = PIN_KEY_ID_MAESTRO;
		}
	else if (NULL != strstr(glCurIssuer.szName, "VISA"))//4
		{
		  ucPinKeyID = PIN_KEY_ID_VISA;
		}
	else if (NULL != strstr(glCurIssuer.szName, "JCB"))//5
		{
		  ucPinKeyID = PIN_KEY_ID_JCB;
		}
	else if (NULL != strstr(glCurIssuer.szName, "AMEX"))//6
		{
		  ucPinKeyID = PIN_KEY_ID_AMEX;
		}
	else if (NULL != strstr(glCurIssuer.szName, "NE"))//7
		{
		  ucPinKeyID = PIN_KEY_ID_NE;
		}


//	1	UPI CUP
//	2	Master Card
//	3	Maestro
//	4	Visa
//	5	JCB
//	6	Amex
//	7	NE



	// !!!! to be check
	//-------------- Internal PCI PED --------------
	if (ChkTermPEDMode(PED_INT_PCI))
	{





//OsLog(LOG_ERROR,"szPAN:%s",szPAN);
//OsLog(LOG_ERROR,"szPAN2222:%s",glProcInfo.stTranLog.szPan);
	//hasan 11.11.2016 add 6 digit for UPI
if (NULL != strstr(glCurIssuer.szName, "CUP"))
		{
	            iRet = PedGetPinBlock(ucPinKeyID, "0,4,5,6,7,8,12",szPAN, glProcInfo.sPinBlock, 0, USER_OPER_TIMEOUT*1000);
		}else
		{
			iRet = PedGetPinBlock(ucPinKeyID, "0,4,5,6,7,8", szPAN, glProcInfo.sPinBlock, 0, USER_OPER_TIMEOUT*1000);
		}



			//hhhHasanHEXPIN(glProcInfo.sPinBlock);




//int h;
     //iRet = PedGetPinBlock(ucPinKeyID, "0,4,5,6,7,8", "11111100", glProcInfo.sPinBlock, 3, USER_OPER_TIMEOUT*1000);




//		  for (h=0;h<8;h++)
//		  {
//		      OsLog(LOG_ERROR,"glProcInfo.sPinBlock:%x",glProcInfo.sPinBlock[h]);
//		  }

///-----------------------------------


//------------------------------

 /*
		 //FF 27 12 43 B1 1F 40 A4
		 glProcInfo.sPinBlock[0]='\xFF';
		 glProcInfo.sPinBlock[1]='\x27';
		 glProcInfo.sPinBlock[2]='\x12';
		 glProcInfo.sPinBlock[3]='\x43';
		 glProcInfo.sPinBlock[4]='\xB1';
		 glProcInfo.sPinBlock[5]='\x1F';
		 glProcInfo.sPinBlock[6]='\x40';
		 glProcInfo.sPinBlock[7]='\xA4';
	*/


/*
		 		 //FE B9 45 D4 E4 7A B2 4B

		 		 glProcInfo.sPinBlock[0]='\xFE';
		 		 glProcInfo.sPinBlock[1]='\xB9';
		 		 glProcInfo.sPinBlock[2]='\x45';
		 		 glProcInfo.sPinBlock[3]='\xD4';
		 		 glProcInfo.sPinBlock[4]='\xE4';
		 		 glProcInfo.sPinBlock[5]='\x7A';
		 		 glProcInfo.sPinBlock[6]='\xB2';
		 		 glProcInfo.sPinBlock[7]='\x4B';


*/
//		 		  for (h=0;h<8;h++)
//		 			  {
//		 			      OsLog(LOG_ERROR,"glProcInfo.sPinBlock:%x",glProcInfo.sPinBlock[h]);
//		 			  }

		if( iRet==0 )
		{
			glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
			UpdateF52();
			return 0;
		}
		else if (iRet==PED_RET_ERR_NO_PIN_INPUT)	// !!!! PIN bypass
		{
			glProcInfo.stTranLog.uiEntryMode |= MODE_PINBYPASS;
			glProcInfo.stTranLog.uiEntryMode |= MODE_SIGNATURE_REQ;
			return 0;
		}
		else if( iRet==PED_RET_ERR_INPUT_CANCEL )	// !!!! cancel input
		{
			return ERR_USERCANCEL;
		}


		DispPciErrMsg(iRet);

		return ERR_NO_DISP;
	}

	//-------------- External PCI PED --------------
	if (ChkTermPEDMode(PED_EXT_PCI))
	{
		// !!!! to be implemented
		MirroringSendEcr("EXT PCI PINPAD\nNOT IMPLEMENTED.");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "EXT PCI PINPAD\nNOT IMPLEMENTED.", gl_stCenterAttr, GUI_BUTTON_NONE, 30, NULL);
		return ERR_NO_DISP;
	}
	
	//-------------- PINPAD --------------

	if (ChkTermPEDMode(PED_EXT_PP))
	{

	    iRet = PPGetPwd_3Des(ucPinKeyID, 0x31, 4, 6, szPAN, glProcInfo.sPinBlock, 0);







	    DispWelcomeOnPED();
	}


	if( iRet==0 )
	{
		glProcInfo.stTranLog.uiEntryMode |= MODE_PIN_INPUT;
		return 0;
	}
	else if( iRet==0x0A )
	{
		return 0;	// PIN by pass
	}
	else if( iRet==0x06 || iRet==0x07 )
	{
		return ERR_USERCANCEL;
	}

	DispPPPedErrMsg((uchar)iRet);

	return ERR_NO_DISP;
}

void DispWelcomeOnPED(void)
{
// 	PPScrCls();
// 	PPScrPrint(0, 0, (uchar *)"   WELCOME!   ");
// 	PPScrPrint(1, 0, (uchar *)"PAX TECHNOLOGY");
}

// get partial pan for PIN entry
int ExtractPAN(const uchar *pszPAN, uchar *pszOutPan)
{
	int		iLength;

	iLength = strlen((char*) pszPAN);
	if( iLength<13 || iLength>19 )
	{
		return ERR_SWIPECARD;
	}

	memset(pszOutPan, '0', 16);
	memcpy(pszOutPan+4, pszPAN+iLength-13, 12);
	pszOutPan[16] = 0;

	return 0;
}

// calculate mac
int GetMAC(uchar ucMode, const uchar *psData, ushort uiDataLen, uchar ucMacKeyID, uchar *psOutMAC)
{
	if( !ChkIfNeedMac() )
	{
		return 0;
	}

	// 0: ANSI x9.9, 1: fast arithm
	if (ChkTermPEDMode(PED_EXT_PP))
	{
		uchar	ucRet;
		ucRet = PPMac(ucMacKeyID, 0x01, psData, uiDataLen, psOutMAC, 0);	// !!!! mode و”¹é€ 
		if( ucRet!=0 )
		{
			DispPPPedErrMsg(ucRet);
			return ERR_NO_DISP;
		}
	}

	if (ChkTermPEDMode(PED_INT_PCI))
	{
		int		iRet;
		iRet = PedGetMac(ucMacKeyID, (uchar *)psData, uiDataLen, psOutMAC, ucMode);
		if (iRet!=0)
		{

			DispPciErrMsg(iRet);
			return ERR_NO_DISP;
		}
		return 0;
	}
	
	if (ChkTermPEDMode(PED_EXT_PCI))
	{
		// External PCI
		// !!!! to be implemented
		MirroringSendEcr("EXTERNAL PCI\nNOT IMPLEMENTED.");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "EXTERNAL PCI\nNOT IMPLEMENTED.", gl_stCenterAttr, GUI_BUTTON_NONE, 30, NULL);
		return ERR_NO_DISP;
	}

	return 0;
}

// show PED/PINPAD error message
void DispPPPedErrMsg(uchar ucErrCode)
{
	unsigned char szErrMsg[50];
	switch( ucErrCode )
	{
	case 0x01:
		strcpy(szErrMsg, _T("INV MAC DATA"));
		break;

	case 0x02:
	case 0x0B:
		strcpy(szErrMsg, _T("INVALID KEY ID"));
	    break;

	case 0x03:
		strcpy(szErrMsg, _T("INVALID MODE"));
		break;

	default:
		sprintf(szErrMsg, "%s:%02X", _T("PED ERROR"), ucErrCode);
	    break;
	}

	MirroringSendEcr(szErrMsg);
	Gui_ClearScr();
	PubBeepErr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szErrMsg, gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
}

void DispPciErrMsg(int iErrCode)
{
	char	szDispBuff[64];

	// to be implemented
	switch( iErrCode )
	{
	case PED_RET_OK:
		return;

	case PED_RET_ERR_NO_KEY:
		sprintf(szDispBuff, _T("KEY MISSING"));
		break;

	case PED_RET_ERR_KEYIDX_ERR:
		sprintf(szDispBuff, _T("INVALID KEY INDEX"));
		break;

	case PED_RET_ERR_DERIVE_ERR:
		sprintf(szDispBuff, _T("INVALID KEY LEVEL"));
	    break;

	case PED_RET_ERR_CHECK_KEY_FAIL:
	case PED_RET_ERR_KCV_CHECK_FAIL:
		sprintf(szDispBuff, _T("CHECK KEY FAIL"));
	    break;

	case PED_RET_ERR_NO_PIN_INPUT:
		sprintf(szDispBuff, _T("PIN BYPASS"));
	    break;

	case PED_RET_ERR_INPUT_CANCEL:
	case PED_RET_ERR_INPUT_TIMEOUT:
		sprintf(szDispBuff, _T("INPUT CANCELLED"));
	    break;

	case PED_RET_ERR_WAIT_INTERVAL:
		sprintf(szDispBuff, _T("PLS TRY AGAIN LATER"));
	    break;

	case PED_RET_ERR_CHECK_MODE_ERR:
		sprintf(szDispBuff, _T("INVALID MODE"));
	    break;

	case PED_RET_ERR_NO_RIGHT_USE:
	case PED_RET_ERR_NEED_ADMIN:
		sprintf(szDispBuff, _T("PED ACCESS DENIALED"));
	    break;

	case PED_RET_ERR_KEY_TYPE_ERR:
	case PED_RET_ERR_SRCKEY_TYPE_ERR:
		sprintf(szDispBuff, _T("INVALID KEY TYPE"));
	    break;

	case PED_RET_ERR_EXPLEN_ERR:
		sprintf(szDispBuff, _T("INVALID PARA"));
	    break;

	case PED_RET_ERR_DSTKEY_IDX_ERR:
		sprintf(szDispBuff, _T("INVALID DST INDEX"));
	    break;

	case PED_RET_ERR_SRCKEY_IDX_ERR:
		sprintf(szDispBuff, _T("INVALID SRC INDEX"));
	    break;

	case PED_RET_ERR_KEY_LEN_ERR:
		sprintf(szDispBuff, _T("INVALID KEY LENGTH"));
	    break;

	case PED_RET_ERR_NO_ICC:
		sprintf(szDispBuff, _T("CARD NOT READY"));
	    break;

	case PED_RET_ERR_ICC_NO_INIT:
		sprintf(szDispBuff, _T("CARD NOT INIT"));
	    break;

	case PED_RET_ERR_GROUP_IDX_ERR:
		sprintf(szDispBuff, _T("INVALID GROUP INDEX"));
	    break;

	case PED_RET_ERR_PARAM_PTR_NULL:
		sprintf(szDispBuff, _T("INVALID PARA"));
	    break;

	case PED_RET_ERR_LOCKED:
		sprintf(szDispBuff, _T("PED LOCKED"));
	    break;

	case PED_RET_ERROR:
		sprintf(szDispBuff, _T("PED GENERAL ERR"));
	    break;

	case PED_RET_ERR_UNSPT_CMD:
	case PED_RET_ERR_DUKPT_OVERFLOW:
	case PED_RET_ERR_NOMORE_BUF:
	case PED_RET_ERR_COMM_ERR:
	case PED_RET_ERR_NO_UAPUK:
	case PED_RET_ERR_ADMIN_ERR:
	case PED_RET_ERR_DOWNLOAD_INACTIVE:
	default:
		sprintf(szDispBuff, "%s:%d", _T("PED ERROR"), iErrCode);
	    break;
	}

	MirroringSendEcr(szDispBuff);
	Gui_ClearScr();
	PubBeepErr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
}

// و ¹وچ®هڈ‚و•°è®¾ç½®ه¯¹PANè؟›è،Œوژ©ç پ
// Output a mask PAN
void MaskPan(const uchar *pszInPan, uchar *pszOutPan)
{
	uchar	szBuff[30];
	int		iCnt, iPanLen, iOption;

	memset(szBuff, 0, sizeof(szBuff));
	iPanLen = strlen((char *)pszInPan);
	if( !ChkOptionExt(glCurIssuer.sPanMask, 0x0080) )	//the first bit of the 24 bits
	{	// right align
		for(iCnt=0; iCnt<iPanLen; iCnt++)
		{
			iOption = ((2-iCnt/8)<<8) + (1<<(iCnt%8));
			if( !ChkOptionExt(glCurIssuer.sPanMask, (ushort)iOption) )
			{
				szBuff[iPanLen-iCnt-1] = pszInPan[iPanLen-iCnt-1];
			}
			else
			{
				szBuff[iPanLen-iCnt-1] = '*';
			}
		}
	}
	else
	{	// left align
		for(iCnt=0; iCnt<iPanLen; iCnt++)
		{
			iOption = (((iCnt+2)/8)<<8) + (0x80>>((iCnt+2)%8));
			if( !ChkOptionExt(glCurIssuer.sPanMask, (ushort)iOption) )
			{
				szBuff[iCnt] = pszInPan[iCnt];
			}
			else
			{
				szBuff[iCnt] = '*';
			}
		}
	}

	sprintf((char *)pszOutPan, "%.*s", LEN_PAN, szBuff);
}


// و ¹وچ®هڈ‚و•°è®¾ç½®ه¯¹PANè؟›è،Œوژ©ç پ
// Output a mask PAN
void MaskPan_nagy(const uchar *pszInPan, uchar *pszOutPan)
{

	 uchar szBuff[30];
	 int  iCnt, iPanLen, iOption;

	 memset(szBuff, 0, sizeof(szBuff));
	 iPanLen = strlen((char *)pszInPan);

	 memcpy(szBuff, pszInPan, iPanLen);

	 for(iCnt=6; iCnt<iPanLen - 4; iCnt++)
	 {
	   szBuff[iCnt] = '*';
	 }


	 sprintf((char *)pszOutPan, "%.*s", LEN_PAN, szBuff);

}


// èژ·هڈ–8583و‰“هŒ…/è§£هŒ…é”™è¯¯ن؟،وپ¯
void Get8583ErrMsg(uchar bPackErr, int iErrCode, uchar *pszErrMsg)
{
	PubASSERT( iErrCode<0 );
	if( bPackErr )
	{
		if( iErrCode<-2000 )
		{
			sprintf((char *)pszErrMsg, "BIT %d DEF ERR", -iErrCode-2000);
		}
		else if( iErrCode<-1000 )
		{
			sprintf((char *)pszErrMsg, "BIT %d PACK ERR", -iErrCode-1000);
		}
		else
		{
			sprintf((char *)pszErrMsg, "PACK HEADER ERR");
		}
	}
	else
	{
		if( iErrCode<-2000 )
		{
			sprintf((char *)pszErrMsg, "BIT %d DEF ERR", -iErrCode-2000);
		}
		else if( iErrCode<-1000 )
		{
			sprintf((char *)pszErrMsg, "UNPACK %d ERR", -iErrCode-1000);
		}
		else if( iErrCode==-1000 )
		{
			sprintf((char *)pszErrMsg, "DATA LENGTH ERR");
		}
		else
		{
			sprintf((char *)pszErrMsg, "UNPACK HEAD ERR");
		}
	}
}


// èژ·هڈ–é¢„وژˆو‌ƒهڈ·ç پ
// get pre-authorization code
int GetPreAuthCode(void)
{
	uchar szBuff[LEN_AUTH_CODE+1];

	GUI_INPUTBOX_ATTR stInputAttr;
    /*=======BEGIN: Jason 2015.03.26  11:28 modify===========*/
    if (ECR_BEGIN == glProcInfo.ucEcrCtrl)
    {
        if(EcrGetAppCode(glProcInfo.stTranLog.szAuthCode) == 0) //Jason 2015.03.26 11:19
        {
            return 0;
        }
    }
    /*====================== END======================== */

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType = GUI_INPUT_MIX;
	stInputAttr.nMinLen = 2;
	stInputAttr.nMaxLen = LEN_AUTH_CODE;

	memset(szBuff, 0, sizeof(szBuff));

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("AUTH CODE ?"), gl_stLeftAttr, szBuff,
		gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))//("APPV CODE ?")
	{
		return ERR_USERCANCEL;
	}

	sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%-*s", LEN_AUTH_CODE, szBuff);

	return 0;
}

// èژ·هڈ–ç¥¨وچ®هڈ·
// get invoice no
int InputInvoiceNo(ulong *pulInvoiceNo)
{
	uchar szBuff[LEN_INVOICE_NO+1];

	GUI_INPUTBOX_ATTR stInputAttr;

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType   = GUI_INPUT_NUM;
	stInputAttr.nMinLen = 1;
	stInputAttr.nMaxLen = LEN_INVOICE_NO;

	memset(szBuff, 0, sizeof(szBuff));

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("TRACE NO ?"), gl_stLeftAttr, szBuff,// TRACE NO
		gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	*pulInvoiceNo = (ulong)atol((char *)szBuff);

	return 0;
}

// get RRN
int  GetRRN(void)
{
	uchar szBuff[LEN_RRN+1];
	GUI_INPUTBOX_ATTR stInputAttr;
	
	/*=======BEGIN: Jason 2014.12.19  17:10 modify===========*/
	if (ECR_BEGIN == glProcInfo.ucEcrCtrl)
    {
        if(EcrGetRRN(glProcInfo.stTranLog.szRRN) == 0) //Jason 2015.03.26 11:19
        {
            //strcpy(glProcInfo.stTranLog.szRefundRRN,glProcInfo.stTranLog.szRRN);//Jason 2015.03.26 15:10
            return 0;
        }
    }
    /*====================== END======================== */

	memset(&stInputAttr, 0, sizeof(stInputAttr));
	stInputAttr.eType   = GUI_INPUT_NUM;
	stInputAttr.nMinLen = LEN_RRN;
	stInputAttr.nMaxLen = LEN_RRN;

	memset(szBuff, 0, sizeof(szBuff));

	Gui_ClearScr();
	if(GUI_OK != Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, _T("RRN ?"), gl_stLeftAttr, szBuff,
		gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT))
	{
		return ERR_USERCANCEL;
	}

	sprintf((char *)glProcInfo.stTranLog.szRRN, "%-*s", LEN_RRN, szBuff);

	return 0;
}


// èژ·هڈ–è¦پوک¾ç¤؛çڑ„ن؛¤وک“çٹ¶و€پن؟،وپ¯
// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug508
// return 0 use current transaction type 
// return 1 use original transaction type
// return -1 error
int  GetStateText(ushort uiStatus, uchar *pszStaText)
{
	if(!pszStaText)
		return -1;
	sprintf((char *)pszStaText,"Normal");
	if( uiStatus & TS_VOID)
	{
		sprintf((char *)pszStaText,"VOIDED");
		return 1;
	}
	else if( uiStatus & TS_ADJ)
	{
		sprintf((char *)pszStaText, "ADJUSTED");
	}
	else if( uiStatus & TS_NOSEND)
	{
		sprintf((char *)pszStaText, "NOT_SEND");
		return 0;
	}
	else if ( uiStatus & TS_NOT_COMP)
	{
		sprintf((char *)pszStaText, "NOT_COMP");
	}
	else if ( uiStatus & TS_AUTH_SEND)
	{
		sprintf((char *)pszStaText, "COMPLETED");
	}


	return 0;
}


// وک¾ç¤؛و“چن½œوˆگهٹںçڑ„هٹ¨ç”»
// Show animation of "done"
void DispOperOk(const void *pszMsg)
{
#ifdef _PROLIN2_4_
	Gui_DrawImage("./res/ok.png", 50 , 30);
	DelayMs(1500);
#else
	static uchar sLogoOkThree[117] =
	{
		0x03,
		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0xc0,0x40,0x0,0x40,0x0,0x40,0x0,0x40,0x0,
		0x40,0x0,0x40,0x0,0x40,0x0,0x80,0xc0,0xc0,0xc0,0xe0,0x60,0x60,0x30,0x30,0x30,
		0x10,0x10,0x10,0x0,

		0x00,0x24,
		0x0,0x4,0x4,0x4,0xc,0x18,0x18,0xba,0x70,0xe0,0xe0,0xc0,0xc0,0x80,0xc0,0xe0,
		0xf0,0xf8,0x7c,0x3e,0x1f,0xf,0x7,0xab,0x1,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0,

		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x6,0x4,0x0,0x5,0x3,0x7,0x3,0x7,0x3,
		0x5,0x0,0x4,0x0,0x4,0x0,0x4,0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0
	};
	static uchar sLogoOkTwo[117] =
	{
		0x03,
		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0xc0,0x40,0x0,0x40,0x0,0x40,0x0,0x40,0x0,
		0x40,0x0,0x40,0x0,0x40,0x0,0x40,0xc0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0,

		0x00,0x24,
		0x0,0x4,0x4,0x4,0xc,0x18,0x18,0xba,0x70,0xe0,0xe0,0xc0,0xc0,0x80,0xc0,0xe0,
		0xf0,0xf8,0x7c,0x38,0x10,0x0,0x0,0xaa,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0,

		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x6,0x4,0x0,0x5,0x3,0x7,0x3,0x7,0x3,
		0x5,0x0,0x4,0x0,0x4,0x0,0x4,0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0
	};
	static uchar sLogoOkOne[117] =
	{
		0x03,
		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0xc0,0x40,0x0,0x40,0x0,0x40,0x0,0x40,0x0,
		0x40,0x0,0x40,0x0,0x40,0x0,0x40,0xc0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0,

		0x00,0x24,
		0x0,0x4,0x4,0x4,0xc,0x18,0x18,0xba,0x70,0xe0,0xe0,0xc0,0xc0,0x80,0x0,0x0,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0xaa,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0,

		0x00,0x24,
		0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x6,0x4,0x0,0x5,0x3,0x7,0x3,0x6,0x0,
		0x4,0x0,0x4,0x0,0x4,0x0,0x4,0x6,0x0,0x0,0x0,0x0,0x0,0x0,0x0,0x0,
		0x0,0x0,0x0,0x0
	};

	uchar	ucLogoNo;

	Gui_DrawText(pszMsg, gl_stCenterAttr, 0, 40);

	TimerSet(TIMER_TEMPORARY, 2);
	//ScrGotoxy(76, 3);
	for(ucLogoNo=0; ucLogoNo<3; )
	{
		if( TimerCheck(TIMER_TEMPORARY)==0 )
		{
			if( ucLogoNo==0 )
			{
				Gui_DrawLogo(sLogoOkOne, 76, 24);
			}
			else if( ucLogoNo==1 )
			{
				Gui_DrawLogo(sLogoOkTwo, 76, 24);
			}
			else
			{
				Gui_DrawLogo(sLogoOkThree, 76, 24);
			}
			ucLogoNo++;
			TimerSet(TIMER_TEMPORARY, 2);
		}
	}
	DelayMs(1500);
#endif
}

// é€‰و‹©و”¶هچ•è،Œ
// (for settle/reprint ....)
int SelectAcq(uchar bAllowSelAll, const uchar *pszTitle, uchar *pucAcqIndex)
{
	uchar		ucCnt, ucIndex;
	GUI_MENU	stAcqMenu;
	GUI_MENUITEM	stAcqMenuItem[MAX_ACQ+1+1];
	int			iSelMenu, iMenuNum;

	if( glSysParam.ucAcqNum==0 )
	{
		MirroringSendEcr("NO ACQUIRER");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(pszTitle, gl_stTitleAttr, _T("NO ACQUIRER"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}
	if( glSysParam.ucAcqNum==1 )
	{
		SetCurAcq(0);
		if( pucAcqIndex!=NULL )
		{
			*pucAcqIndex = 0;
		}
		return 0;
	}

	// here, glSysParam.ucAcqNum must >= 2
	memset(stAcqMenuItem, 0, sizeof(stAcqMenuItem));
	iMenuNum = 0;
	if( bAllowSelAll )
	{
		sprintf((char *)stAcqMenuItem[iMenuNum].szText, "0. AUDIT ALL");//0SETTLE ALL");
		stAcqMenuItem[iMenuNum].bVisible = TRUE;
		stAcqMenuItem[iMenuNum].nValue = MAX_ACQ;
		stAcqMenuItem[iMenuNum].vFunc = NULL;
		iMenuNum++;
	}

	for(ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		sprintf((char *)stAcqMenuItem[iMenuNum].szText, "%d. %3.3s %.12s", ucCnt + 1,
			glSysParam.stAcqList[ucCnt].szNii, glSysParam.stAcqList[ucCnt].szName);
		stAcqMenuItem[iMenuNum].bVisible = TRUE;
		stAcqMenuItem[iMenuNum].nValue = ucCnt;
		stAcqMenuItem[iMenuNum].vFunc = NULL;
		iMenuNum++;
	}

	strcpy((char *)stAcqMenuItem[iMenuNum].szText, "");
	stAcqMenuItem[iMenuNum].bVisible = FALSE;
	stAcqMenuItem[iMenuNum].nValue = -1;
	stAcqMenuItem[iMenuNum].vFunc = NULL;

	Gui_BindMenu(pszTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stAcqMenuItem, &stAcqMenu);
	Gui_ClearScr();
	iSelMenu = 0;
	if(GUI_OK != Gui_ShowMenuList(&stAcqMenu, GUI_MENU_DIRECT_RETURN | GUI_MENU_0_START, USER_OPER_TIMEOUT, &iSelMenu))
	{
		return ERR_USERCANCEL;
	}

	ucIndex = (uchar)iSelMenu;

	if( ucIndex!=MAX_ACQ )
	{
		SetCurAcq(ucIndex);
	}
	else
	{
		glProcInfo.bPrnAllAcq = TRUE;
	}

	if( pucAcqIndex!=NULL )
	{
		*pucAcqIndex = ucIndex;
	}

	return 0;
}


int SelectAcq_Details(uchar bAllowSelAll, const uchar *pszTitle, uchar *pucAcqIndex)
{
	uchar		ucCnt, ucIndex;
	GUI_MENU	stAcqMenu;
	GUI_MENUITEM	stAcqMenuItem[MAX_ACQ+1+1];
	int			iSelMenu, iMenuNum;

	if( glSysParam.ucAcqNum==0 )
	{
		MirroringSendEcr("NO ACQUIRER");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(pszTitle, gl_stTitleAttr, _T("NO ACQUIRER"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}
	if( glSysParam.ucAcqNum==1 )
	{
		SetCurAcq(0);
		if( pucAcqIndex!=NULL )
		{
			*pucAcqIndex = 0;
		}
		return 0;
	}

	// here, glSysParam.ucAcqNum must >= 2
	memset(stAcqMenuItem, 0, sizeof(stAcqMenuItem));
	iMenuNum = 0;
	if( bAllowSelAll )
	{
		sprintf((char *)stAcqMenuItem[iMenuNum].szText, "0. AUDIT ALL");//0SETTLE ALL");
		stAcqMenuItem[iMenuNum].bVisible = TRUE;
		stAcqMenuItem[iMenuNum].nValue = MAX_ACQ;
		stAcqMenuItem[iMenuNum].vFunc = NULL;
		iMenuNum++;
	}

	for(ucCnt=0; ucCnt<glSysParam.ucAcqNum; ucCnt++)
	{
		sprintf((char *)stAcqMenuItem[iMenuNum].szText, "%d. %3.3s %.12s", ucCnt + 1,
			glSysParam.stAcqList[ucCnt].szNii, glSysParam.stAcqList[ucCnt].szName);
		stAcqMenuItem[iMenuNum].bVisible = TRUE;
		stAcqMenuItem[iMenuNum].nValue = ucCnt;
		stAcqMenuItem[iMenuNum].vFunc = NULL;
		iMenuNum++;
	}

	strcpy((char *)stAcqMenuItem[iMenuNum].szText, "");
	stAcqMenuItem[iMenuNum].bVisible = FALSE;
	stAcqMenuItem[iMenuNum].nValue = -1;
	stAcqMenuItem[iMenuNum].vFunc = NULL;

	Gui_BindMenu(pszTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stAcqMenuItem, &stAcqMenu);
	Gui_ClearScr();
	iSelMenu = 0;
//	if(GUI_OK != Gui_ShowMenuList(&stAcqMenu, GUI_MENU_DIRECT_RETURN | GUI_MENU_0_START, USER_OPER_TIMEOUT, &iSelMenu))
//	{
//		return ERR_USERCANCEL;
//	}

	ucIndex = (uchar)iSelMenu;

	if( ucIndex!=MAX_ACQ )
	{
		SetCurAcq(ucIndex);
	}
	else
	{
		glProcInfo.bPrnAllAcq = TRUE;
	}

	if( pucAcqIndex!=NULL )
	{
		*pucAcqIndex = ucIndex;
	}

	return 0;
}

// é€‰و‹©هڈ‘هچ،è،Œ
int SelectIssuer(uchar *pucIssuerIndex)
{
	uchar		ucCnt;
	int			iMenuNo;
	GUI_MENU	stIssuerMenu;
	GUI_MENUITEM	stIssuerMenuItem[MAX_ISSUER+1];

	if( glSysParam.ucIssuerNum==0 )
	{

		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO ISSUER"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		return ERR_NO_DISP;
	}
	if( glSysParam.ucIssuerNum==1 )
	{
		SetCurIssuer(0);
		if( pucIssuerIndex!=NULL )
		{
			*pucIssuerIndex = 0;
		}
		return 0;
	}

	memset(stIssuerMenuItem, 0, sizeof(stIssuerMenuItem));
	for(ucCnt=0; ucCnt<glSysParam.ucIssuerNum; ucCnt++)
	{
		sprintf((char *)stIssuerMenuItem[ucCnt].szText, "%d. %.10s", ucCnt + 1, glSysParam.stIssuerList[ucCnt].szName);
		stIssuerMenuItem[ucCnt].bVisible = TRUE;
		stIssuerMenuItem[ucCnt].nValue = ucCnt;
		stIssuerMenuItem[ucCnt].vFunc = NULL;
	}

	strcpy((char *)stIssuerMenuItem[ucCnt].szText, "");
	stIssuerMenuItem[ucCnt].bVisible = FALSE;
	stIssuerMenuItem[ucCnt].nValue = -1;
	stIssuerMenuItem[ucCnt].vFunc = NULL;

	Gui_BindMenu(_T("SELECT ISSUER"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stIssuerMenuItem, &stIssuerMenu);
	
	Gui_ClearScr();
	//iMenuNo = 0;
	if(GUI_OK != Gui_ShowMenuList(&stIssuerMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo))
	{
		return ERR_USERCANCEL;
	}

	SetCurIssuer((uchar)iMenuNo);
	if( pucIssuerIndex!=NULL )
	{
		*pucIssuerIndex = (uchar)iMenuNo;
	}

	return 0;
}

// و¸…é™¤و±‡و€»ن؟،وپ¯
void ClearTotalInfo(void *pstTotalInfo)
{
	memset(pstTotalInfo, 0, sizeof(TOTAL_INFO));

	memset(((TOTAL_INFO *)pstTotalInfo)->szSaleAmt,       '0', 12);
	memset(((TOTAL_INFO *)pstTotalInfo)->szTipAmt,        '0', 12);
	memset(((TOTAL_INFO *)pstTotalInfo)->szRefundAmt,     '0', 12);
	memset(((TOTAL_INFO *)pstTotalInfo)->szVoidSaleAmt,   '0', 12);
	memset(((TOTAL_INFO *)pstTotalInfo)->szVoidRefundAmt, '0', 12);
}

// وک¾ç¤؛ن؛¤وک“و±‡و€»ن؟،وپ¯(glTransTotal)
// Modified by Kim_LinHB 2014/9/16 v1.01.0009 bug509
int DispTransTotal(uchar bShowVoidTrans)
{
	int iRet;
	uchar	szDispAmt[50];
	GUI_PAGELINE stBuff[12];
	GUI_PAGE stInfoPage;
	uchar	ucCnt = 0;

	sprintf((char *)stBuff[ucCnt].szLine, "%s%12d", _T("SALE"),    glTransTotal.uiSaleCnt);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
	GetDispAmount(glTransTotal.szSaleAmt, stBuff[ucCnt].szLine);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	sprintf((char *)stBuff[ucCnt].szLine, "%s%10d", _T("REFUND"),   glTransTotal.uiRefundCnt);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	sprintf((char *)szDispAmt, "%.12s", glTransTotal.szRefundAmt);
	szDispAmt[0] = 'D';
	GetDispAmount(szDispAmt, stBuff[ucCnt].szLine);
	stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

	if( bShowVoidTrans )
	{
		sprintf((char *)stBuff[ucCnt].szLine, "%s%5d", _T("VOIDED SALE"), glTransTotal.uiVoidSaleCnt);
		stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

		sprintf((char *)szDispAmt, "%.12s", glTransTotal.szVoidSaleAmt);
		szDispAmt[0] = 'D';
		GetDispAmount(szDispAmt, stBuff[ucCnt].szLine);
		stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;

		sprintf((char *)stBuff[ucCnt].szLine, "%s%5d", _T("VOIDED REFD"), glTransTotal.uiVoidRefundCnt);
		stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
		GetDispAmount(glTransTotal.szVoidRefundAmt, stBuff[ucCnt].szLine);
		stBuff[ucCnt++].stLineAttr = gl_stLeftAttr;
	}

	//don't display when use the settle. linzhao 20151113
	if (SETTLEMENT!=glProcInfo.stTranLog.ucTranType)
	{
		Gui_CreateInfoPage(NULL, gl_stTitleAttr, stBuff, ucCnt, &stInfoPage);

		Gui_ClearScr();

		iRet = Gui_ShowInfoPage(&stInfoPage, FALSE, USER_OPER_TIMEOUT);
		if(GUI_OK == iRet)
		{
			return 0;
		}

		return ERR_USERCANCEL;
	}

	return 0;
}

/*
// è°ƒèٹ‚ه±ڈه¹•ه¯¹و¯”ه؛¦
void AdjustLcd(void)
{
	uchar	ucKey, szBuff[30];

	while( 1 )
	{
		PubShowTitle(TRUE, (uchar *)"ADJUST CONTRAST");
		sprintf((char *)szBuff, _T("STEP = [%d]"), glSysParam.stEdcInfo.ucScrGray);
		PubDispString(szBuff, DISP_LINE_CENTER|3);
		PubDispString(_T("[CANCEL] - EXIT"), DISP_LINE_CENTER|6);
		ScrGray(glSysParam.stEdcInfo.ucScrGray);
		ucKey = PubWaitKey(USER_OPER_TIMEOUT);
		if( ucKey==KEYCANCEL || ucKey==NOKEY )
		{
			break;
		}
		glSysParam.stEdcInfo.ucScrGray = (glSysParam.stEdcInfo.ucScrGray+1) % 8;
	}
	SaveEdcParam();
}
*/

// هˆ¤و–­وک¯هگ¦ن¸؛و•°ه­—ن¸²
uchar IsNumStr(const char *pszStr)
{
	if( pszStr==NULL || *pszStr==0 )
	{
		return FALSE;
	}

	while( *pszStr )
	{
		if( !isdigit(*pszStr++) )
		{
			return FALSE;
		}
	}

	return TRUE;
}

// èژ·هڈ–ن؛¤وک“çڑ„è‹±و–‡هگچç§°
//void GetEngTranLabel(uchar *pszTranTitle, uchar *pszEngLabel)

// هڈ–ه¾—é‡‘é¢‌çڑ„ç¬¦هڈ·
uchar GetTranAmountInfo(void *pTranLog)
{
	uchar		ucSignChar;
	TRAN_LOG	*pstLog;

	pstLog = (TRAN_LOG *)pTranLog;
	ucSignChar = 0;
	if( (pstLog->ucTranType==REFUND) || (pstLog->ucTranType==VOID) || 
	    (VOID_AUTH==pstLog->ucTranType) || (pstLog->uiStatus &TS_VOID) )
	{
		ucSignChar = GA_NEGATIVE;
	}

	if( (pstLog->ucTranType==VOID) && (pstLog->ucOrgTranType==REFUND) )
	{
		ucSignChar = 0;
	}

	if( (pstLog->ucTranType==REFUND) && ( pstLog->uiStatus &TS_VOID))
	{
		ucSignChar = 0;
	}

	return ucSignChar;
}

void DispHostRspMsg(uchar *pszRspCode, HOST_ERR_MSG *pstMsgArray)
{
	int		iCnt;
	char	szDispMsg[64];
	
	for(iCnt=0; pstMsgArray[iCnt].szRspCode[0]!=0; iCnt++)
	{
		if( memcmp(pszRspCode, pstMsgArray[iCnt].szRspCode, 2)==0 )
		{
			break;
		}
	}

	sprintf(szDispMsg, _T(pstMsgArray[iCnt].szMsg));

	if( ChkIfBea() )
	{
		if( memcmp(glProcInfo.stTranLog.szRspCode, "08", 2)==0 ||
			memcmp(glProcInfo.stTranLog.szRspCode, "43", 2)==0 )
		{
			sprintf(szDispMsg, _T("PLS CALL BANK"));
		}
	}

	sprintf(szDispMsg + strlen(szDispMsg), "\n%.2s", pszRspCode);

	MirroringSendEcr(szDispMsg);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispMsg, gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
}

void DispResult(int iErrCode)
{
	int		iCnt;

	if( (iErrCode==ERR_NO_DISP) ||
		(iErrCode==ERR_EXIT_APP) )
	{
		return;
	}

	switch( iErrCode )
	{
	case 0:
		switch( glProcInfo.stTranLog.ucTranType )
		{
		case UPLOAD:
		case LOAD_PARA:
		case LOAD_CARD_BIN:
			Beef(3, 60);
			break;

		case OFF_SALE:
		case VOID:

			DispAccepted();
			break;

		case ECHO_TEST:
			MirroringSendEcr("LINK IS OK");
			Gui_ClearScr();
			PubBeepOk();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("LINK IS OK"), gl_stCenterAttr, GUI_BUTTON_OK, glSysParam.stEdcInfo.ucAcceptTimeout, NULL);
			break;

		case LOGON:
			MirroringSendEcr("LOGON COMPLETE");
			Gui_ClearScr();
			PubBeepOk();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("LOGON COMPLETE"), gl_stCenterAttr, GUI_BUTTON_OK, glSysParam.stEdcInfo.ucAcceptTimeout, NULL);

			break;

		default:
			if( glProcInfo.stTranLog.szAuthCode[0]==0 ||
				memcmp(glProcInfo.stTranLog.szAuthCode, "       ", 6)==0 )
			{
				DispAccepted();
			}
			else
			{   
				unsigned char szBuff[50];
				sprintf(szBuff, "%s\n%.6s", _T("AUTH CODE"), glProcInfo.stTranLog.szAuthCode);//_T("APPV CODE")
				MirroringSendEcr(szBuff);
				Gui_ClearScr();
				PubBeepOk();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK, glSysParam.stEdcInfo.ucAcceptTimeout, NULL);
			}
		}
		break;

	case ERR_HOST_REJ:
		DispHostRspMsg(glProcInfo.stTranLog.szRspCode, glHostErrMsg);
		break;

	default:
		for(iCnt=0; glTermErrMsg[iCnt].iErrCode!=0; iCnt++)
		{
			if( glTermErrMsg[iCnt].iErrCode==iErrCode )
			{
				MirroringSendEcr(glTermErrMsg[iCnt].szMsg);
				Gui_ClearScr();
				PubBeepErr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T(glTermErrMsg[iCnt].szMsg), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
				break;
			}
		}
		if( glTermErrMsg[iCnt].iErrCode==0 )
		{
			unsigned char szBuff[50];
			sprintf(szBuff, "%s\n%04x", _T("SYSTEM ERROR"), iErrCode);
			MirroringSendEcr(szBuff);
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		}
	    break;
	}
	Gui_ClearScr(); // Added by Kim_LinHB 2014-08-18 v1.01.0004
}

// è®،ç®—هچ•وچ®و•°ç›®
// Get number of receipts to pint out in one transaction.
int NumOfReceipt(void)
{
	int		iNum;

	//20150916 linzhao
	iNum = 1;
	if( ChkEdcOption(EDC_NUM_PRINT_LOW) )
	{
		iNum++;
	}
	if( ChkEdcOption(EDC_NUM_PRINT_HIGH) )
	{
		iNum += 2;
	}

	return iNum;
}

// if any issuer ticked PIN REQUIRED option, it open the EMV offline PIN
// deleted
//void ModifyTermCapForPIN(void)

#ifdef ENABLE_EMV
// set tag 9C for EMV
void UpdateEMVTranType(void)
{
	// è®¾ç½®EMVهڈ‚و•°
	// set EMV parameters
	EMVGetParameter(&glEmvParam);
	switch( glProcInfo.stTranLog.ucTranType )
	{
	case SALE:
		glEmvParam.TransType = EMV_GOODS;
		EMVSetTLVData(0x9C, (uchar *)"\x00", 1);
		break;

	case AUTH:
		EMVSetTLVData(0x9C, (uchar *)"\x00", 1);
		glEmvParam.TransType = EMV_GOODS;
		break;

	case PREAUTH:
		EMVSetTLVData(0x9C, (uchar *)"\x30", 1);
		glEmvParam.TransType = EMV_GOODS;
		break;

// 	case BALANCE:
// 		EMVSetTLVData(0x9C, (uchar *)"\x31", 1);
//		glEmvParam.TransType = EMV_GOODS;
// 		break;

	default:
		return;
	}
	EMVSetParameter(&glEmvParam);
	// Only in this trasaction, so DON'T back up
}
#endif

int FindCurrency(const uchar *pszCurrencyNameCode, CURRENCY_CONFIG *pstCurrency)
{
	int	iCnt;
	uchar	sBCD[8], sBuff[8];

	for (iCnt=0; glCurrency[iCnt].szName[0]!=0; iCnt++)
	{
		if (IsNumStr(pszCurrencyNameCode))
		{
			sprintf((char *)sBuff, "0%.3s", pszCurrencyNameCode);
			PubAsc2Bcd(sBuff, 3, sBCD);
			if (memcmp(sBCD, glCurrency[iCnt].sCurrencyCode, 2)==0)
			{
				memcpy(pstCurrency, &glCurrency[iCnt], sizeof(CURRENCY_CONFIG));
				return 0;
			}
		}
		else
		{
			if (strcmp((char *)pszCurrencyNameCode, (char *)glCurrency[iCnt].szName)==0)
			{
				memcpy(pstCurrency, &glCurrency[iCnt], sizeof(CURRENCY_CONFIG));
				return 0;
			}
		}
	}

	return -1;
}

#ifdef ENABLE_EMV
// و ¹وچ®EDCهڈ‚و•°è®¾ه®ڑEMVه؛“çڑ„ه›½ه®¶ن»£ç په’Œè´§ه¸پç‰¹و€§
// Setup EMV core parameter due to EDC para
void SyncEmvCurrency(const uchar *psCountryCode, const uchar *psCurrencyCode, uchar ucDecimal)
{
	EMVGetParameter(&glEmvParam);
	if ((memcmp(psCountryCode,  glEmvParam.CountryCode,   2)!=0) ||
        (memcmp(psCurrencyCode, glEmvParam.TransCurrCode, 2)!=0) ||
        (glEmvParam.TransCurrExp!=ucDecimal) )
	{
		memcpy(glEmvParam.CountryCode,   psCountryCode,  2);
		memcpy(glEmvParam.TransCurrCode, psCurrencyCode, 2);
		memcpy(glEmvParam.ReferCurrCode, psCurrencyCode, 2);
		glEmvParam.TransCurrExp = ucDecimal;
		glEmvParam.ReferCurrExp = ucDecimal;
		EMVSetParameter(&glEmvParam);
	}
}
#endif

// Read monitor config info, by API: GetTermInfo()
// return: 0--No need save; 1--Need save
// è¯»هڈ–monitorن؟‌ه­کçڑ„ç³»ç»ںé…چç½®ن؟،وپ¯
// è؟”ه›‍ï¼ڑ0ï¼چï¼چن¸چéœ€è¦پن؟‌ه­کو›´و–°ï¼›1ï¼چï¼چéœ€è¦پن؟‌ه­ک
int UpdateTermInfo(void)
{
	int		iRet;
	uchar	ucNeedUpdate, sBuff[sizeof(glSysParam.sTermInfo)];

	ucNeedUpdate = 0;

	while (1)
	{
		memset(sBuff, 0, sizeof(sBuff));
		iRet = GetTermInfo(sBuff);
		if ( iRet<0 )
		{
#ifdef _WIN32
			MirroringSendEcr("CONNECT SIMULTR.");
			Gui_ClearScr();
			Gui_ShowMsgBox(NULL, gl_stTitleAttr, _T("CONNECT SIMULTR."), gl_stCenterAttr, GUI_BUTTON_NONE, 1000, NULL);
			continue;
#else
			SysHaltInfo(_T("FAIL GET SYSINFO"));
#endif
		}

		break;
	}

	if (memcmp(sBuff, glSysParam.sTermInfo, sizeof(glSysParam.sTermInfo))!=0)
	{
		memcpy(glSysParam.sTermInfo, sBuff, sizeof(glSysParam.sTermInfo));
		ucNeedUpdate = 1;
	}

	return ucNeedUpdate;
}

#ifdef _MONITOR_
static void ShowMsgFontMissing(uchar bIsPrnFont, ST_FONT *psingle_code_font, ST_FONT *pmulti_code_font, int iErrCode)
{
	uchar	szBuff[64 + 30];
	sprintf((char *)szBuff, "%02d:%d*%d %s%s\n%02d:%d*%d %s%s %d",
					psingle_code_font->CharSet,
					psingle_code_font->Width, psingle_code_font->Height,
					(psingle_code_font->Bold ? "B" : ""), (psingle_code_font->Italic ? "I" : ""),
					pmulti_code_font->CharSet,
					pmulti_code_font->Width, pmulti_code_font->Height,
					(pmulti_code_font->Bold ? "B" : ""), (pmulti_code_font->Italic ? "I" : ""), iErrCode);

	if (bIsPrnFont)
	{
		strcat(szBuff, "\nPRN FONT MISS");
	} 
	else
	{
		strcat(szBuff, "\nDISP FONT MISS");
	}
	MirroringSendEcr(szBuff);
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, -1, NULL);
}
#endif

// Check whether system has fonts(for print and display) required under selected language.
// هœ¨ه¤ڑè¯­è¨€هٹ¨و€پهˆ‡وچ¢çژ¯ه¢ƒن¸‹ï¼Œو£€وں¥ç³»ç»ںوک¯هگ¦وœ‰ه·²é€‰و‹©è¯­è¨€و‰€ه¯¹ه؛”çڑ„و‰“هچ°ه’Œوک¾ç¤؛ه­—ه؛“
int CheckSysFont(void)
{
#ifdef _MONITOR_
	int		iRet, iRet1, iRet2, ii;

	ST_FONT	stPrnFonts[] = {
		{CHARSET_WEST, 8,  16, 0, 0},	{-1, 16, 16, 0, 0},
		{CHARSET_WEST, 12, 24, 0, 0},	{-1, 24, 24, 0, 0},
	};

	ST_FONT	stDispFonts[] = {
		{CHARSET_WEST, 8, 16, 0, 0}, {-1, 16, 16, 0, 0},
	};

#ifdef AREA_Arabia
	if(strcmp(LANGCONFIG, "Arabia") == 0)
	{
        iRet = CustomizeAppLibForArabiaLang(TRUE);
		return iRet;
	}
	else
	{
        CustomizeAppLibForArabiaLang(FALSE);
        // then continue
	}	
#endif	

	iRet = 0;
	// و£€وں¥وک¯هگ¦وœ‰و‰“هچ°/وک¾ç¤؛ه­—ه؛“ Check printer/display used fonts
	// for non-S60, display and print share the same fonts
	for (ii=0; ii<sizeof(stPrnFonts)/sizeof(ST_FONT); ii+=2)
	{
		if (stPrnFonts[ii+1].CharSet==-1)// وچ¢وˆگç³»ç»ںه½“ه‰چه·²é€‰و‹©çڑ„è¯­è¨€çڑ„ç¼–ç پ
		{
			stPrnFonts[ii+1].CharSet = glSysParam.stEdcInfo.stLangCfg.ucCharSet;
		}

		iRet2 = PrnSelectFont(&stPrnFonts[ii], &stPrnFonts[ii+1]);
		if (iRet2)
		{
			ShowMsgFontMissing(TRUE, &stPrnFonts[ii], &stPrnFonts[ii+1], iRet2);
			iRet = -1;
		}
	}
	// ه¦‚و‍œوک¯S60ï¼Œè؟کè¦پو£€وں¥و‰‹وœ؛وک¾ç¤؛ç”¨ه­—ه؛“ Check display-used fonts on handset of S60
	if (ChkTerm(_TERMINAL_S60_))
	{
		for (ii=0; ii<sizeof(stDispFonts)/sizeof(ST_FONT); ii+=2)
		{
			if (stDispFonts[ii+1].CharSet==-1)// وچ¢وˆگç³»ç»ںه½“ه‰چه·²é€‰و‹©çڑ„è¯­è¨€çڑ„ç¼–ç پ
			{
				stDispFonts[ii+1].CharSet = glSysParam.stEdcInfo.stLangCfg.ucCharSet;
			}
			
			iRet1 = ScrSelectFont(&stDispFonts[ii], &stDispFonts[ii+1]);
			if (iRet1)
			{
				ShowMsgFontMissing(FALSE, &stDispFonts[ii], &stDispFonts[ii+1], iRet1);
				iRet = -1;
			}
		}
	}

	return iRet;
#else
	if(access(glSysParam.stEdcInfo.stLangCfg.szFilePath, F_OK) != 0)
	{
		uchar	szBuff[64 + 30];
		Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), NULL);
		ChangeLangOrder();
		strcpy(szBuff, glSysParam.stEdcInfo.stLangCfg.szDispName);
		strcat(szBuff, "\nFONT MISS");
		MirroringSendEcr(szBuff);
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, -1, NULL);
		return -1;
	}
	return 0;
#endif
}

// Enumerates all supported fonts in POS.
// هˆ—ن¸¾ç³»ç»ںه­—ه؛“
int EnumSysFonts(void)
{
#ifdef _MONITOR_
	int			iRet, ii;
	ST_FONT		stFontsList[16];

	GUI_MENU	stInfoList;
	GUI_MENUITEM	stInfoListItem[16+1];

	iRet = EnumFont(stFontsList, 16);
	if (iRet<1)
	{
		MirroringSendEcr("ENUM FAILED");
		Gui_ClearScr();
		Gui_ShowMsgBox(_T("ENUM SYS FONTS"), gl_stTitleAttr, _T("ENUM FAILED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);	
		return;
	}

	memset(stInfoListItem, 0, sizeof(stInfoListItem));
	for (ii=0; ii<iRet; ii++)
	{
		sprintf((char *)stInfoListItem[ii].szText, "%02d-%02dx%02d,%d,%d",
			stFontsList[ii].CharSet, stFontsList[ii].Width, stFontsList[ii].Height,
			stFontsList[ii].Bold, stFontsList[ii].Italic); // Modified by Kim_LinHB 2014-8-6 v1.01.0001 bug494
		stInfoListItem[ii].bVisible = TRUE;
		stInfoListItem[ii].nValue = ii;
		stInfoListItem[ii].vFunc = NULL;
	}

	strcpy(stInfoListItem[ii].szText, "");
	stInfoListItem[ii].bVisible = FALSE;
	stInfoListItem[ii].nValue = -1;
	stInfoListItem[ii].vFunc = NULL;

	Gui_BindMenu(_T("ENUM SYS FONTS"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stInfoListItem, &stInfoList);
	Gui_ClearScr();
	Gui_ShowMenuList(&stInfoList, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, NULL);
#else
	int			iRet, ii;
	FT_FONT *stFontsList;

	GUI_MENU	stInfoList;
	GUI_MENUITEM	stInfoListItem[16+1];

	iRet = OsEnumFont(&stFontsList);
	if (iRet<1)
	{
		MirroringSendEcr("ENUM FAILED");
		Gui_ClearScr();
		Gui_ShowMsgBox(_T("ENUM SYS FONTS"), gl_stTitleAttr, _T("ENUM FAILED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);
		return ERR_NO_DISP;
	}

	memset(stInfoListItem, 0, sizeof(stInfoListItem));
	for (ii=0; ii<iRet; ii++)
	{
		sprintf((char *)stInfoListItem[ii].szText, "%d.[%s]%s", ii + 1,
				stFontsList[ii].FileName, stFontsList[ii].FontName);
		stInfoListItem[ii].bVisible = TRUE;
		stInfoListItem[ii].nValue = ii;
		stInfoListItem[ii].vFunc = NULL;
	}

	strcpy(stInfoListItem[ii].szText, "");
	stInfoListItem[ii].bVisible = FALSE;
	stInfoListItem[ii].nValue = -1;
	stInfoListItem[ii].vFunc = NULL;

	Gui_BindMenu(_T("ENUM SYS FONTS"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stInfoListItem, &stInfoList);
	Gui_ClearScr();
	Gui_ShowMenuList(&stInfoList, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, NULL);
#endif
	return 0;
}

int SxxWriteKey(uchar ucSrcKeyIdx, const uchar *psKeyBCD, uchar ucKeyLen, uchar ucDstKeyId, uchar ucDstKeyType, const uchar *psKCV)
{
	int			iRet;
	ST_KEY_INFO	stKeyInfoIn;
	ST_KCV_INFO	stKcvInfoIn;

	memset(&stKeyInfoIn, 0, sizeof(stKeyInfoIn));
	memset(&stKcvInfoIn, 0, sizeof(stKcvInfoIn));

	memcpy(stKeyInfoIn.aucDstKeyValue, psKeyBCD, ucKeyLen);
	stKeyInfoIn.iDstKeyLen   = ucKeyLen;
	stKeyInfoIn.ucDstKeyIdx  = ucDstKeyId;
	stKeyInfoIn.ucDstKeyType = ucDstKeyType;
	stKeyInfoIn.ucSrcKeyIdx  = ucSrcKeyIdx;
	stKeyInfoIn.ucSrcKeyType = PED_TMK;

	if (psKCV==NULL)
	{
		stKcvInfoIn.iCheckMode = 0;
	}
	else
	{
		stKcvInfoIn.iCheckMode = 1;
		stKcvInfoIn.aucCheckBuf[0] = 4;
		memcpy(stKcvInfoIn.aucCheckBuf+1, psKCV, 4);
	}

	iRet = PedWriteKey(&stKeyInfoIn, &stKcvInfoIn);
	return iRet;
}

uchar ChkOnBase(void)
{
#if defined(_Sxx_)
	if (!ChkTerm(_TERMINAL_S60_))
	{
		return 0;
	}
	return OnBase();
#else
	return 0;
#endif
}

void SetOffBase(unsigned char (*Handle)())
{
#if defined(_Sxx_)
	if (!ChkTerm(_TERMINAL_S60_))
	{
		return;
	}
	if (Handle==NULL)
	{
		//ScrPrint(0,0,0," SET NULL ");DelayMs(500);ScrPrint(0,0,0,"          ");
		
		ScrSetEcho(0);
		return;
	}
	//ScrPrint(0,0,0," SET ECHO ");DelayMs(500);ScrPrint(0,0,0,"          ");
	ScrSetOutput(2);
	(*Handle)();
	
	ScrSetEcho(2);
	ScrSetOutput(1);
	ScrSetEcho(1);
#else
	return;

#endif
}

uchar OffBaseDisplay(void)
{
#if defined(_Sxx_)
	MirroringSendEcr("RETURN TO BASE");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("RETURN TO BASE"), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL); 
	return 0;
#else
	return 0;

#endif
}

uchar OffBaseCheckPrint(void)
{
#if defined(_Sxx_)
	if( OnBase()==0 )
	{
		return 0;
	}
	return OffBaseDisplay();
#else
	return 0;

#endif
}

uchar OffBaseCheckEcr(void)
{
#if defined(_Sxx_)
	if( OnBase()==0 )
	{
		return 0;
	}
	return OffBaseDisplay();

#else
	return 0;

#endif
}

// Added by Kim_LinHB 2014-6-21
void SetCurrTitle(const unsigned char *pszTitle)
{
	if(pszTitle)
	{
		sprintf(gl_szCurrTitle, "%.*s", sizeof(gl_szCurrTitle), pszTitle);
	}
}

const unsigned char *GetCurrTitle(void)
{
	if(0 == gl_szCurrTitle[0])
		return NULL;
	return (const unsigned char *)&gl_szCurrTitle[0];
}
// Add End

// Added by Kim_LinHB 2014-08-22 v1.01.0004
void SplitIpAddress(const unsigned char *Ip, unsigned char sub[4])
{
	unsigned char *p;
	int iCnt = 0;

	p = (unsigned char *)Ip ;
	while (p)
	{
		sub[iCnt++] = atoi(p);
		p = strchr(p + 1, '.');
		if(p) ++p;
	}
}

void MergeIpAddress(const unsigned char sub[4], unsigned char *Ip)
{
    if(Ip)
    {
        sprintf(Ip, "%d.%d.%d.%d", sub[0], sub[1], sub[2], sub[3]);
    }
}

#ifdef _PROLIN2_4_
void Reg_CommIcon(int type, char slot)
{
	int iDefWidth = XuiStatusbarCanvas()->width /6;
	int iDefHeight = XuiStatusbarCanvas()->height;
	slot = slot?1:0;
	switch(type)
	{
	case CT_MODEM:
		SB_RegIcon(SB_ICON_MODEM, iDefWidth *slot, 0, iDefWidth, iDefHeight, 200);
		break;
	case CT_TCPIP:
		SB_RegIcon(SB_ICON_ETHERNET, iDefWidth *slot, 0, iDefWidth, iDefHeight, 500);
		break;
	case CT_CDMA:
		{
			char sTermInfo[65];
			OsRegGetValue("ro.fac.radio",sTermInfo);
			if(memcmp(sTermInfo, "MU509", 5) != 0)
				SB_RegIcon(SB_ICON_WIRELESS, iDefWidth *slot, 0, iDefWidth, iDefHeight, 500);
			else
				SB_RegIcon(SB_ICON_WIRELESS, iDefWidth *slot, 0, iDefWidth, iDefHeight, -1);
		}break;
	case CT_GPRS:
		{
			char sTermInfo[65];
			OsRegGetValue("ro.fac.radio",sTermInfo);
			if(memcmp(sTermInfo, "MU509", 5) != 0)
				SB_RegIcon(SB_ICON_WIRELESS, iDefWidth *slot, 0, iDefWidth, iDefHeight, 5000);
			else
				SB_RegIcon(SB_ICON_WIRELESS, iDefWidth *slot, 0, iDefWidth, iDefHeight, -1);
		}break;
	case CT_WIFI:
		SB_RegIcon(SB_ICON_WIFI, iDefWidth *slot, 0, iDefWidth, iDefHeight, 500);
		break;
	case CT_BLTH:
		SB_RegIcon(SB_ICON_BLUETOOTH, iDefWidth *slot, 0, iDefWidth, iDefHeight, 500);
		break;
	default:
		break;
	}
}

void UnReg_CommIcon(int type)
{
	switch(type)
	{
	case CT_MODEM:
		SB_UnRegIcon(SB_ICON_MODEM);
		break;
	case CT_TCPIP:
		SB_UnRegIcon(SB_ICON_ETHERNET);
		break;
	case CT_CDMA:
		SB_UnRegIcon(SB_ICON_WIRELESS);
		break;
	case CT_GPRS:
		SB_UnRegIcon(SB_ICON_WIRELESS);
		break;
	case CT_WIFI:
		SB_UnRegIcon(SB_ICON_WIFI);
		break;
	case CT_BLTH:
		SB_UnRegIcon(SB_ICON_BLUETOOTH);
		break;
	default:
		break;
	}
}

void ChangeLangOrder()
{
	if(0 == strcmp(glSysParam.stEdcInfo.stLangCfg.szDispName, "Arabic"))
	{
		if(GUI_ALIGN_LEFT == gl_stLeftAttr.eAlign) //reverse
		{
			GUI_TEXT_ATTR temp = gl_stLeftAttr;
			gl_stLeftAttr = gl_stRightAttr;
			gl_stRightAttr = temp;
		}
	}
	else
	{
		if(GUI_ALIGN_LEFT != gl_stLeftAttr.eAlign) //recover
		{
			GUI_TEXT_ATTR temp = gl_stLeftAttr;
			gl_stLeftAttr = gl_stRightAttr;
			gl_stRightAttr = temp;
		}
	}
}

static int *sg_PhyKeyList = NULL;
static int sg_PhyKeyNum = 0;
void Reg_PhyKey(const int *keyList, int len)
{
    if(!keyList)
        return;
    if(sg_PhyKeyList)
    {
        free(sg_PhyKeyList);
    }
    sg_PhyKeyList = (int *)malloc((len+1) *sizeof(int));
    memcpy(sg_PhyKeyList, keyList, len * sizeof(int));
    sg_PhyKeyNum = len;
}
char HasPhyKeyExisted(int keyValue)
{
    int i;
    for(i = 0; i < sg_PhyKeyNum; ++i)
    {
        if(keyValue == sg_PhyKeyList[i])
        {
            return 1;
        }
    }
    return 0;
}

const char *TranslateEx(const char *str)
{
	static int iLoop = 0;
	static char szBuffer[20][255] = {{0}};
	char *p;

	strcpy(szBuffer[iLoop], Translate(str));
	if(strcmp(szBuffer[iLoop], str) != 0){ //non-English
		char szTemp[255];
		strcpy(szTemp, szBuffer[iLoop]);
		OsCodeConvert(glSysParam.stEdcInfo.stLangCfg.szCharSet, "UTF-8", szTemp, szBuffer[iLoop], 255);
	}
	p = szBuffer[iLoop++];
	if(iLoop >= 20)
		iLoop = 0;
	return p;
}
#endif

// Get IC Card cpplication currency code.
void GetEmvCurrencyCode(uchar *psCurrencyCode)
{
	int	  iRet;
	int   iTagLen;
	uchar szBuff[64];

	*psCurrencyCode = 0;
#ifdef ENABLE_EMV
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
		memset(szBuff, 0x00, sizeof(szBuff));
		iRet = EMVGetTLVData(0x9F42, szBuff, &iTagLen);
		if( iRet!=EMV_OK )
		{
			return;
		}
		sprintf((char *)psCurrencyCode, "%.2s", szBuff);
		
	}
#endif
	return;
}

// Get TMS-configured currency code.
void GetTmsCurrencyCode(uchar *psCurrencyCode)
{
	int	  iRet;
	int   iTagLen;
	uchar szBuff[64];

	PubASSERT(NULL != psCurrencyCode);
	*psCurrencyCode = 0;
#ifdef ENABLE_EMV
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
		memset(szBuff, 0x00, sizeof(szBuff));
		iRet = EMVGetTLVData(0x5F2A, szBuff, &iTagLen);
		if( iRet!=EMV_OK )
		{
			return;
		}
		sprintf((char *)psCurrencyCode, "%.2s", szBuff);

	}
#endif
	return;
}

// check multi-batch is full(PREAUTH)
// 0-not full, 1-full
int CheckTabBatchFull(void)
{
	int i, bBatch;

	bBatch = TRUE;
	for(i=0; i<MAX_AUTH_TRANLOG; i++)
	{
		if(glSysCtrl.authCtrl.sAcqKeyList[i] == INV_ACQ_KEY)
		{
			bBatch = FALSE;
			break;
		}
	}

	if(i>=MAX_AUTH_TRANLOG || bBatch)
	{
		return 1;
	}

	return 0;
}

// check it's time for pre-auth to complete
// -1-no need to complete, 1-need to complete and the return value is the record number in log file
int ChkIfTimeToCompPreAuth(void)
{
	int i, iRet;
	ulong ulCurDateTime;    // millisecond
	ulong ulInterval;
	uchar szDateTime[14+1]; // YYYYMMDDhhmmss
	TRAN_LOG stLog;

	GetDateTime(szDateTime);
	ulInterval = glSysCtrl.authCtrl.uiTabBatchDay * 24 * 3600;
	for(i=0; i<MAX_AUTH_TRANLOG; i++)
	{
		if(glSysCtrl.authCtrl.sAcqKeyList[i] != INV_ACQ_KEY)
		{
			ulCurDateTime = PubTime2Long(szDateTime);
			if(ulCurDateTime - glSysCtrl.authCtrl.ulStart[i] > ulInterval)
			{
				memset(&stLog, 0x00, sizeof(TRAN_LOG));
				iRet = LoadAuthTranLog(&stLog, i);
				if((iRet == 0) && (TS_NOT_COMP & stLog.uiStatus)) //linzhao 20160106
				{
					return i;
				}
			}
		}
	}

	return -1;
}

// clear batch for pre-auth transaction
int ClearTabBatch(void)
{
	int i, iRet;
	TRAN_LOG stLog;
	if(!glSysCtrl.authCtrl.ucEnableTabBatch)
	{
		return 1;
	}

	for(i=0; i<MAX_AUTH_TRANLOG; i++)
	{
		if(glSysCtrl.authCtrl.sAcqKeyList[i] != INV_ACQ_KEY)
		{
			memset(&stLog, 0x00, sizeof(TRAN_LOG));
			iRet = LoadAuthTranLog(&stLog, i);
			OsLog(LOG_ERROR, "%s--%d, i:%d, uiStatus:%x", __FILE__, __LINE__, i, stLog.uiStatus);//linzhao
			if(0 != iRet)
			{
				return 1;
			}
			//linzhao 20151230
			if((TS_AUTH_SEND & stLog.uiStatus) || (TS_ADJ & stLog.uiStatus) || (TS_VOID & stLog.uiStatus))
			{
			    OsLog(LOG_ERROR, "clearTab" );//linzhao
				glSysCtrl.authCtrl.sAcqKeyList[i] = INV_ACQ_KEY;
				glSysCtrl.authCtrl.uiTotalRec--;
				glSysCtrl.authCtrl.ulStart[i] = 0;
			}
		}
	}

	return 0;
}

// check if log exits in pre-auth/auth log file by transaction date and invoice
// return value, iIdex start from 0, the max value is (MAX_AUTH_TRANLOG-1)
// if error or not exits, return non-zero,otherwise return 0 and update iIdex
int CheckExitsAuthLog(const void *pstInLog, int *iIdx)
{
	int i, iRet;
	TRAN_LOG stLog;

	if(NULL==pstInLog)
	{
		return 1;
	}
	for(i=0; i<MAX_AUTH_TRANLOG; i++)
	{
//		if(glSysCtrl.authCtrl.sAcqKeyList[i] == INV_ACQ_KEY)
//		{
//			continue;
//		}
		memset(&stLog, 0x00, sizeof(TRAN_LOG));
		iRet = LoadAuthTranLog(&stLog, i);
		if(0 != iRet)
		{
			return iRet;
		}
		if( 0 != strcmp(((TRAN_LOG *)pstInLog)->szPan, stLog.szPan) )
		{
			continue;
		}
		if( 0 != strcmp(((TRAN_LOG *)pstInLog)->szRRN, stLog.szRRN) )
		{
			continue;
		}
		if( 0 != strcmp(((TRAN_LOG *)pstInLog)->szAuthCode, stLog.szAuthCode))
		{
			continue;
		}
		*iIdx = i;
		break;
	}

	if(MAX_AUTH_TRANLOG <= i)
	{
		*iIdx = -1;
		return 1;
	}

	return 0;
}

// check if log exits in log file by transaction date and invoice
// return value, iIdex start from 0, the max value is (MAX_TRANLOG-1)
// if error or not exits, return non-zero,otherwise return 0 and update iIdex
int CheckExitsLog(const void *pstInLog, int *iIdx)
{
	int i, iRet;
	TRAN_LOG stLog;

	if(NULL==pstInLog)
	{
		return 1;
	}
	for(i=0; i<MAX_TRANLOG; i++)
	{
//		if(glSysCtrl.sAcqKeyList[i] == INV_ACQ_KEY)
//		{
//			continue;
//		}
		memset(&stLog, 0x00, sizeof(TRAN_LOG));
		iRet = LoadTranLog(&stLog, i);
		if(0 != iRet)
		{
			return iRet;
		}
		if( 0 != strcmp(((TRAN_LOG *)pstInLog)->szRRN, stLog.szRRN) )
		{
			continue;
		}
		if( 0 != strcmp(((TRAN_LOG *)pstInLog)->szAuthCode, stLog.szAuthCode))
		{
			continue;
		}
		*iIdx = i;
		break;
	}

	if(MAX_TRANLOG <= i)
	{
		*iIdx = -1;
		return 1;
	}

	return 0;
}

int GetDccRate(const char *in, char *out)
{
    if(in && out)
    {
        int iRateDot = strlen(in) - (in[0] - '0');
        sprintf(out, "%.*s.%s", iRateDot - 1, in + 1, in + iRateDot);
        return 0;
    }
    return -1;
}

// end of file

