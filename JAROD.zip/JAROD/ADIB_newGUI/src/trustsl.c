/*------------------------------------------------------------
* FileName: trustsl.c
* Author: FOURA
* Date: 2016-03-16
------------------------------------------------------------*/

#include "global.h"
#include <inttypes.h>

int getDataTPK(uchar*strTemp,uchar*szIndex,uchar*szVALUE,uchar*szKCV)
{
        int i;
        int iRet;
        char buf[100];
        char key[] = ",";

//fffFOURA("hehehehe");

///fffFOURA(strTemp);
        iRet = -1;
        strcpy(buf, strTemp);

        if ( strlen(buf) < 40)
            return iRet;

        char *token = strtok(buf, key);
        i=0;
        while ( token )
        {

            if ( i==0 )
            { // fffFOURA("token 1");
                sprintf(szIndex,"%s",token);
                i++;
                iRet = -1 ;
            }
            else if ( i==1 )
             {//fffFOURA("token 2");
                 sprintf(szVALUE,"%s",token);
                 i++;
                 iRet = -1 ;

                //fffFOURA(szVALUE);
             }
            else if ( i==2 )
               {//fffFOURA("token 3");
                   sprintf(szKCV,"%s",token);
                   i++;
                   iRet = 0 ;
                   //fffFOURA(szKCV);
               }

              token = strtok(NULL, key);
        }


     return iRet;
}


int getDataTPKTMK(uchar*strTemp,uchar*szIndex1,uchar*szVALUE1,uchar*szKCV1,uchar*szIndex2,uchar*szVALUE2,uchar*szKCV2)
{
  int k;

    int i;
    int iRet;
    char buf[100];
    char bufT[100];
    char key[] = ",";

//fffFOURA("hehehehe");

///fffFOURA(strTemp);
    iRet = -1;
    strcpy(buf, strTemp);

//    for (k=3;k<strlen(bufT);k++)
//    {
//    	buf[k-3]=bufT[k];
//    }
//
//    buf[strlen(bufT)-3]='\0';

//    strcpy(buf, strTemp);

    if ( strlen(buf) < 40)
        return iRet;

    char *token = strtok(buf, key);
    i=0;
    while ( token )
    {

        if ( i==0 )
        { // fffFOURA("token 1");
            sprintf(szIndex1,"%s",token);
            i++;
            iRet = -1 ;
        }
        else if ( i==1 )
         {//fffFOURA("token 2");
             sprintf(szVALUE1,"%s",token);
             i++;
             iRet = -1 ;

            //fffFOURA(szVALUE);
         }
        else if ( i==2 )
           {//fffFOURA("token 3");
               sprintf(szKCV1,"%s",token);
               i++;
               iRet = -1 ;
               //fffFOURA(szKCV);
           }
        else  if ( i==3 )
        { // fffFOURA("token 1");
            sprintf(szIndex2,"%s",token);
            i++;
            iRet = -1 ;
        }
        else if ( i==4 )
         {//fffFOURA("token 2");
             sprintf(szVALUE2,"%s",token);
             i++;
             iRet = -1 ;

            //fffFOURA(szVALUE);
         }
        else if ( i==5 )
           {//fffFOURA("token 3");
               sprintf(szKCV2,"%s",token);
               i++;
               iRet = 0 ;
               //fffFOURA(szKCV);
           }





          token = strtok(NULL, key);
    }


 return iRet;


}

void setFeePN(uchar*strFeeValue,uchar*pszFeeP,uchar*pszFeeN)
{
                uchar *ptrFeeData;
                uchar szOper[2]={'+','\0'};
                int i;

                for(i=0;i<strlen(strFeeValue);i++)
                {
                    if (strFeeValue[i]=='-')
                    {
                        szOper[0]='-';
                    }

                }

    // OsLog(LOG_ERROR,"strFeeValue%s",strFeeValue);

                //check oper char


              strtok_r (strFeeValue, szOper,&ptrFeeData);
              OsLog(LOG_ERROR, "%s--%d, ptrFeeData:%x, *ptrFeeData:%x", __FILE__, __LINE__, ptrFeeData, *ptrFeeData);


              memset(pszFeeP,0,sizeof(pszFeeP));
              memset(pszFeeN,0,sizeof(pszFeeN));
             if( *ptrFeeData == 0)
             {
                 OsLog(LOG_ERROR,"NULL%s","----NULL");


                 if (!isFound(strFeeValue,'%')){
                         sprintf(pszFeeP,"%s", "0%");
                         sprintf(pszFeeN,"%s", strFeeValue);
                        // pszFeeN[strlen(pszFeeN)]='\0';
                 }else
                 {
                        sprintf(pszFeeP,"%s", strFeeValue);
                         sprintf(pszFeeN,"%s", "0.0");
                        // pszFeeN[strlen(pszFeeN)]='\0';
                 }
             }else
             {


                 if (!isFound(strFeeValue,'%')){
                     sprintf(pszFeeP,"%s", ptrFeeData);
                     sprintf(pszFeeN,"%s", strFeeValue);
                     pszFeeN[strlen(pszFeeN)]='\0';
                 }else
                 {
                     sprintf(pszFeeP,"%s",strFeeValue );
                     sprintf(pszFeeN,"%s",ptrFeeData );
                     pszFeeN[strlen(pszFeeN)]='\0';

                 }


             }



              OsLog(LOG_ERROR,"szFeeValP%s",pszFeeP);
              OsLog(LOG_ERROR,"szFeeValN%s",pszFeeN);

}

uchar isFound(uchar*azParam,uchar chrParam)
{

 int i =0;
 for(i=0;i<strlen(azParam);i++){
     if (azParam[i]==chrParam){
         return TRUE;
     }
 }

 return FALSE;
}

uchar isKCVTRUST(uchar*strKey,uchar*strKCV)
{
     //return TRUE;
	int ENCRYPTION =1;
	int DECRYPTION =0;

	 char str1[15];
     char str2[15];
     int ret;

	 uchar cOut[100];
     int i ;

     uchar szVALUEBCD[100];
      uchar szKCVBCD[50];


     memset(szVALUEBCD,0,sizeof(szVALUEBCD));
      memset(szKCVBCD,0,sizeof(szKCVBCD));


  PubAsc2Bcd(strKey,32,szVALUEBCD);
  PubAsc2Bcd(strKCV,6,szKCVBCD);




	memset(cOut,0,sizeof(cOut));

   // OsDES("\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",cOut, strKey,16,	ENCRYPTION);
  OsDES("\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",cOut, szVALUEBCD,16,	ENCRYPTION);

    memset(str1,0,sizeof(str1));
    memset(str2,0,sizeof(str2));

//    memcpy(str1,strKCV , 3);
    memcpy(str1,szKCVBCD , 3);
    memcpy(str2, cOut, 3);

    ret = memcmp(str1, str2, 3);

     if(ret == 0)
     {
    	// fffFOURA("equel");
    	 return TRUE;
     }else
     {
    	 //fffFOURA("Not equel");
    	 return FALSE;
     }


}


uchar isKCV(uchar*strKey,uchar*strKCV)
{
     //return TRUE;
	int ENCRYPTION =1;
	int DECRYPTION =0;

	 char str1[15];
     char str2[15];
     int ret;

	 uchar cOut[100];
     int i ;


	memset(cOut,0,sizeof(cOut));

    OsDES("\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00",cOut, strKey,16,	ENCRYPTION);


    memset(str1,0,sizeof(str1));
    memset(str2,0,sizeof(str2));

    memcpy(str1,strKCV , 3);
    memcpy(str2, cOut, 3);

    ret = memcmp(str1, str2, 3);

     if(ret == 0)
     {
    	// fffFOURA("equel");
    	 return TRUE;
     }else
     {
    	 //fffFOURA("Not equel");
    	 return FALSE;
     }


}



void fffFOURA(uchar*strData)
{

    Gui_ClearScr();
    Gui_ShowMsgBox("FOURA TEST", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);


}

void fffFOURATMK(uchar*strData)
{

    Gui_ClearScr();
    Gui_ShowMsgBox("ERROR INJECTION", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
    Gui_ClearScr();

}

void hhhHasan(int inData)
{
	uchar strData[100];

	memset(strData,0,sizeof(strData));
	sprintf(strData,"%d",inData);
    Gui_ClearScr();
    Gui_ShowMsgBox("HASAN TEST", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);


}

void hhhHasanHEX(int inData)
{
	uchar strData[100];

	memset(strData,0,sizeof(strData));
	sprintf(strData,"%.2X",inData);
    Gui_ClearScr();
    Gui_ShowMsgBox("HASAN Hexa", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);


}

void hhhHasanHEXPIN(uchar *DATAPIN)
{
	int i;
	uchar strData[100];
	uchar strData2[3];
	memset(strData,0,sizeof(strData));
	strcpy(strData,"");

	for (i=0;i<8;i++)
	{
	memset(strData2,0,sizeof(strData2));

	sprintf(strData2,"%.2X",DATAPIN[i]);
	strcat(strData,strData2);
	}
    Gui_ClearScr();
    Gui_ShowMsgBox("HASAN PIN", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);


}

void gggGETTag(unsigned short Tag)
{
	int i;
	 int iRet  = 0;
	 int iLength = 0;
	 char sBuff[200];

		 memset(sBuff,0,sizeof(sBuff));

		 iRet = EMVGetTLVData(Tag, sBuff, &iLength);

	fffFOURA("Length=")	;
	hhhHasan(iLength);

	for (i=0;i<iLength;i++){

		 hhhHasanHEX(sBuff[i]);
	}


}

uchar isIssuerLocalCurrency(void)
{
	int i;
	 int iRet  = 0;
	 int iLength = 0;
	 char sBuff[200];

	 memset(sBuff,0,sizeof(sBuff));


	   iRet = EMVGetTLVData(0x5F28, sBuff, &iLength);

	//hhhHasan(iRet);
	//hhhHasan(iLength);
	//hhhHasanHEX(sBuff[0]);
	//hhhHasanHEX(sBuff[1]);
 if(iRet!=0){
	 return FALSE ;
 }

    if (   (sBuff[0]=='\x07') && (sBuff[1]=='\x84')  )
    {
    	return TRUE ;
    }else
    {
    	return FALSE ;
    }



}

void injectManual(void){

	// OsPedEraseKeys();

	  // injectTMKs();
	   //injectTPKs();

	  //injectTPKs();


	 //  injectJCB(0);
      // injectCUP(0);

 // injectCUP(0);
	   //   injectJCB(0);
   // injectMESTRO(0);


    //injectLOYALITY(0);
	 //injectMASTER(0);

}//end inject keys

void readSNTRM(void)
{
	memset(szSerialNumberTRM, 0, sizeof(szSerialNumberTRM));
	ReadSN(szSerialNumberTRM);

}


void injectCUP(int intSrcKeyIdx)
{			ST_KEY_INFO     stTmp_Key;
			ST_KCV_INFO		stTmp_Kcv;
			//================================================
				stTmp_Key.ucSrcKeyType = PED_TMK;
			stTmp_Key.ucSrcKeyIdx  = intSrcKeyIdx;
			stTmp_Key.ucDstKeyType = PED_TMK;
			stTmp_Key.ucDstKeyIdx  = 2;//MASTER_KEY_ID
			//TMK
			//============
 			memcpy(stTmp_Key.aucDstKeyValue,"\x37\x5B\xF8\x8C\x25\x29\x37\x01\xF4\xE0\x10\xC1\x45\xAD\x01\x8A",16);
			stTmp_Key.iDstKeyLen = 16;
			stTmp_Kcv.iCheckMode =0;
			PedWriteKey(&stTmp_Key, &stTmp_Kcv);
			//==========================================
			stTmp_Key.ucSrcKeyType = PED_TMK;
			stTmp_Key.ucSrcKeyIdx  = 2;//MASTER_KEY_ID
			stTmp_Key.ucDstKeyType = PED_TPK;
			stTmp_Key.ucDstKeyIdx  = 2;//DEF_PIN_KEY_ID
			//TPK
			memcpy(stTmp_Key.aucDstKeyValue,"\xDF\x76\x24\x53\xFE\xAC\x55\x21\xC3\x1F\x2B\xDB\xE8\xCF\x86\x5E",16);
			//"\x9D\xAA\x5A\xFD\xBC\xBA\x23\xEE\x98\x16\xE4\x59\xFA\xF6\xE5\x87"//old
			stTmp_Key.iDstKeyLen = 16;
			stTmp_Kcv.iCheckMode =0;
			PedWriteKey(&stTmp_Key, &stTmp_Kcv);
			//========================================
}//end injectCUP



void injectJCB(int intSrcKeyIdx)
{
			ST_KEY_INFO     stTmp_Key;
			ST_KCV_INFO		stTmp_Kcv;
			//================================================
	  	  	stTmp_Key.ucSrcKeyType = PED_TMK;
		    stTmp_Key.ucSrcKeyIdx  = intSrcKeyIdx;
		    stTmp_Key.ucDstKeyType = PED_TMK;
		    stTmp_Key.ucDstKeyIdx  = 1;//MASTER_KEY_ID
		   //TMK
		   memcpy(stTmp_Key.aucDstKeyValue,"\x36\xF3\xE4\x42\x60\x74\x72\x09\xBB\xC0\xF3\x6C\x18\x27\x3A\xAC",16);
		    stTmp_Key.iDstKeyLen = 16;
		    stTmp_Kcv.iCheckMode =0;
		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		    //==========================================
		    stTmp_Key.ucSrcKeyType = PED_TMK;
		    stTmp_Key.ucSrcKeyIdx  = 1;//MASTER_KEY_ID
		    stTmp_Key.ucDstKeyType = PED_TPK;
		    stTmp_Key.ucDstKeyIdx  = 1;//DEF_PIN_KEY_ID
		    //TPK
		    memcpy(stTmp_Key.aucDstKeyValue,"\x93\xAC\x5F\x46\x68\xBF\x07\xBB\x57\x47\xAB\x51\x0D\xFE\x49\xB8",16);
		    stTmp_Key.iDstKeyLen = 16;
		    stTmp_Kcv.iCheckMode =0;
		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		    //========================================
}//end injectCUP

void injectTMKs(void)
{
	ST_KEY_INFO     stTmp_Key;
	ST_KCV_INFO		stTmp_Kcv;

	//TMKSSSSSSS
	//================================================
	stTmp_Key.ucSrcKeyType = PED_TMK;
	stTmp_Key.ucSrcKeyIdx  = 0;
	stTmp_Key.ucDstKeyType = PED_TMK;
	stTmp_Key.ucDstKeyIdx  = 2;//MASTER_KEY_ID
	//TMK cup
	//============
	memcpy(stTmp_Key.aucDstKeyValue,"\x37\x5B\xF8\x8C\x25\x29\x37\x01\xF4\xE0\x10\xC1\x45\xAD\x01\x8A",16);
	stTmp_Key.iDstKeyLen = 16;
	stTmp_Kcv.iCheckMode =0;
	PedWriteKey(&stTmp_Key, &stTmp_Kcv);



	//================================================
	stTmp_Key.ucSrcKeyType = PED_TMK;
    stTmp_Key.ucSrcKeyIdx  = 0;
    stTmp_Key.ucDstKeyType = PED_TMK;
    stTmp_Key.ucDstKeyIdx  = 1;//MASTER_KEY_ID
   //TMK jcb
   memcpy(stTmp_Key.aucDstKeyValue,"\x36\xF3\xE4\x42\x60\x74\x72\x09\xBB\xC0\xF3\x6C\x18\x27\x3A\xAC",16);
    stTmp_Key.iDstKeyLen = 16;
    stTmp_Kcv.iCheckMode = 0;
    PedWriteKey(&stTmp_Key, &stTmp_Kcv);






}

void injectTPKs(void)
{
	ST_KEY_INFO     stTmp_Key;
	ST_KCV_INFO		stTmp_Kcv;


    //TPKKKKKKKK
    //==========================================
    stTmp_Key.ucSrcKeyType = PED_TMK;
    stTmp_Key.ucSrcKeyIdx  = 1;//MASTER_KEY_ID
    stTmp_Key.ucDstKeyType = PED_TPK;
    stTmp_Key.ucDstKeyIdx  = 1;//DEF_PIN_KEY_ID
    //TPK jcb
    memcpy(stTmp_Key.aucDstKeyValue,"\x93\xAC\x5F\x46\x68\xBF\x07\xBB\x57\x47\xAB\x51\x0D\xFE\x49\xB8",16);
    stTmp_Key.iDstKeyLen = 16;
    stTmp_Kcv.iCheckMode =0;
    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
    //========================================

	//==========================================
	stTmp_Key.ucSrcKeyType = PED_TMK;
	stTmp_Key.ucSrcKeyIdx  = 1;//MASTER_KEY_ID
	stTmp_Key.ucDstKeyType = PED_TPK;
	stTmp_Key.ucDstKeyIdx  = 2;//DEF_PIN_KEY_ID
	//TPK cup
	memcpy(stTmp_Key.aucDstKeyValue,"\xDF\x76\x24\x53\xFE\xAC\x55\x21\xC3\x1F\x2B\xDB\xE8\xCF\x86\x5E",16);
	stTmp_Key.iDstKeyLen = 16;
	stTmp_Kcv.iCheckMode =0;
	PedWriteKey(&stTmp_Key, &stTmp_Kcv);
	//========================================




}//end injectCUP

void injectTPKsTMS(uchar*inData)
{
	ST_KEY_INFO     stTmp_Key;
	ST_KCV_INFO		stTmp_Kcv;

   int iiRet=0;

     int i = -1;
     int iiindex =0;
     uchar szIndex[3];
     uchar szVALUE[100];
     uchar szKCV[50];
     uchar szVALUEBCD[100];
     uchar szKCVBCD[50];

   	memset(&stTmp_Key, 0, sizeof(stTmp_Key));
	memset(&stTmp_Kcv, 0, sizeof(stTmp_Kcv));


     memset(szIndex,0,sizeof(szIndex));
     memset(szVALUE,0,sizeof(szVALUE));
     memset(szKCV,0,sizeof(szKCV));
     memset(szVALUEBCD,0,sizeof(szVALUEBCD));
     memset(szKCVBCD,0,sizeof(szKCVBCD));

 i =  getDataTPK(inData,&szIndex,&szVALUE,&szKCV);



 if (i==-1){
	 return ;
 }


 iiindex = atoi(szIndex);

 PubAsc2Bcd(szVALUE,32,szVALUEBCD);
 PubAsc2Bcd(szKCV,8,szKCVBCD);


 if (  isKCV(szVALUEBCD,szKCVBCD) == FALSE )
 {
	   PubBeepErr();
	   Gui_ClearScr();
	   Gui_ShowMsgBox("KEY ERROR", gl_stTitleAttr, "Error in KCV", gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
	   return ;
 }



    //TPKKKKKKKK
    //==========================================
    stTmp_Key.ucSrcKeyType = PED_TMK;
    stTmp_Key.ucSrcKeyIdx  = iiindex;//1;//MASTER_KEY_IDiiindex
    stTmp_Key.ucDstKeyType = PED_TPK;;
    stTmp_Key.ucDstKeyIdx  = iiindex;// 1;//DEF_PIN_KEY_ID
    //TPK
    memcpy(stTmp_Key.aucDstKeyValue,szVALUEBCD,16);


    stTmp_Key.iDstKeyLen = 16;

    stTmp_Kcv.iCheckMode = 0;
   // stTmp_Kcv.aucCheckBuf[0] = 3;
  // memcpy(stTmp_Kcv.aucCheckBuf+1, szKCVBCD, 3);


    iiRet =  PedWriteKey(&stTmp_Key, &stTmp_Kcv);
    //========================================
 //hhhHasan(iiRet);//2 -332 -325    3 -325   -325 1

}//end injectTPK


void injectMASTER(int intSrcKeyIdx)
{
	ST_KEY_INFO     stTmp_Key;
 	ST_KCV_INFO		stTmp_Kcv;
	 	 //==========================================================================
// 		 		  Start master ONLINE
//
// 		 		   		TMK
// 		 		  20DC 9807 F815 4ADC B03E C4D5 1054 58BC
// 		 		  158C 5792 0DD9 75B5 F8BC E094 C758 F789
// 		 		  D3F4 5132 D5B0 29B0 7A70 89FE A257 58CE
// 		 		  ---------------------------------------
// 		 		  E6A4 9EA7 207C 16D9 32F2 ADBF 755B F7FB
//
//						TPK
//						8D1498FB86FBB40A820B3D4FBA2F3375
//
//						TID:24032016 MID:1111111116 NII:005
//						MSI 103	PIN=2485


					//================================================
		 	  	  	stTmp_Key.ucSrcKeyType = PED_TMK;
		 		    stTmp_Key.ucSrcKeyIdx  = intSrcKeyIdx;
		 		    stTmp_Key.ucDstKeyType = PED_TMK;
		 		    stTmp_Key.ucDstKeyIdx  = MASTER_KEY_ID;
		 		   //TMK
		 		   memcpy(stTmp_Key.aucDstKeyValue,
		 		    		"\xE6\xA4\x9E\xA7\x20\x7C\x16\xD9"\
		 		    		"\x32\xF2\xAD\xBF\x75\x5B\xF7\xFB",
		 		            16);
		 		    stTmp_Key.iDstKeyLen = 16;
		 		    stTmp_Kcv.iCheckMode =0;
		 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		 		    //==========================================
		 		    stTmp_Key.ucSrcKeyType = PED_TMK;
		 		    stTmp_Key.ucSrcKeyIdx  = MASTER_KEY_ID;
		 		    stTmp_Key.ucDstKeyType = PED_TPK;
		 		    stTmp_Key.ucDstKeyIdx  = DEF_PIN_KEY_ID;
		 		    //TPK
		 		    memcpy(stTmp_Key.aucDstKeyValue,
		 		    		"\x8D\x14\x98\xFB\x86\xFB\xB4\x0A"\
		 		    		"\x82\x0B\x3D\x4F\xBA\x2F\x33\x75",
		 		            16);
		 		    stTmp_Key.iDstKeyLen = 16;
		 		    stTmp_Kcv.iCheckMode =0;
		 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		 		    //========================================
		 		    //This is just for prove the result is "FF271243B11F40A4".  linzhao
		 		    //you can delete this after you check.
		 		    //TMK
		 		    stTmp_Key.ucSrcKeyType = PED_TMK;
		 		    stTmp_Key.ucSrcKeyIdx  = 0;
		 		    stTmp_Key.ucDstKeyType = PED_TMK;
		 		    stTmp_Key.ucDstKeyIdx  = MASTER_KEY_ID;
		 		   memcpy(stTmp_Key.aucDstKeyValue,
	 		 		    		"\xE6\xA4\x9E\xA7\x20\x7C\x16\xD9"\
	 		 		    		"\x32\xF2\xAD\xBF\x75\x5B\xF7\xFB",
	 		 		            16);
		 		    stTmp_Key.iDstKeyLen = 16;
		 		    stTmp_Kcv.iCheckMode =0;
		 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		 		    //=========================================
		 		    stTmp_Key.ucSrcKeyType = PED_TMK;
		 		    stTmp_Key.ucSrcKeyIdx  = MASTER_KEY_ID;
		 		    stTmp_Key.ucDstKeyType = PED_TDK;
		 		    stTmp_Key.ucDstKeyIdx  = DEF_DATA_KEY_ID;
		 		    //TPK
		 		    memcpy(stTmp_Key.aucDstKeyValue,
		 		    		"\x8D\x14\x98\xFB\x86\xFB\xB4\x0A"\
		 		    		"\x82\x0B\x3D\x4F\xBA\x2F\x33\x75",
		 		            16);
		 		    stTmp_Key.iDstKeyLen = 16;
		 		    stTmp_Kcv.iCheckMode =0;
		 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
		 		    ///End UPI CUP ONLINE
		 		    //==========================================================================

}//end injectMASTER

void injectMESTRO(int intSrcKeyIdx)
{			ST_KEY_INFO     stTmp_Key;
			ST_KCV_INFO		stTmp_Kcv;
			//================================================
				stTmp_Key.ucSrcKeyType = PED_TMK;
			stTmp_Key.ucSrcKeyIdx  = intSrcKeyIdx;
			stTmp_Key.ucDstKeyType = PED_TMK;
			stTmp_Key.ucDstKeyIdx  = MASTER_KEY_ID;
			//TMK
			memcpy(stTmp_Key.aucDstKeyValue,"\x31\x3B\x75\x2C\x0B\xC7\x2C\xD6\xDC\xD0\x6E\x7A\x5D\xCB\xB5\xA8",16);

			stTmp_Key.iDstKeyLen = 16;
			stTmp_Kcv.iCheckMode =0;
			PedWriteKey(&stTmp_Key, &stTmp_Kcv);
			//==========================================
			stTmp_Key.ucSrcKeyType = PED_TMK;
			stTmp_Key.ucSrcKeyIdx  = MASTER_KEY_ID;
			stTmp_Key.ucDstKeyType = PED_TPK;
			stTmp_Key.ucDstKeyIdx  = DEF_PIN_KEY_ID;
			//TPK
			//memcpy(stTmp_Key.aucDstKeyValue,"\x5F\xAE\xE4\x42\xE3\xA8\x4B\xC3\xF3\x69\xFC\xB9\xDC\xD3\x5C\x90",16);
			//2BB90C92819B0144F423BA313CF5EAA8
			memcpy(stTmp_Key.aucDstKeyValue,"\x2B\xB9\x0C\x92\x81\x9B\x01\x44\xF4\x23\xBA\x31\x3C\xF5\xEA\xA8",16);
			stTmp_Key.iDstKeyLen = 16;
			stTmp_Kcv.iCheckMode =0;
			PedWriteKey(&stTmp_Key, &stTmp_Kcv);
			//========================================
}//end injectMESTRO


void injectLOYALITY(int intSrcKeyIdx)
{
	ST_KEY_INFO     stTmp_Key;
 	ST_KCV_INFO		stTmp_Kcv;
 	 //==========================================================================


 	//909AAAEE6C4105E7EE2EDB27173FF584

			//================================================
// 	  	  	stTmp_Key.ucSrcKeyType = PED_TMK;
// 		    stTmp_Key.ucSrcKeyIdx  = 0;
// 		    stTmp_Key.ucDstKeyType = PED_TMK;
// 		    stTmp_Key.ucDstKeyIdx  = MASTER_KEY_ID;
// 		   //TMK
// 		   memcpy(stTmp_Key.aucDstKeyValue,
// 		    		"\x90\x9A\xAA\xEE\x6C\x41\x05\xE7"\
// 		    		"\xEE\x2E\xDB\x27\x17\x3F\xF5\x84",
// 		            16);
// 		    stTmp_Key.iDstKeyLen = 16;
// 		    stTmp_Kcv.iCheckMode =0;
// 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
 		    //==========================================
 		    stTmp_Key.ucSrcKeyType = PED_TMK;
 		    stTmp_Key.ucSrcKeyIdx  = MASTER_KEY_ID;
 		    stTmp_Key.ucDstKeyType = PED_TPK;
 		    stTmp_Key.ucDstKeyIdx  = DEF_PIN_KEY_ID;
 		    //TPK
 		    memcpy(stTmp_Key.aucDstKeyValue,
 		    		"\x90\x9A\xAA\xEE\x6C\x41\x05\xE7"\
 		    		 "\xEE\x2E\xDB\x27\x17\x3F\xF5\x84",
 		    		16);
 		    stTmp_Key.iDstKeyLen = 16;
 		    stTmp_Kcv.iCheckMode =0;
 		    PedWriteKey(&stTmp_Key, &stTmp_Kcv);
 		    //========================================



}//end



void sssShowSendMSG(void){
char ss[1000];
  memset(ss,0,sizeof(ss));
  int hhh=0;

//
//  hhhHasan(glSendData.uiLength);
//  hhhHasan(glSendData.sContent);



//  memset(glSendData.sContent,0,sizeof(glSendData.sContent));
// glSendData.uiLength =glSendData.uiLength-3 ;
//memcpy(glSendData.sContent,"\x00\xF8\x60\x00\x01\x80\x00\x02\x00\x30\x38\x07\x80\x20\xC0\x02\x06\x00\x00\x00\x00\x00\x00\x00\x00\x01\x00\x15\x07\x22\x36\x38\x05\x21\x00\x51\x00\x01\x00\x02\x00\x37\x51\x81\x73\x56\x89\x72\x43\x84\xD1\x90\x12\x01\x13\x83\x99\x74\x00\x00\x0F\x38\x30\x30\x34\x30\x31\x39\x37\x35\x30\x30\x31\x31\x33\x33\x20\x20\x20\x20\x20\x20\x20\x20\x01\x26\x5F\x2A\x02\x08\x40\x82\x02\x38\x00\x95\x05\x08\x00\x00\x80\x00\x9A\x03\x17\x05\x21\x9C\x01\x00\x9F\x02\x06\x00\x00\x00\x00\x00\x01\x9F\x03\x06\x00\x00\x00\x00\x00\x00\x9F\x10\x12\x01\x10\xA5\x00\x13\x04\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\xFF\x9F\x1A\x02\x08\x40\x9F\x26\x08\x2B\x0B\xDB\xDF\x19\x4D\x09\xFE\x9F\x27\x01\x80\x9F\x36\x02\x05\xE5\x9F\x37\x04\x18\x8A\x80\x61\x5F\x34\x01\x01\x9F\x33\x03\x60\xD8\xC8\x9F\x34\x03\x41\x03\x02\x9F\x35\x01\x00\x9F\x1E\x08\x32\x30\x33\x36\x34\x38\x36\x34\x00\x06\x30\x30\x31\x33\x37\x34\x00\x28\x00\x36\x31\x39\x30\x30\x30\x30\x30\x30\x30\x30\x30\x30\x30\x32\x34\x30\x30\x37\x32\x30\x30\x34\x30\x30\x30\x32\x00\x00",250);
//
//glSendData.sContent[250]='\x00';
//glSendData.sContent[251]='\x00';
// glSendData.sContent[252]='\0';

  char sd[3];
  strcpy(ss,"");
	        int cc;
	        for (cc=0;cc<glSendData.uiLength;cc++)
	        {

	        	 memset(sd,0,sizeof(sd));
	       sprintf(sd,"%02X",glSendData.sContent[cc]) ;
	        	// szTrack2
            strcat(ss,sd);
	       OsLog(LOG_ERROR,"HOLE_SEND %d--%s",cc,sd);

	        }

	        OsLog(LOG_ERROR,"AAA SendMSG:%s",ss);

}


void sssShowReciveMSG(void){

char ss[1000];
  memset(ss,0,sizeof(ss));
  int hhh=0;
  char sd[3];
  strcpy(ss,"");
	        int cc;
	        for (cc=0;cc<glRecvData.uiLength;cc++)
	        {

	        	 memset(sd,0,sizeof(sd));
	       sprintf(sd,"%02X",glRecvData.sContent[cc]) ;
	        	// szTrack2
            strcat(ss,sd);
	       OsLog(LOG_ERROR,"HOLE_RECIVE %d--%s",cc,sd);

	        }

	        OsLog(LOG_ERROR,"BBB ReciveMSG:%s",ss);

}


void UpdateF52(void)
{

	//BIT 52 foura
		if( (glProcInfo.stTranLog.uiEntryMode & MODE_PIN_INPUT ) && (!(glProcInfo.stTranLog.uiEntryMode & MODE_PINBYPASS )))
		{

		    if ( !( (NULL != strstr(glCurIssuer.szName, "CUP")) && (glProcInfo.stTranLog.ucTranType==VOID  )  ) )
		    {


		    PubLong2Char((ulong)LEN_PIN_DATA, 2, glSendPack.sPINData);
			memcpy(&glSendPack.sPINData[2], glProcInfo.sPinBlock, LEN_PIN_DATA);


		    }





		}
}

int	CheckSrvCode(uchar *service_code, uchar *pin_required, uchar * pin_feasible)
{
	int		retVal;

	retVal			=	-1;
	*pin_required	=	FALSE;
	*pin_feasible	=	FALSE;




	switch(service_code[2])
	{

		case '0':
			retVal			= 0;
			*pin_required	= TRUE;
  			break;

		case '1':
			retVal			= 0;
  			break;

		case '2':
			retVal	= 0;
  			break;

		case '3':
			retVal			= -1;
			*pin_required	= TRUE;
  			break;

		case '4':
			retVal	= -1;
  			break;

		case '5':
			retVal	= 0;
			*pin_required	= TRUE;
  			break;

		case '6':
			retVal			= 0;
			*pin_feasible	= TRUE;
  			break;

		case '7':
			retVal	= 0;
			*pin_feasible	= TRUE;
  			break;

		default:
			retVal	= 0;
			break;
	}


	if ( ChkIssuerOption(ISSUER_EN_PIN))
			{

	          	*pin_required	= TRUE;

			}
	return retVal;
}

uchar SaveSvcCode(uchar *pszTrack2,uchar *serviceCode)
{
	char	*pszSeperator;

	if( *pszTrack2==0 )
	{
		return FALSE;
	}

	pszSeperator = strchr((char *)pszTrack2, '=');
	if( pszSeperator==NULL )
	{
		return FALSE;
	}
	memcpy(serviceCode,&pszSeperator[5],3);
	return TRUE;
}

void dddoHentFMessage(int intParam){

 char chrr[25];
 memset(chrr,0,sizeof(chrr));
 sprintf(chrr,"dddoHentFMessage_%d",intParam);

   //  fffFOURA(chrr);
    // fffFOURA(glRecvPack.szRspCode);
if (PRN_FAIL_2 == FALSE)
{
	return;
}
	if ( intParam == 0  || intParam == 18  ||
		intParam == 22 || intParam == 20
	)
	{

		DispResult(ERR_HOST_REJ);
		SaveRevInfo(FALSE);
	    PrintReceipt_failPrint_T(PRN_NORMAL);
	    PRN_FAIL_2 = FALSE ;
	}


}


void send2ECR(uchar *psData)
{
	//
		// SetEcr( ) ;




	    uchar   szBuff[32], szTitle[32];
	    int iSelected, iRet;
	    GUI_MENU stEcrMode;
	    GUI_MENUITEM stEcrModeItem[4] = {
	            {"1.NO", 0, TRUE, NULL},
	            {"3.INJECT ", 1, FALSE, NULL},//{"2.ENABLE", 1, TRUE, NULL},
	            {"2.YES", 2, TRUE, NULL},// {"3.ECR ONLY", 2, TRUE, NULL},
	            {"", -1, FALSE, NULL},
	    };



	    sprintf((char *)szTitle, "CONTINUES: %.10s",
	                (glSysParam.stECR.ucMode==ECRMODE_OFF) ? "DISABLE" : (glSysParam.stECR.ucMode==ECRMODE_ENABLED ? "E1" : "E2"));
	    memset(&stEcrMode, 0, sizeof(stEcrMode));
	    Gui_BindMenu(szTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stEcrModeItem, &stEcrMode);

	    Gui_ClearScr();
	    iSelected = 0;
	    iRet = Gui_ShowMenuList(&stEcrMode, 0, USER_OPER_TIMEOUT, &iSelected);
	    //No 0 0 Yes 0 2;
//	    hhhHasan(iRet);
//	    hhhHasan(iSelected);

	    glSysParam.stECR.ucMode = iSelected;
	    SaveSysParam();

	    //-----------------------------------------------------
	    if (glSysParam.stECR.ucMode > 0)
	    {
	        int iPort = glSysParam.stECR.ucPort;
	        if(iPort != PORT_COM1 && iPort != PORT_PINPAD)
	            iPort = PORT_COM1;
	        Gui_ClearScr();


//	        if(ChkTerm(_TERMINAL_S800_))
//	        {
//	            iRet = Gui_ShowAlternative("INJECT", gl_stTitleAttr, "SERIAL PORT", gl_stLeftAttr, "COM 1", PORT_COM1, "PIN PAD", PORT_PINPAD,
//	                    USER_OPER_TIMEOUT, &iPort);
//	        }
//	        else
//	        {
//	            iRet = Gui_ShowMsgBox("INJECT", gl_stTitleAttr, "SERIAL PORT\nCOM 1", gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
//	        }

	        iRet = Gui_ShowMsgBox("INJECT", gl_stTitleAttr, "SERIAL PORT\nCOM 1", gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);

	        glSysParam.stECR.ucPort = iPort;
	        SaveSysParam();

	        int iSpeed = glSysParam.stECR.ucSpeed;
	        if(iSpeed != ECRSPEED_9600 && iPort != ECRSPEED_115200)
	            iSpeed = ECRSPEED_9600;
	        Gui_ClearScr();
	        iRet = Gui_ShowAlternative("INJECT", gl_stTitleAttr, "BAUD RATE", gl_stLeftAttr, "9600", ECRSPEED_9600, "115200", ECRSPEED_115200,
	                    USER_OPER_TIMEOUT, &iSpeed);

	        glSysParam.stECR.ucSpeed = iSpeed;
	        SaveSysParam();

	    }

	    //-----------------------------------------------------
	    // TODO : more settings


	////

	    EcrOpen();  // Open port for ECR



///===============================================
 ////=========================================

if(glSysParam.stECR.ucMode >0)
{

		    char cmdMirroring[100];
		    memset(cmdMirroring,0,sizeof(cmdMirroring));
			strcat(cmdMirroring,psData);
		 	MirroringEcr(cmdMirroring, strlen(cmdMirroring));

}
//		int i;
//		for (i=1;i<=30;i++)
//		{	DelayMs(500);
//			MirroringEcr(cmdMirroring, strlen(cmdMirroring));
//
//		}
		//	MirroringEcr(cmdMirroring, strlen(cmdMirroring));


}


int injectTMKTRUST(void)
{
	int iRet ;

	int i ;
    uchar szVALUETEMP1[100];
    uchar szVALUETEMP2[100];

    uchar szVALUETEMPBCD1[100];
    uchar szVALUETEMPBCD2[100];


    uchar szVALUETEMP111[100];
    uchar szVALUETEMP222[100];


    uchar szIndex1[3];
    uchar szVALUE1[100];
    uchar szKCV1[50];
    uchar szIndex2[3];
    uchar szVALUE2[100];
    uchar szKCV2[50];

    uchar szVALUEXP[100];
    int indx1;
    int indx2;

    memset(szIndex1,0,sizeof(szIndex1));
    memset(szVALUE1,0,sizeof(szVALUE1));
    memset(szKCV1,0,sizeof(szKCV1));

    memset(szIndex2,0,sizeof(szIndex2));
    memset(szVALUE2,0,sizeof(szVALUE2));
    memset(szKCV2,0,sizeof(szKCV2));


    memset(szVALUETEMP1,0,sizeof(szVALUETEMP1));
    memset(szVALUETEMP2,0,sizeof(szVALUETEMP2));
    memset(szVALUETEMPBCD1,0,sizeof(szVALUETEMPBCD1));
    memset(szVALUETEMPBCD2,0,sizeof(szVALUETEMPBCD2));

    memset(szVALUETEMP111,0,sizeof(szVALUETEMP111));
      memset(szVALUETEMP222,0,sizeof(szVALUETEMP222));


    DelayMs(1000);


    ///===================
   uchar bufT[1024];
   uchar buf[1024];
   uchar chL[5];


   memset(bufT,0,sizeof(bufT));
   memset(buf,0,sizeof(buf));
   memset(chL,0,sizeof(chL));


   strcpy(bufT, g_TMK_ALL);

   chL[0]=g_TMK_ALL[0];
   chL[1]=g_TMK_ALL[1];
   chL[2]='\0';

   g_TMK_COUNT_ALL = atoi(chL) ;
   int  k;

    for (k=5;k<strlen(bufT);k++)
    {
    	buf[k-5]=bufT[k];
    }
    buf[strlen(bufT)-5]='\0';
//   hhhHasan(g_TMK_COUNT_ALL);
//   fffFOURA(buf);

///buf
 //toktok
    uchar bufcc[100];
    char key[] = "-";

//    for (i=0;i<g_TMK_COUNT_ALL;i++)
//    {
//

// hhhHasan(strlen(buf));
    	    char *token = strtok(buf, key);
    	     i=0;
    	    while ( token )
    	    {
    	    	memset(g_TMK_ALL_KEY[i],0,sizeof(g_TMK_ALL_KEY[i]));


    	        sprintf(g_TMK_ALL_KEY[i],"%s",token);


//    	       	fffFOURA(g_TMK_ALL_KEY[i]);
//    	       	hhhHasan(strlen(g_TMK_ALL_KEY[i]));

    	       		i++;


    	    	          token = strtok(NULL, key);






    	    }



//    }



int iCounter=0;
 for (i=0;i<g_TMK_COUNT_ALL;i++)
 {


 ////=======================
 //  iRet =  getDataTPKTMK(g_TMK_ALL,szIndex1,szVALUE1,szKCV1,szIndex2,szVALUE2,szKCV2);
   // iRet =  getDataTPKTMK(g_TMK_ALL,szIndex1,szVALUETEMP1,szKCV1,szIndex2,szVALUETEMP2,szKCV2);
    iRet =  getDataTPKTMK(g_TMK_ALL_KEY[i],szIndex1,szVALUETEMP1,szKCV1,szIndex2,szVALUETEMP2,szKCV2);


    ////===========================================



    memset(TMK_ENCREPTED_KEY,0,sizeof(TMK_ENCREPTED_KEY));




    memset(szVALUE1,0,sizeof(szVALUE1));
    memset(szVALUE2,0,sizeof(szVALUE2));



    PubAsc2Bcd(szVALUETEMP1,32,szVALUETEMPBCD1);
    PubAsc2Bcd(szVALUETEMP2,32,szVALUETEMPBCD2);

    OsAES(szVALUETEMPBCD1,szVALUETEMP111, TMK_CLEAR_KEY,16,	0);//1 ENC  0 DEC

    OsAES(szVALUETEMPBCD2,szVALUETEMP222, TMK_CLEAR_KEY,16,	0);//1 ENC  0 DEC

    PubBcd2Asc0(szVALUETEMP111,16,szVALUE1);

    PubBcd2Asc0(szVALUETEMP222,16,szVALUE2);

//    fffFOURA(szVALUE1);
//    fffFOURA(szVALUE2);



    ///==============================================
    indx1 = atoi(szIndex1);
    indx2 = atoi(szIndex2);

     if ( indx1 != indx2)
     {
    	 fffFOURATMK("INJECT FAIL,index");
    	 return 0 ;
     }

     if ( strlen(szVALUE1)!=32)
     {
    	 fffFOURATMK("INJECT FAIL,L1");
    	 return 0 ;
     }

     if ( strlen(szVALUE2)!=32)
     {
    	 fffFOURATMK("INJECT FAIL,L2");
    	 return 0 ;
     }



         //fffFOURA(szVALUE1);
        //  fffFOURA(szKCV1);

     if ( isKCVTRUST(szVALUE1,szKCV1) == FALSE)
     {
    	 fffFOURATMK("INJECT FAIL,KCV1");
    	 return 0 ;
     }

     if ( isKCVTRUST(szVALUE2,szKCV2) == FALSE)
     {
    	 fffFOURATMK("INJECT FAIL,KCV2");
    	 return 0 ;
     }

     memset(szVALUEXP,0,sizeof(szVALUEXP));


     //vonvert
     uchar szVALUEBCD1[100];
     uchar szVALUEBCD2[100];
     memset(szVALUEBCD1,0,sizeof(szVALUEBCD1));
      memset(szVALUEBCD2,0,sizeof(szVALUEBCD2));
      PubAsc2Bcd(szVALUE1,32,szVALUEBCD1);
      PubAsc2Bcd(szVALUE2,32,szVALUEBCD2);





      //=========================C1 xor c2 ===================
      int iii;
      for(iii=0;iii<16;iii++)
      {

    		  szVALUEXP[iii] = szVALUEBCD1[iii] ^ szVALUEBCD2[iii];
    		 //  hhhHasanHEX(szVALUEXP[iii]);

      }

      szVALUEXP[iii] ='\0';


      //=======================================================================
      //=========================inject TMK= szVALUEXP index  = indx1 or indx2 ===================
  	ST_KEY_INFO     stTmp_Key;
  	ST_KCV_INFO		stTmp_Kcv;

  	//TMKSSSSSSS
  	//================================================
  	stTmp_Key.ucSrcKeyType = PED_TMK;
  	stTmp_Key.ucSrcKeyIdx  = 0;
  	stTmp_Key.ucDstKeyType = PED_TMK;
  	stTmp_Key.ucDstKeyIdx  = indx1;//MASTER_KEY_ID
  	//TMK cup
  	//============
  	memcpy(stTmp_Key.aucDstKeyValue,szVALUEXP,16);
  	stTmp_Key.iDstKeyLen = 16;
  	stTmp_Kcv.iCheckMode =0;
    int iRo =	PedWriteKey(&stTmp_Key, &stTmp_Kcv);
  	//===============================

      iCounter++;
     SetInjectRestore();

}//forrrrrr


uchar chShow[25];
memset(chShow,0,sizeof(chShow));
sprintf(chShow,"INJECTION %d KEYS",iCounter);

     Gui_ClearScr();
     Gui_ShowMsgBox("INJECTION", gl_stTitleAttr, chShow, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);
     Gui_ClearScr();

     // hhhHasan(iRo);


      //fffFOURA(szVALUEXP);
     //      fffFOURA(szVALUE1);
     //        fffFOURA(szVALUE2);
     //        fffFOURA(szVALUEBCD1);
     //          fffFOURA(szVALUEBCD2);
//    fffFOURA(szIndex1);
//    fffFOURA(szVALUE1);
//    fffFOURA(szKCV1);
//    fffFOURA(szIndex2);
//    fffFOURA(szVALUE2);
//    fffFOURA(szKCV2);

    return 0 ;
}
int SetInjectRestore(void)
{
    uchar   szBuff[32], szTitle[32];
    int iSelected, iRet;
    GUI_MENU stEcrMode;
    GUI_MENUITEM stEcrModeItem[4] = {
            {"1.Disconnect", 0, TRUE, NULL},
//            {"2.McDonald's", 1, TRUE, NULL},//{"2.ENABLE", 1, TRUE, NULL},
//            {"3.Carrefour", 2, TRUE, NULL},// {"3.ECR ONLY", 2, TRUE, NULL},
            {"", -1, FALSE, NULL},
    };

    SetCurrTitle(_T("INJECTION"));
//    if( PasswordBank()!=0 )
//    {
//        return ERR_NO_DISP;
//    }

    sprintf((char *)szTitle, "CUR: %.10s",
                (glSysParam.stECR.ucMode==ECRMODE_OFF) ? "DISABLE" : (glSysParam.stECR.ucMode==ECRMODE_ENABLED ? "ENABLE1" : "ENABLE2"));
    memset(&stEcrMode, 0, sizeof(stEcrMode));
    Gui_BindMenu(szTitle, gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stEcrModeItem, &stEcrMode);

    Gui_ClearScr();
    iSelected = 0;
//    iRet = Gui_ShowMenuList(&stEcrMode, 0, USER_OPER_TIMEOUT, &iSelected);

    iRet=0;
   // hhhHasan(iSelected);
    if(iRet != GUI_OK){
        return ERR_NO_DISP;
    }

    glSysParam.stECR.ucMode = iSelected;
    SaveSysParam();

    //-----------------------------------------------------
    if (glSysParam.stECR.ucMode > 0)
    {
        int iPort = glSysParam.stECR.ucPort;
        if(iPort != PORT_COM1 && iPort != PORT_PINPAD)
            iPort = PORT_COM1;
        Gui_ClearScr();
        if(ChkTerm(_TERMINAL_S800_))
        {
            iRet = Gui_ShowAlternative("INJECT", gl_stTitleAttr, "SERIAL PORT", gl_stLeftAttr, "COM 1", PORT_COM1, "PIN PAD", PORT_PINPAD,
                    USER_OPER_TIMEOUT, &iPort);
        }
        else
        {
            iRet = Gui_ShowMsgBox("INJECT", gl_stTitleAttr, "SERIAL PORT\nCOM 1", gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
        }
        if(iRet != GUI_OK)
        {
            return ERR_NO_DISP;
        }
        glSysParam.stECR.ucPort = iPort;
        SaveSysParam();

        int iSpeed = glSysParam.stECR.ucSpeed;
        if(iSpeed != ECRSPEED_9600 && iPort != ECRSPEED_115200)
            iSpeed = ECRSPEED_9600;
        Gui_ClearScr();
        iRet = Gui_ShowAlternative("INJECT", gl_stTitleAttr, "BAUD RATE", gl_stLeftAttr, "9600", ECRSPEED_9600, "115200", ECRSPEED_115200,
                    USER_OPER_TIMEOUT, &iSpeed);

        if(iRet != GUI_OK)
        {
            return ERR_NO_DISP;
        }
        glSysParam.stECR.ucSpeed = iSpeed;
        SaveSysParam();

    }
    return 0;
    //-----------------------------------------------------
    // TODO : more settings
}


int updatePreAuthPeriod (uchar*inData)
{
	uchar chTemp[5];
	uchar ucNum;
	memset(chTemp,0,sizeof(chTemp));

	strcpy(chTemp,inData);

	//validation
	if(strlen(chTemp)!=2)
	{
		return -1;
	}

	//fffFOURA(chTemp) ;


	if (!IsNumStr(chTemp))
	{
		//fffFOURA("NO number") ;
		return -1;
	}





	//addd
		ucNum = (uchar)atoi((char *)chTemp);

		if( ucNum==0)
		{
			return -1;

		}

		if( ucNum>=1 && ucNum<=99 )//linzhao 20160101
		{
			glSysCtrl.authCtrl.uiTabBatchDay = ucNum;
			SaveSysCtrlBase();
		}


	return 0;

}

int updatetTimeSettle(uchar*inData)
{
	uchar chTemp[5];
	int ucNum;
	memset(chTemp,0,sizeof(chTemp));
	int ucNump1;
	int ucNump2;

	uchar chTemppart1[5];
	uchar chTemppart2[5];
	uchar chTemp2[5];
	strcpy(chTemp,inData);

	//validation
	if(strlen(chTemp)!=4)
	{
		return -1;
	}

	//fffFOURA(chTemp) ;


	if (!IsNumStr(chTemp))
	{
		//fffFOURA("NO number") ;
		return -1;
	}





	memset( chTemppart1,0,sizeof(chTemppart1));

	memset( chTemppart2,0,sizeof(chTemppart2));

	chTemppart1[0]=chTemp[0];
	chTemppart1[1]=chTemp[1];
	chTemppart1[2]='\0';


	chTemppart2[0]=chTemp[2];
	chTemppart2[1]=chTemp[3];
	chTemppart2[2]='\0';

	//addd
	//	ucNum = (uchar)atol((char *)chTemp);

		ucNump1 = (uchar)atoi((char *)chTemppart1);
		ucNump2 = (uchar)atoi((char *)chTemppart2);



		if( !((ucNump1>=0)  && (ucNump1<=23))  )
		{
			return -1;

		}



		if( !((ucNump2>=0)  && (ucNump2<=59))  )
			{
				return -1;

			}






		ucNum = atol((char *)chTemp);

//hhhHasan(ucNum);
//		memset( chTemp2,0,sizeof(chTemp2));
//
//				sprintf(chTemp2,"%04d",ucNum);
//
//				fffFOURA(chTemp2);


		glSysCtrl.uSettlSTATR = ucNum;
		SaveSysCtrlBase();



	return 0;

}


int updatetMAXSettle(uchar*inData)
{
	uchar chTemp[5];
	int ucNum;
	memset(chTemp,0,sizeof(chTemp));
	int ucNump1;
	int ucNump2;

	uchar chTemppart1[5];
	uchar chTemppart2[5];
	uchar chTemp2[5];
	strcpy(chTemp,inData);

	//validation
	if(strlen(chTemp)!=1)
	{
		return -1;
	}

	//fffFOURA(chTemp) ;


	if (!IsNumStr(chTemp))
	{
		//fffFOURA("NO number") ;
		return -1;
	}



	ucNum = (uchar)atol((char *)chTemp);


	if( !((ucNum>=1)  && (ucNum<=9))  )
		{
			return -1;

		}



//hhhHasan(ucNum);
//		memset( chTemp2,0,sizeof(chTemp2));
//
//				sprintf(chTemp2,"%04d",ucNum);
//
//				fffFOURA(chTemp2);


		glSysCtrl.uSettlMAX = ucNum;
		SaveSysCtrlBase();



	return 0;

}


void setAutoSettlements(void)
{
    int iRet22;

    ST_TIME sBuffTime  ;




    int i;








       OsGetTime(&sBuffTime);
       for (i=0;i<=glSysCtrl.uSettlMAX;i++)
       	{

				   if (( (sBuffTime.Hour==g_iHH[i]) && (sBuffTime.Minute == g_iMM[i])  && (sBuffTime.Second == g_iSS[i])     ) && 	(EMP_AUTOSETTELMENT == TRUE  ))
				   {


					   EMP_AUTOSETTELMENT = FALSE ;
					   iRet22 = TransSettle();

				   }

       	}


       	if (sBuffTime.Hour>g_iHH[glSysCtrl.uSettlMAX])
       	{
       	   EMP_AUTOSETTELMENT = FALSE ;
       	}

//	    	  if (( (sBuffTime.Hour>=4) && (sBuffTime.Hour <5) ) && 	(ECR_AUTOSETTELMENT == FALSE  ))
//	    		    	 	    {
//	    		    	    	ECR_AUTOSETTELMENT = TRUE ;
//	    		    	 	   }

	       // EMP_AUTOSETTELMENT_COUNTER;


}

void setTimeAutoSettlement(void)
{

	int i ;


	int iRet22;
	    uchar chTemp2[5];
	    ST_TIME sBuffTime  ;
	    unsigned char date_str22[100] = {0};


	    int iHH ,iMM,iSS;
	    uchar chHH[3];
	    uchar chMM[3];



		for (i=0;i<10;i++){
			g_iHH[i] = -1;
			g_iMM[i] = -1;
			g_iSS[i] = -1;

		}






	    memset( chTemp2,0,sizeof(chTemp2));

	     sprintf(chTemp2,"%04d",glSysCtrl.uSettlSTATR);


	       chHH[0]=chTemp2[0];
	       chHH[1]=chTemp2[1];
	       chHH[2]='\0';

	       chMM[0]=chTemp2[2];
	       chMM[1]=chTemp2[3];
	       chMM[2]='\0';

	       iHH = atoi(chHH);

	       iMM = atoi(chMM);

	       iSS = 0 ;

//	uchar   EMP_AUTOSETTELMENT;
//	int     EMP_AUTOSETTELMENT_COUNTER;
//
//	int g_iHH[10];
//	int g_iMM[10];
//	int g_iSS[10];



	g_iHH[0] = iHH ;
	g_iMM[0] = iMM ;
	g_iSS[0] = iSS ;



	for (i=1;i<=glSysCtrl.uSettlMAX;i++)
	{
		iSS = iSS +15 ;

		if (iSS >=60)
		{
			iSS = iSS -60 ;

			iMM = iMM + 1 ;
		}


		if (iMM>=60)
		{
			iMM = iMM - 60 ;
			iHH = iHH +1 ;
		}

		if (iHH>=24)
		{
			iHH = iHH - 24 ;

		}

		g_iHH[i] = iHH ;
		g_iMM[i] = iMM ;
		g_iSS[i] = iSS ;


	}

//	for (i=0;i<=glSysCtrl.uSettlMAX;i++)
//		{
//
//		hhhHasan(	g_iHH[i] );
//		hhhHasan(	g_iMM[i]  );
//		hhhHasan(	g_iSS[i]  );
//
//		}


}

uchar  getRuleSettelment(int iSettlTime,int iCurrTime)
{
	int iH1;
	int iH2;


//	OsLog(LOG_ERROR,"xxxxx  %d  %d",iSettlTime,iCurrTime);

	if (iSettlTime>=2 && iSettlTime<=23)
	{
		iH1 = iSettlTime -2 ;

		iH2 = iSettlTime -1 ;

//		OsLog(LOG_ERROR,"1111111111111111111  %d==%d  %d==%d",iSettlTime,iCurrTime,iH1,iH2);
		if (iCurrTime>=iH1 && iCurrTime<=iH2)
		{
			return TRUE ;
		}


	}
	else if (iSettlTime==0)
	{
		iH1 = 22 ;

		iH2 = 23 ;
//		OsLog(LOG_ERROR,"22222222  %d==%d  %d==%d",iSettlTime,iCurrTime,iH1,iH2);
		if (iCurrTime>=iH1 && iCurrTime<=iH2)
		{
			return TRUE ;
		}
	}
	else if (iSettlTime==1)
		{
		    iH1 = 23 ;
			if (iCurrTime>=iH1)
			{
				return TRUE ;
			}
		}
	else{
		return FALSE;
	}





	return FALSE;


}


int updatetADIB_TID(uchar*inData)
{	uchar chTemp[8+1];
int ucNum;
memset(chTemp,0,sizeof(chTemp));

strcpy(chTemp,inData);

//validation
if(strlen(chTemp)!=8)
{
	return -1;
}




//if (!IsNumStr(chTemp))
//{
//
//	return -1;
//}


memset(glSysCtrl.szTermID_TEMP,0,sizeof(glSysCtrl.szTermID_TEMP));
strcpy(glSysCtrl.szTermID_TEMP,chTemp) ;


	SaveSysCtrlBase();



return 0;

}

int updatetADIB_MID(uchar*inData)
{
	uchar chTemp[15+1];
	int ucNum;
	memset(chTemp,0,sizeof(chTemp));

	strcpy(chTemp,inData);

	//validation
	if(strlen(chTemp)<7)
	{
		return -1;
	}

	if(strlen(chTemp)>15)
	{
		return -1;
	}



	if (!IsNumStr(chTemp))
	{

		return -1;
	}


	memset(glSysCtrl.szMerchantID_AMEX,0,sizeof(glSysCtrl.szMerchantID_AMEX));
    strcpy(glSysCtrl.szMerchantID_AMEX,chTemp) ;


		SaveSysCtrlBase();



	return 0;

}

int updatetADIB_NII(uchar*inData)
{
	uchar chTemp[15+1];
	int ucNum;
	memset(chTemp,0,sizeof(chTemp));

	strcpy(chTemp,inData);

	//validation
	if(strlen(chTemp)!=3)
	{
		return -1;
	}



	if (!IsNumStr(chTemp))
	{

		return -1;
	}


	memset(glSysCtrl.szNii_Temp,0,sizeof(glSysCtrl.szNii_Temp));
    strcpy(glSysCtrl.szNii_Temp,chTemp) ;


		SaveSysCtrlBase();



	return 0;

}

void PrintFoura(const char*strAName)
{


	//367112

	FILE *fd = fopen("./res/ARIAL.TTF", "r");
	if (!fd)
	{
			return  ;
	}
	fseek(fd, 0, SEEK_END);
	long len = ftell(fd);
	fseek(fd, 0, SEEK_SET);



	unsigned char  FileBuffer[367112];
	long readCnt = 0;
	readCnt = fread(FileBuffer, 1, len, fd);


	if (readCnt != len)
	{

		fclose(fd);
		return  ;
	}
	fclose(fd);


	FtFontLoadMem(FileBuffer, len);
	if (OsPrnOpen(PRN_REAL, NULL) != 0)
	{

		return  ;
	}


	OsPrnReset();

	//sleep(2);

	FtFontAlign(0);
	FtFontStyle(1, 0);
	FtFontSize(32);
	FtFontAlign( FT_ALIGN_RIGHT);
	FtPrnStr(strAName);


	OsPrnPrintf("\n\n\n\n\n\n\n");




	OsPrnStart();
	OsPrnClose();
	FtFontFree();



}

int ReadDCCStan(uchar *dccstan)
{
	uchar strTemp[15];
	FILE* fHandle;

	uchar strData[100];
	memset(strTemp,0,sizeof(strTemp));






		 	if ((fHandle = fopen("data/dccstan.dat", "r")) != NULL)
		 						{
		 								memset(strTemp,0,sizeof(strTemp));
 	 					 				fscanf(fHandle, "%[^\n]%*c", strTemp);
 	 					 				fclose(fHandle);
		 						}



//uchar strZeros[15];
//
//
//int kk;
//hhhHasan(strlen(strTemp));
//for (kk=1;kk<=12-strlen(strTemp);kk++)
//{
//
//	strZeros[kk-1]='0';
//
//}
//
//strZeros[kk-1]='\0';
//
//fffFOURA(strZeros);
//strcpy(dccstan,strZeros);
//strcat(dccstan,strTemp);






  		 	sprintf(dccstan,"%012"PRId64"", atoll(strTemp));

		 	uint64_t i2 = atoll( strTemp	)	;




		 	i2++;


//			    Gui_ClearScr();
//			    Gui_ShowMsgBox("TTTffffff", gl_stTitleAttr, strData, gl_stCenterAttr, GUI_BUTTON_OK,500, NULL);




			    if (i2>999999999999)
			    {
			    	i2= 1 ;
			    }

				memset(strData,0,sizeof(strData));
				sprintf(strData,"%012"PRId64"",i2);

			fHandle = fopen("data/dccstan.dat", "w");


			 	fprintf(fHandle, "%s\n", strData);

				fclose(fHandle);




			//long, int64_t, unsigned long, uint64_t 	unsigned   long long


	return 0;
}


uchar luhnFoura(uchar*inData)
{

	uchar szTemp[24];
    int x1,x2=-1;
    int index;
    int sum=0;
    uchar ch[2];
    int i,z,k;
    memset(szTemp,0,sizeof(szTemp));
    strcpy(szTemp,inData);

    ch[0] = szTemp[strlen(szTemp)-1];
    ch[1] ='\0';

    x1= atoi( ch);

    index = strlen(szTemp)-2;
    for(i=index;i>=0;i--)
    {

        ch[0] = szTemp[i];
        ch[1] ='\0';
    	if ((index-i) % 2 == 0 )
    	{
    		sum = sum  + gettotal(2*atoi(ch));
    	}else
    	{
    		sum = sum  + atoi(ch);
    	}

    }

//    hhhHasan(sum);

    z=0;
    if ( (sum%10) == 0 )
    	{
    	   x2 = 0 ;

    	}
    else
    {
    	  while ( (sum % 10) != 0 )
    	  {
    		   sum  =  sum +1 ;
    		    z = z+1 ;
    	  }
    }




  x2  = z;

//  hhhHasan(x2);


//hhhHasan(x1);

//fffFOURA(szTemp);
//hhhHasan(strlen(szTemp));


if (x1==x2)
{
	return TRUE;
}else
{
	return FALSE ;
}



}

int gettotal(int y)
{
	int t;
    t = y ;
if (y ==10)  t = 1;
if (y ==11) t = 2;
if (y ==12)  t = 3;
if (y ==13) t = 4;
if (y ==14) t = 5;
if (y ==15)  t = 6;
if (y ==16)  t = 7;
if (y ==17)  t = 8;
if (y ==18)  t = 9;
if (y ==19)  t = 1;


return  t ;
}
