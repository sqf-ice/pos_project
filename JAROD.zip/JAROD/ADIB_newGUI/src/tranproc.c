
#include "global.h"
#include <openssl/sha.h>

/********************** Internal macros declaration ************************/
/********************** Internal structure declaration *********************/
/********************** Internal functions declaration *********************/
static void PackInvoice(STISO8583 *pstSendPack, ulong ulInvoice);
static void ModifyProcessCode(void);
static void SetEntryMode(const TRAN_LOG *pstLog);
static void SetAmexEntryMode(const TRAN_LOG *pstLog);
static void SetStdEntryMode(const TRAN_LOG *pstLog);
static void SetCUPEntryMode(const TRAN_LOG *pstLog);
static void SetCondCode(void);
static void SetInstAndAirTicketData(void);
static int  TransCashSub(void);
static int  TransSaleSub(void);
static int  TransAuthSub(uchar ucTranType);
static int  GetOfflineTrans(uchar ucTypeFlag);
static int  AdjustInput(void);
static int  TransSettleSub(void);
static int  TransUpLoad(void);
static int SelectCouponOrGift(uchar *pField63, uchar ucTranType);
static int TransRedeem(void);
static int TransRedeemCoupon(void);

/********************** Internal variables declaration *********************/

/********************** external reference declaration *********************/

extern uchar PubGetECRAmount(uchar *pszPrefix, uchar ucDeciPos,
                             uchar ucMinLen, uchar ucMaxLen, uchar *pszData,
                             uchar ucTimeout, uchar ucMisc);

extern const unsigned char *GetDynamicPassword();
/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/

void PackInvoice(STISO8583 *pstSendPack, ulong ulInvoice)
{
	memcpy(pstSendPack->sField62, "\x00\x06", 2);
	sprintf((char *)&(pstSendPack->sField62[2]), "%06lu", ulInvoice);
}

// 设置请求包的公共bits
// set bit content of ISO8583.
// Work as the "IsoInitSendMsg()" did in old style.
void SetCommReqField(void)//ZOZO SetCommReqField
{
#ifdef ENABLE_EMV
	int	iLength;
#endif
	uchar	szTotalAmt[12+1];

	if( glProcInfo.stTranLog.ucTranType==LOAD_PARA )
	{
		memset(&glTMSSend, 0, sizeof(STTMS8583));
		sprintf((char *)glTMSSend.szMsgCode, "%.*s", LEN_MSG_CODE,
				glTranConfig[glProcInfo.stTranLog.ucTranType].szTxMsgID);
		sprintf((char *)glTMSSend.szProcCode,   "%.*s", LEN_PROC_CODE,
				glTranConfig[glProcInfo.stTranLog.ucTranType].szProcCode);
		sprintf((char *)glTMSSend.szNii,    "%.*s", LEN_NII,     glCurAcq.szNii);
		sprintf((char *)glTMSSend.szTermID, "%.*s", LEN_TERM_ID, glCurAcq.szTermID);
		sprintf((char *)glTMSSend.szSTAN, "%06lu", glSysCtrl.ulSTAN);


//			#ifdef BANK_ADIB
//				sprintf((char *)glSendPack.szNii,    "%.*s", LEN_NII,     glSysCtrl.szNii);
//				sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, glSysCtrl.szTermID);
//				sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_TERM_ID, glSysCtrl.szMerchantID);
//			#endif




		return;
	}
	PRN_FAIL_2 = TRUE ;
	//ISO8583使用说明
	//Step3: 在这里设置打包时需要的数据，该域赋值则送，为空时则不送(默认的初始值全为空)
	//所有的报文都需要用到的域可在//set common bits下进行统一赋值
	//其它根据交易不同条件不同时可送可不送的分别处理
	//另注意sz型与s型开头成员变量,sz型直接赋所需要上送的值，s型需要在前两位赋值为该域的长度
	//例如:	// bit 62, ROC/SOC定义为  sField62
	//则先赋长度值memcpy(glSendPack.sField62, "\x00\x06", 2);
	//再赋数据值sprintf((char *)&glSendPack.sField62[2], "%06lu", glProcInfo.stTranLog.ulInvoiceNo);

	// Usage of ISO8583 module (For step 2, see in st8583.h)
	// Step 3: To set the data need in packing here.
	// If the glSendPack.xxxxx is filled with value, this bit will be sent, and vice versa.

	// Note that there're 2 kinds of member in glSendPack:
	//   glSendPack.szxxxxxx : this type means "string end with zero", the actual length can be determined by strlen()
	//   glSendPack.sxxxxxx  : the first 2 bytes contains length infomation, if length=0x01A0, should be "\x01\xA0"
	//     e.g. : bit62
	//             memcpy(glSendPack.sField62, "\x00\x06", 2);
	//             sprintf((char *)&glSendPack.sField62[2], "%06lu", glProcInfo.stTranLog.ulInvoiceNo);

	// set common bits
	memset(&glSendPack, 0, sizeof(STISO8583));
	sprintf((char *)glSendPack.szMsgCode,    "%.*s", LEN_MSG_CODE,
			glTranConfig[glProcInfo.stTranLog.ucTranType].szTxMsgID);

	sprintf((char *)glSendPack.szProcCode,   "%.*s", LEN_PROC_CODE,
			glTranConfig[glProcInfo.stTranLog.ucTranType].szProcCode);

 	if ( glProcInfo.stTranLog.ucTranType  == ECHO_TEST)
    	{
 			// modify bit 3, process code//krkr
 			ModifyProcessCode();
 	    	sprintf((char *)glSendPack.szNii,        "%.*s", LEN_NII,         glCurAcq.szNii);//krkr
 	    	sprintf((char *)glSendPack.szTermID,     "%.*s", LEN_TERM_ID,     glCurAcq.szTermID);//krkr

 	    	return;
    	}





	// modify bit 3, process code//krkr
	ModifyProcessCode();

    sprintf((char *)glSendPack.szNii,        "%.*s", LEN_NII,         glCurAcq.szNii);//krkr

    if(DCC_RATE == glProcInfo.stTranLog.ucTranType)
	{
	    uchar szDccNii[120];
	    if(0 == GetEnv("DCC_NII", szDccNii))
	        sprintf((char *)glSendPack.szNii,        "%.*s", LEN_NII,         szDccNii);
	}
	else if(SALE_INQUIRY == glProcInfo.stTranLog.ucTranType ||
	          LOYALTY_INQUIRY == glProcInfo.stTranLog.ucTranType ||
	          COUPON == glProcInfo.stTranLog.ucTranType ||
	          REDEEM_INQUIRY == glProcInfo.stTranLog.ucTranType ||
	          REDEEM_POINT == glProcInfo.stTranLog.ucTranType ||
	          GIFT_INQUIRY == glProcInfo.stTranLog.ucTranType ||
	          GIFT_REDEEM == glProcInfo.stTranLog.ucTranType) //TODO add more type, add coupon linzhao
	{
	    uchar szLoyaltyNii[120];
	    if(0 == GetEnv("LOY_NII", szLoyaltyNii))
	        sprintf((char *)glSendPack.szNii,        "%.*s", LEN_NII,         szLoyaltyNii);
	}

	sprintf((char *)glSendPack.szTermID,     "%.*s", LEN_TERM_ID,     glCurAcq.szTermID);//krkr



	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_MERCHANT_ID, glCurAcq.szMerchantID);

	sprintf((char *)glSendPack.szSTAN, "%06lu", glSysCtrl.ulSTAN);  //??
	glProcInfo.stTranLog.ulSTAN = glSysCtrl.ulSTAN;

	if( glProcInfo.stTranLog.ucTranType==SETTLEMENT || glProcInfo.stTranLog.ucTranType==UPLOAD ||
		glProcInfo.stTranLog.ucTranType==LOGON )
	{
		return;
	}

    // Add by lirz v1.02.0000
    if(DCC_RATE == glProcInfo.stTranLog.ucTranType)
    {
        sprintf((char *)glSendPack.szPan, "%.*s", LEN_PAN, glProcInfo.stTranLog.szPan);




//        sprintf((char *)glSendPack.szRRN,       "%.12s", glProcInfo.stTranLog.szRRN);       // jiale 2006.12.12


        //ADIB DCC
//        sprintf((char *)glSendPack.szPan, "%.*s", LEN_PAN, "540375");




        uchar strRRNDCC[15];
        ReadDCCStan(strRRNDCC);

     //   fffFOURA(strRRNDCC);



        // sprintf((char *)glSendPack.szRRN,       "%.12s","000000000007");       // jiale 2006.12.12
             sprintf((char *)glSendPack.szRRN,        "%.12s",strRRNDCC);


         //  sprintf((char *)glSendPack.szRRN,       "%.12s","111111111117");
         //  sprintf((char *)glSendPack.szRRN,       "%.12s",glProcInfo.stTranLog.szRRN);       // jiale 2006.12.12


//        memcpy(glSendPack.sField48, "\x00\x03\x41\x44\x49", 5);


         memcpy(glSendPack.sField48, "\x00\x03", 2);

          sprintf((char *)&glSendPack.sField48[2], "%s","\x41\x44\x49"  );//glProcInfo.szSecurityCode


    }
    // End add by lirz v1.02.0000

	// bit 4, transaction amount
    uchar szEnableFee[8];
    if (!ChkIfZeroAmt(glProcInfo.stTranLog.szSurFee))//linzhao 20160113
    {
        uchar szTotalAmt2[12+1];
        OsLog(LOG_ERROR, "%s-%d, into e_fee", __FILE__, __LINE__);//linzhao

        PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt2);
        PubAscAdd(szTotalAmt2, glProcInfo.stTranLog.szSurFee, 12, szTotalAmt);
		sprintf((char *)glSendPack.szTranAmt,   "%.*s", LEN_TRAN_AMT,   szTotalAmt);
    }
    else if( !ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) )
	{
        OsLog(LOG_ERROR, "%s-%d, into chkifZeroAmt", __FILE__, __LINE__);//linzhao
		//linzhao, 2015.8.18
//		if (glProcInfo.stTranLog.uiStatus & TS_ADJ)
//		{
//			sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szTipAmount);
//		}
//		else
//		{
			PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);

			//PubAddHeadChars(szTotalAmt, 12, '0');		no need: already 12 digits
			sprintf((char *)glSendPack.szTranAmt,   "%.*s", LEN_TRAN_AMT,   szTotalAmt);
			//linzhao
//			sprintf((char *)glSendPack.szExtAmount, "%.*s", LEN_EXT_AMOUNT, glProcInfo.stTranLog.szTipAmount);
			// when the transtype is void_auth, emp need to set field 4 to all ‘0’。 linzhao 20151113
			if( glProcInfo.stTranLog.ucTranType==VOID_AUTH )
			{
				sprintf(glSendPack.szTranAmt, "%012lu", 0L);
				glSendPack.szExtAmount[0] = 0;
			}

			if (ChkIfAmex())
			{
				if( glProcInfo.stTranLog.ucTranType==REFUND )
				{
					glSendPack.szExtAmount[0] = 0;
				}
				if( glProcInfo.stTranLog.ucTranType==VOID || (glProcInfo.stTranLog.uiStatus & TS_VOID) )
				{
					sprintf(glSendPack.szTranAmt, "%012lu", 0L);
					glSendPack.szExtAmount[0] = 0;
				}
			}
//		}
	}
	else
	{
        OsLog(LOG_ERROR, "%s-%d, into else", __FILE__, __LINE__);//linzhao
		sprintf((char *)glSendPack.szTranAmt, "%.*s", LEN_TRAN_AMT, glProcInfo.stTranLog.szAmount);
		//linzhao
		if( glProcInfo.stTranLog.ucTranType==VOID_AUTH )
		{
			sprintf(glSendPack.szTranAmt, "%012lu", 0L);
			glSendPack.szExtAmount[0] = 0;
		}

		if( ChkIfAmex() )
		{
			if( (glProcInfo.stTranLog.ucTranType==VOID) || (glProcInfo.stTranLog.uiStatus & TS_VOID) )
			{
				sprintf(glSendPack.szTranAmt, "%012lu", 0L);
				glSendPack.szExtAmount[0] = 0;
			}
		}
	}
    OsLog(LOG_ERROR, "%s-%d, szTranAmt:%s", __FILE__, __LINE__, glSendPack.szTranAmt);//linzhao

    //EMP host will echo the time field, so if you don't send the time field, EMP will send the time field to POS.linzhao 20160122
	if( (glProcInfo.stTranLog.ucTranType==OFFLINE_SEND) ||
		(glProcInfo.stTranLog.ucTranType==TC_SEND) )
	{
//		sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
//		sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);
		sprintf((char *)glSendPack.szRRN,       "%.12s", glProcInfo.stTranLog.szRRN);
		sprintf((char *)glSendPack.szAuthCode,  "%.6s",  glProcInfo.stTranLog.szAuthCode);
	}
	else if( glProcInfo.stTranLog.ucTranType==VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType )
	{

	    //foura linshaw
 		//sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
 		//sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);

	   // sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
 		//sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);

	    OsLog(LOG_ERROR,"RRRRRRRR:%s--%s",glSendPack.szLocalTime, glSendPack.szLocalDate);


	    sprintf((char *)glSendPack.szRRN,       "%.12s", glProcInfo.stTranLog.szRRN);       // jiale 2006.12.12
		sprintf((char *)glSendPack.szAuthCode,  "%.6s",  glProcInfo.stTranLog.szAuthCode);	// jiale for void send 37.38field
	}
	else if(glProcInfo.stTranLog.ucTranType != DCC_RATE){
//	    sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
//	    sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);
	}

	//linzhao 20151028
	if (NULL != strstr(glCurIssuer.szName, "CUP"))
	{
		OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);
		glSendPack.szLocalDate[0] = 0;
		glSendPack.szLocalTime[0] = 0;
	}


	//foura add de 35 clss
	if (clssSale == TRUE  )//glProcInfo.stTranLog.ucTranType==SALE //&& glProcInfo.stTranLog.ucTranType !=OFF_SALE
			{
				 sprintf((char *)glSendPack.szTrack2,  "%.*s", LEN_TRACK2,   glProcInfo.szTrack2);
				 OsLog(LOG_ERROR,"glProcInfo.szTrack2 %s",glProcInfo.szTrack2);
			}


	// PAN/track 1/2/3/expiry etc
	if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
	{
		if( (glProcInfo.szTrack2[0]==0) ||
			(glProcInfo.stTranLog.ucTranType==OFFLINE_SEND) ||
			(glProcInfo.stTranLog.ucTranType==TC_SEND) )
		{
			sprintf((char *)glSendPack.szPan,     "%.*s", LEN_PAN,      glProcInfo.stTranLog.szPan);
			sprintf((char *)glSendPack.szExpDate, "%.*s", LEN_EXP_DATE, glProcInfo.stTranLog.szExpDate);
		}
		else if(glProcInfo.stTranLog.ucTranType != DCC_RATE)
		{
		    //sprintf((char *)glSendPack.szExpDate, "%.*s", LEN_EXP_DATE, glProcInfo.stTranLog.szExpDate);
		    sprintf((char *)glSendPack.szTrack2,  "%.*s", LEN_TRACK2,   glProcInfo.szTrack2);



		}



		if( ChkIfCiti() || ChkIfDah() )
		{
			if( glProcInfo.stTranLog.ucTranType!=SETTLEMENT )
			{
				if( glProcInfo.stTranLog.bPanSeqOK )
				{
					sprintf((char *)glSendPack.szPanSeqNo, "%0*X", LEN_PAN_SEQ_NO, glProcInfo.stTranLog.ucPanSeqNo);
				}
			}
		}
	}
	else if( (glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) )
	{
		if( glProcInfo.stTranLog.ucTranType==OFFLINE_SEND || glProcInfo.stTranLog.ucTranType==VOID ||
			VOID_AUTH==glProcInfo.stTranLog.ucTranType)
		{
			sprintf((char *)glSendPack.szPan,     "%.*s", LEN_PAN,      glProcInfo.stTranLog.szPan);
			sprintf((char *)glSendPack.szExpDate, "%.*s", LEN_EXP_DATE, glProcInfo.stTranLog.szExpDate);
		}
		else if(glProcInfo.stTranLog.ucTranType != DCC_RATE)
		{
			sprintf((char *)glSendPack.szTrack2, "%.*s", LEN_TRACK2, glProcInfo.szTrack2);




			if ( glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE )
			{
				sprintf((char *)glSendPack.szTrack3, "%.*s", LEN_TRACK3, glProcInfo.szTrack3);
			}
//			if ( !ChkIfBoc() )
//			{
//				sprintf((char *)glSendPack.szTrack1, "%.*s", LEN_TRACK1, glProcInfo.szTrack1);
//			}
		}
	}
	else if( (glProcInfo.stTranLog.uiEntryMode & MODE_MANUAL_INPUT) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
	{
		sprintf((char *)glSendPack.szPan,     "%.*s", LEN_PAN,      glProcInfo.stTranLog.szPan);
		sprintf((char *)glSendPack.szExpDate, "%.*s", LEN_EXP_DATE, glProcInfo.stTranLog.szExpDate);
	}

	if(glProcInfo.stTranLog.ucTranType != DCC_RATE)
	    SetEntryMode(&glProcInfo.stTranLog);		// bit 22, entry mode

	if(glProcInfo.stTranLog.ucTranType != SALE_INQUIRY &&
	   glProcInfo.stTranLog.ucTranType != LOYALTY_INQUIRY &&
	   glProcInfo.stTranLog.ucTranType != COUPON &&
	   glProcInfo.stTranLog.ucTranType != GIFT_INQUIRY &&
	   glProcInfo.stTranLog.ucTranType != GIFT_REDEEM &&
	   glProcInfo.stTranLog.ucTranType != REDEEM_POINT &&
	   glProcInfo.stTranLog.ucTranType != REDEEM_INQUIRY)
	{
	    SetCondCode();		// bit 25, service condition code
	}

	// bit 48 or 55, CVV2 or 4DBC
	if( ChkIfNeedSecurityCode() && !ChkIfAmex() )
	{
		memcpy(glSendPack.sField48, "\x00\x03", 2);
		sprintf((char *)&glSendPack.sField48[2], "%-3.3s", glProcInfo.szSecurityCode);
	}

//BIT 52 foura
//	if( glProcInfo.stTranLog.uiEntryMode & MODE_PIN_INPUT )
//	{
//
////foura pin data
//
//	    if ( !( (NULL != strstr(glCurIssuer.szName, "CUP")) && (glProcInfo.stTranLog.ucTranType==VOID  )  ) )
//	    {
//	    PubLong2Char((ulong)LEN_PIN_DATA, 2, glSendPack.sPINData);
//		memcpy(&glSendPack.sPINData[2], glProcInfo.sPinBlock, LEN_PIN_DATA);
//		 // OsLog(LOG_ERROR,"FRFRFR33333:%s",glSendPack.sPINData);
//
//	    }
//
//		  // memcpy(&glSendPack.sPINData[2], "\xFF\x27\x12\x43\xB1\x1F\x40\xA4", LEN_PIN_DATA);
//		                                   //3E 7E F5 26 D7 E4 50 53
//		                                  //4D 2F 9A 70 71 3A 3D 49
//		                                  //45 CF C9 29 7C 26 29 27
//		                                   //FF 27 12 43 B1 1F 40 A4
//
//
//
//	}

	UpdateF52();

		SetInstAndAirTicketData();	// bit 48 and 63





	// Old bit 49
//	if(NULL == strstr(glCurIssuer.szName, "JCB") &&
//	   NULL == strstr(glCurIssuer.szName, "CUP"))
//	{
//	    SetTranCurrencyCode();
//	}
//

	 //  if( ! (glProcInfo.stTranLog.ucTranType==SALE  &&   NULL != strstr(glCurIssuer.szName, "AMEX")  ))
	 //  if( ! ((glProcInfo.stTranLog.ucTranType==SALE || glProcInfo.stTranLog.ucTranType==AUTH  )  &&   NULL != strstr(glCurIssuer.szName, "AMEX")  ))
	//      if(glProcInfo.stTranLog.ucTranType!=SALE  ||   NULL == strstr(glCurIssuer.szName, "AMEX")  )


//
						if(NULL == strstr(glCurIssuer.szName, "JCB") )//&&	       NULL == strstr(glCurIssuer.szName, "CUP")
						//foura AMEX
						if( ! ( NULL != strstr(glCurIssuer.szName, "AMEX")  ))
						 {
							if (DCC_RATE != glProcInfo.stTranLog.ucTranType)
												{
													SetTranCurrencyCode(); //adibfoura
												}
						 }

						//adibfoura F12 F13
//						    sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
//					 		sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);


//					 		//adibfoura F23
//					    sprintf((char *)glSendPack.szPanSeqNo, "%0*X", LEN_PAN_SEQ_NO, glProcInfo.stTranLog.ucPanSeqNo);



	// process bit 55,56
	if( glProcInfo.stTranLog.ucTranType==AUTH || glProcInfo.stTranLog.ucTranType==PREAUTH ||
		glProcInfo.stTranLog.ucTranType==SALE || glProcInfo.stTranLog.ucTranType==CASH    ||
		glProcInfo.stTranLog.ucTranType==INSTALMENT || glProcInfo.stTranLog.ucTranType==BALANCE)
	{
		if( ChkIfAmex() && ChkIfNeedSecurityCode() && (glProcInfo.szSecurityCode[0]!=0) )
		{
			memcpy(glSendPack.sICCData, "\x00\x04", 2);
			sprintf((char *)&glSendPack.sICCData[2], "%-4.4s", glProcInfo.szSecurityCode);
		}
#ifdef ENABLE_EMV
		else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
			(glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
		{
			SetDE55(DE55_SALE, &glSendPack.sICCData[2], &iLength);
			PubLong2Char((ulong)iLength, 2, glSendPack.sICCData);
			memcpy(glProcInfo.stTranLog.sIccData, &glSendPack.sICCData[2], iLength);
			glProcInfo.stTranLog.uiIccDataLen = (ushort)iLength;

			if (  ( (NULL != strstr(glCurIssuer.szName, "AMEX")) && (  (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE)   )  ) )
			{
				memset(glSendPack.sICCData, 0, 2); //clear De 55 foura
			}

		}
#endif
	}

#ifdef ENABLE_EMV
//	if( glProcInfo.stTranLog.ucTranType==VOID && ChkIfFubon() )
//	{
//		PubLong2Char((ulong)glProcInfo.stTranLog.uiIccDataLen, 2, glSendPack.sICCData);
//		memcpy(&glSendPack.sICCData[2], glProcInfo.stTranLog.sIccData, glProcInfo.stTranLog.uiIccDataLen);
//		PubLong2Char((ulong)glProcInfo.stTranLog.uiField56Len, 2, glSendPack.sICCData2);
//		memcpy(&glSendPack.sICCData2[2], glProcInfo.stTranLog.sField56, glProcInfo.stTranLog.uiField56Len);
//	}
//	if( glProcInfo.stTranLog.ucTranType==VOID && ChkIfHSBC() &&
//		(glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) )
//	{
//		PubLong2Char((ulong)glProcInfo.stTranLog.uiField56Len, 2, glSendPack.sICCData2);
//		memcpy(&glSendPack.sICCData2[2], glProcInfo.stTranLog.sField56, glProcInfo.stTranLog.uiField56Len);
//	}
//	if( ChkIfBea() || ChkIfScb() )
//	{
//		if( (glProcInfo.stTranLog.ucTranType==VOID) ||
//			(glProcInfo.stTranLog.ucTranType==OFFLINE_SEND) ||
//			(glProcInfo.stTranLog.ucTranType==TC_SEND) )
//		{
//			PubLong2Char((ulong)glProcInfo.stTranLog.uiIccDataLen, 2, glSendPack.sICCData);
//			memcpy(&glSendPack.sICCData[2], glProcInfo.stTranLog.sIccData, glProcInfo.stTranLog.uiIccDataLen);
//		}
//	}
#endif

	//bit 60 for cup Foura
	if (  ( (NULL != strstr(glCurIssuer.szName, "CUP")) && (glProcInfo.stTranLog.ucTranType==VOID  )  ) )
	  {
	       PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	       sprintf((char *)glSendPack.szField60, "%.12s", szTotalAmt);
	  }

	//bit 60, linzhao
	if ((VOID==glProcInfo.stTranLog.ucTranType && DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption )||
		(VOID_AUTH==glProcInfo.stTranLog.ucTranType  && DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption))
	{
		//linzhao 20150930
		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
		sprintf((char *)glSendPack.szField60, "%.12s", szTotalAmt);
	}

	// bit 62, ROC/SOC
    /*=======BEGIN: Jason 2015.01.07  11:12 modify===========*/


				if (strlen(glProcInfo.stTranLog.szECRRRN) != 0)
				{
					PubLong2Char(strlen(glProcInfo.stTranLog.szECRRRN), 2, glSendPack.sField62);
					sprintf((char *)&glSendPack.sField62[2], "%s", glProcInfo.stTranLog.szECRRRN);
				}




    /*====================== END======================== */
    if(glProcInfo.stTranLog.ucTranType != DCC_RATE)
    	PackInvoice(&glSendPack, glProcInfo.stTranLog.ulInvoiceNo);

	// For Loyalty
    if(glProcInfo.stTranLog.ucTranType==LOYALTY_INQUIRY ||
        glProcInfo.stTranLog.ucTranType==SALE_INQUIRY ||
        glProcInfo.stTranLog.ucTranType==COUPON ||
        glProcInfo.stTranLog.ucTranType == REDEEM_INQUIRY ||
        glProcInfo.stTranLog.ucTranType == REDEEM_POINT ||
        glProcInfo.stTranLog.ucTranType == GIFT_INQUIRY ||
        glProcInfo.stTranLog.ucTranType == GIFT_REDEEM)  //linzhao
    {
        int iRet, iRet2;
        uchar sHash[LEN_FIELD53] = {0};

        //Masked PAN
        sprintf((char *)glSendPack.szPan, "%6.6s", glProcInfo.stTranLog.szPan);
        memset(glSendPack.szPan + 6, 'F', (strlen(glProcInfo.stTranLog.szPan)+1)/2*2 - 6);
        memset(glSendPack.szPan + 6, 'E', strlen(glProcInfo.stTranLog.szPan) - 6);

        memset(glSendPack.szTrack1, 0, sizeof(glSendPack.szTrack1));
        memset(glSendPack.szTrack2, 0, sizeof(glSendPack.szTrack2));
        memset(glSendPack.szTrack3, 0, sizeof(glSendPack.szTrack3));

        //TODO
        //WK(SHA1(PAN)) => Field 53
        memset(sHash, 0, LEN_FIELD53);
        SHA1(glProcInfo.stTranLog.szPan, strlen(glProcInfo.stTranLog.szPan), sHash);

        iRet = OsPedDes(DEF_DATA_KEY_ID, NULL, sHash, LEN_FIELD53, glSendPack.sField53+2, 0x01);
        //OsLog(LOG_ERROR, "[%s%d] OsPedDes:%d", __FILE__, __LINE__, iRet);
        PubLong2Char(LEN_FIELD53, 2, glSendPack.sField53);



        // WK->KCV => Field 57
        memset(glSendPack.sField57, 0, sizeof(glSendPack.sField57));
        //iRet2 = OsPedDes(DEF_DATA_KEY_ID, "\x00\x00\x00\x00\x00\x00\x00\x00",  glSendPack.sField53+2, LEN_FIELD53, glSendPack.sField57+2, 0x01);
        iRet2 = OsPedGetKcv(PED_TDK, DEF_DATA_KEY_ID, 0, 24, glSendPack.sField53+2, glSendPack.sField57+2);
        //memset(glSendPack.sField57+2+8, 0, sizeof(glSendPack.sField57)-10);
        PubLong2Char(4, 2, glSendPack.sField57);

#ifdef APP_DEBUG
        PubDebugOutput("PAN HASH:", sHash, 20, DEVICE_COM1, HEX_MODE);
        PubDebugOutput("ENCRYPTED PAN HASH:", glSendPack.sField53, 26, DEVICE_COM1, HEX_MODE);
        PubDebugOutput("WK KCV:", glSendPack.sField57, 34, DEVICE_COM1, HEX_MODE);
#endif

        //linzhao
//        if(iRet != 0 || iRet2 != 0)
//        {
//            memset(glSendPack.sField53, 0, sizeof(glSendPack.sField53));
//            memset(glSendPack.sField57, 0, sizeof(glSendPack.sField57));
//            memcpy(glSendPack.sField47+2, sHash, 20);
//            PubLong2Char(20, 2, glSendPack.sField47);
//        }
    }

	// bit 63
	// ...
    if(glProcInfo.stTranLog.ucTranType != DCC_RATE)
    {
        if(NULL == strstr(glCurIssuer.szName, "JCB"))
        {
            //hala
              //Field63Set(glSendPack.sField63);

              ///bit 63 for Amex void Foura
                //if ( ! ( (NULL != strstr(glCurIssuer.szName, "AMEX")) && ((glProcInfo.stTranLog.ucTranType==VOID) ||(glProcInfo.stTranLog.ucTranType==REFUND)||(glProcInfo.stTranLog.ucTranType==AUTH)   )  ) )





        	if (  (!(NULL != strstr(glCurIssuer.szName, "AMEX")))  && (!(NULL != strstr(glCurIssuer.szName, "NE")))  )
                {
        		//adibfoura F63
                  Field63Set(glSendPack.sField63);



                }


                //bit 63 for Amex void Foura
//                        if ( ! (  (NULL != strstr(glCurIssuer.szName, "AMEX"))  && (glProcInfo.stTranLog.ucTranType==VOID)     ) )
//                          {
//                            Field63Set(glSendPack.sField63);
//                          }
        }
    }

	if( ChkIfNeedMac() )
	{
		PubLong2Char((ulong)LEN_MAC, 2, glSendPack.sMac);
	}

	TRUST_SetCommReqField();

}//end set


void TRUST_SetCommReqField(void)
{

#ifdef BANK_ADIB
	TRUST_ISO8583_ADIB();
#endif

}

void TRUST_ISO8583_ADIB(void)
{
	//ZOZO

	int	iLength;
	//===========================================mid nii tid=================================================
	//TID MID NII
// 	sprintf((char *)glSendPack.szNii,    "%.*s", LEN_NII,     glSysCtrl.szNii);
//	sprintf((char *)glSendPack.szTermID, "%.*s", LEN_TERM_ID, glSysCtrl.szTermID);
//	sprintf((char *)glSendPack.szMerchantID, "%.*s", LEN_TERM_ID, glSysCtrl.szMerchantID);
	//=============================================================================================
//=============================35===============================================================
	//F35
	if (glProcInfo.stTranLog.ucTranType==VOID_AUTH) {

		//foura add de 35 clss

					 sprintf((char *)glSendPack.szTrack2,  "%.*s", LEN_TRACK2,   glProcInfo.szTrack2);
					 OsLog(LOG_ERROR,"glProcInfo.szTrack2 %s",glProcInfo.szTrack2);


	}

	//=============================================================================================
	//=============================49===============================================================
	//F49
	if (glProcInfo.stTranLog.ucTranType==REFUND) {
		SetTranCurrencyCode(); //adibfoura

	}else
	{
	//Remove F49
    memset((char *)glSendPack.szTranCurcyCode,0,sizeof((char *)glSendPack.szTranCurcyCode));
	}
	//=============================================================================================
	//=============================23===============================================================

	//Add F23
 	sprintf((char *)glSendPack.szPanSeqNo, "%0*X", LEN_PAN_SEQ_NO, glProcInfo.stTranLog.ucPanSeqNo);

	//=============================================================================================

	//=================================12 13============================================================
	//F12 F13 DATE TIME ADD
 	sprintf((char *)glSendPack.szLocalTime, "%.6s",  &glProcInfo.stTranLog.szDateTime[8]);
 	sprintf((char *)glSendPack.szLocalDate, "%.4s",  &glProcInfo.stTranLog.szDateTime[4]);
	//=============================================================================================
 	//=================================54============================================================

 	if (glProcInfo.stTranLog.ucTranType==SINGLE_TIP)
 	{
 	//F54
	sprintf((char *)glSendPack.szExtAmount, "%.*s", LEN_EXT_AMOUNT, glProcInfo.stTranLog.szTipAmount);
 	}

	//=============================================================================================
//=============================================55================================================
 	//F55
 	if (   (glProcInfo.stTranLog.ucTranType==FandB_PURCHASE) || (glProcInfo.stTranLog.ucTranType==REFUND) || (glProcInfo.stTranLog.ucTranType==SINGLE_TIP)    || (glProcInfo.stTranLog.ucTranType==VOID_AUTH)   ) //DE 55
 	{
#ifdef ENABLE_EMV
 		//add f55
		SetDE55(DE55_SALE, &glSendPack.sICCData[2], &iLength);
		PubLong2Char((ulong)iLength, 2, glSendPack.sICCData);
		memcpy(glProcInfo.stTranLog.sIccData, &glSendPack.sICCData[2], iLength);
		glProcInfo.stTranLog.uiIccDataLen = (ushort)iLength;

#endif



 	}
 	//=============================================================================================
	//=========================================63====================================================
 	//F63


 	if (   (glProcInfo.stTranLog.ucTranType==FandB_PURCHASE) )
 			{
 	// remove f63
 			 memset((char *)glSendPack.sField63,0,sizeof((char *)glSendPack.sField63));

 			}
	//=============================================================================================

	//ZOZO FINAL
}
//frfrfr
// Bit 3 definition:
// AMEX 0200:
// For a sale transaction									00 40 0x
// For a refund transaction									20 40 0x
// For an on line void of on line sale						02 40 0x
// For an on line void of on line refund					22 40 0x
// For an on line void of off line sale seen by host		02 40 0x
// For an on line void of off line sale not seen by host	00 40 0x
//
// AMEX 0220:
// For a sale transaction (referred/sale comp or off line sale)
//													00 40 0x
// For an sale adjustment (i.e. add tip or void of sale):
//		When original sale not seen by host			00 40 0x
//		When original sale seen by host				02 40 0x
// For an off line refund transaction				20 40 0x
// For a void refund transaction:
//		When Trickle fed refund to host				22 40 0x
//		When Void off line refund not trickle fed	20 40 0x
void ModifyProcessCode(void)
{
	if( ChkIfAmex() )
	{
		glSendPack.szProcCode[2] = '4';
		if( glProcInfo.stTranLog.ucTranType==OFFLINE_SEND )
		{
			if( glProcInfo.stTranLog.ucOrgTranType==SALE     ||
				glProcInfo.stTranLog.ucOrgTranType==OFF_SALE ||
				glProcInfo.stTranLog.ucOrgTranType==SALE_COMP )
			{
				if( glProcInfo.stTranLog.uiStatus & (TS_ADJ|TS_VOID) )
				{
					if( glProcInfo.stTranLog.szRRN[0]!=0 )
					{
						glSendPack.szProcCode[1] = '2';
					}
				}
			}
			else if( glProcInfo.stTranLog.ucOrgTranType==REFUND )
			{
				glSendPack.szProcCode[0] = '2';
				if( glProcInfo.stTranLog.uiStatus & TS_VOID )
				{
					if( glProcInfo.stTranLog.ucTranType!=SETTLEMENT )
					{	// trickle feed
						glSendPack.szProcCode[1] = '2';
					}
				}
			}
		}
		else if( glProcInfo.stTranLog.ucTranType==VOID ||VOID_AUTH==glProcInfo.stTranLog.ucTranType )
		{
			if( glProcInfo.stTranLog.ucOrgTranType==SALE )
			{
				glSendPack.szProcCode[1] = '2';
			}
			else if( glProcInfo.stTranLog.ucOrgTranType==REFUND )
			{
				glSendPack.szProcCode[0] = '2';
				glSendPack.szProcCode[1] = '2';
			}
			else if( glProcInfo.stTranLog.ucOrgTranType==OFF_SALE ||
					 glProcInfo.stTranLog.ucOrgTranType==SALE_COMP )
			{
				if( glProcInfo.stTranLog.szRRN[0]!=0 )
				{
					glSendPack.szProcCode[1] = '2';
				}
			}
		}
	}
	else
	{
		if( glProcInfo.stTranLog.ucTranType==OFFLINE_SEND )
		{
			if( glProcInfo.stTranLog.ucOrgTranType==SALE     ||
				glProcInfo.stTranLog.ucOrgTranType==OFF_SALE ||
				glProcInfo.stTranLog.ucOrgTranType==SALE_COMP )
			{
				if( glProcInfo.stTranLog.uiStatus & (TS_ADJ|TS_VOID) )
				{
					if( glProcInfo.stTranLog.szRRN[0]!=0 )
					{
						glSendPack.szProcCode[1] = '2';
					}
				}
			}
			else if( glProcInfo.stTranLog.ucOrgTranType==REFUND )
			{
				glSendPack.szProcCode[0] = '2';
				if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
				{
					if( glProcInfo.stTranLog.szRRN[0]!=0 )
					{
						glSendPack.szProcCode[1] = '2';
					}
				}
			}
		}
		else if( glProcInfo.stTranLog.ucTranType==VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType)
		{
			if( glProcInfo.stTranLog.ucOrgTranType==SALE )
			{
				glSendPack.szProcCode[1] = '2';
			}
			else if( glProcInfo.stTranLog.ucOrgTranType==REFUND )
			{
				glSendPack.szProcCode[0] = '2';
				glSendPack.szProcCode[1] = '2';
			}
		}

        // Processing code 3rd digit
		// ...
	}

    PubStrUpper(glSendPack.szProcCode);
}

void SetEntryMode(const TRAN_LOG *pstLog)
{
	sprintf((char *)glSendPack.szEntryMode, "0000");

	if( ChkIfAmex() )//مصيبة
 	{
		SetAmexEntryMode(pstLog);
	}
	else if (  NULL != strstr(glCurIssuer.szName, "CUP"))
    {
        SetCUPEntryMode(pstLog);
    }
	else
	{
		SetStdEntryMode(pstLog);
	}
}

void SetTranCurrencyCode(void)
{
    uchar	szBuff[32];
    PubBcd2Asc0(glSysParam.stEdcInfo.stLocalCurrency.sCurrencyCode, 2, szBuff);
    sprintf((char *)glSendPack.szTranCurcyCode, "%.3s", szBuff+1);
    return;
}

void Field63Set(char *field63)
{
    int iCnt = 2;
    uchar szTotalAmt[12+1];;
    if(!field63)
        return;

    if(glProcInfo.stTranLog.ucTranType != LOYALTY_INQUIRY  &&
       glProcInfo.stTranLog.ucTranType != SALE_INQUIRY &&
       glProcInfo.stTranLog.ucTranType != COUPON &&
       glProcInfo.stTranLog.ucTranType != GIFT_INQUIRY &&
       glProcInfo.stTranLog.ucTranType != REDEEM_INQUIRY &&
       glProcInfo.stTranLog.ucTranType != REDEEM_POINT &&
        glProcInfo.stTranLog.ucTranType != GIFT_REDEEM)// SN fixed sub Field
    {
        uchar szSN[32];
		int iTagStart = iCnt;
		iCnt += 2;
	    ReadSN(szSN);
		memcpy(field63 + iCnt, "SN", 2); iCnt+=2;
    	sprintf(field63 + iCnt, "%s", szSN); iCnt += strlen(szSN);
		PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
	}

    // Loyalty
    if(glProcInfo.stTranLog.ucTranType==LOYALTY_INQUIRY ||
        glProcInfo.stTranLog.ucTranType==SALE_INQUIRY ||
        glProcInfo.stTranLog.ucTranType==GIFT_INQUIRY ||
        glProcInfo.stTranLog.ucTranType == REDEEM_INQUIRY ||
        glProcInfo.stTranLog.ucTranType == REDEEM_POINT ||
        glProcInfo.stTranLog.ucTranType==GIFT_REDEEM)
    {
        char bFound = 0;
        int iTagStart = iCnt;
        iCnt += 2;

        if(0 == LoadLoyaltyTxnId(field63 + iCnt + 2))
        {
            memcpy(field63 + iCnt, "LS", 2); iCnt+=2;
            iCnt += 12;
            bFound  =1;
        }

        if(!bFound)
        {
            memset(field63 + iCnt+2, '0', 12);
            memcpy(field63 + iCnt, "LS", 2); iCnt+=2;
            iCnt+=12;
        }

        PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);

        if (glProcInfo.stTranLog.ucTranType==GIFT_REDEEM)
        {
        	int iTagStart = iCnt;

			if(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber[0])
			{
				memcpy(field63 + iCnt + 4, glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber+1, 3);
				iCnt += 2;
				memcpy(field63 + iCnt, "SG", 2); iCnt+=2;
				iCnt += 3;
				PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
			}
			else
			{
				memset(field63 + iCnt + 4, '0', 3);
				iCnt += 2;
				memcpy(field63 + iCnt, "SG", 2); iCnt+=2;
				iCnt += 3;
				PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
			}
        }

    }
    else if (glProcInfo.stTranLog.ucTranType==SALE)
    {
        int iTagStart = iCnt;

        if(glProcInfo.stTranLog.stLoyaltyInfo.szTI[0])
        {
            memcpy(field63 + iCnt + 4, glProcInfo.stTranLog.stLoyaltyInfo.szTI+1, 12);
            iCnt += 2;
            memcpy(field63 + iCnt, "LI", 2); iCnt+=2;
            iCnt += 12;
            PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
        }
    }
    else if (glProcInfo.stTranLog.ucTranType==COUPON)//linzhao
    {
        int iTagStart = iCnt;

        if(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber[0])
        {
            memcpy(field63 + iCnt + 4, glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber+1, 3);
            iCnt += 2;
            memcpy(field63 + iCnt, "CS", 2); iCnt+=2;
            iCnt += 3;
            PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
        }
        else
        {
        	memset(field63 + iCnt + 4, '0', 3);
        	iCnt += 2;
            memcpy(field63 + iCnt, "CS", 2); iCnt+=2;
            iCnt += 3;
            PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
        }
    }
    else if (REDEEM_POINT == glProcInfo.stTranLog.ucTranType)
    {
    	int iTagStart = iCnt;

        memcpy(field63 + iCnt + 4, glProcInfo.stTranLog.stLoyaltyInfo.szAV+1, 3);
        iCnt += 2;
        memcpy(field63 + iCnt, "AV", 2); iCnt+=2;
        iCnt += 3;
        PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
    }

// add by lirz v1.02.0000
// 1.Table "DF" must be present for all transactions (SALE, PREAUTH, COMPLETION...)
//   when DCC was offered to cardholder, even if DCC was declined.
// 2.Table "DF" must be present in Reversal, Void and Batch upload messages 
//   if it was present in original request message.
// 3.Table contains DCC related information, including currency and amount
#ifdef ENABLE_DCC
	if(glProcInfo.stTranLog.ucTranType!=DCC_RATE &&
	   glProcInfo.stTranLog.ucDccOption != DCC_TYPE_NODCC)
	{
		ushort usRateLen = 0;
		uchar szRate[2+1];
		uchar sBcdRate[4];
		uchar szCurrencyCode[4+1];
		
		int iTagStart = iCnt;
		iCnt += 2;

		// Table ID 
		sprintf(field63+iCnt, "%.2s", "DC");
		iCnt += 2;

		// DCC Indicator
		if( DCC_TYPE_DCC == glProcInfo.stTranLog.ucDccOption)
		{
			sprintf(glSendPack.sField63+iCnt, "%.1s", "Y");
		}
		else 
		{
			sprintf(glSendPack.sField63+iCnt, "%.1s", "N");
		}
		iCnt += 1;

		if( DCC_TYPE_DCC == glProcInfo.stTranLog.ucDccOption)
		{
			// DCC Currency
            PubBcd2Asc(glProcInfo.stTranLog.stHolderCurrency.sCurrencyCode, 2, glSendPack.sField63+iCnt);
		    memmove(glSendPack.sField63+iCnt, glSendPack.sField63+iCnt+1, 3);
		    iCnt += 3;

			// DCC Amount
		    //linzhao 20151008
		    PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTotalAmt);
			sprintf(glSendPack.sField63+iCnt, "%.12s", szTotalAmt);
			iCnt += 12;

			// DCC Rate
			sprintf(glSendPack.sField63+iCnt, "%.9s", glProcInfo.stTranLog.stDccInfo.szDccExRate);
			iCnt += 9;
		}
		PubLong2Bcd(iCnt - iTagStart - 2, 2, field63+iTagStart);
	}
#endif

    PubLong2Char(iCnt - 2, 2, field63);
}

int Field63Parser(const char *field63, const char *Tag, char *value)
{
    ulong lTol = PubBcd2Long(field63, 2);
    ulong lCnt = 2;
    if(!field63 || !Tag || lTol < 4)
        return -1;
    while(lCnt < lTol){
        ulong lTagLen = PubBcd2Long(field63+lCnt, 2); lCnt += 2;
        if(0 == memcmp(field63 + lCnt, Tag, 2)){
            if(value){
                memcpy(value, field63 + lCnt + 2, lTagLen - 2);
            }
            return lTagLen - 2;
        }
        lCnt += lTagLen;
    }
    return -1;
}

void SetAmexEntryMode(const TRAN_LOG *pstLog)
{
	glSendPack.szEntryMode[3] = '2';
	if (ChkIfPinReqdAllIssuer())
	{
		glSendPack.szEntryMode[3] = '1';	// pin capable

	}

#ifdef ENABLE_EMV
	if( ChkAcqOption(ACQ_EMV_FEATURE) )
	{
		EMVGetParameter(&glEmvParam);
		if (glEmvParam.Capability[1] & 0x40)
		{
			glSendPack.szEntryMode[3] = '1';	// pin capable
		}
		if (glEmvParam.Capability[1] & 0x90)
		{
			glSendPack.szEntryMode[3] = '3';	// offline pin capable
		}
	}
#endif

#ifdef ENABLE_EMV
	if( ChkAcqOption(ACQ_EMV_FEATURE) )
	{
		glSendPack.szEntryMode[1] = '5';
	}
#endif

	if( pstLog->uiEntryMode & MODE_SWIPE_INPUT )
	{
		if (glProcInfo.stTranLog.uiEntryMode & MODE_SECURITYCODE)
		{
			glSendPack.szEntryMode[2] = '6';
		}
		else
		{
			glSendPack.szEntryMode[2] = '2';
		}
	}
#ifdef ENABLE_EMV
	else if( pstLog->uiEntryMode & MODE_CHIP_INPUT )
	{
		glSendPack.szEntryMode[2] = '5';
	}
	else if( pstLog->uiEntryMode & MODE_FALLBACK_SWIPE )
	{
		glSendPack.szEntryMode[1] = '6';
		glSendPack.szEntryMode[2] = (glProcInfo.szSecurityCode[0]!=0) ? '6' : '2';
	}
	else if( pstLog->uiEntryMode & MODE_FALLBACK_MANUAL )
	{
		// ????;
	}
#endif
	else if( pstLog->uiEntryMode & MODE_MANUAL_INPUT )
	{
		glSendPack.szEntryMode[2] = (glProcInfo.szSecurityCode[0]!=0) ? '7' : '1';
	}
}

void SetStdEntryMode(const TRAN_LOG *pstLog)
{

//	if(1==1) {
//			 memcpy(&glSendPack.szEntryMode[0], "0020", 4);
//
//		}
//		else
//		{


	if(clssSale==TRUE) {
			 memcpy(&glSendPack.szEntryMode[0], "0070", 4);

		}
		else
		{


	//------------------------------------------------------------------------------
	// Entry mode digit 1
#ifdef ENABLE_EMV
	if( ChkAcqOption(ACQ_EMV_FEATURE) )
	{
		if( ChkIfBoc() || ChkIfBea() )
		{
			glSendPack.szEntryMode[0] = '5';
		}
	}
#endif

	//------------------------------------------------------------------------------
	// Entry mode digit 2 and digit 3
	if( pstLog->uiEntryMode & MODE_MANUAL_INPUT )
	{
		memcpy(&glSendPack.szEntryMode[1], "01", 2);
	}
	else if( pstLog->uiEntryMode & MODE_SWIPE_INPUT )
	{
		memcpy(&glSendPack.szEntryMode[1], "02", 2);
	}
	else if( pstLog->uiEntryMode & MODE_CHIP_INPUT )
	{
		memcpy(&glSendPack.szEntryMode[1], "05", 2);
	}
	else if( pstLog->uiEntryMode & MODE_FALLBACK_SWIPE )
	{
		memcpy(&glSendPack.szEntryMode[1], "80", 2);

		// sort by banks (acquirer)
		if( ChkIfFubon() )
		{
			glSendPack.szEntryMode[2] = '1';
		}
		else if( ChkIfBoc())
		{
			if( pstLog->szPan[0]=='4' )
			{
				memcpy(&glSendPack.szEntryMode[1], "90", 2);
			}
			else if( pstLog->szPan[0]=='5' )
			{
				memcpy(&glSendPack.szEntryMode[1], "80", 2);
			}
			else if ( memcmp(pstLog->szPan, "35", 2)==0 )
			{
				memcpy(&glSendPack.szEntryMode[1], "97", 2);	// "971"
			}
		}
	}
	else if( pstLog->uiEntryMode & MODE_FALLBACK_MANUAL )
	{
	}

	//------------------------------------------------------------------------------
	// Entry mode digit 4
#ifdef ENABLE_EMV

	 if (  (NULL != strstr(glCurIssuer.szName, "AMEX")) && (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )  )//Amex 0050 foura
	 {
		 glSendPack.szEntryMode[3] = '0';    // default : support offline-PIN
	 }
	else  if( ChkAcqOption(ACQ_EMV_FEATURE) )
	{
		glSendPack.szEntryMode[3] = '1';    // default : support offline-PIN
	}



#endif
	// if (  NULL != strstr(glCurIssuer.szName, "AMEX"))
		}//end clss sale mode
//		}//elsessssss
}

// set bit 22 for CUP UPI
void SetCUPEntryMode(const TRAN_LOG *pstLog)
{
    if (  ( (NULL != strstr(glCurIssuer.szName, "CUP")) && (glProcInfo.stTranLog.ucTranType==VOID  )  ) )
           { memcpy(&glSendPack.szEntryMode[0], "0011", 4);
           }

//    else if (  ( (NULL != strstr(glCurIssuer.szName, "CUP")) && (glProcInfo.stTranLog.ucTranType==UPLOAD  )  ) )
//           { memcpy(&glSendPack.szEntryMode[0], "0050", 4);
//           }

    else
    {
    //------------------------------------------------------------------------------
    // Entry mode digit 1
#ifdef ENABLE_EMV
    if( ChkAcqOption(ACQ_EMV_FEATURE) )
    {
        if( ChkIfBoc() || ChkIfBea() )
        {
            glSendPack.szEntryMode[0] = '5';
        }
    }
#endif

    //------------------------------------------------------------------------------
    // Entry mode digit 2 and digit 3
    if( pstLog->uiEntryMode & MODE_MANUAL_INPUT )
    {
        memcpy(&glSendPack.szEntryMode[1], "01", 2);
    }
    else if( pstLog->uiEntryMode & MODE_SWIPE_INPUT )
    {
        memcpy(&glSendPack.szEntryMode[1], "09", 2);
    }
    else if( pstLog->uiEntryMode & MODE_CHIP_INPUT )
    {
        memcpy(&glSendPack.szEntryMode[1], "05", 2);
    }
    else if( pstLog->uiEntryMode & MODE_FALLBACK_SWIPE )
    {
        memcpy(&glSendPack.szEntryMode[1], "80", 2);

        // sort by banks (acquirer)
        if( ChkIfFubon() )
        {
            glSendPack.szEntryMode[2] = '1';
        }
        else if( ChkIfBoc())
        {
            if( pstLog->szPan[0]=='4' )
            {
                memcpy(&glSendPack.szEntryMode[1], "90", 2);
            }
            else if( pstLog->szPan[0]=='5' )
            {
                memcpy(&glSendPack.szEntryMode[1], "80", 2);
            }
            else if ( memcmp(pstLog->szPan, "35", 2)==0 )
            {
                memcpy(&glSendPack.szEntryMode[1], "97", 2);    // "971"
            }
        }
    }
    else if( pstLog->uiEntryMode & MODE_FALLBACK_MANUAL )
    {
    }

    //------------------------------------------------------------------------------
    // Entry mode digit 4
#ifdef ENABLE_EMV
    if( ChkAcqOption(ACQ_EMV_FEATURE) )
    {
        glSendPack.szEntryMode[3] = '1';    // default : support offline-PIN
    }
#endif

    }//end if
}





// set bit 25
void SetCondCode(void)
{
	if( ChkIfAmex() )
	{
		// condition code==06: Preauth, Auth, SaleComplete, sale below floor
		sprintf((char *)glProcInfo.stTranLog.szCondCode, "00");
		if( (glProcInfo.stTranLog.ucTranType==PREAUTH) || (glProcInfo.stTranLog.ucTranType==AUTH) )
		{
			sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
		}
		if( glProcInfo.stTranLog.ucTranType==OFFLINE_SEND )
		{
			if( !(glProcInfo.stTranLog.uiStatus & (TS_ADJ|TS_VOID)) &&
				 (glProcInfo.stTranLog.ucOrgTranType==SALE_COMP || glProcInfo.stTranLog.ucOrgTranType==SALE) )
			{
				sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
			}
		}
	}
	else
	{
		sprintf((char *)glProcInfo.stTranLog.szCondCode, "00");
		if( glProcInfo.stTranLog.ucTranType==PREAUTH )
		{
			sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
		}
		else if( glProcInfo.stTranLog.ucTranType==VOID || glProcInfo.stTranLog.ucTranType==OFFLINE_SEND ||
				VOID_AUTH==glProcInfo.stTranLog.ucTranType )
		{
			if( glProcInfo.stTranLog.ucOrgTranType==SALE_COMP )
			{
				sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
			}
		}
	}

	if(glProcInfo.stTranLog.ucTranType==VOID || VOID_AUTH==glProcInfo.stTranLog.ucTranType ||
	    glProcInfo.stTranLog.ucTranType==SALE)
	{
	    if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
	    {
	        sprintf((char *)glProcInfo.stTranLog.szCondCode, "55");
	    }
	}

	sprintf((char *)glSendPack.szCondCode, "%.2s", glProcInfo.stTranLog.szCondCode);
}

// RFU for HK (bit 48, 63)
void SetInstAndAirTicketData(void)
{
	uchar	sBuff[32];

	if (ChkIfBea())
	{
		if (glProcInfo.stTranLog.ucInstalment!=0)
		{
			memcpy(glSendPack.sField63, "\x00\x02", 2);
			PubLong2Bcd((ulong)glProcInfo.stTranLog.ucInstalment, 1, sBuff);
			PubBcd2Asc0(sBuff, 1, glSendPack.sField63+2);
		}
	}
}

// 交易初始化:检查交易是否允许,显示交易标题
// initiate transaction, check allowance, display title. 
int TransInit(uchar ucTranType)
{
	glProcInfo.stTranLog.ucTranType = ucTranType;
	SetCurrTitle(_T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel));

	if( !ChkIfTranAllow(ucTranType) )
	{
		return ERR_NO_DISP;
	}

	return 0;
}



#ifdef ENABLE_DCC
int TransDccRateSub(void)
{
	int iRet;

	if( !ChkIfTranAllow(glProcInfo.stTranLog.ucTranType) )
	{
		return ERR_NO_DISP;
	}

	if(glProcInfo.stTranLog.ucTranType != INSTALMENT)
	{
		if( !ChkSettle() )
		{
			return ERR_NO_DISP;
		}
	}

	SetCommReqField();
	iRet = TranProcess();
	return iRet;
}

// initiate DCC rate lookup
// TRUE-Eligible DCC, FALSE-Normal Tansaction Flow
int TransDccRateInit(void)
{
	uchar ucRet;
	uchar sCurrencyCode[2];

	// if( !ChkEdcOption(EDC_ENABLE_DCC) || !ChkIfDccAcquirer() )
	//linzhao
//	if( !ChkIfDccAcquirer() )
//	{
//		#ifdef _SUPERQQ_
//			OsLog(LOG_ERROR, "%s--%d, out of DCC", __FILE__, __LINE__);
//		#endif
//		return FALSE;
//	}
	
#ifdef ENABLE_DCC
    uchar bEnableDcc = 0;
    uchar szEnableDcc[120];
    if(0 == GetEnv("E_DCC", szEnableDcc))
    {
        bEnableDcc = atoi(szEnableDcc);
        if(!bEnableDcc)
        {
            glProcInfo.stTranLog.ucDccOption = DCC_TYPE_NODCC;
            return FALSE;
        }
    }
#endif

	//this is for adjust transaction.  linzhao 2015.8.18
	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
		return TRUE;
	}
	// insert card
	else if(glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT)
	{
		// parameter currency code need to get from ICC card application
		GetEmvCurrencyCode(sCurrencyCode);
		FindCurrency(sCurrencyCode, &glProcInfo.stTranLog.stHolderCurrency);
		ucRet = ChkIfDccEligibleTxn(sCurrencyCode);
		if(FALSE == ucRet)
		{
			glProcInfo.stTranLog.ucDccOption	= DCC_TYPE_NODCC;
		}
		else
		{
			glProcInfo.stTranLog.ucDccOption	= DCC_TYPE_DCC;
		}
	} // swipe card or manual enter card number(PAN)
	else if( (glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT)  ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_MANUAL_INPUT) ||
			 (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
	{
	    // it seems EMP they don't have card bin for it, so all mag card need to do dcc inquiry
		glProcInfo.stTranLog.ucDccOption	= DCC_TYPE_DCC;
	}
	
	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
		return TRUE;
	}

	return FALSE;
}

static int ShowExchangeRate(gui_callbacktype_t type, void *data, int *dataLen)
{
    uchar szDispBuff[255];
    uchar szRate[10] = {0};
    static ST_TIMER  exchange_timer= {0,0,0};
    static char cLoop = 0;

    if(0 == OsTimerCheck(&exchange_timer))
    {
        GetDccRate(glProcInfo.stTranLog.stDccInfo.szDccExRate, szRate);
        sprintf(szDispBuff, "EXCHANGE RATE: %s", szRate);
        Gui_DrawText(szDispBuff, gl_stCenterAttr, 0, 70);
        cLoop = 0;
    }

    if(0 == cLoop){
        OsTimerSet(&exchange_timer, 1000);
        cLoop = 1;
    }

    return 0;
}

// Add by lirz v1.02.0000
// DCC Inqury Rate Transacton 
int TransDccRate(void)
{
    GUI_MENU        stDccMenu;
    GUI_MENUITEM    stDccMenuItem[2+1];
    int iSelected = 0;
	int bDccEnable = 0;
	int	iRet = 0;

//DCC Issuer Cuntry code
if (isIssuerLocalCurrency()==TRUE)
	{
		//fffFOURA("jordan yes");
		 return 0;
	}

//else
//	{
//		fffFOURA("jordan no ");
//	}

	//foura remove DCC
//	if (    (NULL != strstr(glCurIssuer.szName, "AMEX"))  ||   (NULL != strstr(glCurIssuer.szName, "NE"))  )
//        {
//
//
//          return 0;
//        }

	uchar   ucOldTranType = glProcInfo.stTranLog.ucTranType;

	bDccEnable = TransDccRateInit();
	// if not enable DCC, return derectly, proceed with normal transaction flow
	if(FALSE == bDccEnable /*|| PREAUTH == glProcInfo.stTranLog.ucTranType*/)//linzhao 20151230
	{
	    TransInit(ucOldTranType);
		return 0;
	}

	// DCC Transaction
	TransInit(DCC_RATE);
	MirroringSendEcr("PROCESSING...");
	Gui_ClearScr();
	Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PROCESSING..."), gl_stLeftAttr,
				   GUI_BUTTON_NONE, 0, NULL);
	iRet = TransDccRateSub();
	if(0 != iRet || glProcInfo.stTranLog.ucDccOption == DCC_TYPE_NODCC)
	{
		glProcInfo.stTranLog.ucDccOption = DCC_TYPE_NODCC;
		TransInit(ucOldTranType);
		return 0;
	}

    memset(stDccMenuItem, 0, sizeof(stDccMenuItem));
    {
        uchar szAmount[13];
        uchar szTotalAmt[13];
        stDccMenuItem[0].bVisible = TRUE;
        stDccMenuItem[0].nValue = 1;
        stDccMenuItem[0].vFunc = NULL;
        uchar szEnableFee[8];
        App_ConvAmountDccTran(glProcInfo.stTranLog.stDccInfo.szAmount, szAmount, 0);
        sprintf((char *)stDccMenuItem[0].szText, "%d.%s",1, szAmount);

        stDccMenuItem[1].bVisible = TRUE;
        stDccMenuItem[1].nValue = 2;
        stDccMenuItem[1].vFunc = NULL;
        //fix the display without tip . linzhao 20151113
        if ((0==GetEnv("E_FEE", szEnableFee)) && 0!=atoi(szEnableFee) )//linzhao 20160113
        {
            uchar szTotalAmt2[12+1];
            strcpy(szTotalAmt2, szTotalAmt);
            PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt2);
            PubAscAdd(szTotalAmt2, glProcInfo.stTranLog.szSurFee, 12, szTotalAmt);
            App_ConvAmountTran(szTotalAmt, szAmount, 0);
        }
        else if (ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount))
        {
        	App_ConvAmountTran(glProcInfo.stTranLog.szAmount, szAmount, 0);
        }
        else
        {
    		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
        	App_ConvAmountTran(szTotalAmt, szAmount, 0);
        }
        sprintf((char *)stDccMenuItem[1].szText, "%d.%s", 2, szAmount);
    }
    strcpy(stDccMenuItem[2].szText, "");

    Gui_BindMenu(_T("SELECT PAYMENT CURRENCY"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stDccMenuItem, &stDccMenu);
    Gui_ClearScr();
    Gui_RegCallback(GUI_CALLBACK_LISTEN_EVENT, ShowExchangeRate);
    iSelected = 0;
    iRet = Gui_ShowMenuList(&stDccMenu, 0, USER_OPER_TIMEOUT, &iSelected);
    Gui_RegCallback(GUI_CALLBACK_LISTEN_EVENT, NULL);

    TransInit(ucOldTranType);
    Gui_ClearScr();

    if( iRet != GUI_OK)
    {
        return EMV_USER_CANCEL;
    }

    if(2 == iSelected){
        glProcInfo.stTranLog.ucDccOption = DCC_TYPE_DECLINED;
    }
	return 0;
}
#endif // ENABLE_DCC

// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug506
int TransCapture(void)
{
	int	iRet;

	if( glProcInfo.stTranLog.ucTranType==CASH )
	{
		TransInit(glProcInfo.stTranLog.ucTranType);
		iRet = TransCashSub();
	}
	else if ( glProcInfo.stTranLog.ucTranType==SALE ||
		glProcInfo.stTranLog.ucTranType==INSTALMENT )
	{
		TransInit(glProcInfo.stTranLog.ucTranType);
		iRet = TransSaleSub();
	}
	else
	{
		if( ChkEdcOption(EDC_AUTH_PREAUTH) )
		{
			TransInit(AUTH);
			iRet = TransAuthSub(AUTH);
		}
		else
		{
			TransInit(PREAUTH);
			iRet = TransAuthSub(PREAUTH);
		}
	}

	return iRet;
}

// Modified by Kim_LinHB 2014-7-11
int InstallmentMenu(void)
{
	int		iRet, iMenuNo;
	GUI_MENU stInstMenu;
	GUI_MENUITEM stInstMenuItem[] =
	{
		{ _T_NOOP("1.INSTAL SALE "), 0, TRUE,  NULL},
		{ _T_NOOP("2.INSTAL VOID "), 1, TRUE,  NULL},
		{ "", -1, FALSE,  NULL},
	};

	Gui_BindMenu(GetCurrTitle(), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stInstMenuItem, &stInstMenu);
	Gui_ClearScr();
	iMenuNo = 0;
	iRet = Gui_ShowMenuList(&stInstMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);

	if(GUI_OK == iRet)
	{
		switch( iMenuNo )
		{
		case 0:
			iRet = TransSale(TRUE);
			break;

		case 1:
			iRet = TransVoid();
			break;

		default:
			return ERR_NO_DISP;
		}
	}
	else
	{
		return ERR_NO_DISP;
	}

	CommOnHook(FALSE);
	return iRet;
}

int TransCash(void)
{
	int		iRet;

	iRet = TransInit(CASH);
	if( iRet!=0 )
	{
		return iRet;
	}


	iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
	if( iRet!=0 )
	{
		return iRet;
	}

	return TransSaleSub();
}

int TransCashSub(void)
{
	int		iRet;

	if( !ChkIfTranAllow(glProcInfo.stTranLog.ucTranType) )
	{
		return ERR_NO_DISP;
	}
	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetDescriptor();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetAddlPrompt();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}

	SetCommReqField();
	iRet = TranProcess();
	if( iRet!=ERR_NEED_FALLBACK )
	{
		return iRet;
	}

	// continue fallback process
	glProcInfo.bIsFallBack = TRUE;
	glProcInfo.stTranLog.uiEntryMode &= 0xF0;

	iRet = GetCard(FALLBACK_SWIPE|CARD_SWIPED);
	if( iRet!=0 )
	{
		return iRet;
	}

	SetCommReqField();
	return TranProcess();
}

// 普通消费、分期消费
// sale or installment
int TransSale(uchar ucInstallment)
{
	int		iRet;
	uchar	ucEntryMode;

	iRet = TransInit((uchar)(ucInstallment ? INSTALMENT : SALE));


	if( iRet!=0 )
	{
		return iRet;
	}

	ucEntryMode = CARD_SWIPED|CARD_KEYIN;
	if (!ucInstallment)
	{
		ucEntryMode |= CARD_INSERTED;
	}

	iRet = GetCard(ucEntryMode);
	if( iRet!=0 )
	{
		return iRet;
	}

	return TransSaleSub();
}


// sale or installment
int TransSaleType(uchar ucInstallment,uchar ucTranType)
{
	int		iRet;
	uchar	ucEntryMode;

	iRet = TransInit((uchar)ucTranType);


	if( iRet!=0 )
	{
		return iRet;
	}

if ( (glProcInfo.stTranLog.ucTranType==MOTO)  || (glProcInfo.stTranLog.ucTranType==EXPRESS_CHECKOUT )  ){
	iRet = GetCard(CARD_KEYIN);

}else
{

	ucEntryMode = CARD_SWIPED|CARD_KEYIN;

	if (!ucInstallment)
	{
		ucEntryMode |= CARD_INSERTED;
	}

	iRet = GetCard(ucEntryMode);
}



	if( iRet!=0 )
	{
		return iRet;
	}

	return TransSaleSub();
}

// 负责SALE和INSTALLMENT
// for sale and installment
int TransSaleSub(void)
{
	int		iRet;

	if( !ChkIfTranAllow(glProcInfo.stTranLog.ucTranType) )
	{


		return ERR_NO_DISP;
	}

	// instalment时，仅当选择plan之后才最终确认ACQ，因此现在不需要检查settle状态
	// when doing installment, ACQ will be confirmed after selecting plan, so don't need to check if need to settle now.
	if (glProcInfo.stTranLog.ucTranType!=INSTALMENT)
	{
		if( !ChkSettle() )
		{
			return ERR_NO_DISP;
		}
	}

	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}



	iRet = GetInstalPlan();
	if( iRet!=0 )
	{
		return iRet;
	}

	// instalment时，仅当选择plan之后才最终确认ACQ
	// when doing installment, ACQ is confirmed after selecting plan
	if (glProcInfo.stTranLog.ucTranType==INSTALMENT)
	{
		if( !ChkSettle() )
		{
			return ERR_NO_DISP;
		}
	}

	iRet = GetDescriptor();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetAddlPrompt();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}

	if( ChkIfBelowMagFloor() && !glProcInfo.bExpiryError && !ChkIfIccTran(glProcInfo.stTranLog.uiEntryMode) )
	{
//		sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
		sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%02ld", glSysCtrl.ulSTAN % 100);
		glProcInfo.stTranLog.uiStatus |= TS_CHANGE_APPV|TS_FLOOR_LIMIT;
		return FinishOffLine();
	}

	uchar szEnableLoyalty[120];
	if(0 ==GetEnv("E_LOY", szEnableLoyalty) && '1' == szEnableLoyalty[0])
    {
	    TransSaleInquiryAuto();
    }

	SetCommReqField();

	iRet = TranProcess();
	if( iRet!=ERR_NEED_FALLBACK )
	{
		return iRet;
	}

	// continue fallback process
	glProcInfo.bIsFallBack = TRUE;
	glProcInfo.stTranLog.uiEntryMode &= 0xF0;

	iRet = GetCard(FALLBACK_SWIPE|CARD_SWIPED);
	if( iRet!=0 )
	{
		return iRet;
	}

	SetCommReqField();
	return TranProcess();
}

// 授权/预授权交易
// authorization / pre-authorization
int TransAuth(uchar ucTranType)
{
	int		iRet;

	PubASSERT(ucTranType==AUTH || ucTranType==PREAUTH);

	iRet = TransInit(ucTranType);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
	if( iRet!=0 )
	{
		return iRet;
	}

	return TransAuthSub(ucTranType);
}

int TransAuthSub(uchar ucTranType)
{
	int		iRet;

	if( !ChkIfTranAllow(ucTranType) )
	{
		return ERR_NO_DISP;
	}
	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	if( ChkIssuerOption(ISSUER_NO_PREAUTH) )
	{
		DispBlockFunc();
		return ERR_NO_DISP;
	}

	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkIfAmex() )
	{
		iRet = GetDescriptor();
		if( iRet!=0 )
		{
			return iRet;
		}

		iRet = GetAddlPrompt();
		if( iRet!=0 )
		{
			return iRet;
		}
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}
	//linzhao 20150922
	if( ChkIfBelowMagFloor() && !glProcInfo.bExpiryError && !ChkIfIccTran(glProcInfo.stTranLog.uiEntryMode) )
	{
//		sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");
		sprintf((char *)glProcInfo.stTranLog.szAuthCode, "%02ld", glSysCtrl.ulSTAN % 100);
		glProcInfo.stTranLog.uiStatus |= TS_CHANGE_APPV|TS_FLOOR_LIMIT;
		return FinishOffLine();
	}

	uchar szEnableLoyalty[120];
	if(0 ==GetEnv("E_LOY", szEnableLoyalty) && '1' == szEnableLoyalty[0])
    {
	    TransSaleInquiryAuto();
    }

	SetCommReqField();
	iRet = TranProcess();
	if( iRet!=ERR_NEED_FALLBACK )
	{
		return iRet;
	}

	// continue fallback process
	glProcInfo.bIsFallBack = TRUE;
	glProcInfo.stTranLog.uiEntryMode &= 0xF0;

	iRet = GetCard(FALLBACK_SWIPE|CARD_SWIPED);
	if( iRet!=0 )
	{
		return iRet;
	}
	SetCommReqField();
	return TranProcess();
}

int FinishOffLine(void)
{
	uchar	ucTranAct;

	SetOffBase(OffBaseDisplay);

	DispProcess();

	if( !(glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) &&
		(glProcInfo.stTranLog.ucTranType!=SALE_COMP) )
	{
		sprintf((char *)glProcInfo.stTranLog.szRspCode, "00");
	}
	glProcInfo.stTranLog.ulInvoiceNo = glSysCtrl.ulInvoiceNo;
	ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;

	if (ucTranAct & ACT_INC_TRACE)
	{
		GetNewTraceNo();
	}

	if( ucTranAct & WRT_RECORD )
	{
		glProcInfo.stTranLog.uiStatus |= TS_NOSEND;
		OsLog(LOG_DEBUG, "%s-%d, Save COMPLETION LOG : %s, %d, %d", __FILE__, __LINE__,
			  glProcInfo.stTranLog.stHolderCurrency.szName,
			  glProcInfo.stTranLog.stHolderCurrency.ucDecimal,
			  glProcInfo.stTranLog.stHolderCurrency.ucIgnoreDigit);
		SaveTranLog(&glProcInfo.stTranLog);
	}
	//MirroringSendEcr("PLS REMOVE CARD22");
    EcrSendTransSucceed();
	if( ucTranAct & PRN_RECEIPT )	// print slip
	{
		CommOnHook(FALSE);
		GetNewInvoiceNo();
		PrintReceipt(PRN_NORMAL);
	}

	DispResult(0);
	// PubWaitKey(glSysParam.stEdcInfo.ucAcceptTimeout); // Hidden by Kim_LinHB 2014/9/11 v1.01.0008 bug523

	return 0;
}

int TranReversal(void)
{
	int	iRet;
	SYS_PROC_INFO	stProcInfoBak;

	if( glProcInfo.stTranLog.ucTranType==LOAD_PARA ||
		glProcInfo.stTranLog.ucTranType==ECHO_TEST ||
		glProcInfo.stTranLog.ucTranType==LOAD_CARD_BIN )
	{
		return 0;
	}

	if( !glSysCtrl.stRevInfo[glCurAcq.ucIndex].bNeedReversal )
	{
		return 0;
	}

	// backup current process information
	memcpy(&glProcInfo.stSendPack, &glSendPack, sizeof(STISO8583));
	memcpy(&stProcInfoBak, &glProcInfo, sizeof(SYS_PROC_INFO));
	// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug506
	//glProcInfo.stTranLog.ucTranType = REVERSAL;
	TransInit(REVERSAL);

	memcpy(&glSendPack, &glSysCtrl.stRevInfo[glCurAcq.ucIndex].stRevPack, sizeof(STISO8583));
	sprintf((char *)glSendPack.szMsgCode, "0400");
	if( ChkIfBoc() )  // Boc erase F55
	{
		memset(glSendPack.sICCData, 0, 2);
	}
	if( ChkIfAmex() )
	{
		memset(glSendPack.sICCData, 0, 2);
		memset(glSendPack.szLocalDate, 0, sizeof(glSendPack.szLocalDate));
		memset(glSendPack.szLocalTime, 0, sizeof(glSendPack.szLocalTime));
		memset(glSendPack.szRRN,       0, sizeof(glSendPack.szRRN));
		memset(glSendPack.szAuthCode,  0, sizeof(glSendPack.szAuthCode));
	}
	memset(glSendPack.sPINData, 0, sizeof(glSendPack.sPINData));	// erase PIN block

#ifdef ENABLE_EMV
//	if( (glSysCtrl.stRevInfo[glCurAcq.ucIndex].uiEntryMode & MODE_CHIP_INPUT) &&
//		ChkIfAcqNeedDE56() )
//	{
//		iLength = glSysCtrl.stField56[glCurAcq.ucIndex].uiLength;
//		if( iLength>0 )
//		{
//			memcpy(&glSendPack.sICCData2[2], glSysCtrl.stField56[glCurAcq.ucIndex].sData, iLength);
//		}
//		else
//		{
//			SetStdEmptyDE56(&glSendPack.sICCData2[2], &iLength);
//		}
//		PubLong2Char((ulong)iLength, 2, glSendPack.sICCData2);
//	}
//	if( ChkIfDah() || ChkIfCiti() )
//	{
//		memset(glSendPack.sICCData2, 0, 2);
//	}
//	if( (glSysCtrl.stRevInfo[glCurAcq.ucIndex].uiEntryMode & MODE_FALLBACK_SWIPE) ||
//		(glSysCtrl.stRevInfo[glCurAcq.ucIndex].uiEntryMode & MODE_FALLBACK_MANUAL) )
//	{
//		if (ChkIfBoc())
//		{
//			memset(glSendPack.sICCData2, 0, 2);
//		}
//	}
#endif

	if( ChkIfBoc() )
	{
		memset(glSendPack.szLocalDate, 0, sizeof(glSendPack.szLocalDate));
		memset(glSendPack.szLocalTime, 0, sizeof(glSendPack.szLocalTime));
		memset(glSendPack.szRRN, 0, sizeof(glSendPack.szRRN));
		memset(glSendPack.szAuthCode, 0, sizeof(glSendPack.szAuthCode));
	}

	while( 1 )
	{
		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			break;
		}
		if( memcmp(glRecvPack.szRspCode, "00", 2)==0 )
		{
			break;
		}
		if( ChkIfAmex() && (memcmp(glRecvPack.szRspCode, "08", 2)==0 || memcmp(glRecvPack.szRspCode, "88", 2)==0) )
		{
			break;
		}

		sprintf((char *)glProcInfo.stTranLog.szRspCode, "%.2s", glRecvPack.szRspCode);
		DispResult(ERR_HOST_REJ);
// 		iRet = ERR_NO_DISP;
		iRet = ERR_TRAN_FAIL;
		break;
	}
	if( iRet==0 )
	{	// clear reversal flag
		SaveRevInfo(FALSE);
	}

	if (iRet==0)
	{
		// increase invoice for coming AMEX transaction
		if (ChkIfAmex())
		{
			if (glTranConfig[stProcInfoBak.stTranLog.ucTranType].ucTranAct & PRN_RECEIPT)
			{
				stProcInfoBak.stTranLog.ulInvoiceNo = GetNewInvoiceNo();
				PackInvoice(&stProcInfoBak.stSendPack, stProcInfoBak.stTranLog.ulInvoiceNo);
			}
		}
	}

	// restore process information
	memcpy(&glProcInfo, &stProcInfoBak, sizeof(SYS_PROC_INFO));
	memcpy(&glSendPack, &glProcInfo.stSendPack, sizeof(STISO8583));

	TransInit(glProcInfo.stTranLog.ucTranType); // Added by Kim_LinHB 2014-8-8 v1.01.0002

	return iRet;
}

int GetOfflineTrans(uchar ucTypeFlag)
{
	int		iRet;
	ushort	uiCnt;

	for(uiCnt=0; uiCnt<MAX_TRANLOG; uiCnt++)
	{
		if( glSysCtrl.sAcqKeyList[uiCnt]!=glCurAcq.ucKey )
		{
			continue;
		}

		memset(&glProcInfo.stTranLog, 0, sizeof(TRAN_LOG));
		iRet = LoadTranLog(&glProcInfo.stTranLog, uiCnt);
		if( iRet!=0 )
		{
			return FALSE;
		}

		if(glProcInfo.stTranLog.ucTranType == PREAUTH)
		{
			continue;
		}

		if ( (ucTypeFlag & OFFSEND_TC) &&
			 (glProcInfo.stTranLog.uiStatus & TS_NEED_TC) )
		{
			glProcInfo.uiRecNo = uiCnt;
			return TRUE;
		}
		else if ( (ucTypeFlag & OFFSEND_TRAN) &&
			 (glProcInfo.stTranLog.uiStatus & TS_NOSEND) )
		{
			glProcInfo.uiRecNo = uiCnt;
			return TRUE;
		}
	}

	return FALSE;
}

int OfflineSend(uchar ucTypeFlag)
{
#ifdef ENABLE_EMV
	int iLength;
#endif
	int	iRet;
	SYS_PROC_INFO	stProcInfoBak;

	if( glProcInfo.stTranLog.ucTranType == PREAUTH && (0==(TS_ADJ & glProcInfo.stTranLog.uiStatus)) )
	{
		return 0;
	}
	if( glProcInfo.stTranLog.ucTranType == COMPLETION &&  TS_NOSEND == glProcInfo.stTranLog.uiStatus)
	{
		return 0;
	}
	if( glProcInfo.stTranLog.ucTranType!=SETTLEMENT )
	{	// the time to load 400 txn log is about 1-2 seconds
		if( ChkAcqOption(ACQ_DISABLE_TRICK_FEED) )
		{
			return 0;
		}
	}

	memcpy(&glProcInfo.stSendPack, &glSendPack, sizeof(STISO8583));
	memcpy(&stProcInfoBak, &glProcInfo,  sizeof(SYS_PROC_INFO));
	while( 1 )
	{
		InitTransInfo();
		if( !GetOfflineTrans(ucTypeFlag) )
		{
			iRet = 0;
			break;
		}

		if (glProcInfo.stTranLog.uiStatus & TS_NEED_TC)
		{
			glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
			glProcInfo.stTranLog.ucTranType    = TC_SEND;

			SetCommReqField();

			if (0)
			{
				sprintf((char *)glSendPack.szMsgCode, "0220");
			}

			// bit39
			//sprintf((char *)glSendPack.szRspCode, "%.2s", glProcInfo.stTranLog.szRspCode);

#ifdef ENABLE_EMV
			// bit55
			//SetDE55(DE55_TC, glSendPack.sICCData+2, &iLength);
            SetTCDE55(&glProcInfo.stTranLog, glSendPack.sICCData+2, &iLength);
			PubLong2Char((ulong)iLength, 2, glSendPack.sICCData);
#endif

			iRet = SendRecvPacket();
			if( iRet!=0 )
			{
				break;
			}

			// update txn status
			glProcInfo.stTranLog.uiStatus &= ~TS_NEED_TC;

			// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug506
			 glProcInfo.stTranLog.ucTranType = glProcInfo.stTranLog.ucOrgTranType;
			TransInit(glProcInfo.stTranLog.ucOrgTranType);

			UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);

			if( stProcInfoBak.stTranLog.ucTranType!=SETTLEMENT )
			{
				break;
			}

			continue;
		} 

		glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
		glProcInfo.stTranLog.ucTranType    = OFFLINE_SEND;

		SetCommReqField();

		// bit 4
		if( glProcInfo.stTranLog.uiStatus & TS_VOID )
		{
			glSendPack.szTranAmt[0] = 0;
		}

		// bit 37, 39
		if( !ChkIfAmex() )
		{
			if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
			{
				sprintf((char *)glSendPack.szRspCode, "%.2s", glProcInfo.stTranLog.szRspCode);
				if( glProcInfo.stTranLog.szRRN[0]!=0 )	// seen by host
				{
					glSendPack.szRspCode[0] = 0;
				}
			}
		}
		if( ChkAcqOption(ACQ_DBS_FEATURE) )
		{	// 香港星展银行,sale_complete上送时, VISA/MASTER需要上送 BIT37 BIT39
			if( glProcInfo.stTranLog.ucOrgTranType==SALE_COMP &&
				glProcInfo.stTranLog.szRRN[0]==0 )
			{
				sprintf((char *)glSendPack.szRRN, "%.12s", &glProcInfo.stTranLog.szRRN[1]);
			}
		}

		if( ChkIfAmex() && (glProcInfo.stTranLog.uiStatus & TS_FLOOR_LIMIT) )
		{
			if( !(glProcInfo.stTranLog.uiStatus & (TS_ADJ|TS_VOID)) )
			{
				sprintf((char *)glSendPack.szAddlRsp, "03");
			}
		}

		// bit 55
		if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
		{
			if( ChkIfAmex() )
			{
				if( !(glProcInfo.stTranLog.uiStatus & TS_ADJ) &&
					((glProcInfo.stTranLog.ucOrgTranType==OFF_SALE) ||
					 (glProcInfo.stTranLog.ucOrgTranType==SALE_COMP) ||
					 (glProcInfo.stTranLog.ucOrgTranType==SALE && (glProcInfo.stTranLog.uiStatus & TS_NOSEND))) )
				{
					PubLong2Char((ulong)glProcInfo.stTranLog.uiIccDataLen, 2, glSendPack.sICCData);
					memcpy(&glSendPack.sICCData[2], glProcInfo.stTranLog.sIccData, glProcInfo.stTranLog.uiIccDataLen);
				}
			}
			else
			{	// only send ICC sale below floor
				if( glProcInfo.stTranLog.szRRN[0]==0 )
				{
					PubLong2Char((ulong)glProcInfo.stTranLog.uiIccDataLen, 2, glSendPack.sICCData);
					memcpy(&glSendPack.sICCData[2], glProcInfo.stTranLog.sIccData, glProcInfo.stTranLog.uiIccDataLen);
				}
			}
		}

		// bit 60
		if( !ChkIfAmex() && (glProcInfo.stTranLog.uiStatus & (TS_ADJ|TS_VOID)) )
		{
			if( glProcInfo.stTranLog.uiStatus & TS_VOID )
			{
				sprintf((char *)glSendPack.szField60, "%.12s", glProcInfo.stTranLog.szAmount);
			}
			else
			{
				sprintf((char *)glSendPack.szField60, "%.12s", glProcInfo.stTranLog.szOrgAmount);
			}
		}

		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			break;
		}

		// update txn status
		glProcInfo.stTranLog.uiStatus &= ~TS_NOSEND;
		glProcInfo.stTranLog.uiStatus |= TS_OFFLINE_SEND;
		glProcInfo.stTranLog.uiStatus |= TS_AUTH_SEND;

		// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug506
		//glProcInfo.stTranLog.ucTranType = glProcInfo.stTranLog.ucOrgTranType;
		TransInit(glProcInfo.stTranLog.ucOrgTranType);
		UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);

		// Add by lirz v1.02.0000
		if( COMPLETION == glProcInfo.stTranLog.ucOrgTranType && !(glProcInfo.stTranLog.uiStatus & TS_VOID))
		{
			int iIdx = -1;
			int iRes = 0;
			uchar szAuthCode[6 + 1];
			uchar szRRN[13 + 1];

			strcpy(szAuthCode, glProcInfo.stTranLog.szAuthCode);
			strcpy(glProcInfo.stTranLog.szAuthCode, glProcInfo.stTranLog.szOrgAuthCode);
			strcpy(szRRN, glProcInfo.stTranLog.szRRN);
			strcpy(glProcInfo.stTranLog.szRRN, glProcInfo.stTranLog.szOrgRRN);

			iRes = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
			if(0 == iRes && iIdx>=0 && iIdx<MAX_AUTH_TRANLOG)
			{
				if(glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct & VOID_ALLOW)
				{
					TRAN_LOG stLog;
					memset(&stLog, 0x00, sizeof(TRAN_LOG));
					iRes = LoadAuthTranLog(&stLog, iIdx);
					if(0 == iRes && TS_NOT_UPLOAD == stLog.uiStatus)
					{
						stLog.uiStatus = TS_OK;
						UpdateAuthTranLog(&stLog, iIdx);
					}
				}
				else
				{
					DeleteAuthTranLog(iIdx);
				}
			}
			strcpy(glProcInfo.stTranLog.szAuthCode, szAuthCode);
			strcpy(glProcInfo.stTranLog.szRRN, szRRN);
		}
		// End add by lirz v1.02.0000

		if( stProcInfoBak.stTranLog.ucTranType!=SETTLEMENT )
		{	// is trickle feed, only need send one txn
			break;
		}
	}
	memcpy(&glProcInfo, &stProcInfoBak, sizeof(SYS_PROC_INFO));
	memcpy(&glSendPack, &glProcInfo.stSendPack, sizeof(STISO8583));

	return iRet;
}

// transaction complete for voice referral
int TranSaleComplete(void)
{
#ifdef ENABLE_EMV
	int		iLength;
#endif
	int		iRet;
	unsigned char szBuff[100];

	if( !ChkIssuerOption(ISSUER_EN_VOICE_REFERRAL) )
	{
		dddoHentFMessage(37);
		return ERR_TRAN_FAIL;
	}

	if( (glProcInfo.stTranLog.ucTranType!=PREAUTH) &&
		(glProcInfo.stTranLog.ucTranType!=AUTH) &&
		(glProcInfo.stTranLog.ucTranType!=SALE) &&
		(glProcInfo.stTranLog.ucTranType!=INSTALMENT) &&
		(glProcInfo.stTranLog.ucTranType!=CASH) )
	{
		dddoHentFMessage(38);
		return ERR_TRAN_FAIL;
	}

	if( glProcInfo.stTranLog.ucTranType>=SALE )
	{
		TransInit(SALE_COMP);
	}

	CommOnHook(FALSE);
	// Modified by Kim_LinHB 2014-7-11	
	sprintf(szBuff, "CALL:%-11.11s", glCurIssuer.szRefTelNo);
	SetCurrTitle(szBuff);
	Gui_ClearScr();
	
	if( ChkEdcOption(EDC_REFERRAL_DIAL) )
	{
		MirroringSendEcr("PLS CALL BANK");
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS CALL BANK"), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
		iRet = ReferralDial(glCurIssuer.szRefTelNo);
		if( iRet!=0 )
		{
			return iRet;
		}
	}
	else
	{
		MirroringSendEcr("PLS CALL BANK");
		if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLS CALL BANK"), gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
		{   
			MirroringSendEcr("TRANS CANCELED");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TRANS CANCELED"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			return ERR_NO_DISP;
		}
	}

	iRet = GetPreAuthCode();
	if( iRet!=0 )
	{
		MirroringSendEcr("TRANS CANCELED");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("TRANS CANCELED"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
		return ERR_NO_DISP;
	}

	// 香港星展银行,sale_complete上送时, VISA/MASTER需要上送 BIT37 BIT39
	// For DBS in HongKong.
	memmove(&glProcInfo.stTranLog.szRRN[1], glProcInfo.stTranLog.szRRN, 12);
	glProcInfo.stTranLog.szRRN[0] = 0;
//	sprintf((char *)glProcInfo.stTranLog.szCondCode, "06");

#ifdef ENABLE_EMV
	if( (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT) &&
		ChkIfAcqNeedDE56() )
	{
		SetDE56(glProcInfo.stTranLog.sField56, &iLength);
		glProcInfo.stTranLog.uiField56Len = (ushort)iLength;
	}
#endif

#ifdef ENABLE_DCC
	iRet = TransDccRate();
	if(0 != iRet)
	{
		return iRet;
	}
#endif

	return FinishOffLine();
}

// 退货
// refund
int TransRefund(void)
{
	int		iRet;

	iRet = TransInit(REFUND);
	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkEdcOption(EDC_NOT_REFUND_PWD) )
	{
        /*=======BEGIN: Jason 2014.12.20  14:32 modify===========*/
		if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
        {
		    uchar   bufPwd[20] = {0};  //Jason 2014.12.20 14:31
            EcrGetPwd(bufPwd);
            if( !(memcmp(bufPwd, glSysParam.sPassword[PWD_REFUND], 4)==0 &&
                  strlen((char *)bufPwd)== 4)&&
                !(memcmp(bufPwd, GetDynamicPassword(), 6)==0 &&
                  strlen((char *)bufPwd)== 6) &&
                !(memcmp(bufPwd, glSysParam.sPassword[PWD_BANK], 6)==0 &&
                  strlen((char *)bufPwd)== 6))
            {
            	MirroringSendEcr("PWD ERROR!");
                Gui_ClearScr();
                PubBeepErr();
                Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PWD ERROR!"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
                return ERR_NO_DISP;
            }
        }
        else
    	/*====================== END======================== */
		{
			if( PasswordRefund()!=0 )
			{
				return ERR_NO_DISP;
			}
		}
	}

	iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);//CARD_INSERTED SKIP_CHECK_ICC ramziiiiiiii
	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	if( ChkIssuerOption(ISSUER_NO_REFUND) )
	{
		DispBlockFunc();
		return ERR_NO_DISP;
	}

	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetDescriptor();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetAddlPrompt();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}

	if( ChkAcqOption(ACQ_ONLINE_REFUND) )
	{
		SetCommReqField();
		return TranProcess();
	}
	else
	{
		return FinishOffLine();
	}
}

// 离线
// offline sale
int TransOffSale(void)
{
	int		iRet;

	iRet = TransInit(OFF_SALE);
	if( iRet!=0 )
	{
		return iRet;
	}

	//iRet = GetCard(SKIP_CHECK_ICC|CARD_SWIPED|CARD_KEYIN);
   iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);//ADIB OFFLINE

	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	if( !ChkIssuerOption(ISSUER_EN_OFFLINE) )
	{
		DispBlockFunc();
		return ERR_NO_DISP;
	}

	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetDescriptor();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetAddlPrompt();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPreAuthCode();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}

	return FinishOffLine();
}

int TransVoid(void)
{
	int			iRet;
	ulong       ulInvoice;
	uchar		ucTranAct, bOnlineFlag, szTempAmt[12+1];
	uchar		szDispBuff[50];
	GUI_TEXT_ATTR stCenter = gl_stCenterAttr;

	iRet = TransInit(VOID);
	if( iRet!=0 )
	{
		return iRet;
	}

	if( !ChkEdcOption(EDC_NOT_VOID_PWD) )
	{
        /*=======BEGIN: Jason 2014.12.20  14:33 modify===========*/
        if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
        {
            uchar   bufPwd[20] = {0};  //Jason 2014.12.20 14:31
            EcrGetPwd(bufPwd);
            if(!( memcmp(bufPwd, glSysParam.sPassword[PWD_VOID], 4)==0 &&
                  strlen((char *)bufPwd)== 4 )&&
               !(memcmp(bufPwd, GetDynamicPassword(), 6)==0 &&
                  strlen((char *)bufPwd)== 6) &&
               !(memcmp(bufPwd, glSysParam.sPassword[PWD_BANK], 6)==0 &&
                  strlen((char *)bufPwd)== 6))
            {
            	MirroringSendEcr("PWD ERROR!");
                Gui_ClearScr();
                PubBeepErr();
                Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PWD ERROR!"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
                return ERR_NO_DISP;
            }
        }
        else
        /*====================== END======================== */
        {
            if( PasswordVoid()!=0 )
            {
                return ERR_NO_DISP;
            }
        }
    }
    ulInvoice = EcrGetTxnID();


//srsrsrsrsr
//    if (!(NULL != strstr(glCurAcq.szName, "NE")))
//    			{
//    		        glSysParam.bNECard = TRUE;
//
//    			}
//    	      else
//    	       {
//    		      glSysParam.bNECard = FALSE;
//
//    	       }
   // glSysParam.bNECard = TRUE;

    if ((glProcInfo.ucEcrCtrl==ECR_BEGIN) && (ulInvoice>0))
    {
        iRet = GetRecordByInvoice(ulInvoice, TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
        if( iRet!=0 )
        {
            return iRet;
		}
		ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;
        if (!(ucTranAct & VOID_ALLOW))
        {
        	MirroringSendEcr("NOT ALLOW VOID");
            Gui_ClearScr();
            PubBeepErr();
            Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ALLOW VOID"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);

            return ERR_NO_DISP;
        }

        FindAcq(glProcInfo.stTranLog.ucAcqKey);
        FindIssuer(glProcInfo.stTranLog.ucIssuerKey);

        glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
        //linzhao
		memcpy(glProcInfo.stTranLog.szOrgRRN, glProcInfo.stTranLog.szRRN, sizeof(glProcInfo.stTranLog.szRRN));
		memcpy(glProcInfo.stTranLog.szOrgAuthCode, glProcInfo.stTranLog.szAuthCode, sizeof(glProcInfo.stTranLog.szAuthCode));

        //for now. linzhao
        if (AUTH==glProcInfo.stTranLog.ucTranType /*&& 0==(glProcInfo.stTranLog.uiStatus&TS_AUTH_SEND)*/)
        {
        	glProcInfo.stTranLog.ucTranType    = VOID_AUTH;
        }
        else
        {
        	glProcInfo.stTranLog.ucTranType    = VOID;
        }
	}
	else
	{
		while( 1 )
		{
			if(glProcInfo.bPreAuthVoid)
			{
				//iRet = GetRecordByRRNandAuthCode(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
				///delete void preauth hala hasan
				iRet = GetRecord(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
			}
			else
			{
				iRet = GetRecord(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
			}
			if( iRet!=0 )
			{
				return iRet;
			}

			ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;

			//linzhao
			memcpy( glProcInfo.stTranLog.szOrgRRN,  glProcInfo.stTranLog.szRRN, sizeof(glProcInfo.stTranLog.szRRN));
			memcpy( glProcInfo.stTranLog.szOrgAuthCode, glProcInfo.stTranLog.szAuthCode,  sizeof(glProcInfo.stTranLog.szAuthCode));

			if( ucTranAct & VOID_ALLOW )
			{
				//separate void sale and void auth. linzhao 2015.11.13
				glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
				//for now
				if (AUTH==glProcInfo.stTranLog.ucTranType /*&& 0==(glProcInfo.stTranLog.uiStatus&TS_AUTH_SEND)*/)
				{
					glProcInfo.stTranLog.ucTranType    = VOID_AUTH;
				}
				else
				{
					glProcInfo.stTranLog.ucTranType    = VOID;
				}

				break;
			}

			MirroringSendEcr("NOT ALLOW VOID");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ALLOW VOID"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		}
	}
	
	FindAcq(glProcInfo.stTranLog.ucAcqKey);
	FindIssuer(glProcInfo.stTranLog.ucIssuerKey);

	if( ChkIssuerOption(ISSUER_NO_VOID) )
	{
		DispBlockFunc();
		return ERR_NO_DISP;
	}

	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	if( ChkAcqOption(ACQ_ONLINE_VOID) )
	{
		DispWait();
		PreDial();
	}

	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
	    PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTempAmt);
	    GetDispDccAmount(szTempAmt, szDispBuff);   // show total amount



	    //foura showing JOD amount
	    ///==================================
	    uchar szTempAmt2[12+1];
	    uchar szTempAmt3[12+1];
	    uchar szTempAmt4[12+1];

	    memset(szTempAmt2,0,sizeof(szTempAmt2));
	    memset(szTempAmt3,0,sizeof(szTempAmt3));
	    memset(szTempAmt4,0,sizeof(szTempAmt4));

	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTempAmt2);
	   	PubAscAdd(szTempAmt2, glProcInfo.stTranLog.szSurFee, 12, szTempAmt3);
	   	GetDispAmount(szTempAmt3, szTempAmt4);	// show total amount

	    strcat(szDispBuff,"\n");
	    strcat(szDispBuff,szTempAmt4);
       //==========================================
	}
	else//add surCharge fee. linzhao 20160113
    {
	    uchar szTempAmt2[12+1];
	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTempAmt2);
	    PubAscAdd(szTempAmt2, glProcInfo.stTranLog.szSurFee, 12, szTempAmt);
	    GetDispAmount(szTempAmt, szDispBuff);	// show total amount
    }

//
	//OsLog(LOG_ERROR,"szTempAmt2:%s",szTempAmt);
    //rana foura
  // OsLog(LOG_ERROR,"AMMMSSSSSOUNT%s", szCMDAmount) ;

		if(  glProcInfo.stTranLog.ulInvoiceNo == 0  ){

			MirroringSendEcr("INVALID TRACE");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "INVALID TRACE", stCenter, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);

			return  ERR_NO_DISP;
		}



		   if (MirroringCheckEcr())
			    {



					int retcomp = strcmp(szTempAmt, szCMDAmount);
						if(  (retcomp != 0) && (ulInvoice>0)  ){
							MirroringSendEcr("VOID CANCLED");
			 				Gui_ClearScr();
							 Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "VOID CANCLED", stCenter, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);

							return ERR_USERCANCEL;
						}

			    }//end mirroring



// fffFOURA( glProcInfo.stTranLog.szPan);

 //srsrsrsrsr
     if ((NULL != strstr(glCurAcq.szName, "NE")))
     			{
     		        glSysParam.bNECard = TRUE;

     			}
     	      else
     	       {
     		      glSysParam.bNECard = FALSE;

     	       }
    //RANA FOURA
	strcat(szDispBuff, "\n");
	strcat(szDispBuff, _T("VOID ?"));

	MirroringSendEcr(szDispBuff);
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispBuff, stCenter, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
	{
		return ERR_USERCANCEL;
	}

 	bOnlineFlag = TRUE;
  	if( glProcInfo.stTranLog.uiStatus & TS_NOSEND )
 	{	// offsale/sale below/sale comp.../adjust
 		if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
 		{	// 该调整还未上送,作废调整后的金额
 			if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
 			{
				PubAscSub(glProcInfo.stTranLog.stDccInfo.szOrgAmount, glProcInfo.stTranLog.stDccInfo.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.stDccInfo.szTipAmt, "%.12s", szTempAmt);

				PubAscSub(glProcInfo.stTranLog.szOrgAmount, glProcInfo.stTranLog.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%.12s", szTempAmt);
 			}
 			else
 			{
				PubAscSub(glProcInfo.stTranLog.szOrgAmount, glProcInfo.stTranLog.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%.12s", szTempAmt);
 			}
 		}
		if( glProcInfo.stTranLog.szRRN[0]==0 )
		{
			bOnlineFlag = FALSE;
		}
 	}

 	if( !ChkAcqOption(ACQ_ONLINE_VOID) )
	{
		bOnlineFlag = FALSE;
	}

	if( bOnlineFlag )
	{
		SetCommReqField();
		return TranProcess();
	}
	else	// offline void
	{
		glProcInfo.stTranLog.uiStatus |= (TS_VOID|TS_NOSEND);
		if( glProcInfo.stTranLog.szRRN[0]==0 )
		{	// not seen by host(orginal txn is offsale/sale below/salecomp/ ...)
			glProcInfo.stTranLog.uiStatus &= ~(TS_NOSEND);
		}
		GetDateTime(glProcInfo.stTranLog.szDateTime);
		UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);

		// Add by lirz v1.02.0000
		if(COMPLETION == glProcInfo.stTranLog.ucOrgTranType)
		{
			int iIdx = -1;
			int iRes = 0;
			uchar szAuthCode[6 + 1];
			uchar szRRN[13 + 1];

			strcpy(szAuthCode, glProcInfo.stTranLog.szAuthCode);
			strcpy(glProcInfo.stTranLog.szAuthCode, glProcInfo.stTranLog.szOrgAuthCode);
			strcpy(szRRN, glProcInfo.stTranLog.szRRN);
			strcpy(glProcInfo.stTranLog.szRRN, glProcInfo.stTranLog.szOrgRRN);

			iRes = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
			if(0 == iRes && iIdx>=0 && iIdx<MAX_AUTH_TRANLOG)
			{
				if(glTranConfig[glProcInfo.stTranLog.ucOrgTranType].ucTranAct & VOID_ALLOW)
				{
					TRAN_LOG stLog;
					memset(&stLog, 0x00, sizeof(TRAN_LOG));
					iRes = LoadAuthTranLog(&stLog, iIdx);
					if( 0==iRes && ((TS_OK == stLog.uiStatus) || (TS_NOT_UPLOAD == stLog.uiStatus)) )
					{
						stLog.uiStatus = TS_NOSEND;
						UpdateAuthTranLog(&stLog, iIdx);
					}
				}
			}
			strcpy(glProcInfo.stTranLog.szAuthCode, szAuthCode);
			strcpy(glProcInfo.stTranLog.szRRN, szRRN);
		}
		// End add by lirz

		PrintReceipt(PRN_NORMAL);
		DispResult(0);

		return 0;
	}
}

int TransVoidAuthADIB(void)
{

	int			iRet;
	ulong       ulInvoice;
	uchar		ucTranAct, bOnlineFlag, szTempAmt[12+1];
	uchar		szDispBuff[50];
	GUI_TEXT_ATTR stCenter = gl_stCenterAttr;

	iRet = TransInit(VOID_AUTH);
	if( iRet!=0 )
	{
		return iRet;
	}
	/////===============ramzi remmah======================
	   iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);//ADIB OFFLINE NO_SWIPE_INSERT

		if( iRet!=0 )
		{
			return iRet;
		}
	///===============================

	if( !ChkEdcOption(EDC_NOT_VOID_PWD) )
	{
        /*=======BEGIN: Jason 2014.12.20  14:33 modify===========*/
        if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
        {
            uchar   bufPwd[20] = {0};  //Jason 2014.12.20 14:31
            EcrGetPwd(bufPwd);
            if(!( memcmp(bufPwd, glSysParam.sPassword[PWD_VOID], 4)==0 &&
                  strlen((char *)bufPwd)== 4 )&&
               !(memcmp(bufPwd, GetDynamicPassword(), 6)==0 &&
                  strlen((char *)bufPwd)== 6) &&
               !(memcmp(bufPwd, glSysParam.sPassword[PWD_BANK], 6)==0 &&
                  strlen((char *)bufPwd)== 6))
            {
            	MirroringSendEcr("PWD ERROR!");
                Gui_ClearScr();
                PubBeepErr();
                Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PWD ERROR!"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
                return ERR_NO_DISP;
            }
        }
        else
        /*====================== END======================== */
        {
            if( PasswordVoid()!=0 )
            {
                return ERR_NO_DISP;
            }
        }
    }
    ulInvoice = EcrGetTxnID();


//srsrsrsrsr
//    if (!(NULL != strstr(glCurAcq.szName, "NE")))
//    			{
//    		        glSysParam.bNECard = TRUE;
//
//    			}
//    	      else
//    	       {
//    		      glSysParam.bNECard = FALSE;
//
//    	       }
   // glSysParam.bNECard = TRUE;

    if ((glProcInfo.ucEcrCtrl==ECR_BEGIN) && (ulInvoice>0))
    {
        iRet = GetRecordByInvoice(ulInvoice, TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
        if( iRet!=0 )
        {
            return iRet;
		}
		ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;
        if (!(ucTranAct & VOID_ALLOW))
        {
        	MirroringSendEcr("NOT ALLOW VOID");
            Gui_ClearScr();
            PubBeepErr();
            Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ALLOW VOID"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);

            return ERR_NO_DISP;
        }

        FindAcq(glProcInfo.stTranLog.ucAcqKey);
        FindIssuer(glProcInfo.stTranLog.ucIssuerKey);

        glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
        //linzhao
		memcpy(glProcInfo.stTranLog.szOrgRRN, glProcInfo.stTranLog.szRRN, sizeof(glProcInfo.stTranLog.szRRN));
		memcpy(glProcInfo.stTranLog.szOrgAuthCode, glProcInfo.stTranLog.szAuthCode, sizeof(glProcInfo.stTranLog.szAuthCode));

        //for now. linzhao
        if (AUTH==glProcInfo.stTranLog.ucTranType /*&& 0==(glProcInfo.stTranLog.uiStatus&TS_AUTH_SEND)*/)
        {
        	glProcInfo.stTranLog.ucTranType    = VOID_AUTH;
        }
        else
        {
        	glProcInfo.stTranLog.ucTranType    = VOID;
        }
	}
	else
	{
		while( 1 )
		{
			if(glProcInfo.bPreAuthVoid)
			{
				//iRet = GetRecordByRRNandAuthCode(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
				///delete void preauth hala hasan
				iRet = GetRecord(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
			}
			else
			{
				iRet = GetRecord(TS_OK|TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
			}
			if( iRet!=0 )
			{
				return iRet;
			}

			ucTranAct = glTranConfig[glProcInfo.stTranLog.ucTranType].ucTranAct;

			//linzhao
			memcpy( glProcInfo.stTranLog.szOrgRRN,  glProcInfo.stTranLog.szRRN, sizeof(glProcInfo.stTranLog.szRRN));
			memcpy( glProcInfo.stTranLog.szOrgAuthCode, glProcInfo.stTranLog.szAuthCode,  sizeof(glProcInfo.stTranLog.szAuthCode));

			if( ucTranAct & VOID_ALLOW )
			{
				//separate void sale and void auth. linzhao 2015.11.13
				glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
				//for now
				if (AUTH==glProcInfo.stTranLog.ucTranType /*&& 0==(glProcInfo.stTranLog.uiStatus&TS_AUTH_SEND)*/)
				{
					glProcInfo.stTranLog.ucTranType    = VOID_AUTH;
				}
				else
				{
					glProcInfo.stTranLog.ucTranType    = VOID;
				}

				break;
			}

			MirroringSendEcr("NOT ALLOW VOID");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NOT ALLOW VOID"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
		}
	}

	FindAcq(glProcInfo.stTranLog.ucAcqKey);
	FindIssuer(glProcInfo.stTranLog.ucIssuerKey);

	if( ChkIssuerOption(ISSUER_NO_VOID) )
	{
		DispBlockFunc();
		return ERR_NO_DISP;
	}

	if( !ChkSettle() )
	{
		return ERR_NO_DISP;
	}

	if( ChkAcqOption(ACQ_ONLINE_VOID) )
	{
		DispWait();
		PreDial();
	}

	if(glProcInfo.stTranLog.ucDccOption == DCC_TYPE_DCC)
	{
	    PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTempAmt);
	    GetDispDccAmount(szTempAmt, szDispBuff);   // show total amount



	    //foura showing JOD amount
	    ///==================================
	    uchar szTempAmt2[12+1];
	    uchar szTempAmt3[12+1];
	    uchar szTempAmt4[12+1];

	    memset(szTempAmt2,0,sizeof(szTempAmt2));
	    memset(szTempAmt3,0,sizeof(szTempAmt3));
	    memset(szTempAmt4,0,sizeof(szTempAmt4));

	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTempAmt2);
	   	PubAscAdd(szTempAmt2, glProcInfo.stTranLog.szSurFee, 12, szTempAmt3);
	   	GetDispAmount(szTempAmt3, szTempAmt4);	// show total amount

	    strcat(szDispBuff,"\n");
	    strcat(szDispBuff,szTempAmt4);
       //==========================================
	}
	else//add surCharge fee. linzhao 20160113
    {
	    uchar szTempAmt2[12+1];
	    PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTempAmt2);
	    PubAscAdd(szTempAmt2, glProcInfo.stTranLog.szSurFee, 12, szTempAmt);
	    GetDispAmount(szTempAmt, szDispBuff);	// show total amount
    }

//
	//OsLog(LOG_ERROR,"szTempAmt2:%s",szTempAmt);
    //rana foura
  // OsLog(LOG_ERROR,"AMMMSSSSSOUNT%s", szCMDAmount) ;

		if(  glProcInfo.stTranLog.ulInvoiceNo == 0  ){

			MirroringSendEcr("INVALID TRACE");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "INVALID TRACE", stCenter, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);

			return  ERR_NO_DISP;
		}



		   if (MirroringCheckEcr())
			    {



					int retcomp = strcmp(szTempAmt, szCMDAmount);
						if(  (retcomp != 0) && (ulInvoice>0)  ){
							MirroringSendEcr("VOID CANCLED");
			 				Gui_ClearScr();
							 Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, "VOID CANCLED", stCenter, GUI_BUTTON_CANCEL, USER_OPER_TIMEOUT, NULL);

							return ERR_USERCANCEL;
						}

			    }//end mirroring



// fffFOURA( glProcInfo.stTranLog.szPan);

 //srsrsrsrsr
     if ((NULL != strstr(glCurAcq.szName, "NE")))
     			{
     		        glSysParam.bNECard = TRUE;

     			}
     	      else
     	       {
     		      glSysParam.bNECard = FALSE;

     	       }
    //RANA FOURA
	strcat(szDispBuff, "\n");
	strcat(szDispBuff, _T("VOID ?"));

	MirroringSendEcr(szDispBuff);
	Gui_ClearScr();
	if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szDispBuff, stCenter, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
	{
		return ERR_USERCANCEL;
	}

 	bOnlineFlag = TRUE;
  	if( glProcInfo.stTranLog.uiStatus & TS_NOSEND )
 	{	// offsale/sale below/sale comp.../adjust
 		if( glProcInfo.stTranLog.uiStatus & TS_ADJ )
 		{	// 该调整还未上送,作废调整后的金额
 			if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
 			{
				PubAscSub(glProcInfo.stTranLog.stDccInfo.szOrgAmount, glProcInfo.stTranLog.stDccInfo.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.stDccInfo.szTipAmt, "%.12s", szTempAmt);

				PubAscSub(glProcInfo.stTranLog.szOrgAmount, glProcInfo.stTranLog.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%.12s", szTempAmt);
 			}
 			else
 			{
				PubAscSub(glProcInfo.stTranLog.szOrgAmount, glProcInfo.stTranLog.szAmount, 12, szTempAmt);
				//PubAddHeadChars(szTempAmt, 12, '0');		no need: already 12 digits
				sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%.12s", szTempAmt);
 			}
 		}
		if( glProcInfo.stTranLog.szRRN[0]==0 )
		{
			bOnlineFlag = FALSE;
		}
 	}

 	if( !ChkAcqOption(ACQ_ONLINE_VOID) )
	{
		bOnlineFlag = FALSE;
	}

	if( bOnlineFlag )
	{
		SetCommReqField();
		return TranProcess();
	}
	else	// offline void
	{
		glProcInfo.stTranLog.uiStatus |= (TS_VOID|TS_NOSEND);
		if( glProcInfo.stTranLog.szRRN[0]==0 )
		{	// not seen by host(orginal txn is offsale/sale below/salecomp/ ...)
			glProcInfo.stTranLog.uiStatus &= ~(TS_NOSEND);
		}
		GetDateTime(glProcInfo.stTranLog.szDateTime);
		UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);

		// Add by lirz v1.02.0000
		if(COMPLETION == glProcInfo.stTranLog.ucOrgTranType)
		{
			int iIdx = -1;
			int iRes = 0;
			uchar szAuthCode[6 + 1];
			uchar szRRN[13 + 1];

			strcpy(szAuthCode, glProcInfo.stTranLog.szAuthCode);
			strcpy(glProcInfo.stTranLog.szAuthCode, glProcInfo.stTranLog.szOrgAuthCode);
			strcpy(szRRN, glProcInfo.stTranLog.szRRN);
			strcpy(glProcInfo.stTranLog.szRRN, glProcInfo.stTranLog.szOrgRRN);

			iRes = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
			if(0 == iRes && iIdx>=0 && iIdx<MAX_AUTH_TRANLOG)
			{
				if(glTranConfig[glProcInfo.stTranLog.ucOrgTranType].ucTranAct & VOID_ALLOW)
				{
					TRAN_LOG stLog;
					memset(&stLog, 0x00, sizeof(TRAN_LOG));
					iRes = LoadAuthTranLog(&stLog, iIdx);
					if( 0==iRes && ((TS_OK == stLog.uiStatus) || (TS_NOT_UPLOAD == stLog.uiStatus)) )
					{
						stLog.uiStatus = TS_NOSEND;
						UpdateAuthTranLog(&stLog, iIdx);
					}
				}
			}
			strcpy(glProcInfo.stTranLog.szAuthCode, szAuthCode);
			strcpy(glProcInfo.stTranLog.szRRN, szRRN);
		}
		// End add by lirz

		PrintReceipt(PRN_NORMAL);
		DispResult(0);

		return 0;
	}

}


// Modified by Kim_LinHB 2014-7-11
int TransOther(void)
{
	int		iRet, iMenuNo;
	uchar	ucTranType;
	GUI_MENU stTranMenu;

	if (0==glSysParam.stIceTable.iCount)
	{
		GUI_MENUITEM stTranMenuItem[] =
		{
//	#ifdef ENABLE_CONTLESS
//			{ _T_NOOP("CLSS SALE"), 0,TRUE,  NULL},
//	#else
//			{ _T_NOOP("CLSS SALE"), 0,FALSE,  NULL},
//	#endif
//			{ _T_NOOP("VOID    "), 1,TRUE,  NULL},
//			{ _T_NOOP("OFFLINE "), 2,TRUE,  NULL},
//			{ _T_NOOP("REFUND  "), 3,TRUE,  NULL},
//			{ _T_NOOP("ADJUST  "), 4,TRUE,  NULL},
//			{ _T_NOOP("SETTLE  "), 5,TRUE,  NULL},
//			{ "", 6,TRUE,  NULL},	// reserved for auth/preauth
//			{ _T_NOOP("INSTALLMENT"), 7,TRUE,  NULL},
//			{ _T_NOOP("BALANCE"), 8, TRUE, NULL},
//			{ _T_NOOP("COMPLETION"), 9, TRUE, NULL},
//			{ _T_NOOP("VOID PREAUTH"), 10, TRUE, NULL},
//			{ _T_NOOP("EMPlus"), 11, FALSE, NULL},
//			{ "", -1,FALSE,  NULL},

		//=====================================================================
			{ _T_NOOP("PURCHASE"),			19, TRUE, NULL},//NEW ADIB
			{ "", 6, TRUE,  NULL},	// reserved for auth/preauth
			{ _T_NOOP("VOID PURCHASE"), 1,TRUE,  NULL},
			{ _T_NOOP("VOID PREAUTH"), 10, TRUE, NULL},
			{ _T_NOOP("VOID REFUND"), 		27, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("OFFLINE PURCHASE"), 2, TRUE,  NULL},//ADIB
			{ _T_NOOP("OFFLINE REFUND"),	20, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("REFUND "), 3, TRUE,  NULL},
    		{ _T_NOOP("CASH ADVANCE"), 		21, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("SINGLE TIP"), 		22, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("F&B PURCHASE"), 		23, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("TIP COMPLETION"),	24, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("BALANCE INQUIRY"), 8, TRUE, NULL},
			{ _T_NOOP("AUTH COMPLETION"), 9, TRUE, NULL},//ADIB
			{ _T_NOOP("EXPRESS CHECKOUT"),	25, TRUE, NULL},//NEW ADIB
			{ _T_NOOP("MOTO"), 				26, TRUE, NULL},//NEW ADIB
			//=====================================================================
//			{ _T_NOOP("RECONCILIATION"), 5,TRUE,  NULL},
			{ _T_NOOP("AUDIT REPORT"), 12, TRUE, NULL},
			{ _T_NOOP("PRINT TOTAL"), 13, TRUE, NULL},
			{ _T_NOOP("REPRINT DUPLICATE"), 14, TRUE, NULL},
			{ _T_NOOP("REPRINT RECEIPT NO"), 15, TRUE, NULL},
			{ _T_NOOP("PREAUTH REPORT"), 16, TRUE, NULL},
			{ _T_NOOP("AUDIT REPORT DETAILS"), 18, TRUE, NULL},
			//=====================================================================
			#ifdef ENABLE_CONTLESS
						{ _T_NOOP("CLSS SALE"), 0,TRUE,  NULL},
				#else
						{ _T_NOOP("CLSS SALE"), 0,FALSE,  NULL},
				#endif
			//=====================================================================
			{ _T_NOOP("ADJUST  "), 4,FALSE,  NULL},
			{ _T_NOOP("INSTALLMENT"), 7,FALSE,  NULL},
			{ _T_NOOP("EMPlus"), 11, FALSE, NULL},
			{ _T_NOOP("SALES INSTALLMENT"), 17, FALSE, NULL},
			//=====================================================================
			{ "", -1,FALSE,  NULL},
		};
		static	uchar	szPreAuthTitle[] = _T_NOOP("PREAUTH ");
		static	uchar	szAuthTitle[]    = _T_NOOP("PRE AUTH");//AUTH


		if( ChkEdcOption(EDC_AUTH_PREAUTH) )
		{
			ucTranType = AUTH;
			sprintf((char *)stTranMenuItem[1].szText, "%s", szAuthTitle);
		}
		else
		{
			ucTranType = PREAUTH;
			sprintf((char *)stTranMenuItem[1].szText, "%s", szPreAuthTitle);
		}

//		if ((glSysParam.ucPlanNum==0) || !ChkEdcOption(EDC_ENABLE_INSTALMENT)) ///REFUND REMOVE
//		{
//			stTranMenuItem[7].bVisible = FALSE;		// delete installment item.
//		}
	
		uchar szEnableLoyalty[120];
		if(0 ==GetEnv("E_LOY", szEnableLoyalty) && '1' == szEnableLoyalty[0])
			stTranMenuItem[12].bVisible = TRUE;

		int i = 0, iNo = 1;

		for ( i=0; i<(sizeof(stTranMenuItem) / sizeof(stTranMenuItem[0])); i++)
		{
			uchar ucTempBuf[50];
			if(TRUE == stTranMenuItem[i].bVisible)
			{
				strcpy(ucTempBuf, stTranMenuItem[i].szText);
				sprintf(stTranMenuItem[i].szText, "%2d.%s", iNo, ucTempBuf);
				iNo++;
			}
		}
		Gui_BindMenu("CUSTOMER", gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);

		Gui_ClearScr();
		iMenuNo = 0;
		iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_MANUAL_INDEX, USER_OPER_TIMEOUT, &iMenuNo);

	}
	else//todo linzhao
	{
		uchar ucCnt;
		GUI_MENUITEM stTranMenuItem[30];
		uchar szEnableLoyalty[120];

		memset(stTranMenuItem, 0, sizeof(stTranMenuItem));
		memset(&stTranMenu, 0, sizeof(stTranMenu));
		if (ChkEdcOption(EDC_AUTH_PREAUTH))
		{
			ucTranType = AUTH;
		}
		else
		{
			ucTranType = PREAUTH;
		}

		hhhHasan(glSysParam.stIceTable.iCount);
		for (ucCnt=0; ucCnt<glSysParam.stIceTable.iCount; ucCnt++)
		{
//			memcpy(stTranMenuItem[ucCnt].szText, glSysParam.stIceTable.tButton[ucCnt].sLabelLine1,
//				   strlen(glSysParam.stIceTable.tButton[ucCnt].sLabelLine1));
			sprintf(stTranMenuItem[ucCnt].szText, "%d.%s", ucCnt+1, glSysParam.stIceTable.tButton[ucCnt].sLabelLine1);
			stTranMenuItem[ucCnt].nValue = ucCnt;
			if (7==(atoi(glSysParam.stIceTable.tButton[ucCnt].sNodeID)) &&
				   ((glSysParam.ucPlanNum==0) || !ChkEdcOption(EDC_ENABLE_INSTALMENT)))
			{
				stTranMenuItem[ucCnt].bVisible = FALSE;		// delete installment item.
			}
			else if ((0 == GetEnv("E_LOY", szEnableLoyalty)) && ('0' == szEnableLoyalty[0]) &&
					(11 == atoi(glSysParam.stIceTable.tButton[ucCnt].sNodeID)))
			{
				stTranMenuItem[ucCnt].bVisible = FALSE;
			}
			else
			{
				stTranMenuItem[ucCnt].bVisible = TRUE;
			}
			stTranMenuItem[ucCnt].vFunc = NULL;
		}
		stTranMenuItem[ucCnt].nValue = -1;
		stTranMenuItem[ucCnt].bVisible = FALSE;
		stTranMenuItem[ucCnt].vFunc = NULL;

		iRet = Gui_BindMenu("CUSTOMER", gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stTranMenuItem, &stTranMenu);

		Gui_ClearScr();
		iMenuNo = 0;
		iRet = Gui_ShowMenuList(&stTranMenu, GUI_MENU_MANUAL_INDEX, USER_OPER_TIMEOUT, &iMenuNo);
		iMenuNo = atoi(glSysParam.stIceTable.tButton[iMenuNo].sNodeID);
	}

	if(GUI_OK == iRet)
	{
		switch( iMenuNo )
		{
#ifdef ENABLE_CONTLESS
		case 0:
		//koko start
         	//added by Keviuliu 20160719
		    PiccLightOpen();
		    Gui_RegCallback(GUI_CALLBACK_LISTEN_EVENT, ClssVirtualLight);
		//koko end
			iRet = TransClssSale();
     	//koko start
		Gui_RegCallback(GUI_CALLBACK_LISTEN_EVENT, NULL);
		PiccLightClose();
		//koko end	
	
			break;
#endif
		case 1:
			iRet = TransVoid();
			break;

		case 2:
			iRet = TransOffSale();
			break;

		case 3:
			iRet = TransRefund();
			break;

		case 4:
			TransAdjust();
			iRet = 0;
			break;

		case 5:
			iRet = TransSettle();
			break;

		case 6:
			iRet = TransAuth(ucTranType);
			break;

		case 7:
			iRet = InstallmentMenu();
			break;

		case 8:
			iRet = TransBalanceInquiry();
			break;
		case 9:
//			iRet = TransPreAuthCompletion();
			iRet = TransAuthCompletion();
			break;
		case 10:
			iRet = TransVoidPreAuth();
			break;
		case 11:
		    iRet = TransLoyaltyMenu();
		    break;
		case 12:
			PrnAllList();
			iRet = 0;
			break;
		case 13:
			PrnTotal();
			iRet = 0;
			break;
		case 14:
			PrnLastTrans();
			iRet = 0;
			break;
		case 15:
			RePrnSpecTrans();
			iRet = 0;
			break;
		case 16:
		    PrnAllList_PreAuth();
		    iRet = 0;
		    break;
		case 17:
            iRet = TransSale(FALSE);
            break;
		case 18:
			PrnAllList_Details();
			iRet = 0;
            break;

		case 19:
			   iRet = TransSaleType(FALSE,SALE);
            break;
		case 20:
			iRet = TransSaleType(FALSE,OFFLINE_REFUND);
            break;
		case 21:
			iRet =TransSaleType(FALSE,CASH);
            break;
		case 22:
			   iRet = TransSaleType(FALSE,SINGLE_TIP);
            break;
		case 23:
			   iRet = TransSaleType(FALSE,FandB_PURCHASE);
            break;
		case 24:
			iRet = TransSaleType(FALSE,TIP_COMPLETION);
            break;
		case 25:
			iRet = TransSaleType(FALSE,EXPRESS_CHECKOUT);
            break;
		case 26:
			iRet = TransSaleType(FALSE,MOTO);
            break;
		case 27:
			iRet = TransSaleType(FALSE,VOID_REFUND);
            break;

//			{ _T_NOOP("PURCHASE"),			19, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("OFFLINE REFUND"),	20, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("CASH ADVANCE"), 		21, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("SINGLE TIP"), 		22, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("F&B PURCHASE"), 		23, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("TIP COMPLETION"),	24, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("EXPRESS CHECKOUT"),	25, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("MOTO"), 				26, TRUE, NULL},//NEW ADIB
//			{ _T_NOOP("VOID REFUND"), 		27, TRUE, NULL},//NEW ADIB


		default:
			return ERR_NO_DISP;
		}

		CommOnHook(FALSE);
		Gui_ClearScr(); // Added by Kim_LinHB 9/9/2014 v1.01.0007 bug515

		return iRet;
	}
	return ERR_NO_DISP;
}

//
int CompletionInput(void)
{
	int		iRet;
	ulong       ulInvoice;//Jason 2014.12.19 16:29

	SetCurrTitle(_T("COMPLETION"));

	while( 1 )
	{
		//InitTransInfo();
		/*=======BEGIN: Jason 2014.12.19  16:30 modify===========*/
        ulInvoice = EcrGetTxnID();
        if ((ECR_BEGIN == glProcInfo.ucEcrCtrl) && (ulInvoice>0))
        {
            iRet = GetRecordByInvoice(ulInvoice, TS_ALL_LOG, &glProcInfo.stTranLog);
        }
        else
        {
            iRet = GetRecord(TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
        }
        /*====================== END======================== */

		if( iRet!=0 )
		{
			return iRet;
		}

		if( ChkIfZeroAmt(glProcInfo.stTranLog.szAmount) &&
			ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) )
		{
			MirroringSendEcr("DO NOT COMPLETION");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("DO NOT COMPLETION"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
			continue;
		}


		FindAcq(glProcInfo.stTranLog.ucAcqKey);
		FindIssuer(glProcInfo.stTranLog.ucIssuerKey);
//		if( !ChkIssuerOption(ISSUER_EN_ADJUST) )
//		{
//			DispBlockFunc();
//			continue;
//		}
		if( ChkSettle() )
		{
			break;
		}
		return ERR_NO_DISP;
	}

	return 0;
}
// 调整交易输入
// adjust transaction amount
// Modified by Kim_LinHB 2014-7-11
int AdjustInput(void)
{
	int		iRet;
	ulong       ulInvoice;//Jason 2014.12.19 16:29

	SetCurrTitle(_T("ADJUST"));

	while( 1 )
	{
		//InitTransInfo();
		/*=======BEGIN: Jason 2014.12.19  16:30 modify===========*/
        ulInvoice = EcrGetTxnID();
        if ((ECR_BEGIN == glProcInfo.ucEcrCtrl) && (ulInvoice>0))
        {
            iRet = GetRecordByInvoice(ulInvoice, TS_ALL_LOG, &glProcInfo.stTranLog);
        }
        else
        {
//            iRet = GetRecord(TS_NOSEND|TS_ADJ, &glProcInfo.stTranLog);
            iRet = GetRecord(TS_NOSEND, &glProcInfo.stTranLog);
        }
        /*====================== END======================== */

		if( iRet!=0 )
		{
			return iRet;
		}

		if( ChkIfZeroAmt(glProcInfo.stTranLog.szAmount) &&
			ChkIfZeroAmt(glProcInfo.stTranLog.szTipAmount) )
		{
			MirroringSendEcr("DO NOT ADJUST");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("DO NOT ADJUST"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
			continue;
		}

		if( glProcInfo.stTranLog.ucTranType==REFUND && ChkIfAmex() )
		{
			MirroringSendEcr("DO NOT ADJUST");
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("DO NOT ADJUST"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
			continue;
		}

		if (glProcInfo.stTranLog.uiStatus & TS_AUTH_SEND)
		{
			unsigned char szStatus[16 + 1];
			strcpy(szStatus, "INVALID TRACE");
			MirroringSendEcr(szStatus);
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szStatus, gl_stCenterAttr, GUI_BUTTON_NONE, 2, NULL);

			continue;

		}

		FindAcq(glProcInfo.stTranLog.ucAcqKey);
		FindIssuer(glProcInfo.stTranLog.ucIssuerKey);
		if( !ChkIssuerOption(ISSUER_EN_ADJUST) )
		{
			DispBlockFunc();
			continue;
		}
		if( ChkSettle() )
		{
			break;
		}
		return ERR_NO_DISP;
	}

	return 0;
}

static int GetValidAdjustAmount(void)
{
    uchar   iRet;
    char    szCurrName[32], szTemp[12+1];
    uchar   szTotalAmt[LEN_TRAN_AMT+1], szForeignAmt[LEN_TRAN_AMT+1], szTipAmt[LEN_TRAN_AMT+1];

    while (1)
    {
       /*=======BEGIN: Jason 2014.12.19  16:35 modify===========*/
        if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
        {
            memset(szForeignAmt, 0, sizeof(szForeignAmt));
            iRet = PubGetECRAmount(szCurrName, glProcInfo.stTranLog.stTranCurrency.ucDecimal,
                                       1, 8, szTotalAmt, USER_OPER_TIMEOUT, 0);
            if( iRet!=0 )
            {
                return ERR_USERCANCEL;
            }
        }

        else
            /*====================== END======================== */
        {
            GUI_INPUTBOX_ATTR stInputAttr;
            memset(&stInputAttr, 0, sizeof(stInputAttr));

            stInputAttr.eType = GUI_INPUT_AMOUNT;
            stInputAttr.nMinLen = 1;
            stInputAttr.nMaxLen = /*8*/12;
            stInputAttr.bEchoMode = 1;
            //linzhao, 20150922
            if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
            {
            	sprintf(stInputAttr.szPrefix, "%.3s", glProcInfo.stTranLog.stHolderCurrency.szName);
            	stInputAttr.ucDeciPos = glProcInfo.stTranLog.stHolderCurrency.ucDecimal;
            }
            else
            {
            	sprintf(stInputAttr.szPrefix, "%.3s", glSysParam.stEdcInfo.stLocalCurrency.szName);
            	stInputAttr.ucDeciPos = glProcInfo.stTranLog.stTranCurrency.ucDecimal;
            }

            //linzhao 2015.8.18
            if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
            {
            	strcpy(szTotalAmt, glProcInfo.stTranLog.stDccInfo.szAmount);
            	strcpy(szTipAmt, glProcInfo.stTranLog.stDccInfo.szTipAmt);
            }
            else
            {
            	strcpy(szTotalAmt, glProcInfo.stTranLog.szAmount);
            	strcpy(szTipAmt, glProcInfo.stTranLog.szTipAmount);
            }
            Gui_ClearScr();
//            iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("NEW TOTAL"), gl_stLeftAttr,
//                szTotalAmt, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
            iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("TIP"), gl_stLeftAttr,
            						szTipAmt, gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
            if( iRet!=0 )
            {
                return ERR_USERCANCEL;
            }
        }
        if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
        {
        	AmtConvToBit4Format(szTipAmt, glProcInfo.stTranLog.stHolderCurrency.ucIgnoreDigit);
        }
        else
        {
        	AmtConvToBit4Format(szTipAmt, glProcInfo.stTranLog.stTranCurrency.ucIgnoreDigit);
        }
        if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
        {
        	strcpy(glProcInfo.stTranLog.stDccInfo.szTipAmt, szTipAmt);
        	PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTotalAmt);
        	OsLog(LOG_ERROR, "%s--%d, szTotalAmt:%s", __FILE__, __LINE__, szTotalAmt);//linzhao
        }
        else
        {
        	strcpy(glProcInfo.stTranLog.szTipAmount, szTipAmt);
        	PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
        }

        if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
        {
			if( !ValidAdjustAmount(glProcInfo.stTranLog.stDccInfo.szAmount, szTotalAmt) )
			{
				/*=======BEGIN: Jason 2015.01.13  16:31 modify===========*/
				if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
				{
					return ERR_USERCANCEL;
				}
				else
					/*====================== END======================== */
				{
					continue;
				}
			}

        }
        else
        {
			if( !ValidAdjustAmount(glProcInfo.stTranLog.szAmount, szTotalAmt) )
			{
				/*=======BEGIN: Jason 2015.01.13  16:31 modify===========*/
				if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
				{
					return ERR_USERCANCEL;
				}
				else
					/*====================== END======================== */
				{
					continue;
				}
			}
        }
        if (!ValidBigAmount(szTotalAmt))
        {
            /*=======BEGIN: Jason 2015.01.13  16:31 modify===========*/
            if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
            {
                return ERR_USERCANCEL;
            }
            else
                /*====================== END======================== */
            {
                continue;
            }
        }
        

       if( !ConfirmAmount(NULL, szTotalAmt) )
       {
            return ERR_NO_DISP;
       }
       if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
       {
    	   DccAmt2LocalAmt(glProcInfo.stTranLog.stDccInfo.szTipAmt, glProcInfo.stTranLog.szTipAmount);
       }
       if( !(glProcInfo.stTranLog.uiStatus & TS_NOSEND) )
       {
        	if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
        	{
        		PubAscAdd(glProcInfo.stTranLog.stDccInfo.szAmount, glProcInfo.stTranLog.stDccInfo.szTipAmt, 12, szTemp);
        		sprintf((char *)glProcInfo.stTranLog.stDccInfo.szOrgAmount, "%.12s", szTemp);
        		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTemp);
        		sprintf((char *)glProcInfo.stTranLog.szOrgAmount, "%.12s", szTemp);
        	}
        	else
        	{
        		PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTemp);
        		sprintf((char *)glProcInfo.stTranLog.szOrgAmount, "%.12s", szTemp);
        	}
            glProcInfo.stTranLog.uiStatus |= (TS_ADJ|TS_NOSEND);
        }
        // Calculate new tip amount, change the flow, already deal with tips. linzhao 2015.8.18
//        PubAscSub(szTotalAmt, glProcInfo.stTranLog.szAmount, 12, szTemp);
//        sprintf((char *)glProcInfo.stTranLog.szTipAmount, "%.12s", szTemp);
        return 0;
    }
    return 0;
}

// 调整
// adjustment transaction
int TransAdjust( void )
{
	int		iRet;
	uchar	szTotalAmt[12+1], szTemp[12+1];
	uchar	szCurTime[14+1];


	SetCurrTitle(_T("ADJUST"));
	if( !ChkEdcOption(EDC_NOT_ADJUST_PWD) )
	{
		if( PasswordAdjust()!=0 )
		{
			return ERR_NO_DISP;
		}
	}

	if( GetTranLogNum(ACQ_ALL)==0 )
	{
		MirroringSendEcr("EMPTY BATCH");
		Gui_ClearScr();
		PubBeepErr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
		Gui_ClearScr(); 
		return ERR_NO_DISP;
	}


	while( 1 )
	{
		iRet = AdjustInput();
		if( iRet!=0 )
		{
			return iRet;
		}

		while( 2 )
		{
            iRet = GetValidAdjustAmount();
			if( iRet!=GUI_OK )
			{
				return iRet;
			}


			GetDateTime(szCurTime);
			sprintf((char *)glProcInfo.stTranLog.szDateTime, "%.14s", szCurTime);

//			if (DCC_TYPE_DCC==glProcInfo.stTranLog.ucDccOption)
//			{
//				int iRet;
//				iRet = TransDccRate();
//				if (0!=iRet || glProcInfo.stTranLog.ucDccOption == DCC_TYPE_NODCC)
//				{
//					Gui_ClearScr();
//					PubBeepErr();
//					Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("NOT ACCEPTED"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 3, NULL);
//					break;
//				}
//			}
			//linzhao 20151231 modify begin

			if (PREAUTH==glProcInfo.stTranLog.ucTranType )
			{
				int iIdx = -1, iRet;

				glProcInfo.stTranLog.uiStatus &= ~(TS_NOT_COMP);
	            iIdx = -1;
	            iRet = CheckExitsLog(&glProcInfo.stTranLog, &iIdx);
	            if(0 == iRet && -1 != iIdx)
	            {
	                DeleteTranLog(iIdx);
	            }
	            glProcInfo.uiRecNo = iIdx;
	//          UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);
	            OsLog(LOG_ERROR, "%s--%d PREAUTH, iIdx:%d", __FILE__, __LINE__, iIdx);//linzhao

	            iIdx = -1;
	            iRet = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
	            if(0 == iRet && -1 != iIdx)
	            {
	                DeleteAuthTranLog(iIdx);
	                UpdateAuthTranLog(&glProcInfo.stTranLog, iIdx);
	            }

	            SaveTranLog(&glProcInfo.stTranLog);

			}
			else
			{
				UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);
	//			UpdateAuthTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);//linzhao 20151230
			}
			//linzhao 20151231 add end

			//linzhao, 2015.8.18
			PrintReceipt(PRN_NORMAL);	// no receipt for adjust
			glSysCtrl.uiLastRecNo = glProcInfo.uiRecNo;		// use reprint to print adjust
			SaveSysCtrlBase();

			DispAccepted();
			break;	// continue to adjust
		}	// end of while( 2
		break;//hala hasan adjust
	}	// end of while( 1
	return RET_OK;
}

// Echo test
int TransEchoTest(void)
{
	int		iRet;
	uchar	ucAcqIndex, szTitle[16+1];

	TransInit(ECHO_TEST);

	sprintf((char *)szTitle, "%s", glSysParam.ucAcqNum>8 ? "SELECT ACQ:" : "SELECT ACQUIRER");
	iRet = SelectAcq(FALSE, szTitle, &ucAcqIndex);
	//judge NE TEST, Hasan FOURA



	if (NULL != strstr(glCurAcq.szName, "NE"))
			{
		        glSysParam.bNECard = TRUE;
			}
	      else
	       {
		      glSysParam.bNECard = FALSE;
	       }


//	if(glSysParam.ucAcqNum )//frfrfrfrf
//		{
//			glSysParam.bNECard = TRUE;
//
//		}
//		else
//		{
//			glSysParam.bNECard = FALSE;
//		}
//
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}

	SetCommReqField();
	iRet = SendRecvPacket();
	DispResult(iRet);
	return 0;
}

// 结算
// settlement
int TransSettle(void)
{
	int		iRet;
	uchar	ucAcqIndex, szTitle[16+1];
	uchar	ucForceSettle;

	TransInit(SETTLEMENT);

	sprintf((char *)szTitle, "%s", glSysParam.ucAcqNum>8 ? "SELECT ACQ:" : "SELECT ACQUIRER");
	ucAcqIndex = MAX_ACQ;
	glProcInfo.bPrnAllAcq = TRUE;


	//linzhao
//	iRet = SelectAcq(TRUE, szTitle, &ucAcqIndex);
//	if( iRet!=0 )
//	{
//		return ERR_NO_DISP;
//	}

	DispProcess();
	//linzhao 20151008
	ucAcqIndex = MAX_ACQ;
	if( ucAcqIndex==MAX_ACQ )
	{
		CalcTotal(ACQ_ALL);
	}
//	else
//	{
//		CalcTotal(glCurAcq.ucKey);
//	}

	iRet = DispTransTotal(TRUE);
	if( iRet!=0 )
	{
		return ERR_NO_DISP;
	}

	ucForceSettle = FALSE;
	if( ChkIfZeroTotal(&glTransTotal) )
	{
		unsigned char szBuff[100];
//		sprintf(szBuff, "%s\n%s", (char *)_T("EMPTY BATCH"), (char *)_T("SETTLE ANYWAY ?"));
		sprintf(szBuff, "%s\n", (char *)_T("EMPTY BATCH"));
		MirroringSendEcr(szBuff);
		Gui_ClearScr();
		if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
		{
			return ERR_NO_DISP;
		}
//		ucForceSettle = TRUE;
	}

	//linzhao 20151230
	// Add by lirz v1.01.0007
	if(glSysCtrl.authCtrl.ucEnableTabBatch)
	{
		if(GetAuthTranLogNum(ACQ_ALL))
		{
			MirroringSendEcr("CLEAR TAB BATCH ?");
			if(GUI_OK == Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CLEAR TAB BATCH ?"), gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
			{
				iRet = ClearTabBatch();
				if(0 != iRet)
				{
					MirroringSendEcr("CLEAR FAIL, CONTINUE ?");
					if(GUI_OK != Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("CLEAR FAIL, CONTINUE ?"), gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL))
					{
						return ERR_USERCANCEL;
					}
				}
			}
		}
	}
	// End add by lirz
	OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);//linzhao
	
    if (glProcInfo.ucEcrCtrl != ECR_BEGIN)  //Jason 2014.12.19 16:52
    {
        if( !ChkEdcOption(EDC_NOT_SETTLE_PWD) )
        {
            if( PasswordSettle()!=0 )
            {
                return ERR_NO_DISP;
            }
        }
    }
	if( ucAcqIndex!=MAX_ACQ )
	{
		return TransSettleSub();
	}



	OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);//linzhao
	for(ucAcqIndex=0; ucAcqIndex<glSysParam.ucAcqNum; ucAcqIndex++)
	{
		SetCurAcq(ucAcqIndex);
		memcpy(&glTransTotal, &glAcqTotal[ucAcqIndex], sizeof(TOTAL_INFO));


		///fffFOURA(glCurAcq.szName);
		 //srsrsrsrsr
		     if ((NULL != strstr(glCurAcq.szName, "NE")))
		     			{
		     		        glSysParam.bNECard = TRUE;

		     			}
		     	      else
		     	       {
		     		      glSysParam.bNECard = FALSE;

		     	       }


		if (ChkIfZeroTotal(&glTransTotal) && !ucForceSettle)
		{
			continue;
		}

		iRet = TransSettleSub();
		if( iRet!=0 )
		{
			if( iRet!=ERR_NO_DISP )
			{
				return iRet;
			}
		}
		// last error ?
	}

	OsLog(LOG_ERROR, "%s--%d", __FILE__, __LINE__);//linzhao
	Gui_ClearScr(); // add by lrz v1.02.0000

	return 0;
}

// 结算当前收单行(glCurAcq)
// Settle current acquirer.
int TransSettleSub(void)
{
#ifdef ENABLE_EMV
	int		iLength;
#endif
	int		iRet, bFirstSettle;
	uchar	szBuff[200];

	// don't need to check zero total. it has been check outside.

	TransInit(SETTLEMENT);

	sprintf((char*)glProcInfo.szSettleMsg, "CLOSED");
	if( glCurAcq.ucPhoneTimeOut<150 )	// ???? How about Tcp
	{	// 结算时，timeout加长
		// increase the timeout when settle
		glCurAcq.ucPhoneTimeOut += glCurAcq.ucPhoneTimeOut/2;
	}
	else
	{
		glCurAcq.ucPhoneTimeOut = 250;
	}

	iRet = TranReversal();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = OfflineSend(OFFSEND_TC | OFFSEND_TRAN);
	if( iRet!=0 )
	{
		return iRet;
	}

	//linzhao 2015.1026
	iRet = TransAuthComplete();
	if( iRet!=0 )
	{
		return iRet;
	}


	bFirstSettle = TRUE;
	while( 1 )
	{
		TransInit(SETTLEMENT);

		SetCurrTitle(glCurAcq.szName);
		SetCommReqField();
		sprintf((char *)glSendPack.szProcCode, "%s", bFirstSettle ? "920000" : "960000");
		if( ChkIfAmex() )
		{
			memcpy((char *)glSendPack.sField62, "\x00\x06", 2);
			sprintf((char *)glSendPack.sField62+2, "%06lu", glSysCtrl.ulInvoiceNo);
		}
		//PubAddHeadChars(glTransTotal.szSaleAmt,   12, '0');  no need: already 12 digits
		//PubAddHeadChars(glTransTotal.szRefundAmt, 12, '0');  no need: already 12 digits
		sprintf((char *)&glSendPack.sField63[2], "%03d%12.12s%03d%12.12s",
						glTransTotal.uiSaleCnt,   glTransTotal.szSaleAmt,
						glTransTotal.uiRefundCnt, glTransTotal.szRefundAmt);
		memset(&glSendPack.sField63[30+2], '0', 60); //should be 30+2
		PubLong2Char(90L, 2, glSendPack.sField63);

#ifdef ENABLE_EMV
		//linzhao, delete it
//		if( bFirstSettle && !ChkIfAmex() && ChkIfEmvEnable() && ChkIfAcqNeedDE56() )
//		{
//			// 送F56
//			// send Field56
//			iLength = glSysCtrl.stField56[glCurAcq.ucIndex].uiLength;
//			if( iLength>0 )
//			{
//				memcpy(&glSendPack.sICCData2[2], glSysCtrl.stField56[glCurAcq.ucIndex].sData, iLength);
//			}
//			else
//			{
//				SetStdEmptyDE56(&glSendPack.sICCData2[2], &iLength);
//			}
//			PubLong2Char((ulong)iLength, 2, glSendPack.sICCData2);
//		}
#endif

		if( ChkIfAmex() )
		{
			// when AMEX settlement, bit63 len = 36 byte
			PubLong2Char(36L, 2, glSendPack.sField63);
			glSendPack.sField63[2+36] = 0;
		}
		sprintf((char *)glSendPack.szField60, "%06lu", glCurAcq.ulCurBatchNo);

		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			return iRet;
		}
		if( !bFirstSettle )
		{
			if( memcmp(glRecvPack.szRspCode, "95", 2)==0 )
			{
				memcpy(glRecvPack.szRspCode, "77", 2);
			}
			break;
		}

		if( memcmp(glRecvPack.szRspCode, "95", 2)!=0 )
		{
			break;
		}
		if( glSysCtrl.stField56[glCurAcq.ucIndex].uiLength>0 )
		{
			glSysCtrl.stField56[glCurAcq.ucIndex].uiLength = 0;	// erase bit 56
			SaveField56();
		}

		// display error information
		DispResult(ERR_HOST_REJ);

		sprintf((char*)glProcInfo.szSettleMsg, "CLOSED(95)");
		iRet = TransUpLoad();


		if( iRet!=0 )
		{
			return iRet;
		}
		bFirstSettle = FALSE;
	}
	if( memcmp(glRecvPack.szRspCode, "77", 2)==0 )
	{
		sprintf((char*)glProcInfo.szSettleMsg, "CLOSED(77 RECONCILE ERROR)");
	}

	if( memcmp(glRecvPack.szRspCode, "00", 2)==0 ||
		(!ChkIfAmex() && memcmp(glRecvPack.szRspCode, "77", 2)==0) )
	{
		glSysCtrl.sAcqStatus[glCurAcq.ucIndex] = S_CLR_LOG;
		SaveSysCtrlBase();
		CommOnHook(FALSE);
		ClearRecord(glCurAcq.ucKey);
		GetNewInvoiceNo();

		DispPrinting();
		iRet = PrintSettle(PRN_NORMAL);
		if( iRet!=0 )
		{
			// Modified by Kim_LinHB 2014-7-11
			MirroringSendEcr("PLEASE REPRINT");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("PLEASE REPRINT"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			iRet = ERR_NO_DISP;
		}

		// Modified by Kim_LinHB 2014-7-11
		if( memcmp(glRecvPack.szRspCode, "77", 2)==0 )
		{
			strcpy(szBuff, _T("RECONCILE ERROR"));
		}
		else if( glTransTotal.uiSaleCnt==0 && glTransTotal.uiRefundCnt==0 )
		{
			strcpy(szBuff, _T("NO TXN TOTAL"));
		}
		else
		{
			sprintf((char *)szBuff, "BATCH %06ld\nCompleted Successfully", glCurAcq.ulCurBatchNo);
		}
		MirroringSendEcr(szBuff);
		Gui_ClearScr();
		PubBeepOk();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_OK, 5, NULL);
		Gui_ClearScr();
		return iRet;
	}

	Gui_ClearScr();
	return 0;
}

// 批上送
// batch upload
// Modified by Kim_LinHB 2014-7-11
int TransUpLoad(void)
{
	int			iRet;
	ushort		uiIndex, uiTranNum, uiCnt;
	uchar		szTotalAmt[12+1], szTitle[20];
	TRAN_LOG	stLog;

	TransInit(UPLOAD);

	uiTranNum = GetTranLogNum(glCurAcq.ucKey);
	for(uiCnt=uiIndex=0; uiIndex<MAX_TRANLOG; uiIndex++)
	{
		if( glSysCtrl.sAcqKeyList[uiIndex]!=glCurAcq.ucKey )
		{
			continue;
		}
		uiCnt++;
		
		sprintf(szTitle, "%03u/%03u", uiCnt, uiTranNum);
		SetCurrTitle(szTitle);
	
		memset(&stLog, 0, sizeof(TRAN_LOG));
		iRet = LoadTranLog(&stLog, uiIndex);
		if( iRet!=0 )
		{
			return iRet;
		}
		if( (stLog.ucTranType==PREAUTH) && (stLog.uiStatus & TS_NOT_COMP) )
		{
			OsLog(LOG_ERROR, "%s--%d, uiStatus:%x, fuck", __FILE__, __LINE__, stLog.uiStatus);//linzhao
			continue;
		}
		if( (stLog.uiStatus & TS_VOID) && !ChkIfAmex() )
		{	// AMEX 需要upload void，其它acquirer不用
			continue;
		}

		SetCommReqField();
		sprintf((char *)glSendPack.szPan, "%.19s", stLog.szPan);
		sprintf((char *)glSendPack.szProcCode, "%.*s", LEN_PROC_CODE,
				glTranConfig[stLog.ucTranType].szProcCode);//000000Processing foura
		glSendPack.szProcCode[LEN_PROC_CODE-1] = '1';

		//sprintf((char *)glSendPack.szProcCode, "%.*s", LEN_PROC_CODE,"000000");//000000Processing foura 96 95



		if (ChkIfAmex())
		{
			glSendPack.szProcCode[1] = '0';
			glSendPack.szProcCode[2] = '4';
		}

		if (ChkIfAmex() && (stLog.uiStatus & TS_VOID))
		{
			sprintf(glSendPack.szTranAmt, "%012lu", 0L);
			glSendPack.szExtAmount[0] = 0;
		}
		else
		{
			PubAscAdd(stLog.szAmount, stLog.szTipAmount, 12, szTotalAmt);
			//PubAddHeadChars(szTotalAmt, 12, '0');  no need: already 12 digits
			sprintf((char *)glSendPack.szTranAmt, "%.12s", szTotalAmt);
			if( !ChkIfZeroAmt(stLog.szTipAmount) )
			{
				sprintf((char *)glSendPack.szExtAmount, "%.12s", stLog.szTipAmount);
			}
		}

		sprintf((char *)glSendPack.szLocalTime, "%.6s", &stLog.szDateTime[8]);
		sprintf((char *)glSendPack.szLocalDate, "%.4s", &stLog.szDateTime[4]);
		sprintf((char *)glSendPack.szExpDate,   "%.4s", stLog.szExpDate);	// [1/11/2007 Tommy]
		SetEntryMode(&stLog);
		sprintf((char *)glSendPack.szCondCode, "%.2s",  stLog.szCondCode);
		sprintf((char *)glSendPack.szRRN,      "%.12s", stLog.szRRN);
		sprintf((char *)glSendPack.szAuthCode, "%.6s",  stLog.szAuthCode);

		if( !ChkIfAmex() )
		{
			sprintf((char *)glSendPack.szRspCode, "%.2s", stLog.szRspCode);
			if( stLog.uiEntryMode & MODE_CHIP_INPUT )
			{   //DE 55 for upload foura
				PubLong2Char((ulong)stLog.uiIccDataLen, 2, glSendPack.sICCData);
				memcpy(&glSendPack.sICCData[2], stLog.sIccData, stLog.uiIccDataLen);
			}
		}

		memcpy(glSendPack.sField62, "\x00\x06", 2);
		sprintf((char *)&glSendPack.sField62[2], "%06ld", stLog.ulInvoiceNo);
		memcpy(glSendPack.szField60, glTranConfig[stLog.ucTranType].szTxMsgID, 4);
		if( stLog.uiStatus & TS_OFFLINE_SEND )
		{
			memcpy(glSendPack.szField60, "0220", 4);
			if( ChkAcqOption(ACQ_DBS_FEATURE) )
			{
				if( stLog.ucTranType!=OFF_SALE && stLog.ucTranType==SALE_COMP &&
					!(stLog.uiStatus & TS_FLOOR_LIMIT) )
				{
					memcpy(glSendPack.szField60, "0200", 4);
				}
			}
		}
		else if( stLog.uiStatus & TS_VOID )
		{
			memcpy(glSendPack.szField60, "0200", 4);
		}
		sprintf((char *)&glSendPack.szField60[4], "%06ld%12s", stLog.ulSTAN, "");

		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			return iRet;
		}
		DispResult(0);
	}

	return 0;
}

int TransAuthComplete(void)
{
	int			iRet;
	ushort		uiIndex, uiTranNum;
	uchar		szTotalAmt[12+1], szTitle[20];
	TRAN_LOG	stLog;
	SYS_PROC_INFO	stProcInfoBak;

	memcpy(&glProcInfo.stSendPack, &glSendPack, sizeof(STISO8583));
	memcpy(&stProcInfoBak, &glProcInfo,  sizeof(SYS_PROC_INFO));


	uiTranNum = GetTranLogNum(glCurAcq.ucKey);
	for(uiIndex=0; uiIndex<MAX_TRANLOG; uiIndex++)
	{
		if( glSysCtrl.sAcqKeyList[uiIndex]!=glCurAcq.ucKey )
		{
			continue;
		}
//		uiCnt++;
//
//		sprintf(szTitle, "%03u/%03u", uiCnt, uiTranNum);
//		SetCurrTitle(szTitle);

		memset(&stLog, 0, sizeof(TRAN_LOG));
		iRet = LoadTranLog(&stLog, uiIndex);
		if( iRet!=0 )
		{
			return iRet;
		}
		if( stLog.ucTranType!=AUTH || (stLog.uiStatus & TS_NOT_UPLOAD) )
		{
			continue;
		}
		if( (stLog.uiStatus & TS_VOID) && !ChkIfAmex() )
		{	// AMEX 需要upload void，其它acquirer不用
			continue;
		}
		if (stLog.uiStatus & TS_OFFLINE_SEND || stLog.uiStatus & TS_AUTH_SEND )
		{
			continue;
		}

		glProcInfo.uiRecNo = uiIndex;

		//linzhao 20151021
		memcpy(&glProcInfo.stTranLog, &stLog, sizeof(TRAN_LOG));
		glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
		glProcInfo.stTranLog.ucTranType = AUTH_COMPLETE;
		SetCommReqField();
		sprintf((char *)glSendPack.szPan, "%.19s", stLog.szPan);
		sprintf((char *)glSendPack.szProcCode, "%.*s", LEN_PROC_CODE,
				glTranConfig[stLog.ucTranType].szProcCode);
		//linzhao 20151020
//		glSendPack.szProcCode[LEN_PROC_CODE-1] = '1';
		if (ChkIfAmex())
		{
			glSendPack.szProcCode[1] = '0';
			glSendPack.szProcCode[2] = '4';
		}

		if (ChkIfAmex() && (stLog.uiStatus & TS_VOID))
		{
			sprintf(glSendPack.szTranAmt, "%012lu", 0L);
			glSendPack.szExtAmount[0] = 0;
		}
		else
		{
			PubAscAdd(stLog.szAmount, stLog.szTipAmount, 12, szTotalAmt);
			//PubAddHeadChars(szTotalAmt, 12, '0');  no need: already 12 digits
			sprintf((char *)glSendPack.szTranAmt, "%.12s", szTotalAmt);
			//linzhao 20151020
//			if( !ChkIfZeroAmt(stLog.szTipAmount) )
//			{
//				sprintf((char *)glSendPack.szExtAmount, "%.12s", stLog.szTipAmount);
//			}
		}

		sprintf((char *)glSendPack.szLocalTime, "%.6s", &stLog.szDateTime[8]);
		sprintf((char *)glSendPack.szLocalDate, "%.4s", &stLog.szDateTime[4]);
		sprintf((char *)glSendPack.szExpDate,   "%.4s", stLog.szExpDate);	// [1/11/2007 Tommy]
		SetEntryMode(&stLog);
		sprintf((char *)glSendPack.szCondCode, "%.2s",  stLog.szCondCode);
		sprintf((char *)glSendPack.szRRN,      "%.12s", stLog.szRRN);
		sprintf((char *)glSendPack.szAuthCode, "%.6s",  stLog.szAuthCode);

		if( !ChkIfAmex() )
		{
			//linzhao 20151020
//			sprintf((char *)glSendPack.szRspCode, "%.2s", stLog.szRspCode);
//			if( stLog.uiEntryMode & MODE_CHIP_INPUT )
//			{
//				PubLong2Char((ulong)stLog.uiIccDataLen, 2, glSendPack.sICCData);
//				memcpy(&glSendPack.sICCData[2], stLog.sIccData, stLog.uiIccDataLen);
//			}
		}

		//linzhao 20151021
//		memcpy(glSendPack.sField62, "\x00\x06", 2);
//		sprintf((char *)&glSendPack.sField62[2], "%06ld", stLog.ulInvoiceNo);

//		memcpy(glSendPack.szField60, glTranConfig[stLog.ucTranType].szTxMsgID, 4);
//		if( stLog.uiStatus & TS_OFFLINE_SEND )
//		{
//			memcpy(glSendPack.szField60, "0220", 4);
//			if( ChkAcqOption(ACQ_DBS_FEATURE) )
//			{
//				if( stLog.ucTranType!=OFF_SALE && stLog.ucTranType==SALE_COMP &&
//					!(stLog.uiStatus & TS_FLOOR_LIMIT) )
//				{
//					memcpy(glSendPack.szField60, "0200", 4);
//				}
//			}
//		}
//		else if( stLog.uiStatus & TS_VOID )
//		{
//			memcpy(glSendPack.szField60, "0200", 4);
//		}
//		sprintf((char *)&glSendPack.szField60[4], "%06ld%12s", stLog.ulSTAN, "");

		SetCurrTitle((char *)_T("SETTLEMENT"));
		iRet = SendRecvPacket();
		if( iRet!=0 )
		{
			return iRet;
		}

		glProcInfo.stTranLog.uiStatus |= TS_AUTH_SEND;

		// Modified by Kim_LinHB 2014-8-8 v1.01.0002 bug506
		//glProcInfo.stTranLog.ucTranType = glProcInfo.stTranLog.ucOrgTranType;
		TransInit(stLog.ucTranType);
		UpdateTranLog(&glProcInfo.stTranLog, glProcInfo.uiRecNo);


//		DispResult(0);
	}

	memcpy(&glProcInfo, &stProcInfoBak, sizeof(SYS_PROC_INFO));
	memcpy(&glSendPack, &glProcInfo.stSendPack, sizeof(STISO8583));

	return 0;
}

int TransLoyaltyMenu(void)
{
    int     iRet, iMenuNo;
    GUI_MENU stLoyaltyMenu;
    GUI_MENUITEM stLoyaltyMenuItem[] =
    {
        { _T_NOOP("CARDHOLDER INQUIRY"), 1, TRUE, NULL},
        { _T_NOOP("GIFT COLLECTION"), 2, TRUE, NULL},
        { _T_NOOP("PTS REDEEM"), 3, TRUE, NULL},
        { "", -1,FALSE,  NULL},
    };

    Gui_BindMenu(_T("LOYALTY"), gl_stTitleAttr, gl_stLeftAttr, (GUI_MENUITEM *)stLoyaltyMenuItem, &stLoyaltyMenu);

    Gui_ClearScr();
    iMenuNo = 0;
    iRet = Gui_ShowMenuList(&stLoyaltyMenu, GUI_MENU_DIRECT_RETURN, USER_OPER_TIMEOUT, &iMenuNo);
    if(GUI_OK == iRet)
    {
        switch( iMenuNo )
        {
        case 1:
            iRet = TransLoyaltyInquiry();
            break;
        case 2:
        	iRet = TransGiftCollection();
        	break;
        case 3:
        	iRet = TransRedeem();
        	break;
        default:
            return ERR_NO_DISP;
        }

        CommOnHook(FALSE);
        Gui_ClearScr(); // Added by Kim_LinHB 9/9/2014 v1.01.0007 bug515

        return iRet;
    }
    return ERR_NO_DISP;
}

//int SelectCoupon(char *pField63)
//{
//	int iCouponCnt, iCnt;
//	uchar sCouponDescription[6][40 + 1] ;
//	GUI_PAGE		stHexMsgPage;
//	GUI_PAGELINE	stBuff[10];
//	uchar			ucLines = 0;
//	uchar sCouponNumber[6][3];
//	int iRet;
//
//	iCouponCnt = PubBcd2Long(pField63, 1);
//	pField63 += 1;
//
//	memset(&sCouponNumber, 0, sizeof(sCouponNumber));
//	memset(&sCouponDescription, 0, sizeof(sCouponDescription));
//	memset(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber, 0,
//		   sizeof(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber));
//	memset(glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription, 0,
//		   sizeof (glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription));
//	for (iCnt=0; iCnt<iCouponCnt; iCnt++)
//	{
//		memcpy(&sCouponNumber[iCnt], pField63, 3);
//		pField63 += 3;
//		memcpy(&sCouponDescription[iCnt], pField63, 40);
//		pField63 += 40;
//	}
//
//	iCnt = 0;
//	while (1)
//	{
//		if (iCnt<0)
//		{
//			Gui_ClearScr();
//			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("START OF COUPON"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
//			iCnt = 0;
//		}
//		else if (iCnt>iCouponCnt)
//		{
//			Gui_ClearScr();
//			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("END OF COUPON"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
//			iCnt = iCouponCnt;
//		}
//		ucLines = 0;
//		sprintf(stBuff[ucLines].szLine, "COUPON NUMBER:%x%x%x",
//				sCouponNumber[iCnt][0], sCouponNumber[iCnt][1], sCouponNumber[iCnt][2]);
//		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;
//
//		//todo, 要分行
//		sprintf(stBuff[ucLines].szLine, "%s", sCouponDescription[iCnt]);
//		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;
//
//		strcpy(stBuff[ucLines].szLine, _T("PRESS ENTER TO REEDEEM"));
//		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;
//
//		Gui_CreateInfoPage(_T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), gl_stTitleAttr, stBuff, ucLines, &stHexMsgPage);
//		Gui_ClearScr();
//
//		iRet = Gui_ShowInfoPage(&stHexMsgPage, iCouponCnt > 1 ? TRUE : FALSE, USER_OPER_TIMEOUT);
//		if (GUI_OK==iRet || GUI_ERR_USERCANCELLED==iRet || GUI_ERR_TIMEOUT==iRet)
//		{
//			break;
//		}
//		else if (GUI_OK_NEXT==iRet)
//		{
//			iCnt++;
//		}
//		else if (GUI_OK_PREVIOUS==iRet)
//		{
//			iCnt--;
//		}
//
//	}
//	if (GUI_OK==iRet)
//	{
//		glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber[0] = 1;
//		memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber + 1, sCouponNumber[iCnt], 3);
//		//todo  可能需要改
//		strcpy(glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription, sCouponDescription);
//	}
//
//	return 0;
//}


int TransRedeem(void)
{
	int iRet;
	GUI_INPUTBOX_ATTR stInputAttr;

	iRet = TransInit(REDEEM_INQUIRY);
	if(0!=iRet)
	{
		return iRet;
	}

	iRet = GetCard(SKIP_DETECT_ICC|CARD_INSERTED);
	if( iRet!=0 )
	{
		return iRet;
	}

    SetCommReqField();
    iRet = TranProcess();
    if (0!=iRet)
    {
        return iRet;
    }

    if(0 == strcmp(glProcInfo.stTranLog.szRspCode, "00"))
    {
        uchar sAV[12];

        memset(glProcInfo.stTranLog.stLoyaltyInfo.szAV, 0, sizeof(glProcInfo.stTranLog.stLoyaltyInfo.szAV));
        if(Field63Parser(glRecvPack.sField63, "AV", sAV) > 0)
        {
            glProcInfo.stTranLog.stLoyaltyInfo.szAV[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szAV+1, sAV, 6);
        }
        else
        {
        	glProcInfo.stTranLog.stLoyaltyInfo.szAV[0] = 0;
        }
    }


    int iSelOpt = 0;
	uchar szAVInfo[128], szBuff[128], szTotalAmt[12+1], szAvailAmt[12+1], szAmtTmp[24];
	uchar szAvailAmtInput[12+1];

	PubAscAdd(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szTipAmount, 12, szTotalAmt);
	App_ConvAmountTran(szTotalAmt, szAmtTmp, 0);
	sprintf(szAVInfo, "SALE AMONUT: %s\n ", szAmtTmp);
	PubBcd2Asc0(glProcInfo.stTranLog.stLoyaltyInfo.szAV+1, 6, szBuff);
	App_ConvAmountTran(szBuff, szAvailAmt, 0);
	strcat(szAVInfo, "AVAILABEL: ");
	strcat(szAVInfo, szAvailAmt);

	Gui_ClearScr();
    iRet = Gui_ShowAlternative(GetCurrTitle(), gl_stTitleAttr, szAVInfo, gl_stCenterAttr,
        "PARTIAL", 1, "FULL", 0, USER_OPER_TIMEOUT, &iSelOpt);
    if (GUI_OK != iRet)
    {
        return iRet;
    }

    if(iSelOpt)
    {
    	memset(&stInputAttr, 0, sizeof(stInputAttr));
    	stInputAttr.eType = GUI_INPUT_AMOUNT;
    	stInputAttr.bEchoMode = 1;

    	stInputAttr.ucDeciPos = glProcInfo.stTranLog.stTranCurrency.ucDecimal;
    	sprintf(stInputAttr.szPrefix, "%.3s", glSysParam.stEdcInfo.stLocalCurrency.szName);
    // 	sprintf((char *)szCurrName, "%.3s%1.1s", glSysParam.stEdcInfo.szCurrencyName, &glSysParam.stEdcInfo.ucCurrencySymbol);
    	stInputAttr.nMinLen = 1;
    	stInputAttr.nMaxLen = MIN(glSysParam.stEdcInfo.ucTranAmtLen, 10);
    	while (1)
    	{
			Gui_ClearScr();
			iRet = Gui_ShowInputBox(GetCurrTitle(), gl_stTitleAttr, szAVInfo, gl_stLeftAttr, szAvailAmtInput,
				gl_stRightAttr, &stInputAttr, USER_OPER_TIMEOUT);
			if (GUI_OK != iRet)
			{
				return iRet;
			}
			if (strcmp(szAvailAmtInput, szAvailAmt) < 0 )
			{
				break;
			}
			else
			{
				MirroringSendEcr("Exceeded Available Balance");
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("Exceeded Available Balance"), gl_stLeftAttr,
						       GUI_BUTTON_NONE, 3, NULL);
			}
    	}
    	Gui_ClearScr();

    	uchar szCalResult[12+1], szAmtTmp2[12+1];

    	PubAscSub(szTotalAmt, szAvailAmtInput, 12, szCalResult);
    	App_ConvAmountTran(szAvailAmtInput, szAmtTmp, 0);
    	App_ConvAmountTran(szCalResult, szAmtTmp2, 0);
    	sprintf(szBuff, "REDEEM AMT: %s\n AMT TO BE AUTHORIZED:\n%s", szAmtTmp, szAmtTmp2);
    	MirroringSendEcr(szBuff);
    	iRet = Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_YandN, USER_OPER_TIMEOUT, NULL);
    	if (GUI_OK==iRet)
    	{
    		PubAscSub(szCalResult, glProcInfo.stTranLog.szTipAmount, 12, glProcInfo.stTranLog.szAmount);
    		PubAsc2Bcd(szCalResult, 12, glProcInfo.stTranLog.stLoyaltyInfo.szAV+1);
    	}
    }
    else
    {
    	strcpy(szAvailAmt, szTotalAmt);
    	PubAsc2Bcd(szTotalAmt, 12, glProcInfo.stTranLog.stLoyaltyInfo.szAV+1);
    }

	iRet = TransInit(REDEEM_POINT);
	if(0!=iRet)
	{
		return iRet;
	}

    SetCommReqField();
    iRet = TranProcess();
    if (0!=iRet)
    {
        return iRet;
    }

 	iRet = TransInit(SALE);
	if(0!=iRet)
	{
		return iRet;
	}

    SetCommReqField();
    iRet = TranProcess();
    if (0!=iRet)
    {
        return iRet;
    }




    return iRet;

}

int TransRedeemCoupon(void)
{
	int iRet;

	uchar ucOldTran = glProcInfo.stTranLog.ucTranType;

	iRet = TransInit(COUPON);
	if(0!=iRet)
	{
		TransInit(ucOldTran);
		return iRet;
	}
    SetCommReqField();
    iRet = TranProcess();
    if (0!=iRet)
    {
        TransInit(ucOldTran);
        return iRet;
    }

    if(0 == strcmp(glProcInfo.stTranLog.szRspCode, "00"))
    {
        uchar sTI[12];
        if(Field63Parser(glRecvPack.sField63, "TI", sTI) > 0)
        {
            SaveLoyaltyTxnId(sTI);
            glProcInfo.stTranLog.ucLoyaltyOption = LOY_TYPE_YES;
            glProcInfo.stTranLog.stLoyaltyInfo.szTI[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szTI+1,sTI, 12);
        }
    }

    if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
    {
        uchar sTemp[300];
        if(Field63Parser(glRecvPack.sField63, "DI", sTemp) > 0)
        {
            glProcInfo.stTranLog.stLoyaltyInfo.sDiscountAmt[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sDiscountAmt+1, sTemp, 6);
            glProcInfo.stTranLog.stLoyaltyInfo.sActualAmt[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sActualAmt+1, sTemp+6, 6);
        }

        if(Field63Parser(glRecvPack.sField63, "RP", glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints[0] = 1;
        if(Field63Parser(glRecvPack.sField63, "UP", glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints[0] = 1;
        if(Field63Parser(glRecvPack.sField63, "PT", glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0] = 1;

        if(Field63Parser(glRecvPack.sField63, "PB", sTemp) > 0)
        {
            glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints+1, sTemp, 5);
            glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount+1, sTemp+5, 6);
        }

        if (Field63Parser(glRecvPack.sField63, "CO", sTemp) > 0)
        {
        	int iValueLen = PubBcd2Long(sTemp, 2);
        	memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer, sTemp+2, iValueLen);
        	glProcInfo.stTranLog.stLoyaltyInfo.szCurrentOffer[iValueLen] = 0;
        }
    }

    TransInit(ucOldTran);
    return iRet;

}
int TransSaleInquiryAuto(void)
{
    int iRet;
    uchar ucOldTran = glProcInfo.stTranLog.ucTranType;
    iRet = TransInit(SALE_INQUIRY);
    if( iRet!=0 )
    {
        TransInit(ucOldTran);
        return iRet;
    }

    glProcInfo.stTranLog.ucLoyaltyOption = LOY_TYPE_NO;

    SetCommReqField();
    iRet = TranProcess();
    if(iRet != 0)
    {
        TransInit(ucOldTran);
        return iRet;
    }

    if(0 == strcmp(glProcInfo.stTranLog.szRspCode, "00"))
    {
        uchar sTI[12];
        if(Field63Parser(glRecvPack.sField63, "TI", sTI) > 0)
        {
            SaveLoyaltyTxnId(sTI);
            glProcInfo.stTranLog.ucLoyaltyOption = LOY_TYPE_YES;
            glProcInfo.stTranLog.stLoyaltyInfo.szTI[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szTI+1,sTI, 12);
        }
    }

    if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
    {
        uchar sTemp[300];
        if(Field63Parser(glRecvPack.sField63, "DI", sTemp) > 0)
        {
            glProcInfo.stTranLog.stLoyaltyInfo.sDiscountAmt[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sDiscountAmt+1, sTemp, 6);
            glProcInfo.stTranLog.stLoyaltyInfo.sActualAmt[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sActualAmt+1, sTemp+6, 6);
        }
        else if(Field63Parser(glRecvPack.sField63, "CL", sTemp) > 0)
        {
            //TODO ui of coupon
        	SelectCouponOrGift(sTemp, COUPON);
        }

        if(Field63Parser(glRecvPack.sField63, "RP", glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.sRewardedPoints[0] = 1;
        if(Field63Parser(glRecvPack.sField63, "UP", glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.sUnderProcessingPoints[0] = 1;
        if(Field63Parser(glRecvPack.sField63, "PT", glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0] = 1;

        if(Field63Parser(glRecvPack.sField63, "PB", sTemp) > 0)
        {
            glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sAvailablePoints+1, sTemp, 5);
            glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sEquivalentAmount+1, sTemp+5, 6);
        }
    }

    //coupon sent, linzhao
    if (1==glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber[0])
    {
    	TransRedeemCoupon();
    }

    TransInit(ucOldTran);
    return iRet;
}

int SelectCouponOrGift(uchar *pField63, uchar ucTranType)
{
	int iCouponCnt, iCnt;
	uchar sCouponDescription[6][40 + 1] ;
	GUI_PAGE		stHexMsgPage;
	GUI_PAGELINE	stBuff[10];
	uchar			ucLines = 0;
	uchar sCouponNumber[6][3];
	int iRet;

	iCouponCnt = PubBcd2Long(pField63, 1);
	pField63 += 1;

	memset(&sCouponNumber, 0, sizeof(sCouponNumber));
	memset(&sCouponDescription, 0, sizeof(sCouponDescription));
	if (COUPON==ucTranType)
	{
		memset(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber, 0,
			   sizeof(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber));
		memset(glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription, 0,
			   sizeof (glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription));
	}
	else if (GIFT_INQUIRY==ucTranType)
	{
		memset(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber, 0,
			   sizeof(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber));
		memset(glProcInfo.stTranLog.stLoyaltyInfo.szGiftDescription, 0,
			   sizeof (glProcInfo.stTranLog.stLoyaltyInfo.szGiftDescription));

	}

	for (iCnt=0; iCnt<iCouponCnt; iCnt++)
	{
		memcpy(&sCouponNumber[iCnt], pField63, 3);
		pField63 += 3;
		memcpy(&sCouponDescription[iCnt], pField63, 40);
		pField63 += 40;
	}

	iCnt = 0;
	while (1)
	{
		if (iCnt<0)
		{
			MirroringSendEcr("START OF COUPON");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("START OF COUPON"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
			iCnt = 0;
		}
		else if (iCnt>iCouponCnt)
		{
			MirroringSendEcr("END OF COUPON");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("END OF COUPON"), gl_stCenterAttr, GUI_BUTTON_NONE, 1, NULL);
			iCnt = iCouponCnt;
		}
		ucLines = 0;
		if (COUPON==ucTranType)
		{
			sprintf(stBuff[ucLines].szLine, "COUPON NUMBER:%x%x%x",
				sCouponNumber[iCnt][0], sCouponNumber[iCnt][1], sCouponNumber[iCnt][2]);
		}
		else if (GIFT_INQUIRY==ucTranType)
		{
			sprintf(stBuff[ucLines].szLine, "GIFT NUMBER:%x%x%x",
				sCouponNumber[iCnt][0], sCouponNumber[iCnt][1], sCouponNumber[iCnt][2]);
		}
		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

		//todo, 要分行
		sprintf(stBuff[ucLines].szLine, "%s", sCouponDescription[iCnt]);
		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

		strcpy(stBuff[ucLines].szLine, _T("PRESS ENTER TO REEDEEM"));
		stBuff[ucLines++].stLineAttr = gl_stLeftAttr;

		Gui_CreateInfoPage(_T(glTranConfig[glProcInfo.stTranLog.ucTranType].szLabel), gl_stTitleAttr, stBuff, ucLines, &stHexMsgPage);
		Gui_ClearScr();

		iRet = Gui_ShowInfoPage(&stHexMsgPage, iCouponCnt > 1 ? TRUE : FALSE, USER_OPER_TIMEOUT);
		if (GUI_OK==iRet || GUI_ERR_USERCANCELLED==iRet || GUI_ERR_TIMEOUT==iRet)
		{
			break;
		}
		else if (GUI_OK_NEXT==iRet)
		{
			iCnt++;
		}
		else if (GUI_OK_PREVIOUS==iRet)
		{
			iCnt--;
		}

	}
	if (GUI_ERR_USERCANCELLED==iRet)
	{
		if (COUPON==ucTranType)
		{
			memset(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber, 0, sizeof(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber));
			glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber[0] = 1;
		}
		else if (GIFT_INQUIRY==ucTranType)
		{
			memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber, 0, sizeof(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber));
			glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber[0] = 1;
		}

	}
	else if (GUI_OK==iRet)
	{
		if (COUPON==ucTranType)
		{
			glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber[0] = 1;
			memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sCouponNumber + 1, sCouponNumber[iCnt], 3);
			//todo  可能需要改
			strcpy(glProcInfo.stTranLog.stLoyaltyInfo.szCouponDescription, sCouponDescription);
		}
		else if (GIFT_INQUIRY==ucTranType)
		{
			glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber[0] = 1;
			memcpy(glProcInfo.stTranLog.stLoyaltyInfo.sGiftNumber + 1, sCouponNumber[iCnt], 3);
			//todo  可能需要改
			strcpy(glProcInfo.stTranLog.stLoyaltyInfo.szGiftDescription, sCouponDescription);

		}
	}

	return 0;
}

int TransGiftInquiry(void)
{
	int iRet;
	uchar ucOldTranType = glProcInfo.stTranLog.ucTranType;
	uchar sTemp[300];

	iRet = TransInit(GIFT_INQUIRY);
	if (0!=iRet)
	{
		TransInit(ucOldTranType);
		return iRet;
	}

    SetCommReqField();
    iRet = TranProcess();
    if(iRet != 0)
    {
        TransInit(ucOldTranType);
        return iRet;
    }

	if(Field63Parser(glRecvPack.sField63, "GL", sTemp) > 0)
	{
		//TODO ui of gift
		SelectCouponOrGift(sTemp, GIFT_INQUIRY);
	}


	TransInit(ucOldTranType);
	return iRet;
}

int TransGiftCollection(void)
{
    int iRet;
    uchar ucOldTran = glProcInfo.stTranLog.ucTranType;
    iRet = TransInit(GIFT_REDEEM);
    if( iRet!=0 )
    {
        return iRet;
    }
    iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
    if( iRet!=0 )
    {
        return iRet;
    }

    iRet = TransGiftInquiry();
    if (0!=iRet)
    {
    	return iRet;
    }

    SetCommReqField();
    iRet = TranProcess();
    if(0 == strcmp(glProcInfo.stTranLog.szRspCode, "00"))
    {
        uchar sTI[12];
        if(Field63Parser(glRecvPack.sField63, "TI", sTI) > 0)
        {
            SaveLoyaltyTxnId(sTI);
            glProcInfo.stTranLog.ucLoyaltyOption = LOY_TYPE_YES;
            glProcInfo.stTranLog.stLoyaltyInfo.szTI[0] = 1;
            memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szTI+1,sTI, 12);
        }
    }

    if(LOY_TYPE_YES == glProcInfo.stTranLog.ucLoyaltyOption)
    {
        uchar sTemp[300];

        if(Field63Parser(glRecvPack.sField63, "PT", glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText+1) > 0)
            glProcInfo.stTranLog.stLoyaltyInfo.szPromotionalText[0] = 1;

        if(Field63Parser(glRecvPack.sField63, "RG", sTemp) > 0)
        {
        	ulong ulLenght = PubBcd2Long(sTemp, 2);
        	glProcInfo.stTranLog.stLoyaltyInfo.szRedeemedGift[0] = 1;
        	memcpy(glProcInfo.stTranLog.stLoyaltyInfo.szRedeemedGift+1, sTemp+2, ulLenght);
        	glProcInfo.stTranLog.stLoyaltyInfo.szRedeemedGift[1+ulLenght] = 0;
        }
    }

    TransInit(ucOldTran);

    return iRet;

}

int TransLoyaltyInquiry(void)
{
    int iRet;

    iRet = TransInit(LOYALTY_INQUIRY);
    if( iRet!=0 )
    {
        return iRet;
    }
    iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
    if( iRet!=0 )
    {
        return iRet;
    }

    memset(glProcInfo.stTranLog.szAmount,    '0', 12);
    SetCommReqField();
    iRet = TranProcess();

    return iRet;
}

int TransBalanceInquiry(void)
{
	int iRet;

	iRet = TransInit(BALANCE);
	if( iRet!=0 )
	{
		return iRet;
	}
	iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
	if( iRet!=0 )
	{
		return iRet;
	}

	memset(glProcInfo.stTranLog.szAmount,    '0', 12);
	SetCommReqField();
	iRet = TranProcess();

	return iRet;
}

int TransAuthCompletion(void)
{
		int		iRet;
		uchar	szTotalAmt[12+1], szTemp[12+1];
		uchar	szCurTime[14+1];


		SetCurrTitle(_T("COMLETION"));
		if( !ChkEdcOption(EDC_NOT_ADJUST_PWD) )
		{
			//todo
			if( PasswordAdjust()!=0 )
			{
				return ERR_NO_DISP;
			}
		}

//		if( GetTranLogNum(ACQ_ALL)==0 )
//		{
//			Gui_ClearScr();
//			PubBeepErr();
//			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("EMPTY BATCH"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
//			Gui_ClearScr();
//			return ERR_NO_DISP;
//		}


		iRet = CompletionInput();
		if( iRet!=0 )
		{
			return iRet;
		}

		if (0==(glProcInfo.stTranLog.uiStatus & TS_NOT_COMP))
		{
			unsigned char szStatus[16 + 1];
			strcpy(szStatus, "INVALID TRACE");
			MirroringSendEcr(szStatus);
			Gui_ClearScr();
			PubBeepErr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szStatus, gl_stCenterAttr, GUI_BUTTON_NONE, 2, NULL);

			return 0;

		}
		OsLog(LOG_ERROR, "%s--%d, ucTrantype:%d, uiStatus:%x, ",
				__FILE__, __LINE__, glProcInfo.stTranLog.ucTranType, glProcInfo.stTranLog.uiStatus);//linzhao

		glProcInfo.stTranLog.ucOrgTranType = glProcInfo.stTranLog.ucTranType;
		glProcInfo.stTranLog.ucTranType = AUTH_COMPLETE;
		TransInit(glProcInfo.stTranLog.ucTranType);
		glProcInfo.uiRecType = glProcInfo.stTranLog.ucOrgTranType;

		//no display
		if(!ConfirmAmount((char *)_T("ORG. AMOUNT\n"), glProcInfo.stTranLog.szAmount))
		{
			return ERR_USERCANCEL;
		}

		memcpy(glProcInfo.stTranLog.szOrgAmount, glProcInfo.stTranLog.szAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
		memcpy(glProcInfo.stTranLog.szOrgTipAmount, glProcInfo.stTranLog.szTipAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
		memcpy(glProcInfo.stTranLog.stDccInfo.szOrgAmount, glProcInfo.stTranLog.stDccInfo.szAmount, sizeof(glProcInfo.stTranLog.stDccInfo.szOrgAmount));
		//fffFOURA(glProcInfo.stTranLog.szRRN);
		//fffFOURA(glProcInfo.stTranLog.szAuthCode);
		//linzhao 20151231
		memcpy(glProcInfo.stTranLog.szOrgRRN, glProcInfo.stTranLog.szRRN, sizeof(glProcInfo.stTranLog.szRRN));
		memcpy(glProcInfo.stTranLog.szOrgAuthCode, glProcInfo.stTranLog.szAuthCode, sizeof(glProcInfo.stTranLog.szAuthCode));
		memset(glProcInfo.stTranLog.szAmount, 0, sizeof(glProcInfo.stTranLog.szAmount));



		iRet = GetAmount();
		if( iRet!=0 )
		{
			return iRet;
		}

		//todo
		if(strcmp(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szInitialAmount) > 0 && glSysCtrl.authCtrl.iCompPercent != 0)
		{
			uchar szExceed[12 + 1], szPercent[12 + 1], szAllow2Exceed[12 + 1];

			int iPercVar = glSysCtrl.authCtrl.iCompPercent;
			PubAscSub(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szInitialAmount, 12, szExceed);
			sprintf(szPercent, "%012d", iPercVar);
			PubAscMul(glProcInfo.stTranLog.szInitialAmount, szPercent, szAllow2Exceed);
			szAllow2Exceed[strlen(szAllow2Exceed) - 2] = 0;
			PubAddHeadChars(szAllow2Exceed, 12, '0');

			if(strcmp(szExceed, szAllow2Exceed) > 0)
			{
				MirroringSendEcr("AMOUNT EXCEED");
				Gui_ClearScr();
				Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, (char *)_T("AMOUNT EXCEED"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
				return ERR_AMT_EXCEED;
			}
		}


		SetCommReqField();
		sprintf((char *)glSendPack.szRRN,       "%.12s", glProcInfo.stTranLog.szRRN);       // fuck
		sprintf((char *)glSendPack.szAuthCode,  "%.6s",  glProcInfo.stTranLog.szAuthCode);	// fuck
		sprintf((char *)glSendPack.szRspCode,  "%.6s",  glProcInfo.stTranLog.szRspCode);	// fuck
		return TranProcess();

}


int TransPreAuthCompletion(void)
{
	int iRet, iIdx;

	glProcInfo.stTranLog.ucTranType = COMPLETION;
	TransInit(glProcInfo.stTranLog.ucTranType);
	iRet = GetCard(CARD_INSERTED|CARD_SWIPED|CARD_KEYIN);
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetRRN();
	if( iRet!=0 )
	{
		return iRet;
	}

	iRet = GetPreAuthCode();
	if( iRet!=0 )
	{
		return iRet;
	}

	iIdx = -1;
	iRet = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
	if(0 != iRet)
	{
		MirroringSendEcr("NO RECORD");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO RECORD"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
		return ERR_NO_DISP;
	}

	if(-1 == iIdx)
	{
		MirroringSendEcr("NO RECORD");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO RECORD"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
		return ERR_NO_DISP;
	}

	memset(&glProcInfo.stTranLog, 0x00, sizeof(TRAN_LOG));
	iRet = LoadAuthTranLog(&glProcInfo.stTranLog, iIdx);
	if(0 != iRet)
	{
		return iRet;
	}

	if(TS_NOSEND != glProcInfo.stTranLog.uiStatus)
	{
		MirroringSendEcr("NO RECORD");
		Gui_ClearScr();
		Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("NO RECORD"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
		return ERR_NO_DISP;
	}

	glProcInfo.stTranLog.ucTranType = COMPLETION;
	TransInit(glProcInfo.stTranLog.ucTranType);
	glProcInfo.stTranLog.ucDccOption = DCC_TYPE_NODCC;
	glProcInfo.uiRecNo   = iIdx;
	glProcInfo.uiRecType = PREAUTH;

	if(!ConfirmAmount(_T("ORG. AMOUNT\n"), glProcInfo.stTranLog.szAmount))
	{
		return ERR_USERCANCEL;
	}

	memcpy(glProcInfo.stTranLog.szInitialAmount, glProcInfo.stTranLog.szAmount, sizeof(glProcInfo.stTranLog.szInitialAmount));
	memset(glProcInfo.stTranLog.szAmount, 0, sizeof(glProcInfo.stTranLog.szAmount));
	iRet = GetAmount();
	if( iRet!=0 )
	{
		return iRet;
	}

	// check if amount exceed or not
	if(strcmp(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szInitialAmount) > 0 && glSysCtrl.authCtrl.iCompPercent != 0)
	{
		uchar szExceed[12 + 1], szPercent[12 + 1], szAllow2Exceed[12 + 1];

		int iPercVar = glSysCtrl.authCtrl.iCompPercent;
		PubAscSub(glProcInfo.stTranLog.szAmount, glProcInfo.stTranLog.szInitialAmount, 12, szExceed);
		sprintf(szPercent, "%012d", iPercVar);
		PubAscMul(glProcInfo.stTranLog.szInitialAmount, szPercent, szAllow2Exceed);
		szAllow2Exceed[strlen(szAllow2Exceed) - 2] = 0;
		PubAddHeadChars(szAllow2Exceed, 12, '0');

		if(strcmp(szExceed, szAllow2Exceed) > 0)
		{
			MirroringSendEcr("AMOUNT EXCEED");
			Gui_ClearScr();
			Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, _T("AMOUNT EXCEED"), gl_stCenterAttr, GUI_BUTTON_OK, 3, NULL);
			return ERR_AMT_EXCEED;
		}
	}

	iRet = GetPIN(FALSE);
	if( iRet!=0 )
	{
		return iRet;
	}

	glProcInfo.stTranLog.uiStatus = TS_NOT_UPLOAD;
	strcpy((char *)glProcInfo.stTranLog.szOrgAuthCode, (char *)glProcInfo.stTranLog.szAuthCode);
	strcpy((char *)glProcInfo.stTranLog.szOrgRRN, (char *)glProcInfo.stTranLog.szRRN);
	iRet = UpdateAuthTranLog(&glProcInfo.stTranLog, iIdx);
	if( iRet!=0 )
	{
		return iRet;
	}

	iIdx = -1;
	iRet = CheckExitsLog(&glProcInfo.stTranLog, &iIdx);
	if(0 == iRet && -1 != iIdx)
	{
		DeleteTranLog(iIdx);
	}

	return FinishOffLine();
}

int TransVoidPreAuth()
{
	int iIdx ;
	int iRet;
	glProcInfo.bPreAuthVoid = TRUE;
	//iRet = TransVoid();



	iRet = TransVoidAuthADIB();
	glProcInfo.bPreAuthVoid = FALSE;

					///delete void preauth hala hasan
                    iIdx = -1;
                    iRet = CheckExitsAuthLog(&glProcInfo.stTranLog, &iIdx);
                    if(0 == iRet && -1 != iIdx)
                    {
                        DeleteAuthTranLog(iIdx);
                        UpdateAuthTranLog(&glProcInfo.stTranLog, iIdx);
                    }
                    // SaveTranLog(&glProcInfo.stTranLog);;

	return iRet;
}


int DccAmt2LocalAmt(uchar *szDccAmt, uchar *szLocalAmt)
{
	ulong uDccAmt ;
	double uExRate, uLocalAmt;
	uchar szResult[12+1],szResult2[12+1], szDccExRate[9+1], szDccExRate2[9+1], *pDotLoc;
	int iDem, iResult;

	uDccAmt = atoi(szDccAmt);
	strcpy(szDccExRate, glProcInfo.stTranLog.stDccInfo.szDccExRate + 1);
	iDem = glProcInfo.stTranLog.stDccInfo.szDccExRate[0];
	sprintf(szDccExRate2, "%c.%s", szDccExRate[0], szDccExRate+1);
	uExRate = atof(szDccExRate2);
	uLocalAmt = (double)uDccAmt / uExRate;
	if (2 == glProcInfo.stTranLog.stHolderCurrency.ucDecimal)
	{
		uLocalAmt *= 10;
	}
	else if (3 == glProcInfo.stTranLog.stHolderCurrency.ucDecimal)
	{
		uLocalAmt *= 100;
	}
	sprintf(szResult, "%f", uLocalAmt);
	pDotLoc = strchr(szResult, '.');
	*pDotLoc = '\0';
	iResult = atoi(szResult);
	sprintf(szResult2,"%.12d", iResult);


	strcpy(szLocalAmt, szResult2);



}

// end of file

