
#ifndef _EMVTEST_H
#define _EMVTEST_H

void InitTestKeys(void);
void InitTestApps(void);
void InitLiveKeys(void);
void InitLiveApps(void);

unsigned long g_ulAmexFloorLimit;

#endif
