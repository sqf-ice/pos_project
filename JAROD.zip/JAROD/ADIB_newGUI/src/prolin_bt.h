#ifndef __PROLIN_BT_H__
#define __PROLIN_BT_H__

#define ERR_BT_NONE             0       /* success */
#define ERR_BT_NOT_PAIR         -3451   /* BT has not paired */
#define ERR_BT_MODE_ERR         -3452   /* mode error */
#define ERR_BT_STATE_FAIL       -3453   /* acquiring state filed */
#define ERR_BT_SCAN_FAIL        -3454   /* scanning failed */
#define ERR_BT_SCAN_DOING       -3455   /* BT is scanning */
#define BT_CONN_REJ_SAFE        -3456   /* verification is rejected */
#define BT_CONN_KEY_MISS        -3457   /* remote device passowrd lost */
#define BT_CONN_CHANNEL_EXIST   -3458   /* channel already existed */
#define BT_CONN_SDC_FAILED      -3459   /* device can not be connected */
#define BT_CONN_NO_RESPONE      -3460   /* no response from remote device */
#define ERR_BT_PAIR_AUTH        -3461   /* verification failed */
#define ERR_BT_PAIR_TIMEOUT     -3462   /* paring timeout */
#define ERR_BT_PAIR_DOING       -3463   /* device has been paired already */
#define ERR_BT_INVALID_MODE     -3464   /* BT mode not set */

typedef enum {
	BT_MODE_STD,        /* bluetooth standard mode */
	BT_MODE_BLE,        /* bluetooth low energy mode */
} BT_MODE;

/* BT state */
typedef enum {
	BT_STATE_CLOSED,        /* bluetooth is close */
	BT_STATE_OPENED,        /* bluetooth is open */
	BT_STATE_CONNTING,      /* bluetooth is connecting to another device */
	BT_STATE_CONNECT_OK,    /* bluetooth's connecting is successful */
} BT_STATE;

/* BT action  */
typedef enum {
	BT_ACTION_NONE,             /* action none */
	BT_ACTION_DISPLAY_ONLY,     /* how password only */
	BT_ACTION_DISPLAY_YESNO,    /* confirm password, no input */
	BT_ACTION_DISPLAY_PASSKEY,  /* show password only */
	BT_ACTION_INPUT_PASSKEY,    /* input password only */
} BT_ACTION;

/* verification methods of BT device */
typedef enum {
	BT_PAIR_AUTH_DISPLAY_ONLY,  /* display only */
	BT_PAIR_AUTH_DISPLAY_YESNO, /* display yes/no to confirm */
	BT_PAIR_AUTH_PASSKEY,       /* input password */
	BT_PAIR_AUTH_NONE,          /* none */
} BT_PAIR_AUTH;

/* struct of scanning BT device. */
typedef struct {
	char Name[64];          /* bluetooth device name */
	char Mac[32];           /* bluetooth device mac address */
} ST_BT_SCAN_RESULT;

/* BT devices paring information struct  */
typedef struct {
	char Mac[32];       /* mac address */
	char LinkKey[64];   /* link key */
} ST_BT_PAIRED;

typedef int  (*PAIR_FUNC)(BT_ACTION Action, char *Mac, char *Key);
typedef void (*DISCONN_FUNC)(void);
typedef void (*PAIR_RESULT_FUNC)(char *Mac, int Result);
typedef void (*CONN_RESULT_FUNC)(int Result);
typedef void (*SCAN_RESULT_FUNC)(ST_BT_SCAN_RESULT Scan[], int Count);

int OsBluetoothSetMode(BT_MODE Mode);
int OsBluetoothGetMode(BT_MODE* pMode);
int OsBluetoothOpen(const char *BtName, int Visible);
int OsBluetoothSetCallback(PAIR_FUNC pOnPair,
			DISCONN_FUNC pOnDisConn,
			PAIR_RESULT_FUNC pPairRet, CONN_RESULT_FUNC pConnRet);
void OsBluetoothClose(void);
int OsBluetoothStartScan(SCAN_RESULT_FUNC pOnScan);
int OsBluetoothCheck(void);
int OsBluetoothSetPairAuth(BT_PAIR_AUTH Auth, int Mitm, char *LegacyPin);
int OsBluetoothStartPair(const char *Mac);
int OsBluetoothGetPairedList(ST_BT_PAIRED Result[], int ResultCount);
int OsBluetoothRemovePaired(const char *Mac);
int OsBluetoothStartSPPConnect(const char *Mac);
int OsBluetoothSPPDisconnect(void);
int OsBluetoothGetSPPDevice(char *OutSppDev, int OutSppDevSize);

#endif /* __PROLIN_BT_H__ */
