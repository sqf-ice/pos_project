
#include "global.h"

/********************** Internal macros declaration ************************/
#define TIMER_TEMPORARY		4
#define TIMERCNT_MAX		48000

/********************** Internal structure declaration *********************/
/********************** Internal functions declaration *********************/
static int   main_sub(const ST_EVENT_MSG *pstEventMsg);
static int   CheckTermSatus(const ST_EVENT_MSG *pstEventMsg);
static void  FirstRunProc(const ST_EVENT_MSG *pstEventMsg);
static void  SetIdleTimer(void);
static uchar ChkIdleTimer(int iSeconds);
static void  ShowIdleMainUI(uchar *pbForceUpdate, uchar bShowGallery, int iGallery_Image_Num);
static void  ShowGallery();
static int   CheckInitTerminal(void);
static void  MainIdleProc(void);
/********************** Internal variables declaration *********************/
#ifdef _PROLIN2_4_
int Refresh_UpDown(gui_callbacktype_t type, void *data, int *len);
#endif

/********************** external reference declaration *********************/
extern int event_main(ST_EVENT_MSG *pstEventMsg);

const APPINFO AppInfo =
{
	APP_NAME,
	EDCAPP_AID,
	EDC_VER_INTERN _TERMTYPE_,
	"PAX TECHNOLOGY",
	"EDC TEMPLATE FOR VISA/MC PROJECTS",
	"",
	0xFF,
	0xFF,
	0x01,
	""
};

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/


int event_main(ST_EVENT_MSG *pstEventMsg)
{
	glEdcMsgPtr = pstEventMsg;	// save the event pointer 
	return main_sub(pstEventMsg);
}

int main(void)
{



    int iRet22;

    ST_TIME sBuffTime  ;
    unsigned char date_str22[100] = {0};

	uchar			bUpdateUI, bGallery = FALSE;
	int				iRet;
	int				iRet32;
	uchar            chTemp[20];
    uchar   ecr_port_opened;
	ST_EVENT_MSG	stEventMsg;
	int iGallery_Image_Num = 0;
	uchar szGallery_Image_Num[5]= {0};
	uchar szlight[5]= {0};
//#ifdef APP_DEBUG
 	ST_KEY_INFO     stTmp_Key;
 	ST_KCV_INFO		stTmp_Kcv;
//#endif
 	CountKBD = 0;
#if defined(_PROLIN2_4_)
	OsLogSetTag(APP_NAME);
    OsRegGetValue("ro.fac.mach", gl_szTerminalType);
#endif
    ecr_port_opened     = FALSE;

    // Application initialization
	memset(&stEventMsg, 0, sizeof(stEventMsg));
	stEventMsg.MsgType = USER_MSG;
	iRet = event_main(&stEventMsg);
	if (iRet == ERR_EXIT_APP)
	{
//	    CommOnHook(TRUE);
		return 0;
	}

	//==============================================================
	//OsPedEraseKeys();
	//injectManual();


	readSNTRM();
	//==============================================================

	//temp
//#ifdef APP_DEBUG



//#endif

	clssSale = FALSE ;
	//////////////////////////////////////////////////////////////////////////
	   ECR_AUTOSETTELMENT =FALSE ;
	   EMP_AUTOSETTELMENT =FALSE ;

    // Main loop
	bUpdateUI = TRUE;


	//==============================================================
	memset(szGallery_Image_Num,0,sizeof(szGallery_Image_Num));
	DelayMs(200);
	for (iRet32=0;iRet32<=25;iRet32++)
	{

				if(0 == GetEnv("PIC_NO", szGallery_Image_Num))
				{

					iGallery_Image_Num = atoi(szGallery_Image_Num);
					break;
				}
				else
				{
					iGallery_Image_Num = 0;

				}

	}
	DelayMs(200);
	// iGallery_Image_Num =2 ;
	//==============================================================

	//==============================================================
	   //ight hansdle  03.11.2016
	   int intlight ;
	   //int intlight =  OsRegSetValue("persist.sys.backlighttime",  "0"); //always light
		memset(szlight,0,sizeof(szlight));
		DelayMs(200);
		for (iRet32=0;iRet32<=25;iRet32++)
		{

					if(0 == GetEnv("M_LIGHT", szlight))
					{

						intlight =  OsRegSetValue("persist.sys.backlighttime",  szlight);


						break;
					}
					else
					{

						intlight =  OsRegSetValue("persist.sys.backlighttime",  szlight);

					}

		}
		DelayMs(200);
		//==============================================================




	//fffFOURA(szGallery_Image_Num);
	//added by Kevin for auto connect
	if((glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag != CONNECT_OK))
	{
		Gui_ClearScr();
		Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECTING", gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);
		iRet = BTPrn_AutoConnect();
		OsLog(LOG_INFO, "iRet=%d", iRet);
		if(iRet == 0)
		{
			Gui_ClearScr();
			Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT OK", gl_stCenterAttr, GUI_BUTTON_OK, 3,NULL);
		}
		else
		{
			Gui_ClearScr();
			Gui_ShowMsgBox("Blue Tooth", gl_stTitleAttr, "BTPRN CONNECT FAIL", gl_stCenterAttr, GUI_BUTTON_OK, -1,NULL);
		}
		Gui_ClearScr();
//		OsTimerSet(&Timer, 30*1000);	//for check bluetooth connection
	}




setTimeAutoSettlement();

	while( 1 )
	{
		clssSale = FALSE ;


	    if (MirroringCheckEcr())
	    {
	       // OsScrBrightness(8);
	      //int intlight =  OsRegSetValue("persist.sys.backlighttime",  "0");
	    	//kbflush();
	       // ECR_MODE = FALSE ;

	        OsGetTime(&sBuffTime);


	    	    if (( (sBuffTime.Hour>=4) && (sBuffTime.Hour <5) ) && 	(ECR_AUTOSETTELMENT == FALSE  ))
	    	 	    {
	    	    	ECR_AUTOSETTELMENT = TRUE ;
	    	 	   }



	    	    if (( (sBuffTime.Hour>=5) && (sBuffTime.Hour <6) ) && 	(ECR_AUTOSETTELMENT == TRUE  ))
	    	    {
	    	    	ECR_AUTOSETTELMENT = FALSE ;
	    	    	iRet22 = TransSettle();

	    	    }


	    }
	    else ///Auto settelment for other
	    {

//	    	int iHO =g_iHH[0] -1;
//
//	    	if ( !(iHO >=0 && iHO<=23) )
//	    	{
//	    		iHO = 0 ;
//	    	}



	    	OsGetTime(&sBuffTime);
	    	uchar blTest;

	    	blTest = getRuleSettelment(g_iHH[0],sBuffTime.Hour);



	    	  if (( blTest == TRUE ) && 	(EMP_AUTOSETTELMENT == FALSE  ))
	    		    	 	    {

	    		                     EMP_AUTOSETTELMENT = TRUE ;
	    		    	 	   }

	       // EMP_AUTOSETTELMENT_COUNTER;
//
 	    	setAutoSettlements();
//
	    }
//	    else if (CheckCarrfour()){
//	    	  // int intlight =  OsRegSetValue("persist.sys.backlighttime",  "0");
//	    }






//	    else
//	    {
//	    	 ECR_MODE = TRUE ;
//	    }

		// Setup idle timer
		if (bUpdateUI)
		{
			SetIdleTimer();
		}

		ShowIdleMainUI(&bUpdateUI, bGallery, iGallery_Image_Num);	// bUpdateUI value may change

		if (glSysParam.stECR.ucMode)
		{
			if (!ecr_port_opened)
            {
                EcrOpen();  // Open port for ECR
                ecr_port_opened = TRUE;
            }

            //event
            if (ProcEcrEvent()==0)
            {
                bUpdateUI = TRUE;
                bGallery = FALSE;
                continue;
            }
		}


if (! MirroringCheckEcr())
	    {
        // When magstripe card swiped
		if( MagSwiped()==0 )
		{
			if((glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_NO))
			{
				BTPrn_ReconnectOp();
				bUpdateUI = TRUE;
			}
			memset(&stEventMsg, 0, sizeof(ST_EVENT_MSG));
			stEventMsg.MsgType = MAGCARD_MSG;
			stEventMsg.MagMsg.RetCode = MagRead(stEventMsg.MagMsg.track1,
												stEventMsg.MagMsg.track2,
												stEventMsg.MagMsg.track3);
			iRet = event_main(&stEventMsg);
			if (iRet==ERR_EXIT_APP)
			{
//			    CommOnHook(TRUE);
				return 0;
			}
			bUpdateUI = TRUE;
			bGallery = FALSE;
			CommOnHook(FALSE);
			continue;
		}
	    }//end check mirror

if (! MirroringCheckEcr())
	    {
        // When chip card inserted
		if( ChkIfEmvEnable() && IccDetect(ICC_USER)==0 )
		{
			if((glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_NO))
			{
				BTPrn_ReconnectOp();
				bUpdateUI = TRUE;
			}
			memset(&stEventMsg, 0, sizeof(ST_EVENT_MSG));
			stEventMsg.MsgType = ICCARD_MSG;
			iRet = event_main(&stEventMsg);
			if (iRet==ERR_EXIT_APP)
			{
//			    CommOnHook(TRUE);
				return 0;
			}
			bUpdateUI = TRUE;
			bGallery = FALSE;
			CommOnHook(FALSE);
			continue;
		}
	    }//end check mirror

 //if ( ( ! MirroringCheckEcr()  ) && 0!=kbhit()  )



	   // CountKBD =0 ;
        // If any key is pressed
		if( 0==kbhit() )
		{
			if((glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_NO))
			{
				BTPrn_ReconnectOp();
				bUpdateUI = TRUE;
			}
			memset(&stEventMsg, 0, sizeof(ST_EVENT_MSG));
			stEventMsg.MsgType  = KEYBOARD_MSG;
			stEventMsg.KeyValue = getkey();
			// Add by lirz v1.02.0000
			// If key enter,it repaint the main UI(mainly logo) again and again,do not do this
			if(  (KEYENTER == stEventMsg.KeyValue )   )
			{


				continue;

			}

			if (MirroringCheckEcr())

				{
						if(     CountKBD<5    )
								{

										CountKBD ++;
										continue;

									}
						CountKBD =0;


				   }




			iRet = event_main(&stEventMsg);
			if (iRet==ERR_EXIT_APP)
			{
				//linzhao
//			    CommOnHook(TRUE);
//				return 0;
				SetCurrTitle((char *)_T("Exit"));
				if( PasswordBank()==0 )
				{
					return 0;
				}
			}
			bUpdateUI = TRUE;
			bGallery = FALSE;
			CommOnHook(FALSE);
			continue;
		}
		////kebad frfr



		if((glSysParam.stEdcInfo.ucPrinterType == PRNMODE_BTPRNTER) && (ucBTConnectFlag == CONNECT_NO))
		{
			BTPrn_ReconnectOp();
			bUpdateUI = TRUE;
		}

		// Add by lirz v1.02.0000
		// if multi-batch for pre-auth is full
		if(CheckTabBatchFull())
		{
			Gui_ShowMsgBox(_T("TAB BATCH FULL"), gl_stTitleAttr, _T("PLS SETTLE TAB BATCH"),
					       gl_stLeftAttr, GUI_BUTTON_OK, -1, NULL);
		}
		// End add bi lirz 

		// TODO:add your event-handlers here...
        if (ChkIdleTimer(glSysParam.stEdcInfo.ucIdleMinute * 60 /2))
        {
            bGallery = TRUE;
            continue;
        }

		// One of idle-processing
		if (ChkIdleTimer(glSysParam.stEdcInfo.ucIdleMinute * 60))
		{
			MainIdleProc();
			bUpdateUI = TRUE;
			bGallery = FALSE;
			continue;
		}
	} // end of while( 1
	return 0;
}

// event processing
int main_sub(const ST_EVENT_MSG *pstEventMsg)
{
	int	iRet;

	SystemInit();

#ifdef ENABLE_EMV
	iRet = EMVCoreInit();
	if( iRet==EMV_KEY_EXP )
	{
		EraseExpireCAPK();
	}
	
#ifdef ENABLE_CONTLESS
	Clss_CoreInit_Entry();
	Clss_CoreInit_Wave();
#ifdef _PROLIN2_4_
	Clss_CoreInit_MC(1);
#else
	Clss_CoreInit_MC();	
	Clss_CoreInit_Pboc();
#endif
#endif

#endif

	SetOffBase(NULL);

	CheckTermSatus(pstEventMsg);

#ifndef APP_MANAGER_VER
	// Process manager attached administrative message.
	// Not implemented
#endif

	iRet = ERR_NO_DISP;
	switch( pstEventMsg->MsgType )
	{
	case USER_MSG:
		ProcUserMsg();
		break;
	
	case EDCAPP_AUTOUPDATE:
		AutoDownParam();
	    break;
	
	case EDCAPP_GETPARA:
		GetAutoDownParam();
	    break;

	case EDC_ECR_MSG:
		iRet = ProcEcrMsg();
		break;
	
	case MAGCARD_MSG:
		iRet = ProcMagMsg();
		break;
	
	case ICCARD_MSG:
		iRet = ProcICCMsg();
		PromptRemoveICC();
	    break;
	case EPSAPP_FUNCKEYMSG:
		ProcFuncKeyMsg();
	    break;
	case KEYBOARD_MSG:
		iRet = ProcKeyMsg();
		break;

	case APPMSG_SYNC:
		break;

	default:
	    break;
	}
	if( iRet!=0 )
	{
		DispResult(iRet);
		Gui_ClearScr(); // Added by Kim_LinHB 2014-08-13 v1.01.0003 bug512
	}

	SetOffBase(NULL);

    kbflush();
	CheckInitTerminal();
	UnLockTerminal();

	if (iRet==ERR_EXIT_APP)
	{
		return ERR_EXIT_APP;
	}

#ifndef APP_MANAGER_VER
	// Response to manager admin msg
#endif

	return iRet; // Modified by Kim_LinHB 2014-08-13 v1.01.0003 bug 512
}

// read config parameters, check terminal status(e.g. if need to download parameters, if it's locked, etc.)
// and reset reversal flag etc
int CheckTermSatus(const ST_EVENT_MSG *pstEventMsg)
{
	FirstRunProc(pstEventMsg);
	LoadEdcLang();

	memcpy(&glSysParamBak, &glSysParam, sizeof(glSysParam));
	LoadSysDownEdcFile();	// load the files downloaded from Protims

	glSysParam.stTxnCommCfg.ucTCPClass_BCDHeader = FALSE;
	CheckInitTerminal();
	UnLockTerminal();

	RecoverTranLog();	// must called after system initialization
	InitTransInfo();

#ifndef APP_MANAGER_VER
	// load the synchronous parameters file received from main application if main application is existed
	// Not implemented
#endif

	return 0;
}

// 第一次运行时候处理(事实上每次main_sub都会运行)
// process for the first run
static char bInitGui_1 = 0;
static char bInitGui_2 = 0;
void FirstRunProc(const ST_EVENT_MSG *pstEventMsg)
{
	uchar	szEngTime[16+1];
	uchar	ucNeedUpdateParam;

	// Added by Kim_LinHB 2014-7-2
	if(!bInitGui_1)
	{
		unsigned char sTermInfo[60];

#ifdef _MONITOR_
		ST_FONT stFont[3];
		Gui_Init(GUI_WHITE, _RGB_INT_(0, 20,255), NULL);
		GetTermInfo(sTermInfo);
		memcpy(stFont, gl_Font_Def, sizeof(gl_Font_Def));
		// Added by Kim_LinHB 2014-8-12 v1.01.0003 bug510
#ifdef _Sxxx_
		if ((sTermInfo[0] != _TERMINAL_S300_) && (sTermInfo[0] != _TERMINAL_S900_))
		{
			if(_TERMINAL_S800_ == sTermInfo[0]){
				stFont[1].Width = 12;
				stFont[1].Height = 24;
			}
			else{
				stFont[0].Width = 6;
				stFont[0].Height = 8;

				stFont[1].Width = 8;
				stFont[1].Height = 16;
			}
		}
#endif

		Gui_LoadFont(GUI_FONT_SMALL,  &stFont[0], NULL);
		Gui_LoadFont(GUI_FONT_NORMAL, &stFont[1], NULL);
		Gui_LoadFont(GUI_FONT_LARGE,  &stFont[2], NULL );
#else
		int iDefWidth = XuiStatusbarCanvas()->width/6;
		int iDefHeight = XuiStatusbarCanvas()->height;
		Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), NULL); //default

		//font
		Gui_SetFontSize(GUI_FONT_SMALL,  16);
		Gui_SetFontSize(GUI_FONT_NORMAL, 28);
		Gui_SetFontSize(GUI_FONT_LARGE,  40);

	    if(Gui_GetScrHeight() > Gui_GetScrWidth())
	        Gui_SetBgImage("./data/240_320.png");
	    else
	        Gui_SetBgImage("./data/320_240.png");
	    Gui_SetGlobalBtnImg("./res/button_normal.png", "./res/button_pressed.png");

        if(0 == strcmp(gl_szTerminalType, "s800"))
        {
            int iKeyListS800[] = {
                    XUI_KEY1,XUI_KEY2,XUI_KEY3,XUI_KEY4,XUI_KEY5,XUI_KEY6,
                    XUI_KEY7,XUI_KEY8,XUI_KEY9,XUI_KEY0,
                    XUI_KEYF1,XUI_KEYUP,XUI_KEYDOWN,XUI_KEYMENU,XUI_KEYFUNC,
                    XUI_KEYALPHA,XUI_KEYCANCEL,XUI_KEYCLEAR,XUI_KEYENTER,
            };
            Reg_PhyKey(iKeyListS800, sizeof(iKeyListS800)/sizeof(int));
        }
        else if(0 == strcmp(gl_szTerminalType, "s900"))
        {
            int iKeyListS900[] = {
                    XUI_KEY1,XUI_KEY2,XUI_KEY3,XUI_KEY4,XUI_KEY5,XUI_KEY6,
                    XUI_KEY7,XUI_KEY8,XUI_KEY9,XUI_KEY0,
                    XUI_KEYUP,XUI_KEYDOWN,XUI_KEYMENU,XUI_KEYFUNC,
                    XUI_KEYALPHA,XUI_KEYCANCEL,XUI_KEYCLEAR,XUI_KEYENTER,
            };
            Reg_PhyKey(iKeyListS900, sizeof(iKeyListS900)/sizeof(int));
        }
        else if(0 == strcmp(gl_szTerminalType, "s300"))
        {
            int iKeyListS300[] = {
                    XUI_KEY1,XUI_KEY2,XUI_KEY3,XUI_KEY4,XUI_KEY5,XUI_KEY6,
                    XUI_KEY7,XUI_KEY8,XUI_KEY9,XUI_KEY0,
                    XUI_KEYFUNC,XUI_KEYALPHA,XUI_KEYCANCEL,XUI_KEYCLEAR,XUI_KEYENTER,
            };
            Reg_PhyKey(iKeyListS300, sizeof(iKeyListS300)/sizeof(int));
        }
        else if(0 == strcmp(gl_szTerminalType, "s920"))
        {
            int iKeyListS920[] = {
                    XUI_KEY1,XUI_KEY2,XUI_KEY3,XUI_KEY4,XUI_KEY5,XUI_KEY6,
                    XUI_KEY7,XUI_KEY8,XUI_KEY9,XUI_KEY0,XUI_KEYFUNC,
                    XUI_KEYALPHA,XUI_KEYCANCEL,XUI_KEYCLEAR,XUI_KEYENTER,
            };

            Reg_PhyKey(iKeyListS920, sizeof(iKeyListS920)/sizeof(int));
        }
        else if(0 == strcmp(gl_szTerminalType, "Px7"))
        {
            int iKeyListPx7[] = {
                    XUI_KEY1,XUI_KEY2,XUI_KEY3,XUI_KEY4,XUI_KEY5,XUI_KEY6,
                    XUI_KEY7,XUI_KEY8,XUI_KEY9,XUI_KEY0,
                    XUI_KEYALPHA,XUI_KEYCANCEL,XUI_KEYCLEAR,XUI_KEYENTER,
            };

            Reg_PhyKey(iKeyListPx7, sizeof(iKeyListPx7)/sizeof(int));
        }
        //add d200, linzhao
        else if (0 == strcmp(gl_szTerminalType, "d200"))
        {
        	int iKeyListD200[] = {
                    XUI_KEY1, XUI_KEY2, XUI_KEY3, XUI_KEY4, XUI_KEY5, XUI_KEY6,
                    XUI_KEY7, XUI_KEY8, XUI_KEY9, XUI_KEY0, XUI_KEYF1,
                    XUI_KEYF2, XUI_KEYCANCEL, XUI_KEYCLEAR, XUI_KEYENTER,
        	};
            Reg_PhyKey(iKeyListD200, sizeof(iKeyListD200)/sizeof(int));
        }

		SB_BindResource(XuiStatusbarCanvas(), "./res/icons.ini");

		SB_RegIcon(SB_ICON_BATTERY, iDefWidth * 5, 0, iDefWidth, iDefHeight, 500);
		SB_RegIcon(SB_ICON_UP_DOWN, iDefWidth * 4, 0, iDefWidth, iDefHeight, -1);
		Gui_RegCallback(GUI_CALLBACK_UPDATE_UPDOWN_ICON, Refresh_UpDown);
		SB_RegIcon(SB_ICON_CARDINSERTED, iDefWidth * 3, 0, iDefWidth, iDefHeight, 200);
		if (OsRegGetValue("ro.fac.printer", sTermInfo) > 0)
			SB_RegIcon(SB_ICON_PRINTER, iDefWidth * 2, 0, iDefWidth, iDefHeight, -1);

#endif
		bInitGui_1 = 1;
	}

    // Modified by Kim_LinHB 2014-7-2
    if( ExistSysFiles() )
    {
        if (ValidSysFiles())
        {
            int i;
            uchar *pType  = NULL;
            LoadSysParam();
            LoadSysCtrlAll();

#ifdef _PROLIN2_4_
            if(!bInitGui_2)
            {
                //update language
                Gui_Init(GUI_WHITE, _GUI_RGB_INT_(0, 0, 0), glSysParam.stEdcInfo.stLangCfg.szFilePath);

                ChangeLangOrder();
                for(i = 0; i < 2; ++i)
                {
                    pType = (0 == i? &glSysParam.stTxnCommCfg.ucCommType: &glSysParam.stTxnCommCfg.ucCommTypeBak);
                    Reg_CommIcon(*pType, i);
                }
                bInitGui_2 = 1;
            }
#endif

            ucNeedUpdateParam = FALSE;
            if (pstEventMsg->MsgType==USER_MSG)
            {
                if (UpdateTermInfo() || InitMultiAppInfo())
                {
                    ucNeedUpdateParam = TRUE;
                }
            }
            if( glSysParam.stTxnCommCfg.pfUpdWaitUI!=DispWaitRspStatus )
            {
                glSysParam.stTxnCommCfg.pfUpdWaitUI = DispWaitRspStatus;
                glSysParam.stTMSCommCfg.pfUpdWaitUI = DispWaitRspStatus;
                ucNeedUpdateParam = TRUE;
            }

            if (ucNeedUpdateParam)
            {
                SaveSysParam();
            }
            return;
        } // if (ValidSysFiles())
        else
        {
        	OsLog(LOG_ERROR, "%s--%d, no ExistSysFiles", __FILE__, __LINE__);//linzhao
            int iRet;
            Gui_ClearScr();
            iRet = Gui_ShowMsgBox(NULL, gl_stTitleAttr, _T("APP AND DATA\nINCONSIST.\nRESET CONFIG?"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);
            if (iRet != GUI_OK)
            {
                SysHaltInfo("PLS REPLACE APP");
            }

            Gui_ClearScr();
            iRet = Gui_ShowMsgBox(NULL, gl_stTitleAttr, _T("WARNING\nDATA WILL BE CLEAR\nCONTINUE ?"), gl_stCenterAttr, GUI_BUTTON_YandN, -1, NULL);
            if (iRet != GUI_OK)
            {
                SysHaltInfo("PLS REPLACE APP");
            }

            RemoveSysFiles();
        }
    } // if( ExistSysFiles() )

    GetEngTime(szEngTime);
    Gui_ClearScr();
    Gui_ShowMsgBox(szEngTime, gl_stTitleAttr, _T("PLEASE WAIT...\nSYSTEM INIT..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

    LoadEdcDefault();	// set EDC default values
    Gui_ClearScr();
    Gui_ShowMsgBox(szEngTime, gl_stTitleAttr, _T("PLEASE WAIT...\nSYSTEM FILE UPDATE..."), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
    InitTranLogFile();	// Init transaction log file
    NoDownloadInit();

#ifdef ENABLE_EMV
	LoadEmvDefault();	// Init EMV kernel
#endif
}

// 设置空闲计时。设置一个比较长的倒计时，以用于不止一种的空闲事件处理
// set a idle timer with a long period of time, for processing several idle events
void SetIdleTimer(void)
{
	TimerSet(TIMER_TEMPORARY, TIMERCNT_MAX);
}

// 检查空闲计时，看是否已经流过了指定的分钟数
// check if the timer counted the specific time(uint:minute)
uchar ChkIdleTimer(int iSeconds)
{
	int	iCnt = TIMERCNT_MAX-TimerCheck(TIMER_TEMPORARY);
	
	PubASSERT(TIMERCNT_MAX > iSeconds*10);	//	ScrPrint(0,7,ASCII,"%d  ", iCnt/10);
	return (iCnt >= iSeconds*10);
}

// 显示空闲时用户界面
// show an idle UI
void ShowIdleMainUI(uchar *pbForceUpdate, uchar bShowGallery, int iGallery_Image_Num)
{
	static	uchar	szLastTime[5+1] = {"00000"};
	uchar	szCurTime[16+1];

	GetEngTime(szCurTime);//am/pm

	if( *pbForceUpdate || memcmp(szLastTime, &szCurTime[11], 4)!=0 )	// Reset magstripe reader every 10 minutes
	{
		MagClose();
		MagOpen();
		MagReset();
	}

	if(bShowGallery){
	    ShowGallery(iGallery_Image_Num);
	}

	if( *pbForceUpdate || memcmp(szLastTime, &szCurTime[11], 5)!=0)
	{
		// refresh UI
		sprintf((char *)szLastTime, "%.5s", &szCurTime[11]); 

		// Gui_ClearScr(); // removed by Kim_LinHB 2014-08-13 v1.01.0003 bug512
		// Modified by Kim_LinHB 2014-8-11 v1.01.0003
        //Gui_ShowMsgBox(szCurTime, gl_stTitleAttr, NULL, gl_stCenterAttr, GUI_BUTTON_NONE, 0,NULL);
        Gui_UpdateTitle(szCurTime, gl_stTitleAttr);
		//Gui_DrawText(szCurTime, gl_stTitleAttr, 0, 5);
        if(*pbForceUpdate){
            if(!bShowGallery)
            {
            	//linzhao
            	if (0==strcmp(gl_szTerminalType, "d200"))
            	{
            		DispSwipeCard(TRUE);
            	}
            	else
            	{
            		Gui_UpdateKey(XUI_KEYFUNC, "FUNC", NULL, NULL);
            		Gui_UpdateKey(XUI_KEYMENU, "MENU", NULL, NULL);
            		Gui_SetVirtualButton(!HasPhyKeyExisted(XUI_KEYFUNC), !HasPhyKeyExisted(XUI_KEYMENU));
            		DispSwipeCard(TRUE);
            	}
            }
            else
                Gui_SetVirtualButton(0,0);
        }
		*pbForceUpdate = FALSE;
	}
#ifdef _WIN32
	DelayMs(100);
#endif
}

static void ShowGallery(int num)
{
    static int iCurrImages = 0;
    static ST_TIMER stGalleryTimer = {0};
    static unsigned long ulTimer_Late = 0;
    static unsigned long ulTimer_Curr = 0;

    if(num <= 0)
        return;

    ulTimer_Curr = OsGetTickCount();
    if(ulTimer_Curr - ulTimer_Late >= 10000)
    {
        uchar szImageKey[8];
        uchar szImageValue[255] = {0};
        sprintf(szImageKey, "PIC_%d", iCurrImages);
        if(0 == GetEnv(szImageKey, szImageValue))
        {
            char szId[10];
            ulTimer_Late = ulTimer_Curr;
            Gui_ClearScr();
            char *p = strstr(szImageValue, "???");
            if(p)
            {
                p+=3;
                strcpy(szId, p);
                p-=3;
                strcpy(p, gl_szTerminalType);
                strcat(szImageValue, szId);
                Gui_DrawImage(szImageValue, 0,0);
            }
        }

        ++iCurrImages;
        if(iCurrImages >= num)
            iCurrImages = 0;
    }

}

// Modified by Kim_LinHB 2014-7-8
int CheckInitTerminal(void)
{
	uchar	szCurTime[16+1], szLastTime[16+1];
	uchar	ucKey;
	uchar	szBuff[50];
	
	if( !(glSysParam.ucTermStatus & INIT_MODE) )
	{
		return 0;
	}
	
	TimerSet(0, 0);
	memset(szCurTime,  0, sizeof(szCurTime));
	memset(szLastTime, 0, sizeof(szLastTime));
	while( glSysParam.ucTermStatus & INIT_MODE )
	{
		if( TimerCheck(0)==0 )
		{
			TimerSet(0, 10);
			GetEngTime(szCurTime);
			if (strcmp(szCurTime, szLastTime)!=0)
			{
				Gui_ClearScr();
				sprintf(szBuff, "%s\n[%.14s]", _T("PLEASE INIT"), AppInfo.AppName);
				Gui_ShowMsgBox(szCurTime, gl_stTitleAttr, szBuff, gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);
				memcpy(szLastTime, szCurTime, sizeof(szLastTime));
			}
		}

		ucKey = PubWaitKey(10);
		if(
			(ucKey==KEYF1 && ChkTerm(_TERMINAL_D200_)) || (ucKey==KEYFN && !ChkTerm(_TERMINAL_D200_))
			)
		{
			InitTransInfo();
			FunctionInit();
			TimerSet(0, 0);
			memset(szLastTime, 0, sizeof(szLastTime));
		}
	}

	return 0;
}

void MainIdleProc(void)
{
	int iRec;
#if (defined(_Sxx_) && !defined(_WIN32)) || defined(_PROLIN2_4_)
	// should not let POS go into sleep mode when running simulator
	int	iRet;

#ifdef _MONITOR_
	if (ChkTerm(_TERMINAL_S90_))
#else
	if (POWER_BATTERY == OsCheckPowerSupply())
#endif
	{
		if (glSysParam.stEdcInfo.ucIdleShutdown)
		{
			PowerOff();
		}
		else
		{
			// Modified by Kim_LinHB 2014-7-8
			Gui_ClearScr();
			Gui_ShowMsgBox(_T("POWER SAVING"), gl_stTitleAttr, _T("PRESS ANY KEY\nTO RECOVER"), gl_stCenterAttr, GUI_BUTTON_NONE, 0, NULL);

			do 
			{
				iRet = SysSleep("00");
			} while((iRet==-3) && (kbhit()!=0));
			// 很奇怪的现象：除非在上次SysSleep返回之后调用DelayMs(3000)，否则即使间隔1分钟，调用SysSleep仍会直接返回-3。
			// 因此我在这里加了判断，如果返回-3而且没有按键则继续重复SysSleep
			// 在外部已经保证了进入MainIdleProc的间隔>=1分钟
			// it needs to delay 3 seconds after return from SysSleep, otherwise SysSleep will return -3 even the period of calling SysSleep is over 1 min,
			// so here is a special processing, if return -3 from SysSleep and no key was pressed then continue calling SysSleep.

			DelayMs(100);
			kbflush();
			Gui_ClearScr(); // Added by Kim_LinHB 2014-08-13 v1.01.0003
		}
	}
#endif
	
	// Add by lirz v1.02.0000
	// if it's time to complete pre-auth transaction
	iRec = -1;
	if( ( iRec=ChkIfTimeToCompPreAuth() ) != -1 )
	{
		Gui_ShowMsgBox(_T("TIME TO COMPLETE"), gl_stTitleAttr, _T("PLS COMPLETE PREAUTH"),
								   gl_stLeftAttr, GUI_BUTTON_OK, -1, NULL);
	}
	// End add by lirz
}

// Added by Kim 2014-12-19
#ifdef _PROLIN2_4_
int Refresh_UpDown(gui_callbacktype_t type, void *data, int *len)
{
	int iRet;
	gui_updownstatus_t status = *(gui_updownstatus_t *)data;
	if (GUI_UP == status)
		iRet = SB_ManuallyRefresh(SB_ICON_UP_DOWN, OPENICON_UP);
	else if (GUI_DOWN == status)
		iRet = SB_ManuallyRefresh(SB_ICON_UP_DOWN, OPENICON_DOWN);
	else if ((GUI_UP & status) && (GUI_DOWN & status))
		iRet = SB_ManuallyRefresh(SB_ICON_UP_DOWN, OPENICON_UP_DOWN);
	else
		iRet = SB_ManuallyRefresh(SB_ICON_UP_DOWN, NULL);

	return iRet;
}
#endif

// end of file

