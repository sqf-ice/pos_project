
#include "global.h"

/********************** Internal macros declaration ************************/
#define ECR_TIME_ID     2       /*ECR ͨѶʹ��2 timer*/
#define ECR_BUFFER_LEN  1024    /*ECR ͨѶ buffer*/
#define BYTE_ACK        0x06
#define BYTE_NAK        0x15
#define BYTE_STX        0x02
#define BYTE_ETX        0x03
#define STR_ECR_START   "\"<START>\""
#define STR_ECR_ACK     "\"<START>\",\"<END>\""

/********************** Internal structure declaration *********************/
/********************** Internal functions declaration *********************/
/********************** Internal variables declaration *********************/
unsigned char   now_app_num,app_num;
const unsigned char ecr_version[] = "6.13";
/********************** external reference declaration *********************/

extern void EpsUpdateReverseState(uchar needReverse);
extern int event_main(ST_EVENT_MSG *pstEventMsg);

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/
// ��ECR�˿�
void EcrOpen(void)
{
    uchar   ucRet;

    if (glSysParam.stECR.ucSpeed==ECRSPEED_9600)
    {
        ucRet = PortOpen(glSysParam.stECR.ucPort, (char*)"9600,8,n,1");
    }
    else
    {
        ucRet = PortOpen(glSysParam.stECR.ucPort, (char*)"115200,8,n,1");
    }

    PortReset(glSysParam.stECR.ucPort);
}

static uchar EcrPortReset(void)
{
    return PortReset(glSysParam.stECR.ucPort);
}

static int EcrRecvDataOnly(uchar *psDataBuff, ushort usDataBuffSize, ushort usTimeoutMs)
{
    uchar   ucRet;
    int     iLen;

    if (usDataBuffSize<1)
    {
        return -1;
    }

    iLen = 0;
    while(1)
    {
        ucRet = PortRecv(glSysParam.stECR.ucPort, psDataBuff+iLen, usTimeoutMs);

        if (ucRet!=0)
        {
            break;
        }

        iLen++;
        usTimeoutMs = 10;   // 10ms between char
        if (iLen>=usDataBuffSize)
        {
            break;
        }
    }

    return iLen;
}


//HALA

static uchar MirroringEcr_Sub(uchar *psData, ushort usLen, uchar bNeedAck)
{
    int ii, iCnt, iRet;
    uchar   ucRet, sBuff[512];

    // Max try 3 times if no ack from ECR
//    for (ii=0; ii<3; ii++)
//    {
        for (iCnt=0; iCnt<usLen; iCnt++)
        {
            ucRet = PortSend(glSysParam.stECR.ucPort, psData[iCnt]);
            //linzhao
            if (0==(iCnt % 240))
            {
              //  DelayMs(500);
                DelayMs(1);
            }

            if (ucRet!=0)
            {
                return ucRet;
            }
        }

        if (!bNeedAck)
        {
            return 0;
        }

        // check ECR confirmation.
//        DelayMs(1000);//???not sure if need this delay
        memset(sBuff, 0, sizeof(sBuff));
        iRet = EcrRecvDataOnly(sBuff, sizeof(sBuff), 1);//500
        if ((iRet>0) && (strstr(sBuff, STR_ECR_ACK)!=NULL))
        {
            return 0;
        }
//    }
    return 0x80;
}

uchar MirroringEcr(uchar *psData, ushort usLen)
{
    return MirroringEcr_Sub(psData, usLen, TRUE);
}
void MirroringSendEcr (uchar *psData){

    //"<START>","MirrorMsg=Data","<END>"
    char cmdMirroring[100];
    memset(cmdMirroring,0,sizeof(cmdMirroring));
    strcat(cmdMirroring,"\"<START>\",");
    strcat(cmdMirroring,"\"MirrorMsg=");
    strcat(cmdMirroring,psData);
    strcat(cmdMirroring,"\",");
    strcat(cmdMirroring,"\"<END>\"");

    if(MirroringCheckEcr())
    {
        MirroringEcr(cmdMirroring, strlen(cmdMirroring));
    }
}

void MirroringSendEcrEND (uchar *psData){

    //"<START>","MirrorMsg=Data","<END>"
    char cmdMirroring[100];
    memset(cmdMirroring,0,sizeof(cmdMirroring));
    strcat(cmdMirroring,"\"<START>\",");
    strcat(cmdMirroring,"\"MSG=");
    strcat(cmdMirroring,"END");
    strcat(cmdMirroring,"\",");
    strcat(cmdMirroring,"\"<END>\"");

    if(MirroringCheckEcr())
    {
        MirroringEcr(cmdMirroring, strlen(cmdMirroring));
    }
}

uchar MirroringCheckEcr (){

	//return FALSE;
  //  if ( glSysParam.stECR.ucMode==ECRMODE_ENABLED || glSysParam.stECR.ucMode==ECRMODE_ONLY )
if ( glSysParam.stECR.ucMode==ECRMODE_ENABLED  )
    {
        // OsScrBrightness(8);
         //kbflush();
        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

uchar  CheckCarrfour ()
{

if ( glSysParam.stECR.ucMode == ECRMODE_ONLY  )
    {

        return TRUE;
    }
    else
    {
        return FALSE;
    }
}

//END HALA
static uchar EcrSendData_Sub(uchar *psData, ushort usLen, uchar bNeedAck)
{
    int ii, iCnt, iRet;
    uchar   ucRet, sBuff[512];

    // Max try 3 times if no ack from ECR
    for (ii=0; ii<3; ii++)
    {
        for (iCnt=0; iCnt<usLen; iCnt++)
        {
            ucRet = PortSend(glSysParam.stECR.ucPort, psData[iCnt]);
            //linzhao
            if (0==(iCnt % 240))
            {
            	DelayMs(500);
            }

            if (ucRet!=0)
            {
                return ucRet;
            }
        }

        if (!bNeedAck)
        {
            return 0;
        }

        // check ECR confirmation.
        DelayMs(1000);//???not sure if need this delay
        memset(sBuff, 0, sizeof(sBuff));
        iRet = EcrRecvDataOnly(sBuff, sizeof(sBuff), 500);
        if ((iRet>0) && (strstr(sBuff, STR_ECR_ACK)!=NULL))
        {
            return 0;
        }
    }
    return 0x80;
}

uchar EcrSendData(uchar *psData, ushort usLen)
{
    return EcrSendData_Sub(psData, usLen, TRUE);
}

static void PackEcrMsgToEvent(ST_EVENT_MSG *pstEvent, int iMsgType, uchar *pszEcrMsgBuff)
{
    int iLen = strlen(pszEcrMsgBuff);

    InitEventMsg(pstEvent, iMsgType);
    pstEvent->MagMsg.track1[0] = iLen / 0x100;
    pstEvent->MagMsg.track1[1] = iLen % 0x100;
    pstEvent->UserMsg = (void *)EcrSendData;  // pass the function to sub-app
    //todo the size of MagMsg.track1 is 256, the size of pszEcrMsgBuff is 1024. linzhao 20160223
    strcpy(&(pstEvent->MagMsg.track1[2]), pszEcrMsgBuff);
}
void PackEcrMsgToEPS(ST_EVENT_MSG *pstEvent, int iMsgType, uchar *pszEcrMsgBuff, int msgLen)//build 136 eps Jardine
{
    memset(pstEvent, 0, sizeof(ST_EVENT_MSG));
    pstEvent->MsgType = iMsgType;
    pstEvent->MagMsg.RetCode = (unsigned char) msgLen;
    strcpy(pstEvent->MagMsg.track1, pszEcrMsgBuff);
}
int ProcEcrEvent(void)//EPS should change here
{
    int     ii=0, iLen=0,DataLen=0;
    uchar   ucRet, szBuff[ECR_BUFFER_LEN],ucLRC;
    ST_EVENT_MSG    stEvent;
    memset(szBuff,0,sizeof(szBuff));
    iLen = EcrRecvDataOnly(szBuff, sizeof(szBuff), 100);



    if ( (iLen>40) && (szBuff[2]=='T') && (szBuff[3]=='M') && (szBuff[4]=='K')  )
    {
//        hhhHasan(iLen);
//        fffFOURA(szBuff);

    	memset(g_TMK_ALL,0,sizeof(g_TMK_ALL));
    	strcpy (g_TMK_ALL,szBuff);
    	injectTMKTRUST();
        return 0;
    }


    if (iLen<1 || iLen>sizeof(szBuff))
    {
        return -1;
    }
    DelayMs(100);
    //PubDebugOutput("msg1",szBuff,iLen,DEVICE_COM1, HEX_MODE);
    // find first quote in data
    for (ii=0; ii<iLen; ii++)
    {
        if (szBuff[ii]=='\"')
        {
            break;
        }
        if (szBuff[ii]==0x02)//eps jardine 4mat
        {
            break;
        }
    }
    if (ii>=iLen)
    {
        return -1;
    }

    // continue receive from first quote
    if (ii!=0)
    {
        memmove(szBuff, szBuff+ii, iLen-ii);
        iLen = iLen-ii;
    }
    ii = EcrRecvDataOnly(szBuff+iLen, (ushort)(sizeof(szBuff)-iLen), 0);
    iLen += ii;
    //OsLog(LOG_ERROR,"ECR111 EcrRecvDataOnly %s",szBuff);
    {

        // ensure start/end format
        if ((strstr(szBuff, "\"<START>\"")==NULL) || (strstr(szBuff, "\"<END>\"")==NULL))
        {
            //OsLog(LOG_ERROR,"ECR111 ERRRRR EcrRecvDataOnly %s",szBuff);
            return -3;
        }

        ucRet = EcrSendData_Sub((uchar *)STR_ECR_ACK, (ushort)strlen(STR_ECR_ACK), FALSE);


        Beep();
        //zeeeeeeeed
        //OsLog(LOG_ERROR,"ECR111 ACK TRUST%s",szBuff);
        if (strstr(szBuff,(uchar *)STR_ECR_ACK)!=NULL)//STR_ECR_ACK will send to eventmain which will cause excption
        {
            //OsLog(LOG_ERROR,"ECR111 Done %s",szBuff);
            return 0;
        }
        // TODO : add processing here
        if (strstr(szBuff, "\"FUNC=EPS\"")!=NULL)
        {
            // TODO : Call EPS
        }
        else
        {
            // Call EDC
            PackEcrMsgToEvent(&stEvent, EDC_ECR_MSG, szBuff);
            event_main(&stEvent);

            //AppDoEvent(glSysParam.astSubApp[APP_EDC].ucAppNo, &stEvent);
        }
    }
    EcrPortReset();
    return 0;
}

// end of file

