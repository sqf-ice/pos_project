
#ifndef _EMV_MID_H
#define _EMV_MID_H

#define CAPKINFO	"./data/CAPKINFO"
#define AIDINFO		"./data/AIDINFO"


int SaveCAPKFile(EMV_CAPK  *pstCAPK);
int AddCAPKIntoEmvLib(uchar ucKeyID, uchar *sRID);
int AddAppIntoEmvLib(void);
int SaveAIDFile(EMV_APPLIST *pstApp);
int ReadCAPKFile(int index, EMV_CAPK  *pstCAPK);
int ReadAIDFile(int index, EMV_APPLIST *pstApp);

int EMVProcTrans(void);

/*
int FileToStruct(char *pszFileName, ST_EVENT_MSG *pstEvent, ST_TMS_MSG *pstTmsMsg);
int StructToFile(char *pszFileName, ST_EVENT_MSG *pstEvent, ST_TMS_MSG *pstTmsMsg);
*/

#endif // _EMV_MID_H
