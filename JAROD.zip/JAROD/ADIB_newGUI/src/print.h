
/****************************************************************************
NAME
    print.h - 定义打印模块

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    shengjx     2006.09.12      - created
****************************************************************************/

#ifndef _PRINT_H
#define _PRINT_H

#define PRN_NORMAL		0
#define PRN_REPRINT		1

#ifndef PRN_OK
#define PRN_OK			0
#define PRN_BUSY		1
#endif

#define PRN_NO_PAPER	2
#define PRN_DATA_ERR	3
#define PRN_ERR			4
#define PRN_OVERHEAT  8
#define PRN_NO_DOT		0xFC
#define PRN_DATA_BIG	0xFE
#define PRN_CANCEL		0xA1

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

int PrnCurAcqTransList(void);
int PrnAllList(void);
int PrnAllList_PreAuth(void);

int PrnAllList_Details(void);
int PrnCurAcqTransList_Details(void);

void  PrnSetSmall(void);//no
void  PrnSetNormal(void);//no
void  PrnSetBig(void);//no


int  PrintReceipt(uchar ucPrnFlag);
int  PrnTotalIssuer(uchar ucIssuerKey);
int PrnTotalIssuer_Details(uchar ucIssuerKey)  ;
int  PrnTotalAcq(void);
int PrnTotalAcq_Details(void);

int  PrintSettle(uchar ucPrnFlag);
int  PrintParam(void);
int  StartPrinter(void);
void PrintEmvErrLogSub(void);
void PrintReceiptTest(void);//linzhao

#ifdef _PROLIN2_4_
int PrnInit();
void MultiLngPrnStr(uchar alignment, uchar size, const char *str, ...);
#define PrnStep OsPrnFeed
#define PrnLogo OsPrnPutImage
#define PrnLeftIndent(x) OsPrnSetIndent(x, 0)
#define PrnStart StartPrinter
#endif

#ifdef __cplusplus
}
#endif /* __cplusplus */ 

#endif	// _PRINT_H

// end of file
