
#include "global.h"

/********************** Internal macros declaration ************************/
#define MAX_ECR_MSGLEN      576   //Jason 2014.12.19 15:54
#define MAX_ECR_TAGLEN      32
#define MAX_ECR_VALUELEN    64

#define RET_ECR_OK              0
#define RET_ECR_ERR_SYNTAX      -1
#define RET_ECR_ERR_UNKNOWNTAG  -2

#define TAG_ECR_START   "\"<START>\","
#define TAG_ECR_END     "\"<END>\""
#define SYMBOL_QUOTE    '\"'
#define SYMBOL_EQUAL    '='
#define STR_QUOTE       "\""
#define STR_EQUAL       "="
#define STR_ECR_ACK     "\"<START>\",\"<END>\""

#define TAG_ECR_TXNID               "TXNID"
#define TAG_ECR_CMD                 "CMD"
#define TAG_ECR_AMT                 "AMT"
#define TAG_ECR_DETAIL              "DETAIL"
#define TAG_ECR_TXNNO               "TXNNO"
#define TAG_ECR_TXNCONSEQUENTIALNO  "TXNCONSEQUENTIALNO"
#define TAG_ECR_FUNC                "FUNC"
#define TAG_ECR_PLAN                "PLAN"
#define TAG_ECR_INVOICENO           "INVOICENO"
#define TAG_ECR_ACQNAME             "ACQNAME"
/*=======BEGIN: Jason 2014.12.19  15:54 modify===========*/
#define TAG_ECR_ADJAMT                 "ADJAMT"
#define TAG_ECR_PWD                    "PWD"
#define TAG_ECR_ECRREF                    "ECRREF"    //ECR reference no. up to 16 digits(optional) 
/*====================== END======================== */
#define TAG_ECR_DATE                   "DATE"  //Jason 2015.03.26 10:55
#define TAG_ECR_APPCODE                   "APPCODE" //Jason 2015.03.26 11:24
#define TAG_ECR_RRN                    "RRN"
/********************** Internal structure declaration *********************/
typedef struct _tagECR_TRAN_INFO
{
//    uchar   szTxnID[6+1];           // Txn ID//Jason 2014.12.19 15:55
    uchar   ucTranType;
    uchar   bTranInstallment;       // Is installment
    uchar   szAmount[12+1];         // same as ISO format
    uchar   szTxnNo[6+1];           // TXNNO
    uchar   szTxnConseqNo[4+1];     // TXNCONSEQUENTIALNO
    ulong   ulInvoice;              // invoice number
    uchar   bDetailRequired;        // ECR requires POS to return detail info
    uchar   ucInstPlan;             // installment tenure (month)
    uchar   szAcqName[10+1];
    /*=======BEGIN: Jason 2014.12.19  15:55 modify===========*/
    uchar   szADJamt[12+1];            // adjust tip
    uchar   sPassword[6+1];          //password
    int   ucCardType;             //?��??type
    uchar szRRN[13+1];              //RRN
    uchar   szTxnID[10+1];           // Txn ID
    /*====================== END======================== */
    uchar  szCmdText[16+1];    //Jason 2015.01.13 18:40
    uchar  szDate[4+1];  //Jason 2015.03.26 10:58 MMDD
    uchar   szAuthCode[6+1];//Jason 2015.03.26 11:25
} ST_ECR_TRAN_INFO;

/********************** Internal functions declaration *********************/
static void EcrShowDebug(char *pszStr, ...);
static int UnpackEcrData(char *pszTag, char *pszValue);
static int GetAllEcrElements(void *pszEcrMsg);
static void StrCatEcrRsp_TxnTypeDateTime(TRAN_LOG *pstLog, char *pszEcrMsgBuff);

/********************** Internal variables declaration *********************/
static ST_ECR_TRAN_INFO g_stEcr;

/********************** external reference declaration *********************/

/******************>>>>>>>>>>>>>Implementations<<<<<<<<<<<<*****************/


//Jason 2014.12.19 15:57
enum
{
    VAL_ECRCMD_NONE=0,
    VAL_ECRCMD_SALE,
    VAL_ECRCMD_VOID,
    VAL_ECRCMD_GETTXN,
    VAL_ECRCMD_GETTOTAL,
    VAL_ECRCMD_ADJUST,
    VAL_ECRCMD_REFUND,
    VAL_ECRCMD_SETTLE,
    VAL_ECRCMD_PREAUTH,
    VAL_ECRCMD_PREAUTHOK,
    VAL_ECRCMD_OFFLINE,
    VAL_ECRCMD_REPRINT,
    VAL_ECRCMD_INSTALLMENT,
    /*=======BEGIN: Jason 2015.03.26  10:2 modify===========*/
    VAL_ECRCMD_PREAUTHVOID,
    VAL_ECRCMD_PREAUTHCOMP,
    /*====================== END======================== */
    VAL_ECRCMD_PREAUTHCOMPVOID,//Jason 2015.03.27 15:30

};


typedef uchar (*FNPTR_EcrSend)(uchar *psData, ushort usLen);

static void EcrShowDebug(char *pszStr, ...)
{
    uchar       szBuff[1024+1];
    va_list     pVaList;

    if( pszStr==NULL || *(uchar *)pszStr==0 )
    {
        return;
    }

    va_start(pVaList, pszStr);
    vsprintf((char*)szBuff, (char*)pszStr, pVaList);
    va_end(pVaList);

    Gui_ClearScr();
    Gui_ShowMsgBox(GetCurrTitle(), gl_stTitleAttr, szBuff, gl_stLeftAttr, GUI_BUTTON_NONE, -1, NULL);
}

static int UnpackEcrData(char *pszTag, char *pszValue)
{
    int ii, iCnt;
    struct
    {
        char    szCmdText[16+1];
        uchar   ucTranType;
    } astCmdTxnMap[] =
    {
            {"SALE",     VAL_ECRCMD_SALE},
            {"VOID",     VAL_ECRCMD_VOID},
            {"GETTXN",   VAL_ECRCMD_GETTXN},
            {"GETTOTAL", VAL_ECRCMD_GETTOTAL},
        /*=======BEGIN: Jason 2014.12.19  15:57 modify===========*/
            {"ADJUST",   VAL_ECRCMD_ADJUST},
            {"REFUND",   VAL_ECRCMD_REFUND},
            {"AUTH",     VAL_ECRCMD_PREAUTH},
            {"OFFLINE",  VAL_ECRCMD_PREAUTHOK},
            {"SETTLE",   VAL_ECRCMD_SETTLE},
            {"REPRINT",  VAL_ECRCMD_REPRINT},
            {"INST",  VAL_ECRCMD_INSTALLMENT},
        /*====================== END======================== */
    };

    if (strcmp(pszTag, TAG_ECR_TXNID)==0)
    {
        sprintf(g_stEcr.szTxnID, "%.*s", sizeof(g_stEcr.szTxnID)-1, pszValue);
    }
    else if (strcmp(pszTag, TAG_ECR_CMD)==0)
    {
        for (ii=0; ii<sizeof(astCmdTxnMap)/sizeof(astCmdTxnMap[0]); ii++)
        {
            if (strcmp(astCmdTxnMap[ii].szCmdText, pszValue)==0)
            {
                g_stEcr.ucTranType = astCmdTxnMap[ii].ucTranType;
                strcpy(g_stEcr.szCmdText,astCmdTxnMap[ii].szCmdText); //Jason 2015.01.13 18:41
                break;
            }
        }
    }
    else if (strcmp(pszTag, TAG_ECR_AMT)==0)
    {

    	if (MirroringCheckEcr())
    	{

    	    uchar szFeeValP[24],szFeeValN[24];//

    	    double  dblAmount=0.0 ;

    	        memset(szAmountRMZI,0,sizeof(szAmountRMZI));
     	        dblAmount = atof(pszValue);
    	        dblAmount = dblAmount*1.0;
    	       sprintf(szAmountRMZI, "%.2f", dblAmount);



    	       strcat(pszValue,"0");




    	}

      // save amount in ISO8583 DE4 format
    	if (strlen(pszValue)<14)
        {




            g_stEcr.szAmount[12] = 0;
            for (ii=strlen(pszValue)-1, iCnt=11; ii>=0 && iCnt>=0; ii--)
            {
                if (isdigit(pszValue[ii]))
                {
                    g_stEcr.szAmount[iCnt] = pszValue[ii];
                    iCnt--;
                }
            }
            while (iCnt>=0)
            {
                g_stEcr.szAmount[iCnt] = '0';
                iCnt--;
            }
        }
    }
    else if (strcmp(pszTag, TAG_ECR_DETAIL)==0)
    {
        g_stEcr.bDetailRequired = (strcmp(pszValue, "Y")==0);
    }
    else if (strcmp(pszTag, TAG_ECR_TXNNO)==0)
    {
        sprintf(g_stEcr.szTxnNo, "%.*s", sizeof(g_stEcr.szTxnNo)-1, pszValue);
    }
    else if (strcmp(pszTag, TAG_ECR_TXNCONSEQUENTIALNO)==0)
    {
        sprintf(g_stEcr.szTxnConseqNo, "%.*s", sizeof(g_stEcr.szTxnConseqNo)-1, pszValue);
    }
    else if (strcmp(pszTag, TAG_ECR_FUNC)==0)
    {
        if (strcmp(pszValue, "INST")==0)
        {
            g_stEcr.bTranInstallment = TRUE;
        }
    }
    else if (strcmp(pszTag, TAG_ECR_PLAN)==0)
    {
        g_stEcr.ucInstPlan = (uchar)atoi(pszValue);
    }
    else if (strcmp(pszTag, TAG_ECR_INVOICENO)==0)
    {
        g_stEcr.ulInvoice = (ulong)atol(pszValue);
    }
    else if (strcmp(pszTag, TAG_ECR_ACQNAME)==0)
    {
        sprintf(g_stEcr.szAcqName, "%.*s", sizeof(g_stEcr.szAcqName)-1, pszValue);
    }
    /*=======BEGIN: Jason 2014.12.19  15:59 modify===========*/
    else if (strcmp(pszTag, TAG_ECR_ADJAMT)==0)
    {
        // save amount in ISO8583 DE4 format
        if (strlen(pszValue)<14)
        {
            g_stEcr.szADJamt[12] = 0;
            for (ii=strlen(pszValue)-1, iCnt=11; ii>=0 && iCnt>=0; ii--)
            {
                if (isdigit(pszValue[ii]))
                {
                    g_stEcr.szADJamt[iCnt] = pszValue[ii];
                    iCnt--;
                }
            }
            while (iCnt>=0)
            {
                g_stEcr.szADJamt[iCnt] = '0';
                iCnt--;
            }
        }
    }
    else if (strcmp(pszTag, TAG_ECR_PWD)==0)
    {
        for (ii=0, iCnt=0; ii <= (int)strlen(pszValue); ii++)
        {
            if (isdigit(pszValue[ii]))
            {
                g_stEcr.sPassword[iCnt] = pszValue[ii];
                iCnt++;
            }
        }
        g_stEcr.sPassword[iCnt+1]= 0;
    }
//ECR reference number is carried in F62 instead of F63 ID 04
    else if (strcmp(pszTag, TAG_ECR_ECRREF)==0)
    {
        sprintf(glProcInfo.stTranLog.szECRRRN, "%.*s", sizeof(glProcInfo.stTranLog.szECRRRN)-1, pszValue);
    }
    /*====================== END======================== */
    /*=======BEGIN: Jason 2015.03.26  10:55 modify===========*/
    //DATE
    else if (strcmp(pszTag, TAG_ECR_DATE)==0)
    {
        sprintf(g_stEcr.szDate, "%.*s", sizeof(g_stEcr.szDate)-1, pszValue);
#ifdef Jason_Debug
        ScrCls();
        ScrPrint(0, 0, 0, "szDate=%s",g_stEcr.szDate);
        getkey();
#endif

    }
    else if (strcmp(pszTag, TAG_ECR_APPCODE)==0)
    {
        sprintf(g_stEcr.szAuthCode, "%.*s", sizeof(g_stEcr.szAuthCode)-1, pszValue);
#ifdef Jason_Debug
        ScrCls();
        ScrPrint(0, 0, 0, "szAuthCode=%s",g_stEcr.szAuthCode);
        getkey();
#endif

    }
    else if (strcmp(pszTag, TAG_ECR_RRN)==0)
    {
        sprintf(g_stEcr.szRRN, "%.*s", sizeof(g_stEcr.szRRN)-1, pszValue);
    }
    /*====================== END======================== */
    else
    {
        return -1;
    }

    return 0;
}

static int GetAllEcrElements(void *pszEcrMsg)
{
    char    szBuff[MAX_ECR_MSGLEN+1], szTag[MAX_ECR_TAGLEN+1], szValue[MAX_ECR_VALUELEN+1];
    char    *pStart, *pEnd, *pEqual, *pNow;
    int     iLen, iRet;

    ///zeeeeed

 OsLog(LOG_ERROR,"CASH AS IS : %s",pszEcrMsg);


    iLen = strlen(pszEcrMsg);    // Check length
    if (iLen>MAX_ECR_MSGLEN)
    {
        return RET_ECR_ERR_SYNTAX;
    }

    pStart = strstr(pszEcrMsg, TAG_ECR_START);    // Locate start
    if (pStart==NULL)
    {
        return RET_ECR_ERR_SYNTAX;
    }
    pStart += strlen(TAG_ECR_START);

    pEnd = strstr(pStart, TAG_ECR_END);    // Locate end
    if (pEnd==NULL)
    {
        return RET_ECR_ERR_SYNTAX;
    }

    memset(szBuff, 0, sizeof(szBuff));    // Get msg body
    memcpy(szBuff, pStart, pEnd-pStart-1);// ignore last ',' in string



    pNow = szBuff;
    while (strlen(pNow)!=0)
    {
        pStart = strstr(pNow, STR_QUOTE);
        if (pStart==NULL)
        {
            EcrShowDebug("ERR START QUOTE");
            return RET_ECR_ERR_SYNTAX;
        }
        pEnd = strstr(pNow+1, STR_QUOTE);
        if (pEnd==NULL)
        {
            EcrShowDebug("ERR END QUOTE");
            return RET_ECR_ERR_SYNTAX;
        }
        pEqual = strstr(pNow+1, STR_EQUAL);
        if ((pEqual==NULL) || (pEqual>pEnd) || (pEqual<pStart))
        {
            EcrShowDebug("ERR EQUAL");
            return RET_ECR_ERR_SYNTAX;
        }

        iLen = pEqual-pStart-1;
        if ((iLen==0) || (iLen>MAX_ECR_TAGLEN))
        {
            EcrShowDebug("ERR TAGLEN");
            return RET_ECR_ERR_SYNTAX;
        }

        iLen = pEnd-pEqual-1;
        if ((iLen==0) || (iLen>MAX_ECR_VALUELEN))
        {
            EcrShowDebug("ERR VALUELEN");
            return RET_ECR_ERR_SYNTAX;
        }

        sprintf(szTag,   "%.*s", pEqual-pStart-1, pStart+1);
        sprintf(szValue, "%.*s", pEnd-pEqual-1,   pEqual+1);

        iRet = UnpackEcrData(szTag, szValue);

        pNow = pEnd+1;
        if (*pNow==',')
        {
            pNow++;
        }
    }

    return 0;
}

int EcrTrans(void *pszEcrMsg)
{
    int iRet;

    memset(&g_stEcr, 0, sizeof(g_stEcr));
    iRet = GetAllEcrElements(pszEcrMsg);
    if (iRet!=0)
    {
        PubBeepErr();
        Gui_ShowMsgBox(_T("ECR MESSAGE"), gl_stTitleAttr, _T("INVALID ECR MESSAGE"), gl_stCenterAttr, GUI_BUTTON_CANCEL, 5, NULL);
        return ERR_NO_DISP;
    }

    // If it is a CHECK LINE STATUS message
    if ((strlen((char *)g_stEcr.szTxnID)!=0) && (atoi((char *)g_stEcr.szTxnID)==0)
        && (g_stEcr.ucTranType==VAL_ECRCMD_NONE))
    {
        iRet = EcrSendAckStr();
        if (iRet==0)
        {

            PubBeepOk();

        }
        return iRet;
    }

    sprintf(glProcInfo.stTranLog.szEcrTxnNo,    "%.6s", g_stEcr.szTxnNo);
    sprintf(glProcInfo.stTranLog.szEcrConseqNo, "%.4s", g_stEcr.szTxnConseqNo);
    glProcInfo.ucEcrCtrl = ECR_BEGIN;

    // TODO : process different transactions below
    if (g_stEcr.ucTranType==VAL_ECRCMD_SALE)
    {

        iRet = TransSale(g_stEcr.bTranInstallment);
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }
        CommOnHook(FALSE);
        PromptRemoveICC();
        return iRet;
    }
    else if (g_stEcr.ucTranType==VAL_ECRCMD_VOID)
    {
        iRet = TransVoid();
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }
        CommOnHook(FALSE);
        PromptRemoveICC();
        return iRet;
    }
    else if (g_stEcr.ucTranType==VAL_ECRCMD_GETTXN)
    {
        g_stEcr.bDetailRequired = TRUE;
        iRet = GetRecordByInvoice(g_stEcr.ulInvoice, TS_ALL_LOG, &glProcInfo.stTranLog);
        if( iRet!=0 )
        {
            EcrSendTranFail();
            return ERR_NO_DISP;
        }
        FindAcq(glProcInfo.stTranLog.ucAcqKey);
        FindIssuer(glProcInfo.stTranLog.ucIssuerKey);
       // MirroringSendEcr("PLS REMOVE CARD1");
        return EcrSendTransSucceed();
    }
    else if (g_stEcr.ucTranType==VAL_ECRCMD_GETTOTAL)
    {
        iRet = FindAcqIdxByName(g_stEcr.szAcqName, TRUE);
        if (iRet>=MAX_ACQ)
        {
            EcrSendTranFail();
            PubBeepErr();
            return ERR_NO_DISP;
        }
        SetCurAcq((uchar)iRet);
        CalcTotal(glCurAcq.ucKey);
        return EcrSendAcqTotal();
    }
    /*=======BEGIN: Jason 2014.12.19  16:0 modify===========*/
//add adjust tip
    else if (g_stEcr.ucTranType==VAL_ECRCMD_ADJUST)
    {
        iRet = TransAdjust();
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }
        CommOnHook(FALSE);
       // MirroringSendEcr("PLS REMOVE CARD2");
        return EcrSendTransSucceed();
    }

    //add PREAUTH
    else if (g_stEcr.ucTranType==VAL_ECRCMD_PREAUTH)
    {
        iRet = TransAuth(PREAUTH);
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }
        g_stEcr.ucCardType = 0;
        CommOnHook(FALSE);
        PromptRemoveICC(); //added by Kim
       // MirroringSendEcr("PLS REMOVE CARD3");
        return EcrSendTransSucceed();
    }

    //add RREAUTH COMPLETION
    else if (g_stEcr.ucTranType==VAL_ECRCMD_PREAUTHOK)
    {
        iRet =TransOffSale();
        if (iRet!=0)
        {
            EcrSendTranFail();
        }
       // MirroringSendEcr("PLS REMOVE CARD4");
        return EcrSendTransSucceed();
    }

    //add refund
    else if (g_stEcr.ucTranType==VAL_ECRCMD_REFUND)
    {
        iRet = TransRefund();
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }

        CommOnHook(FALSE);
        PromptRemoveICC();
       // MirroringSendEcr("PLS REMOVE CARD5");
        return EcrSendTransSucceed();
    }

    //add settle
    else if (g_stEcr.ucTranType==VAL_ECRCMD_SETTLE)
    {
        iRet = TransSettle();
        if (iRet!=0)
        {
            EcrSendTranFail();
        }
        CommOnHook(FALSE);
       // MirroringSendEcr("PLS REMOVE CARD6");
        return EcrSendTransSucceed();
    }

    //add reprint
    else if (g_stEcr.ucTranType==VAL_ECRCMD_REPRINT)
    {
        if (1 == EcrGetTxnID())
        {
            PrnLastTrans();
           // MirroringSendEcr("PLS REMOVE CARD7");
            return EcrSendTransSucceed();
        }
        else if (2 == EcrGetTxnID())
        {
            RePrnSettle();
            //MirroringSendEcr("PLS REMOVE CARD8");
            return EcrSendTransSucceed();
        }
        else
        {
            RePrnSpecTrans();
           // MirroringSendEcr("PLS REMOVE CARD9");
            return EcrSendTransSucceed();
        }
    }

    else if (g_stEcr.ucTranType==VAL_ECRCMD_INSTALLMENT)
    {
        iRet = TransSale(TRUE);
        if (iRet!=0)
        {
        	MirroringSendEcr("PLS REMOVE CARD");
            EcrSendTranFail();
        }

        CommOnHook(FALSE);
        PromptRemoveICC();
       // MirroringSendEcr("PLS REMOVE CARD10");
        return EcrSendTransSucceed();
    }
    return 0;
}

int EcrGetAmount(uchar *pszAmount, uchar *pszTip)
{
    if (strlen(g_stEcr.szAmount)!=0)
    {
        sprintf(pszAmount, "%.12s", g_stEcr.szAmount);
        sprintf(pszTip, "000000000000");
        return 0;
    }
    return -1;
}
/*=======BEGIN: Jason 2015.03.26  11:4 modify===========*/
int EcrGetDate(uchar *pszDate)
{
    if (strlen(g_stEcr.szDate)!=0)
    {
        sprintf(pszDate, "%.4s", g_stEcr.szDate);
        return 0;
    }
    return -1;
}
int EcrGetAppCode(uchar *szAppCode)
{
    if (strlen(g_stEcr.szAuthCode)!=0)
    {
        sprintf((char *)szAppCode, "%.6s",g_stEcr.szAuthCode);
        return 0;
    }

    return -1;
}
/*====================== END======================== */
/*=======BEGIN: Jason 2014.12.19  16:2 modify===========*/
int EcrGetADJamt(uchar *pszADJAmount)
{
    if (strlen(g_stEcr.szADJamt)!=0)
    {
        sprintf(pszADJAmount, "%.12s", g_stEcr.szADJamt);
        return 0;
    }
    return -1;
}
//��?��??����a
int EcrGetPwd(uchar *pszPwd)
{
    if (strlen(g_stEcr.sPassword)!=0)
    {
        sprintf(pszPwd, "%s", g_stEcr.sPassword);
        return 0;
    }
    return -1;
}

int EcrGetRRN(uchar *szRRN)
{
    if (strlen(g_stEcr.szRRN)!=0)
    {
        sprintf((char *)szRRN, "%.12s",g_stEcr.szRRN);
        return 0;
    }

    return -1;
}

/*====================== END======================== */
unsigned long EcrGetTxnID(void)
{

    memset(szCMDAmount,0,sizeof(szCMDAmount));
    /*=======BEGIN: Jason 2014.12.19  16:3 modify===========*/
    if (0 == memcmp(g_stEcr.szTxnID, "LASTSALE", 8))
    {
        return 1;
    }
    else if (0 == memcmp(g_stEcr.szTxnID, "LASTSETTLE", 10))
    {
        return 2;
    }
    else
        /*====================== END======================== */
    {
       //rana foura
        memset(szCMDAmount,0,sizeof(szCMDAmount));
        strcpy(szCMDAmount,g_stEcr.szAmount);


        return (ulong)atol(g_stEcr.szTxnID);
    }
}

unsigned long  EcrGetInvoice(void)
{
    return g_stEcr.ulInvoice;
}

int EcrGetInstPlan(uchar *pucMonth)
{
    if (g_stEcr.ucInstPlan)
    {
        *pucMonth = g_stEcr.ucInstPlan;
        return 0;
    }
    return -1;
}

int EcrSendAckStr(void)
{
    FNPTR_EcrSend   FuncEcrSend;

    FuncEcrSend = (FNPTR_EcrSend)(glEdcMsgPtr->UserMsg);
    FuncEcrSend((uchar *)STR_ECR_ACK, (ushort)strlen(STR_ECR_ACK));
    return 0;
}

static void StrCatEcrRsp_TxnTypeDateTime(TRAN_LOG *pstLog, char *pszEcrMsgBuff)
{
    uchar   szBuff1[32] = {0}, szBuff2[128] = {0};

    /*=======BEGIN: Jason 2015.01.13  18:42 modify===========*/
    memset(szBuff2,0,sizeof(szBuff2));
    sprintf(szBuff2, "\"TXNTYPE=%s\",",  g_stEcr.szCmdText);
    strcat(pszEcrMsgBuff, szBuff2);

    memset(szBuff2,0,sizeof(szBuff2));
    /*====================== END======================== */
    //PubGetDateTime(szBuff1);
    sprintf(szBuff2, "\"TXNDATE=%.8s\",", pstLog->szDateTime);
    strcat(pszEcrMsgBuff, szBuff2);
    sprintf(szBuff2, "\"TXNTIME=%.4s\",", pstLog->szDateTime+8);
    strcat(pszEcrMsgBuff, szBuff2);
}

int EcrSendTransSucceed(void)
{
    char    szEcrMsgBuff[MAX_ECR_MSGLEN+1], szBuff[192];
    FNPTR_EcrSend   FuncEcrSend;
    int iCnt = 0 ; //Jason 2015.01.05 16:42


    if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
    {
        sprintf(szEcrMsgBuff, TAG_ECR_START);

   //hasan foura ECR
        //glProcInfo.stTranLog.szECRRRN ;
        //glProcInfo.stTranLog.szHolderName;
        ///end
        strcat(szEcrMsgBuff, "\"STATUS=A\",");
        /*=======BEGIN: Jason 2015.01.05  16:31 modify===========*/
        if (strlen(glProcInfo.stTranLog.szRspCode)!=0)
        {
            memset(szBuff,0,sizeof(szBuff));
            sprintf(szBuff, "\"RESPONSECODE=%s\",", glProcInfo.stTranLog.szRspCode);
            strcat(szEcrMsgBuff, szBuff);
//======================
           // memset(szBuff,0,sizeof(szBuff));
             //sprintf(szBuff, "\"RRN=%s\",", glProcInfo.stTranLog.szRRN);
            // strcat(szEcrMsgBuff, szBuff);
            // memset(szBuff,0,sizeof(szBuff));//CARDHOLDERNAME
           //  sprintf(szBuff, "\"CARDHOLDERNAME=%s\",", glProcInfo.stTranLog.szHolderName);
           //  strcat(szEcrMsgBuff, szBuff);




 //==============================

            for(iCnt=0; glHostErrMsg[iCnt].szRspCode[0]!=0; iCnt++)
            {
                if( memcmp(glProcInfo.stTranLog.szRspCode, glHostErrMsg[iCnt].szRspCode, 2)==0 )
                {
                    break;
                }
            }
            memset(szBuff,0,sizeof(szBuff));
            sprintf(szBuff, "\"RSPTEXT=%s\",",(char *)(glHostErrMsg[iCnt].szMsg));
            strcat(szEcrMsgBuff, szBuff);

        }
        memset(szBuff,0,sizeof(szBuff));
        sprintf(szBuff+32, "%06lu", glProcInfo.stTranLog.ulInvoiceNo);
        sprintf(szBuff, "\"TXNID=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);
        /*====================== END======================== */

        StrCatEcrRsp_TxnTypeDateTime(&glProcInfo.stTranLog, szEcrMsgBuff);

        sprintf(szBuff, "\"APPCODE=%s\",", glProcInfo.stTranLog.szAuthCode);
        strcat(szEcrMsgBuff, szBuff);

        MaskPan(glProcInfo.stTranLog.szPan, szBuff+32);
        sprintf(szBuff, "\"PAN=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);

        sprintf(szBuff, "\"EXPDATE=%.2s%.2s\",", glProcInfo.stTranLog.szExpDate+2, glProcInfo.stTranLog.szExpDate);
        strcat(szEcrMsgBuff, szBuff);

        PubConvAmount(NULL, glProcInfo.stTranLog.szAmount, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                      glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
        sprintf(szBuff, "\"AMT=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);
        /*=======BEGIN: Jason 2014.12.20  14:25 modify===========*/
        //??����?{??����????����?{???e?~
        if (g_stEcr.ucTranType==VAL_ECRCMD_ADJUST)
        {
            PubConvAmount(NULL, g_stEcr.szADJamt, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                          glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
            sprintf(szBuff, "\"ADJAMT=%s\",", szBuff+32);
            strcat(szEcrMsgBuff, szBuff);
        }


        if (glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT)

     //   if (!ChkIfPrnSignature())
        {
            strcat(szEcrMsgBuff, "\"NOSIGN=Y\",");
            //strcat(szEcrMsgBuff, "\"STT=Y\",");
        }
        else
        {
            strcat(szEcrMsgBuff, "\"NOSIGN=N\",");
            //strcat(szEcrMsgBuff, "\"STT=N\",");
        }

        //��Y?e?T?~
        if (glProcInfo.stTranLog.szPan[0]=='4')
        {
            if (glSysParam.stEdcInfo.ulNoSignLmtVisa ==0)
            {
                //return TRUE; //o???
            }
            else
            {
                sprintf((char *)szBuff, "%lu", glSysParam.stEdcInfo.ulNoSignLmtVisa);
                AmtConvToBit4Format((char *)szBuff, glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit);
                // Now szBuff is local floor limit
                if( memcmp(glProcInfo.stTranLog.szAmount, szBuff, 12)>=0 )
                {
                    //return TRUE;
                    strcat(szEcrMsgBuff, "\"STT=N\",");
                }
                else
                {
                    strcat(szEcrMsgBuff, "\"STT=Y\",");
                }
            }
        }
        else if (glProcInfo.stTranLog.szPan[0]=='5')
        {
            if (glSysParam.stEdcInfo.ulNoSignLmtMaster == 0)
            {
                //return TRUE;
            }
            else
            {
                sprintf((char *)szBuff, "%lu", glSysParam.stEdcInfo.ulNoSignLmtMaster);
                AmtConvToBit4Format((char *)szBuff, glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit);
                // Now szBuff is local floor limit
                if( memcmp(glProcInfo.stTranLog.szAmount, szBuff, 12)>=0 )
                {
                    //return TRUE;
                    strcat(szEcrMsgBuff, "\"STT=N\",");
                }
                else
                {
                    strcat(szEcrMsgBuff, "\"STT=Y\",");
                }
            }
        }
        else if (memcmp(glProcInfo.stTranLog.szPan,"34",2)== 0 || memcmp(glProcInfo.stTranLog.szPan,"37",2)==0)
        {
            if (glSysParam.stEdcInfo.ulNoSignLmtAmex==0)
            {
                //return TRUE;
            }
            else
            {
                sprintf((char *)szBuff, "%lu", glSysParam.stEdcInfo.ulNoSignLmtAmex);
                AmtConvToBit4Format((char *)szBuff, glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit);
                // Now szBuff is local floor limit
                if( memcmp(glProcInfo.stTranLog.szAmount, szBuff, 12)>=0 )
                {
                    //return TRUE;
                    strcat(szEcrMsgBuff, "\"STT=N\",");
                }
                else
                {
                    strcat(szEcrMsgBuff, "\"STT=Y\",");
                }
            }
        }

        // settle ACQNAME
        if (SETTLEMENT == glProcInfo.stTranLog.ucTranType)
        {
            strcat(szEcrMsgBuff, "\"ACQNAME=PAX\",");
        }
        /*====================== END======================== */
        // When "DETAIL=Y"
        if (g_stEcr.bDetailRequired)
        {
            if( glProcInfo.stTranLog.uiEntryMode & MODE_SWIPE_INPUT )
            {
                strcat(szEcrMsgBuff, "\"ENTRYMODE=S\",");
            }
            else if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
            {
                strcat(szEcrMsgBuff, "\"ENTRYMODE=C\",");
            }
            else if( (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_SWIPE) ||
                     (glProcInfo.stTranLog.uiEntryMode & MODE_FALLBACK_MANUAL) )
            {
                strcat(szEcrMsgBuff, "\"ENTRYMODE=F\",");
            }
            else
            {
                strcat(szEcrMsgBuff, "\"ENTRYMODE=M\",");
            }

#if 0//Jason 2015.01.05 16:20
            sprintf(szBuff+32, "%06lu", glProcInfo.stTranLog.ulInvoiceNo);
            sprintf(szBuff, "\"INVOICENO=%s\",", szBuff+32);
            strcat(szEcrMsgBuff, szBuff);
#endif
            sprintf(szBuff, "\"TERMINALID=%s\",", glCurAcq.szTermID);
            strcat(szEcrMsgBuff, szBuff);

            sprintf(szBuff, "\"MERCHANTID=%s\",", glCurAcq.szMerchantID);
            strcat(szEcrMsgBuff, szBuff);

            ConvIssuerName(glCurIssuer.szName, szBuff+32);
            sprintf(szBuff, "\"CARDTYPE=%.10s\",", szBuff+32);
            strcat(szEcrMsgBuff, szBuff);

            if (strlen(glProcInfo.stTranLog.szHolderName)!=0)
            {
                sprintf(szBuff, "\"CARDHOLDERNAME=%s\",", glProcInfo.stTranLog.szHolderName);
                strcat(szEcrMsgBuff, szBuff);
            }

            sprintf(szBuff+32, "%06lu", glCurAcq.ulCurBatchNo);
            sprintf(szBuff, "\"BATCHNO=%s\",", szBuff+32);
            strcat(szEcrMsgBuff, szBuff);

            sprintf(szBuff, "\"REFERENCENO=%s\",", glProcInfo.stTranLog.szRRN);
            strcat(szEcrMsgBuff, szBuff);

            if (strlen(g_stEcr.szTxnNo)!=0)
            {
                sprintf(szBuff, "\"TXNNO=%s\",", g_stEcr.szTxnNo);
                strcat(szEcrMsgBuff, szBuff);
            }
            if (strlen(g_stEcr.szTxnConseqNo)!=0)
            {
                sprintf(szBuff, "\"TXNCONSEQUENTIALNO=%s\",", g_stEcr.szTxnConseqNo);
                strcat(szEcrMsgBuff, szBuff);
            }

            if( glProcInfo.stTranLog.uiEntryMode & MODE_CHIP_INPUT )
            {
                if (strlen(glProcInfo.stTranLog.szAppPreferName)!=0)
                {
                    sprintf(szBuff, "\"APP=%.16s\",", glProcInfo.stTranLog.szAppPreferName);
                }
                else
                {
                    sprintf(szBuff, "\"APP=%.16s\",", glProcInfo.stTranLog.szAppLabel);
                }
                strcat(szEcrMsgBuff, szBuff);

                PubBcd2Asc0(glProcInfo.stTranLog.sAID, glProcInfo.stTranLog.ucAidLen, szBuff+32);
                PubTrimTailChars(szBuff+32, 'F');
                sprintf(szBuff, "\"AID=%s\",", szBuff+32);
                strcat(szEcrMsgBuff, szBuff);

                PubBcd2Asc0(glProcInfo.stTranLog.sAppCrypto, 8, szBuff+32);
                sprintf(szBuff, "\"TC=%s\",", szBuff+32);
                strcat(szEcrMsgBuff, szBuff);
                /*=======BEGIN: Jason 2014.12.20  14:26 modify===========*/
                PubBcd2Asc0(glProcInfo.stTranLog.sTSI, 2, szBuff+32);//+8?
                sprintf(szBuff, "\"TSI=%s\",", szBuff+32);
                strcat(szEcrMsgBuff, szBuff);

                PubBcd2Asc0(glProcInfo.stTranLog.sTVR, 5, szBuff+32);// +20?
                sprintf(szBuff, "\"TVR=%s\",", szBuff+32);
                strcat(szEcrMsgBuff, szBuff);

                PubBcd2Asc0(glProcInfo.stTranLog.sATC, 2, szBuff+32);// +8?
                sprintf(szBuff, "\"ATC=%s\",", szBuff+32);
                strcat(szEcrMsgBuff, szBuff);
                /*====================== END======================== */
            }
        }

        strcat(szEcrMsgBuff, TAG_ECR_END);

        FuncEcrSend = (FNPTR_EcrSend)(glEdcMsgPtr->UserMsg);
        FuncEcrSend((uchar *)szEcrMsgBuff, (ushort)strlen(szEcrMsgBuff));
        glProcInfo.ucEcrCtrl = ECR_SUCCEED;
    }
    return 0;
}

int EcrSendTranFail(void)
{
    char    szEcrMsgBuff[MAX_ECR_MSGLEN+1];
    FNPTR_EcrSend   FuncEcrSend;

    if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
    {
        sprintf(szEcrMsgBuff, TAG_ECR_START);
        strcat(szEcrMsgBuff, "\"STATUS=R\",");
        StrCatEcrRsp_TxnTypeDateTime(&glProcInfo.stTranLog, szEcrMsgBuff);
        strcat(szEcrMsgBuff, TAG_ECR_END);

        // send response
        FuncEcrSend = (FNPTR_EcrSend)(glEdcMsgPtr->UserMsg);
        FuncEcrSend((uchar *)szEcrMsgBuff, (ushort)strlen(szEcrMsgBuff));
        glProcInfo.ucEcrCtrl = ECR_REJECT;
    }
    return 0;
}

int EcrSendAcqTotal(void)
{
    char    szEcrMsgBuff[MAX_ECR_MSGLEN+1], szBuff[192];
    FNPTR_EcrSend   FuncEcrSend;

    if (glProcInfo.ucEcrCtrl==ECR_BEGIN)
    {
        sprintf(szEcrMsgBuff, TAG_ECR_START);

        sprintf(szBuff, "\"ACQNAME=%s\",", g_stEcr.szAcqName);
        strcat(szEcrMsgBuff, szBuff);

        sprintf(szBuff, "\"SALENUM=%d\",", (int)glTransTotal.uiSaleCnt);
        strcat(szEcrMsgBuff, szBuff);
        PubConvAmount(NULL, glTransTotal.szSaleAmt, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                      glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
        sprintf(szBuff, "\"SALEAMT=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);

        sprintf(szBuff, "\"VOIDNUM=%d\",", (int)glTransTotal.uiVoidSaleCnt);
        strcat(szEcrMsgBuff, szBuff);
        PubConvAmount(NULL, glTransTotal.szVoidSaleAmt, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                      glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
        sprintf(szBuff, "\"VOIDAMT=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);

        sprintf(szBuff, "\"REFUNDNUM=%d\",", (int)glTransTotal.uiRefundCnt);
        strcat(szEcrMsgBuff, szBuff);
        PubConvAmount(NULL, glTransTotal.szRefundAmt, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                      glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
        sprintf(szBuff, "\"REFUNDAMT=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);

        sprintf(szBuff, "\"VRFNUM=%d\",", (int)glTransTotal.uiVoidRefundCnt);
        strcat(szEcrMsgBuff, szBuff);
        PubConvAmount(NULL, glTransTotal.szVoidRefundAmt, glSysParam.stEdcInfo.stLocalCurrency.ucDecimal,
                      glSysParam.stEdcInfo.stLocalCurrency.ucIgnoreDigit, szBuff+32, 0);
        sprintf(szBuff, "\"VRFAMT=%s\",", szBuff+32);
        strcat(szEcrMsgBuff, szBuff);

        strcat(szEcrMsgBuff, TAG_ECR_END);

        FuncEcrSend = (FNPTR_EcrSend)(glEdcMsgPtr->UserMsg);
        FuncEcrSend((uchar *)szEcrMsgBuff, (ushort)strlen(szEcrMsgBuff));
        glProcInfo.ucEcrCtrl = ECR_SUCCEED;
    }
    return 0;
}

// end of file
