/*
 * Port.h
 *
 *  Created on: 2012-12-4
 *      Author: wenjf
 */

#ifndef PORT_H_
#define PORT_H_

#include "structDefine.h"

typedef struct{
	int prolin_ret;
	uchar monitor_ret;
}PORT_RESULT;

/******************通信口******************/
uchar PortOpen(uchar channel, uchar *Attr);
uchar PortClose(uchar channel);
uchar PortSend(uchar channel, uchar ch);
uchar PortRecv(uchar channel, uchar *ch, uint ms);
uchar PortReset(uchar channel);
uchar PortSends(uchar channel, uchar *str, ushort str_len);
uchar PortTxPoolCheck(uchar channel);
//int PortPeep(uchar channel,uchar *buf,ushort len);
int PortRecvs(uchar channel, uchar * pszBuf, ushort usBufLen, ushort usTimeoutMs);
int SetHeartBeat(int SwOn, int MsgLen, const unsigned char *Msg, ushort interval100Ms,int COMn);


#endif /* PORT_H_ */
