/*
 * Copyright (c), 2001-2013, PAX. Co.,Ltd.
 *
 * File Name		: crypt.h
 *
 * Version		: rsakey.h-v1.0
 *
 * Author			:
 *
 * Created		: 27/9/2013
 *
 * Description		: crypt.c header file
 *
 * Function List	:
 *
 * History		:
   1.Date         	: 27/9/2013
     Author       	: 
     Modification 	: Created file
 */

#ifndef __CRYPT_H__
#define __CRYPT_H__


#ifdef __cplusplus
#if __cplusplus
extern "C"{
#endif
#endif /* __cplusplus */


#include "structDefine.h"

/*---------------------------------------------------------------------------*
 * Include Files        					                           					        *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * Macros                                       												 *
 *---------------------------------------------------------------------------*/
	

	
//#define MAX_RSA_MODULUS_BITS 2048
//
//#define MAX_RSA_MODULUS_LEN ((MAX_RSA_MODULUS_BITS + 7) / 8)
//#define MAX_RSA_PRIME_BITS ((MAX_RSA_MODULUS_BITS + 1) / 2)
//#define MAX_RSA_PRIME_LEN ((MAX_RSA_PRIME_BITS + 7) / 8)


/*---------------------------------------------------------------------------*
 * Local Structures and Typedefs                  							 			 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * Constants                                    							 				 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * Local  Variables				                  							  			 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * External Variables			                							 			 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * Internal Routine Prototypes	                 							 			 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * External Routine Prototypes	                 										 *
 *---------------------------------------------------------------------------*/

/*---------------------------------------------------------------------------*
 * Routines' Implementations	                							 			 *
 *---------------------------------------------------------------------------*/

//typedef struct {
//  unsigned short int bits;                     /* length in bits of modulus */
//  unsigned char modulus[MAX_RSA_MODULUS_LEN];  /* modulus */
//  unsigned char exponent[MAX_RSA_MODULUS_LEN]; /* public exponent */
//} R_RSA_PUBLIC_KEY;
//
//typedef struct {
//  unsigned short int bits;                     /* length in bits of modulus */
//  unsigned char modulus[MAX_RSA_MODULUS_LEN];  /* modulus */
//  unsigned char publicExponent[MAX_RSA_MODULUS_LEN];     /* public exponent */
//  unsigned char exponent[MAX_RSA_MODULUS_LEN]; /* private exponent */
//  unsigned char prime[2][MAX_RSA_PRIME_LEN];   /* prime factors */
//  unsigned char primeExponent[2][MAX_RSA_PRIME_LEN];     /* exponents for CRT */
//  unsigned char coefficient[MAX_RSA_PRIME_LEN];          /* CRT coefficient */
//} R_RSA_PRIVATE_KEY;

void des(unsigned char *input, unsigned char *output, unsigned char *deskey, int mode);
void Hash(unsigned char *DataIn, unsigned char DataInLen, unsigned char *DataOut);
int RSARecover(unsigned char *pbyModule, unsigned int dwModuleLen, unsigned char *pbyExp, unsigned int dwExpLen, unsigned char *pbyDataIn, unsigned char *pbyDataOut);
int RSAKeyPairGen(R_RSA_PUBLIC_KEY *pPublicKey,R_RSA_PRIVATE_KEY *pPrivateKey,int iProtoKeyBit,int iPubEType);
int RSAKeyPairVerify(R_RSA_PUBLIC_KEY puk,R_RSA_PRIVATE_KEY pvk);

#ifdef __cplusplus
#if __cplusplus
}
#endif
#endif /* __cplusplus */


#endif /* __RSAKEY_H__ */


