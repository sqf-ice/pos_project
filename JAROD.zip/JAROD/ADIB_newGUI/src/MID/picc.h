#ifndef PICC_H_
#define PICC_H_

#include "structDefine.h"

uchar PiccOpen(void);
uchar PiccSetup(uchar mode, PICC_PARA *picc_para);	
uchar PiccDetect(uchar Mode,uchar *CardType,uchar *SerialInfo,uchar *CID,uchar *Other);
uchar PiccIsoCommand(uchar cid, APDU_SEND *ApduSend, APDU_RESP *ApduRecv);
uchar PiccRemove(uchar mode, uchar cid);
uchar PiccClose(void);

uchar M1Authority(uchar Type, uchar BlkNo, uchar *Pwd, uchar *SerialNo);
uchar M1ReadBlock(uchar BlkNo, uchar *BlkValue);
uchar M1WriteBlock (uchar BlkNo, uchar *BlkValue);
uchar M1Operate(uchar Type, uchar BlkNo, uchar *Value, uchar UpdateBlkNo);
uchar PiccInitFelica(uchar ucRate, uchar ucPol);
uchar PiccCmdExchange(int uiSendLen, uchar* paucInData, int* puiRecLen, uchar* paucOutData);


#endif
