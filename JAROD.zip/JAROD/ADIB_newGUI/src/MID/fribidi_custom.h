/*
 ============================================================================
 Name        : fribidi.h
 Author      : PAX
 Version     : 
 Copyright   : PAX Computer Technology(Shenzhen) CO., LTD
 Description : PAX POS Shared Library
 ============================================================================
 */
 
 
#ifndef SHARED_LIBRARY_H_fribidi
#define SHARED_LIBRARY_H_fribidi

#include "MID/fribidi/fribidi.h"

#ifdef __cplusplus
extern "C"
{
#endif


char *bidi_utf8strdup(char *str);


#ifdef __cplusplus
};
#endif

#endif /* SHARED_LIBRARY_H_fribidi */

