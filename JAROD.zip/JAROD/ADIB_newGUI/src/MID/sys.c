/*
 * MIDsys.c
 *
 *  Created on: 2012-11-29
 *      Author: xiaowy
 */
#include <dirent.h>
#include <pthread.h>
#include <sys/reboot.h>
#include <sys/ioctl.h>
#include <sys/socket.h>
#include <signal.h>
#include <linux/if.h>
#include <linux/sockios.h>
#include <linux/ethtool.h>
#include <time.h>
#include <sys/times.h>
#include "../posapi.h"
#include "./undef.h"
//#include "file.h"
#include <cbinder.h>
#include <iniparser.h>

#ifndef SYSTEMINITDATA
#define SYSTEMINITDATA "./SYSTEMINITDATA"
#endif

#ifndef SYSTEMAPPINFOPATH
#define SYSTEMAPPINFOPATH	"appinfo"
#endif

#define MS 1000
#define CLOCK_TICKS sysconf(_SC_CLK_TCK)

#define MID_VERSION  "v2.1"


typedef struct
{
	char name[256];

}FileName;
extern int CopyFile(char *filefrom, char *fileto, int mode);
extern int GetDirFileNum(char *dirpath);
extern int GetDirFolderNum(char *dirpath);
extern int GetDirFileName(char *pszPath, FileName *psFileName);
extern int GetDirFolderName(char *pszPath, FileName *psFolderName);
extern int CopyFiles(char *dirfrom, char *dirto, int mode);
extern int CopyFolder(char *dirfrom, char *dirto, int mode);
extern int chmodDir(char *pszDirPath, int mode);

static TTIMER g_timer_list[128]={{0}};

void *g_BinderSrv = NULL;
struct binder_state *g_BinderState = NULL;

typedef struct
{
    uchar   code;
    uchar   model[16];
} MACHINE_MODELS;
MACHINE_MODELS  g_MachModels[]  =
{
    {1, "P60-S"},
    {2, "P70"},
    {3, "P60-S1"},
    {4, "P80"},
    {5, "P78"},
    {6, "P90"},
    {7, "S80"},
    {8, "SP30"},
    {9, "S60"},
    {10,"S90"},
    {11,"S78"},
    {12,"MT30"},
    {13,"T52"},
    {14,"S58"},
    {15,"D200"},
    {16,"D210"},
    {17,"D300"},
    {18,"T610"},
    {19,"T620"},
    {0x80,"R50"},
    {0x81,"P50"},
    {0x82,"P58"},
    {0x83,"R30"},
    {0x84,"R50-M"},
    {0x86,"T60"},
    {0x87,"D100"},
    {0x88,"T100"},
    {0x89,"S200"},
    // Modified by Kim 20150116 bug609
    {20,"S300"},
    {21,"S800"},
    {22,"S900"},
    {24,"S920"},
};

int GetMidVersion(char* ver)
{
	if(NULL == ver)
		return -1;
	strcpy(ver,MID_VERSION);
	return 0;
}

// 0: no
// 1: yes
char ChkIfMainApp()
{
	char szPath[256] = {0};

	getcwd(szPath, sizeof(szPath));
	if (strcmp(szPath, "/data/app/MAINAPP") == 0)
	{
		return 1;
	}
	else
	{
		return 0;
	}
}

void  TimerSet(uchar cTimerNo, int iCnts)
{
  iCnts = iCnts <= 65535 ? iCnts : 65535;
  g_timer_list[cTimerNo].start = OsGetTickCount();
  g_timer_list[cTimerNo].stop  = g_timer_list[cTimerNo].start + iCnts*100;
  g_timer_list[cTimerNo].timeleft = (g_timer_list[cTimerNo].stop - g_timer_list[cTimerNo].start)/100;
}

int TimerCheck(uchar cTimerNo)
{
  long timerleft;
  unsigned long curtime;
  if (g_timer_list[cTimerNo].timeleft == 0)
  {
	return 0 ;
  }
  curtime = OsGetTickCount();

  timerleft = ((long)(g_timer_list[cTimerNo].stop - curtime))/100; 
  if (timerleft < 0)
   {
     timerleft = 0;
   }
   g_timer_list[cTimerNo].timeleft = timerleft;
   return (int)timerleft;
}

void Mid_OpenDevice()
{
	LogInit(0xFF, 0xFF, 0xFFFFFFFF);

	OsPedOpen();
	OsIccOpen(ICC_USER_SLOT);
}

void Mid_CloseDevice()
{
	OsPedClose();
	OsIccClose(ICC_USER_SLOT);
	OsMsrClose();
	OsPrnClose();
	OsPortClose(0);
	OsPortClose(1);
	OsModemClose();
	OsWlLogout();
 	 //OsWifiClose();
}

//////////////////////////////////////////////////////////
static unsigned s1_token;
char *strtoupper(char* str)
{
    while (*str)
    {
        *str = toupper(*str);
        str++;
    }
	return str;
}

uchar mySetTime(uchar *time)
{
	char szTimeBuf[20];
	char szBuf[10];
	ST_TIME stCurTime;
	int iRet;

	MIDPubBcd2Asc0((char *)time, 6, szTimeBuf);
	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf, 2);
	stCurTime.Year = 2000+atoi(szBuf);

	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf+2, 2);
	stCurTime.Month = atoi(szBuf);

	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf+4, 2);
	stCurTime.Day = atoi(szBuf);

	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf+6, 2);
	stCurTime.Hour = atoi(szBuf);

	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf+8, 2);
	stCurTime.Minute = atoi(szBuf);

	memset(szBuf, 0, sizeof(szBuf));
	memcpy(szBuf, szTimeBuf+8, 2);
	stCurTime.Second = atoi(szBuf);

	iRet = OsSetTime(&stCurTime);
	if (iRet != 0)
	{
		return 0xFF;
	}
	else
	{
		return 0;
	}
}

int GetNetlinkStatus(const char *if_name)
{
    int skfd;
    struct ifreq ifr;
    struct ethtool_value edata;

    edata.cmd = ETHTOOL_GLINK;
    edata.data = 0;
    memset(&ifr, 0, sizeof(ifr));
    strncpy(ifr.ifr_name, if_name, sizeof(ifr.ifr_name) - 1);
    ifr.ifr_data = (char *) &edata;
    if (( skfd = socket( AF_INET, SOCK_DGRAM, 0 )) == 0)
    {
    	_LOG(E_LOG, "socket return %d, error=%d", skfd, errno);
        return -1;
    }
    if(ioctl( skfd, SIOCETHTOOL, &ifr ) == -1)
    {
	   	_LOG(E_LOG, "ioctl error, error=%d", errno);
        close(skfd);
        return -1;
    }
    close(skfd);
    return edata.data;
}

static int s1_handler(struct binder_state *bs, struct binder_txn *txn,
	struct binder_io *msg,
	struct binder_io *reply,
	void *data)
{
	char *p = NULL;
	char *p1 = NULL;
	char file[256] = {0};
	char app[128] = {0};
	int ret = 0;
	unsigned int len = 0;


	switch(txn->code) {
	case BID_ADD: {
		int a, b, sum;
		a = bio_get_uint32(msg);
		b = bio_get_uint32(msg);
		sum = a + b;
		bio_put_uint32(reply, sum);
		return 0;
	}
	case BID_STRUPR: {
		char *s;
		char buf[1024];
		s = bio_get_string8(msg, &len);
		if (s == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return NULL");
			return -1;
		}

		strcpy(buf, s); 	// s is readonly
		strtoupper(buf);

		bio_put_uint32(reply, 0); // return code
		bio_put_string8(reply, buf);
		return 0;
	}
	case BID_MEMCPY: {
		char *s1;
		char *s2;
		s2 = bio_get_buffer(msg, &len);
		bio_get_uint32(msg); // ignore it
		s1 = malloc(len);
		memcpy(s1, s2, len);
		bio_put_uint32(reply, 0); // return code
		bio_put_buffer(reply, s1, len);
		free(s1);
		return 0;
	}
	case BID_SLEEP: {
		int n;
//		char *s;
		n = bio_get_uint32(msg);
		sleep(n);
		bio_put_uint32(reply, 0); // return code
		return 0;
	}
	case BID_WRITE: {
		int fd;
		char *s;
		fd = bio_get_fd(msg);
		s = bio_get_buffer(msg, &len);
		ret = write(fd, s, len);
		bio_put_uint32(reply, ret); // return code
		return 0;
	}
	case BID_SETTIME:{
		p = NULL;
		p = bio_get_buffer(msg,&len);
		ret = mySetTime((unsigned char *)p);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_REBOOT:{
		sync();
		sleep(2);
		ret = reboot(RB_AUTOBOOT);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_POWEROFF:{
		sync();
		sleep(2);
		ret = reboot(RB_POWER_OFF);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_FILETOAPP:{
		p = bio_get_string8(msg, &len);
		if (p == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(file, p);
		ret = OsInstallFile(NULL,file,FILE_TYPE_APP);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_FILETOPARAM:{
		p = bio_get_string8(msg, &len);
		p1 = bio_get_string8(msg, &len);
		bio_get_uint32(msg);
		if (p == NULL || p1 == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(file, p);
		strcpy(app, p1);
		ret = OsInstallFile(app,file,FILE_TYPE_APP_PARAM);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_FILETOMON:{
		break;
	}
	case BID_FILETOFONT:{
		p = bio_get_string8(msg, &len);
		if (p == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(file, p);
		ret = OsInstallFile(NULL,file,FILE_TYPE_SYS_LIB);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_FILETOPUK:{
		bio_get_uint32(msg);
		bio_get_uint32(msg);
		p = bio_get_string8(msg, &len);
		if (p == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(file, p);
		ret = OsInstallFile("uspuk0",file,FILE_TYPE_PUB_KEY);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_DELAPPFILE:{
		p = bio_get_string8(msg, &len);
		if (p == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(app, p);
		ret = OsUninstallFile(app,FILE_TYPE_APP);
		bio_put_uint32(reply, ret);
		return 0;
	}
	case BID_LINKSTAT:{
		p = bio_get_string8(msg,&len);
		if (p == NULL)
		{
			_LOG(E_LOG, "bio_get_string8 return null");
			return -1;
		}
		strcpy(app, p);
		ret = GetNetlinkStatus(app);
		bio_put_uint32(reply,ret);
		return 0;
	}
	default:
		return -1;
	}
	return 0;
}
struct binder_state *bs;

void binder_server2(void *arg)
{
	int ret;

	bs = binder_start(1);
	ret = svcmgr_publish(bs, BINDER_SERVICE_MANAGER, "EDC.APP.SER", &s1_token);
	if (ret < 0)
	{
		_LOG(E_LOG, "svcmgr_publish return %d", ret);
		exit(1);
	}

	binder_add_target(bs, &s1_token, s1_handler, NULL);
}

static void CrashReportInit(void)
{
	signal(SIGILL,    OsSaveCrashReport);
	signal(SIGABRT,   OsSaveCrashReport);
	signal(SIGBUS,    OsSaveCrashReport);
	signal(SIGFPE,    OsSaveCrashReport);
	signal(SIGSEGV,   OsSaveCrashReport);
	signal(SIGSTKFLT, OsSaveCrashReport);
	signal(SIGPIPE,   OsSaveCrashReport);
}

uchar SystemInit(void)
{
//	int iRet;
	uchar ucRet = 0x00;
	char szAppName[256] = {0};
	char szTimeStr1[32] = {0};
	char szTimeStr2[32] = {0};
	char szPath[256] = {0};
	struct stat buf;
	FILE *fp;
	unsigned long t;
	static char bFirst = TRUE;

	if(bFirst){
		char value[128];
		char rotate_str[32];
		char statusbar_str[32];
		int ret;
		char *xui_argv[10];
		int  xui_argc;

		CrashReportInit();

		ret = OsRegGetValue("ro.fac.lcd.rotate", value);
		if (ret > 0) {
			snprintf(rotate_str, sizeof(rotate_str), "ROTATE=%s", value);
		}
		else {
			strcpy(rotate_str, "ROTATE=0");
		}

		strcpy(statusbar_str, "STATUSBAR=40");

		xui_argv[0] = rotate_str;
		xui_argv[1] = statusbar_str;
		xui_argv[2] = NULL;
		xui_argc = 2;

		ret = XuiOpen(xui_argc, xui_argv);
		if (ret == XUI_RET_OK) {
		    //XuiCanvasSetBackground(XuiRootCanvas(), XUI_BG_NORMAL, NULL, BLUE);
		    //sg_newstatusbar = XuiCreateCanvas(XuiRootCanvas(), 0,0,XuiRootCanvas()->width, statusbar_height);
		    //XuiShowWindow(sg_newstatusbar, XUI_SHOW,0);
		}
		Mid_OpenDevice();
	}

	if (ChkIfMainApp())
	{
		if(bFirst){
			pthread_t tid=0;
			pthread_create(&tid,NULL,(void *)binder_server2,NULL);
		}
		chmodDir("/data/appinfo", S_IRWXU|S_IRWXG|S_IROTH|S_IXOTH);
		_LOG(T_LOG, "This is main app");
	}
	bFirst = FALSE;
	if(access("./data", W_OK|F_OK) < 0)
	{
		mkdir("./data", S_IRWXU);
	}

	fp = fopen(SYSTEMINITDATA, "rb");
	if(fp == NULL)
	{
		ucRet = 0x00;
	}
	else
	{
		fread(szTimeStr1, 1, sizeof(szTimeStr1), fp);
		fclose(fp);
	}

	getcwd(szPath, sizeof(szPath));
	memmove(szPath+13, szPath+9, strlen(szPath)-9);
	memcpy(szPath+9, "info", 4);
	strcat(szPath, "/appinfo");

	char *p = NULL;
	dictionary *ini;
	ini = iniparser_load(szPath);
	p = iniparser_getstring(ini, "app:bin", "");
	strcpy(szAppName,p);
	iniparser_freedict(ini);

	if(szAppName[0] == 0x00)
	{
		_LOG(E_LOG, "SystemInit: Failed to read app name");
		return 0x00;
	}


	if(stat(szAppName, &buf)<0)
	{
		_LOG(E_LOG, "SystemInit: Failed to read app info");
		return 0x00;
	}
	else
	{
		t = buf.st_mtime;
		int i = 0;
		while(t > 0)
		{
			szTimeStr2[31 - i] = t % 10 + '0';
			t = t / 10;
			i ++;
		}
		memmove(szTimeStr2, &szTimeStr2[32 - i], i);
		szTimeStr2[i] = 0x00;
	}

	if(strcmp(szTimeStr1, szTimeStr2) == 0)
	{
		ucRet = 0xff;
	}
	else
	{
		ucRet = 0x00;
	}

	if(ucRet == 0x00)
	{
		fp = fopen(SYSTEMINITDATA, "w+");
		if(fp == NULL)
		{
			_LOG(E_LOG, "SystemInit: Failed to create SYSTEMINIDATA");
			return 0;
		}
		fseek(fp, 0 ,SEEK_SET);
		fwrite(szTimeStr2, 1, strlen(szTimeStr2), fp);
		fclose(fp);
	}

	return ucRet;	// 0 or 0xff
}

void Beep(void)
{
	OsBeep(7, 100);
}

void Beef(uchar mode, int DlyTime)
{
	OsBeep(mode, DlyTime);
}
void BeepF(uchar mode, int DlyTime)
{
	Beef(mode, DlyTime);
}

int BinderStart(void)
{
	if (g_BinderState == NULL)
	{
		g_BinderState = binder_start(1);
		if (g_BinderState == NULL)
		{
			_LOG(E_LOG, "binder_start return NULL");
		}
	}
	if (g_BinderSrv == NULL)
	{
		g_BinderSrv = svcmgr_lookup(g_BinderState, BINDER_SERVICE_MANAGER, "EDC.APP.SER");
		if (g_BinderSrv == NULL)
		{
			_LOG(E_LOG, "svcmgr_lookup return NULL");
		}
	}

	if (g_BinderState == NULL || g_BinderSrv == NULL)
	{
		return 0;
	}
	return 1;
}

uchar SetTime(uchar *time)
{
    int ret = 0;
    void *srv;
    struct binder_state *bs;
    unsigned iodata[1024] = {0};
    struct binder_io msg, reply;

	if (time == NULL || BinderStart() == 0)
	{
		_LOG(E_LOG, "error! parameter error!");
		return 0xff;
	}
	bs = g_BinderState;
	srv = g_BinderSrv;

	bio_init(&msg, iodata, sizeof(iodata), 4);
	bio_put_buffer(&msg, time, 6);
	OsLog(LOG_ERROR, "%s--%d, %02X %02X %02X %02X %02X %02X", __FILE__, __LINE__, time[0], time[1], time[2], time[3], time[4], time[5]);//linzhao
//	_LOG(T_LOG, "%02X %02X %02X %02X %02X %02X", time[0], time[1], time[2], time[3], time[4], time[5]);
	if (binder_call(bs, &msg, &reply, srv, BID_SETTIME))
	{
		_LOG(E_LOG, "binder_call call failed!");
		OsLog(LOG_ERROR,  "%s--%d, binder_call call failed!", __FILE__, __LINE__);//linzhao
		return 0xff;
	}
	ret = bio_get_uint32(&reply);
	binder_done(bs,&msg,&reply);
	return ret;
}

void GetTime(uchar *szTime)
{
	time_t lClock;
	struct tm *pstTm;
	char tDate[16], tTime[8];

	lClock = time(NULL);
	pstTm = localtime(&lClock);
	sprintf(tDate, "%04d%02d%02d", pstTm->tm_year+1900, pstTm->tm_mon+1,pstTm->tm_mday);
	sprintf(tTime, "%02d%02d%02d", pstTm->tm_hour, pstTm->tm_min, pstTm->tm_sec);

	memmove(tDate, tDate + 2, 6);
	memcpy(tDate + 6, tTime, 6);

	MIDPubAsc2Bcd(tDate, 12, tTime);
	memcpy(szTime, tTime, 6);
	szTime[6] = 0x00;
	return ;
}

void DelayMs(int Ms)
{
	OsSleep(Ms);
}

uchar BatteryCheck(void)
{
	int iRet;

	iRet = OsCheckBattery();
	if (iRet >= BATTERY_LEVEL_0 && iRet <= BATTERY_LEVEL_ABSENT)
	{
		if (iRet == BATTERY_LEVEL_ABSENT)
		{
			iRet = BATTERY_LEVEL_COMPLETE;
		}
		return (uchar)iRet;
	}
	else
	{
		return 0xFF;
	}

}

int Reboot()
{
	int ret = 0;
	void *srv;
	struct binder_state *bs;
	unsigned iodata[1024] = {0};
	struct binder_io msg, reply;

	if (BinderStart() == 0)
	{
		_LOG(E_LOG, "error! parameter error!");
		return -1;
	}
	bs = g_BinderState;
	srv = g_BinderSrv;

	bio_init(&msg, iodata, sizeof(iodata), 4);
	if (binder_call(bs, &msg, &reply, srv, BID_REBOOT))
	{
		_LOG(E_LOG, "binder_call call failed!");
		return -1;
	}
	ret = bio_get_uint32(&reply);
	binder_done(bs,&msg,&reply);
	return ret;
}

void PowerOff(void)
{
//    int ret = 0;
    void *srv;
    struct binder_state *bs;
    unsigned iodata[1024] = {0};
    struct binder_io msg, reply;

	if (BinderStart() == 0)
	{
		_LOG(E_LOG, "error! parameter error!");
		return ;
	}
	bs = g_BinderState;
	srv = g_BinderSrv;

	bio_init(&msg, iodata, sizeof(iodata), 4);
	if (binder_call(bs, &msg, &reply, srv, BID_POWEROFF))
	{
		_LOG(E_LOG, "binder_call call failed!");
		return ;
	}
	bio_get_uint32(&reply);
	binder_done(bs,&msg,&reply);
}


void PciGetRandom(uchar *random)
{
	OsGetRandom(random, 8);
	return;
}

int SysSleep(uchar *DownCtrl)
{
	int iRet;
	iRet = OsSysSleep();
	if(iRet == ERR_SYS_NOT_SUPPORT)
	{
		return -2;
	}
	else
	{
		return 3;
	}
}

#ifndef ENVFILENAME
#define ENVFILENAME "./data/ENVFILE"
//#define ENVFILENAME "./data/para.ini"
//#define ENVFILENAME "/data/app/MAINAPP/para.ini"
#endif


dictionary *g_spDict = NULL;
#define PAXSETCTION "PAX"
uchar GetIni(char *name, uchar *value)
{
	uchar szValueBuf[256];
//	int iRet;
//    dictionary *ini;
	char *p = NULL;

	if (g_spDict != NULL)
	{
	     sprintf((char *)szValueBuf, "%s:%s", PAXSETCTION, name);
	     if ((p = iniparser_getstring(g_spDict, (const char *)szValueBuf, NULL)) == NULL)
	     {
	     	_LOG(E_LOG, "iniparser_getstring[%s]", szValueBuf);
	         return 1;
	     }
	  	strcpy((char *)value,p);
	 	return 0;
	}


	g_spDict = iniparser_load(ENVFILENAME);
    if (g_spDict == NULL)
     {
    	_LOG(E_LOG, "iniparser_load[%s]", ENVFILENAME);
         return 1;
     }

     sprintf((char *)szValueBuf, "%s:%s", PAXSETCTION, name);
     if ((p = iniparser_getstring(g_spDict, (const char *)szValueBuf, NULL)) == NULL)
     {
     	_LOG(E_LOG, "iniparser_getstring[%s]", szValueBuf);
         return 1;
     }
 	strcpy((char *)value,p);

// 	g_spDict = ini;
//  iniparser_freedict(ini);
 	return 0;
}

uchar PutIni(char *name, uchar *value)
{
	int iRet;
	uchar szValueBuf[256];

    dictionary *ini;
//	char *p = NULL;

	if (g_spDict != NULL)
	{
	    iniparser_freedict(g_spDict);
	    g_spDict = NULL;
	}
    ini = iniparser_load(ENVFILENAME);
    if (ini == NULL)
    {
    	_LOG(E_LOG, "iniparser_load[%s]", ENVFILENAME);
    	return 1;
    }

    sprintf((char *)szValueBuf, "%s:%s", PAXSETCTION, name);
	iRet = iniparser_set(ini, szValueBuf, value);
	FILE *fp  = fopen(ENVFILENAME, "w+");
//	iniparser_dump(ini,fp);
	iniparser_dump_ini(ini,fp);

	fflush(fp);
	fclose(fp);

	iniparser_freedict(ini);
	if (iRet == 0)
	{
		return 0;
	}
	else
	{
     	_LOG(E_LOG, "iniparser_set[%d %s %s]", iRet, szValueBuf, value);
		return 1;
	}
}



#define ENVNAMELENGTH 	8
#define ENVUNITLENGTH	128

char *g_psEnv=NULL;
int iEnvUnitTotal;
char cFirstFlag = 0;

uchar FindEnvFile(void)
{
	int iFileNum;
	FileName	*pstFileName;
	int iCnt;
	int iRet;

	iFileNum = GetDirFileNum("./data");
	if (iFileNum <= 0)
	{
		return 1;
	}

//	_LOG(T_LOG, "file num=%d", iFileNum);
	pstFileName = (FileName *)malloc(sizeof(FileName)*iFileNum);
	GetDirFileName("./data", pstFileName);

	int iEnvIndex= -1;
	int iTmsEnvFile = -1;
	for (iCnt = 0; iCnt < iFileNum; iCnt++)
	{
		_LOG(T_LOG, "file name=[%s]", (pstFileName+iCnt)->name);
		//local file
		if (strstr((pstFileName+iCnt)->name, ".env") != NULL)
		{
		    iEnvIndex = iCnt;
		}

		//tms file
		if (0 == strcmp((pstFileName+iCnt)->name, "EnvFile"))
        {
		    iTmsEnvFile = iCnt;
        }
	}

	char szNewFile[256];
	// file from Tms has higher priority
	if(iTmsEnvFile != -1)
	{
        sprintf(szNewFile, "./data/%s", (pstFileName+iTmsEnvFile)->name);
        if(0 == access(ENVFILENAME, F_OK) )
        {
            remove(ENVFILENAME);
        }
        iRet = rename(szNewFile, ENVFILENAME);
        if (iRet < 0)
        {
            _LOG(E_LOG, "rename return %d, errno=%d,%s, P1=%s", iRet, errno, strerror(errno), szNewFile);
            free(pstFileName);
            return 1;
        }
        if(iEnvIndex != -1)
        {
            sprintf(szNewFile, "./data/%s", (pstFileName+iEnvIndex)->name);
            remove(szNewFile);
        }
        free(pstFileName);
        return 0;
	}

	if(iEnvIndex != -1)
	{
	    sprintf(szNewFile, "./data/%s", (pstFileName+iEnvIndex)->name);
        if(0 == access(ENVFILENAME, F_OK) )
        {
            remove(ENVFILENAME);
        }
        iRet = rename(szNewFile, ENVFILENAME);
        if (iRet < 0)
        {
            _LOG(E_LOG, "rename return %d, errno=%d,%s, P1=%s", iRet, errno, strerror(errno), szNewFile);
            free(pstFileName);
            return 1;
        }
        free(pstFileName);
        return 0;
	}

    free(pstFileName);
    return 1;
}

uchar ReadEnvFile(void)
{
	struct stat buf;
	int iFileId;
	int iRet;

	if (cFirstFlag == 0)
	{
		cFirstFlag = 1;
		if (FindEnvFile() != 0)
		{
			_LOG(E_LOG, "NO ENV FILE");
			return 1;
		}
	}
	if(stat(ENVFILENAME, &buf) < 0)
	{
		_LOG(E_LOG, "stat return error %d, %s", errno, strerror(errno));
		return 1;
	}
	if (buf.st_size%ENVUNITLENGTH)
	{
		_LOG(E_LOG, "Env file error");
		return 1;
	}
	iEnvUnitTotal = buf.st_size/ENVUNITLENGTH;
//	_LOG(T_LOG, "env total = %d", iEnvUnitTotal);
	g_psEnv = (char *)malloc(buf.st_size+ENVUNITLENGTH);
	if (g_psEnv == NULL)
	{
		_LOG(E_LOG, "malloc error");
		return 1;
	}
	iFileId = open(ENVFILENAME, O_RDWR);
	if (iFileId < 0)
	{
		_LOG(E_LOG, "open return %d, errno=%d,%s, P1=%s", iFileId, errno, strerror(errno), ENVFILENAME);
		return 1;
	}
	iRet = read(iFileId, g_psEnv, buf.st_size);
	close(iFileId);
	if (iRet != buf.st_size)
	{
		_LOG(E_LOG, "read return %d, errno=%d,%s", iRet, errno, strerror(errno));
		return 1;
	}
	return 0;
}

uchar WriteEnvFile(void)
{
	int iFileId;
	int iRet;

	if (g_psEnv == NULL)
	{
		_LOG(E_LOG, "Point is null");
		return 1;
	}
	iFileId = open(ENVFILENAME, O_RDWR);
	if (iFileId < 0)
	{
		_LOG(E_LOG, "open return %d, errno=%d,%s, P1=%s", iFileId, errno, strerror(errno), ENVFILENAME);
		free(g_psEnv);
		g_psEnv = NULL;
		return 1;
	}
	iRet = write(iFileId, g_psEnv, iEnvUnitTotal*ENVUNITLENGTH);
	close(iFileId);
	if (iRet != iEnvUnitTotal*ENVUNITLENGTH)
	{
		_LOG(E_LOG, "write return %d, errno=%d,%s", iRet, errno, strerror(errno));
		free(g_psEnv);
		g_psEnv = NULL;
		return 1;
	}
	free(g_psEnv);
	g_psEnv = NULL;
	return 0;
}

uchar GetEnv(char *pszName, uchar *pszValue)
{
	int iCnt;
	uchar ucRet;
//	char szValue[256];

	if (strlen(pszName) > ENVNAMELENGTH-1)
	{
		pszName[ENVNAMELENGTH-1] = 0x00;
	}
	if (g_psEnv == NULL)
	{
		ucRet = ReadEnvFile();
		if (ucRet != 0)
		{
			return 1;
		}
	}
//	_LOG(T_LOG, "env total = %d", iEnvUnitTotal);
	for (iCnt = 0; iCnt < iEnvUnitTotal; iCnt++)
	{
		if(memcmp(pszName, g_psEnv+iCnt*ENVUNITLENGTH, strlen(pszName)+1) == 0)
		{
			strcpy((char *)pszValue,g_psEnv+iCnt*ENVUNITLENGTH+8);
//			_LOG(T_LOG, "pszName=[%s] value=[%s]", pszName, pszValue);
			return 0;
		}
	}
	return 1;
}


uchar PutEnv(char *pszName, uchar *pszValue)
{
	uchar ucRet;
	int iCnt;

	if (strlen(pszName) > ENVNAMELENGTH-1)
	{
		pszName[ENVNAMELENGTH-1] = 0x00;
	}
	if (strlen((const char *)pszValue) > ENVUNITLENGTH-ENVNAMELENGTH-1)
	{
		pszValue[ENVUNITLENGTH-ENVNAMELENGTH-1] = 0x00;
	}
	if (g_psEnv == NULL)
	{
		ucRet = ReadEnvFile();
		if (ucRet != 0)
		{
			return 1;
		}
	}
	for (iCnt = 0; iCnt < iEnvUnitTotal; iCnt++)
	{
		if(memcmp(pszName, g_psEnv+iCnt*ENVUNITLENGTH, strlen(pszName)+1) == 0)
		{
			strcpy(g_psEnv+iCnt*ENVUNITLENGTH+ENVNAMELENGTH, (char *)pszValue);
			ucRet = WriteEnvFile();
			return ucRet;
		}
	}
	strcpy(g_psEnv+iCnt*ENVUNITLENGTH, pszName);
	strcpy(g_psEnv+iCnt*ENVUNITLENGTH+ENVNAMELENGTH, (char *)pszValue);
	iEnvUnitTotal++;
	ucRet = WriteEnvFile();
	return ucRet;
}

#ifdef ENVFILENAME
#undef ENVFILENAME
#endif

void ReadSN(uchar *SerialNo)
{
    char buf[32] = {0};
    if (SerialNo == NULL)
        return ;
    OsRegGetValue("ro.fac.sn",buf);
    strcpy((char *)SerialNo, buf);

	return;
}

void EXReadSN(uchar *SN)
{
    char buf[32] = {0};

    if (SN == NULL)
        return ;
    OsRegGetValue("ro.fac.exsn",buf);
    strcpy((char *)SN, buf);
}

uchar ReadVerInfo(uchar *VerInfo)
{
	VerInfo[0] = 0x00;
	return 0;
}

int GetTermInfo(uchar *out_info)
{
	int i = 0;
	int iRet;
	char temp[32] = {0};

	if (out_info == NULL)
	{
		_LOG(E_LOG, "P1 is null");
		return 0;
	}

	//machins model
	OsRegGetValue("ro.fac.mach",temp);
	for (i=0; i<sizeof(g_MachModels)/sizeof(g_MachModels[0]); i++)
	{
		if (strcasecmp((char *)g_MachModels[i].model, temp) == 0)
		{
			out_info[0] = g_MachModels[i].code;
			break;
		}
	}

	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.printer",temp);
	if (strlen(temp) > 1)
		out_info[1] = 'T';
	else
		out_info[1] = 0x00;

	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.modem",temp);
	if (strlen(temp) > 1)
		out_info[2] = 1;
	else
		out_info[2] = 0;

//	    memset(temp, 0, sizeof(temp));
//	    OsGetSysVer(TYPE_MODEM_VER,temp);
//	    _LOGHEX(T_LOG, temp, 30);
//	    if (temp[0] == 0)
//	        out_info[2] = 0;
//	    else
//	        out_info[2] = 1;


	// TODO:modem sync rate
	out_info[3] = 1;

	// TODO: modem asynchronous rate
	out_info[4] = 1;

	//PCI security module
	out_info[5] = 1;

	//USB host exist?
	memset(temp, 0, sizeof(temp));
	OsRegGetValue("ro.fac.usb.host",temp);
	if (strcmp(temp, "1") == 0)
		out_info[6] = 1;
	else
		out_info[6] = 0;

	//USB device
	memset(temp, 0, sizeof(temp));
	OsRegGetValue("ro.fac.usb.device",temp);
	if (strcmp(temp, "1") == 0)
		out_info[7] = 1;
	else
		out_info[7] = 0;

	//ethernet support ?
	memset(temp, 0, sizeof(temp));
//	    OsRegGetValue("persist.sys.eth0.enable",temp,sizeof(temp));
	OsRegGetValue("ro.fac.eth",temp);
	if (strcmp(temp, "1") == 0)
		out_info[8] = 1;
	else
		out_info[8] = 0;

	//GPRS version code
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.radio",temp);
	if (iRet > 0)
	  	out_info[9] = 1;
	else
	  	out_info[9] = 0;
//	memset(temp, 0, sizeof(temp));
//	OsGetSysVer(TYPE_GPRS_VER,temp);
//	_LOGHEX(T_LOG, temp, 30);
//	if (temp[0] == 0)
//		out_info[9] = 0;
//	else
//		out_info[9] = 1;

	//CDMA version code
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.radio",temp);
	if (iRet > 0)
		out_info[10] = 1;
	else
		out_info[10] = 0;

	//WIFI version code
	memset(temp, 0, sizeof(temp));
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.wifi",temp);
	if (iRet > 0)
		out_info[11] = 1;
	else
		out_info[11] = 0;

	//RF version code
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.pcd",temp);
	if (strlen(temp) > 1)
		out_info[12] = 1;
	else
		out_info[12] = 0;

	// TODO: chinese font exist ?
	out_info[13] = 1;


	// TODO: font files exist ?
	out_info[14] = 1;

	//IC reader
	memset(temp, 0, sizeof(temp));
	OsGetSysVer(TYPE_ICC_VER,temp);
	if (temp[0] == 0)
		out_info[15] = 0;
	else
		out_info[15] = 1;

	//Magnetic stripe cards reader
	memset(temp, 0, sizeof(temp));
	OsGetSysVer(TYPE_MSR_VER,temp);
	if (temp[0] == 0)
		out_info[16] = 0;
	else
		out_info[16] = 1;

	// TODO:Tilt sensor
	out_info[17] = 0;

	// TODO: WCDMA module
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.radio",temp);
	if (strcmp(temp, "RU509") == 0 )
		out_info[18] = 1;
	else
		out_info[18] = 0;

	//touchscreen
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.touchscreen",temp);
	if (iRet > 0)
		out_info[19] |= 0x01;

	out_info[19] |= 0x02;

	//added by Kim 2014-12-10
	memset(temp, 0, sizeof(temp));
	iRet = OsRegGetValue("ro.fac.bt",temp);
	if (iRet > 0)
		out_info[19] |= 0x08;

	_LOG(T_LOG, "GetTermInfo return:");
	_LOGHEX(T_LOG, out_info, 20);
	return 20;
}


// ---------- UNSUPPORT -------------------------------

/*
int EnumFont (ST_FONT *Fonts, int MaxFontNums)
{

	_LOG(T_LOG, "EnumFOnt called, return 0");
	return 0;
}


int ReadFontLib(unsigned long Offset, uchar *FontData, int ReadLen)
{
	_LOG(W_LOG, "ReadFontLib called, return -1");
	return -1;
}

int SysConfig(uchar *ConfigInfoIn, int InfoInLen)
{
	_LOG(W_LOG, "SysConfig called, return 0");
	return 0;
}

void LedDisplay(unsigned char type, unsigned char *str)
{
	_LOG(W_LOG, "LedDisplay called, empty function");
	return;
}

void SysIdle(void)
{
	_LOG(W_LOG, "SysIdle called, empty function");
	return;
}
*/

uchar OnBase(void)
{
//	_LOG(W_LOG, "OnBase called");
	return 0;
}

//int EnumBaseFont (ST_FONT *Fonts, int MaxFontNums)
//{
//
//	_LOG(T_LOG, "EnumBaseFont called, return 0");
//	return 0;
//}
//
//int GetTermInfoExt(uchar *InfoOut, int InfoOutLen)
//{
//
//	_LOG(W_LOG, "GetTermInfoExt called, return 0");
//	return 0;
//}
