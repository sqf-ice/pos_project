#ifndef UNDEF_FUNC_H_
#define UNDEF_FUNC_H_


#ifdef  ScrInit
#undef  ScrInit
#endif

#ifdef  Lcdprintf
#undef  Lcdprintf
#endif

#ifdef open
#undef open
#endif

#ifdef truncate
#undef truncate
#endif

#ifdef read
#undef read
#endif

#ifdef write
#undef write
#endif

#ifdef close
#undef close
#endif

#ifdef remove
#undef remove
#endif

#endif
