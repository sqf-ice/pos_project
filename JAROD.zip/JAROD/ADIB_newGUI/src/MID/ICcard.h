/*
 * Author:
 * date:   20131018
 */

#ifndef _ICCARD_H_
#define _ICCARD_H_

#include "structDefine.h"

#ifdef __cplusplus
extern "C"
{
#endif

////////////////////////////////////////////////////////////////////
// 函数定义

uchar IccInit(uchar slot, uchar *ATR);
uchar IccClose(uchar slot);
uchar IccAutoResp(uchar slot, uchar autoresp);
uchar IccIsoCommand(uchar slot, APDU_SEND *ApduSend, APDU_RESP *ApduResp);
uchar IccDetect(uchar slot);

#ifdef __cplusplus
};
#endif
#endif
