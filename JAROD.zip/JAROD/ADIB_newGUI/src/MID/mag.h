
#ifndef _MAG_H_H
#define _MAG_H_H

#include "structDefine.h"

int MagOpen(void);
void MagClose(void);
void MagReset(void);
uchar MagSwiped(void);
uchar MagRead(uchar *Track1, uchar *Track2, uchar *Track3);

#endif
