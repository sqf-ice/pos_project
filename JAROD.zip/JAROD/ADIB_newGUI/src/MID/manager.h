#ifndef _MANAGER_H_
#define _MANAGER_H_

#include "structDefine.h"

// rename it cuz it will conflict with ProtimsE lib
int MIDReadAppInfo(unsigned char AppNo, APPINFO* ai);
int RunAppByName(const char *appnum);
int RunApp(unsigned char  appnum);	
int DoEvent(unsigned char AppNo, ST_EVENT_MSG *msg);
int OS_MultiThread(void *vThread);

#endif 
