
//============================================
//  header file for protims.(v1.00.06)
//============================================

#ifndef _POSAPI_H
#define _POSAPI_H

#include <xui.h>

//================================================
//  structure for modem operation
//=================================================


// setup of communication parameter
typedef struct
{
    unsigned char bCommMode;        // 0:Serial, 1:Modem, 2:LAN, 3:GPRS, 4:CDMA, 5:PPP 6:wifi 7:usb

    unsigned char *psAppName;       //the name of app, if it is set for null, it will download all task.
    unsigned char bLoadType;        //the type of download.bit0:app bit1:para bit2:datafile
    unsigned char psProtocol;       //the information of download protocol.0-protims
    unsigned char bPedMode;          //not used

    unsigned char bDMK_index;      //not used
    unsigned char sTransCode[5];    // not used

    unsigned char ucCallMode;    //not used

    unsigned char *psTermID;     // the terminal ID for downloaded task

    union
    {
        struct
        {
            unsigned char *psPara; //the para for serial connection.
        }tSerial;      // bCommMode = 0
        struct
        {
            unsigned char *psTelNo;         //the telephone number.
            COMM_PARA *ptModPara;  		//the para for Modem communication
            unsigned char bTimeout;         //
        }tModem;      //  bCommMode = 1
        struct
        {
            unsigned char *psLocal_IP_Addr;       //local IP
            unsigned short wLocalPortNo;           //not used
            unsigned char *psRemote_IP_Addr;      //remote IP
            unsigned short wRemotePortNo;          //remote Port
            unsigned char *psSubnetMask;          //subnetMask
            unsigned char *psGatewayAddr;         //gateway
        }tLAN; // bCommMode=2
        struct
        {
            unsigned char *psAPN;          //APN
            unsigned char *psUserName;     //username
            unsigned char *psPasswd;       //password
            unsigned char *psIP_Addr; 		//remote IP
            unsigned short nPortNo;			//remote Port
            unsigned char *psPIN_CODE;     //pin code
            unsigned char *psAT_CMD;       //AT command.
        }tGPRS; //bCommMode=3
        struct
        {
            unsigned char *psTelNo;        //telephone number
            unsigned char *psUserName;
            unsigned char *psPasswd;
            unsigned char *psIP_Addr;
            unsigned short nPortNo;
            unsigned char *psPIN_CODE;
            unsigned char *psAT_CMD;
        }tCDMA; //bCommMode=4
        struct
        {
            unsigned char *psTelNo;			//telephone number
            COMM_PARA *ptModPara; 			//the para for Modem communication
            unsigned char *psUserName;     //username
            unsigned char *psPasswd;       //password
            unsigned char *psIP_Addr;      //remote IP
            unsigned short nPortNo;         //remote Port
        }tPPP; // bCommMode=5

		struct //bCommMode=6
		{

			unsigned char *Wifi_SSID;      // SSID
			unsigned char *Wifi_BSSID;     //SSID Mac
			unsigned char *psPasswd;       //password for wifi.

			unsigned char *Remote_IP_Addr;  //remote ip
			unsigned short RemotePortNo;    //remote port

			unsigned char Wifi_Mode;    //0:station 1:IBSS
			unsigned char Wifi_SecMode; //NONE,WEP,TKIP,CCMP
			unsigned char Wifi_AuthMode;// AUTH_NONE_OPEN = 1,
										//AUTH_NONE_WEP,
										//AUTH_NONE_WEP_SHARED,
										//AUTH_IEEE8021X,
										//AUTH_WPA_PSK,
										//AUTH_WPA_EAP,
										//AUTH_WPA_WPA2_PSK,
										//AUTH_WPA_WPA2_EAP,
										//AUTH_WPA2_PSK,
										//AUTH_WPA2_EAP,
			unsigned char KeyLen;       //the length of password

        }tWIFI;
    }tUnion;
}T_INCOMMPARA;


//the API for remote download.
int ProTimsRemoteLoadApp(T_INCOMMPARA *ptCommPara);
int ProTimsSetStyle(XuiWindow *XuiWindow);
int GetLoadedTaskNum(void);
int ProTimsGetVersion(char *ver);
void ProTimsGetLastErr(int* pLastError);
int ProTimsSelSIMSlot(int uslot);
//int ProTimsMain(XuiWindow *pWindow, int iKeyValue);

#endif

