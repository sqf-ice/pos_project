/*------------------------------------------------------------
* FileName: GetDynamicPassword.c
* Author: linhb
* Date: 2015-05-22
------------------------------------------------------------*/

#include <osal.h>
#include <openssl/sha.h>

static unsigned char sg_szBankResult[7] = {0};
static unsigned char sg_date[100] = {0};
const unsigned char *GetDynamicPassword()
{
    //generate password
    int i, len = 0;
    ST_TIME curr_time;
    unsigned char date_str[100] = {0}, date_reversal[100] = {0};
    OsGetTime(&curr_time);
    sprintf(date_str, "P%04dA%02dX%02dSZ", curr_time.Year, curr_time.Month, curr_time.Day);
//    if(0 == memcmp(sg_date, date_str, strlen(date_str)))
//    {
//        return sg_szBankResult;
//    }
    strcpy(sg_date, date_str);

    len = strlen(date_str);
    for(i = 0; i < len; ++i)
    {
        date_reversal[i] = date_str[len - i - 1];
    }

    SHA_CTX c;
    unsigned char sha1[20]={0};
    SHA1_Init(&c);
    SHA1_Update(&c, date_str, strlen(date_str));
    SHA1_Update(&c, date_reversal, strlen(date_reversal));
    SHA1_Final(sha1,&c);

    sprintf(sg_szBankResult, "%02d%02d%02d",
                                    sha1[curr_time.Year % 20] % 100,
                                    sha1[curr_time.Month % 20] % 100,
                                    sha1[curr_time.Day % 20] % 100);
    //OsLog(LOG_ERROR, "PASSWORD: %s", sg_szBankResult);
    return sg_szBankResult;
}
