
/****************************************************************************
NAME
    tranproc.h - 定义交易处理模块

DESCRIPTION

REFERENCE

MODIFICATION SHEET:
    MODIFIED   (YYYY.MM.DD)
    shengjx     2006.09.12      - created
****************************************************************************/

#ifndef _TRANPROC_H
#define _TRANPROC_H

/************************************************************************
* 定义交易类型 查询 批上送 签到 预授权 授权销售 退款 冲正 销售 结算 测试
* 撤消预授权 撤消
************************************************************************/
// !!!! Every time a new transaction type is added, glTranConfig[] also add a new item accordingly.
enum
{ //ZOZO
	PREAUTH,				// 0				
	AUTH,					// 1
	SALE,					// 2
	INSTALMENT,				// 3
	RATE_BOC,				// 4
	RATE_SCB,				// 5
	UPLOAD,					// 6
	LOGON,					// 7
	REFUND,					// 8
	REVERSAL,				// 9
	SETTLEMENT,				// 10
	LOAD_PARA,				// 11
	VOID,					// 12
	OFFLINE_SEND,			// 13
	OFF_SALE,				// 14
	SALE_COMP,				// 15
	CASH,					// 16
	SALE_OR_AUTH,			// 17
	TC_SEND,				// 18
	ECHO_TEST,				// 19
	ENQUIRE_BOC_RATE,		// 20
	LOAD_CARD_BIN,			// 21
	DCC_RATE,				// 22
	BALANCE,				// 23
	COMPLETION,				// 24
	LOYALTY_INQUIRY,         //25
	SALE_INQUIRY,           //26
	COUPON,					//27
	GIFT_INQUIRY,			//28
	GIFT_REDEEM,			//29
	AUTH_COMPLETE,			//30
	VOID_AUTH,				//31
	REDEEM_INQUIRY,					//32
	REDEEM_POINT,			//33
	PURCHASE,			//34 //NEW ADIB ***
	OFFLINE_REFUND,		//35 //NEW ADIB
	CASH_ADVANCE,		//36 //NEW ADIB ----
	SINGLE_TIP,			//37 //NEW ADIB ***
	FandB_PURCHASE,		//38 //NEW ADIB ***
	TIP_COMPLETION,		//39 //NEW ADIB
	EXPRESS_CHECKOUT,	//40 //NEW ADIB
	MOTO,				//41 //NEW ADIB
	VOID_REFUND,		//42 //NEW ADIB

	// 在此之前加新的交易类型宏名称. ADD NEW TRANS BEFORE MAX_TRANTYPE
	// 必须同步地在glTranConfig增加交易配置. Must sync with glTranConfig
	// ADD NEW TRANS BEFORE MAX_TRANTYPE,Must sync with glTranConfig
	MAX_TRANTYPE,
};

// error code
#define ERR_BASE			0x10000
#define ERR_PINPAD			(ERR_BASE+0x01)
#define ERR_NO_TELNO		(ERR_BASE+0x03)
#define ERR_SWIPECARD		(ERR_BASE+0x05)
#define ERR_USERCANCEL		(ERR_BASE+0x06)
#define ERR_TRAN_FAIL		(ERR_BASE+0x07)
#define ERR_UNSUPPORT_CARD	(ERR_BASE+0x08)
#define ERR_SEL_ACQ			(ERR_BASE+0x09)
#define ERR_HOST_REJ		(ERR_BASE+0x0A)
#define ERR_RETRY_TIMEOUT	(ERR_BASE+0x0B)

#define ERR_FILEOPER		(ERR_BASE+99)


// #define ERR_NOT_EMV_CARD	(ERR_BASE+100)
#define ERR_NEED_INSERT		(ERR_BASE+101)
#define ERR_NEED_FALLBACK	(ERR_BASE+102)
#define ERR_NEED_SWIPE		(ERR_BASE+103)

// Add by lirz v1.02.0000
#define ERR_AMT_EXCEED		(ERR_BASE+201)
#define ERR_NO_RECORD		(ERR_BASE+202)

#define ERR_EXIT_APP		(ERR_BASE+990)
#define ERR_NO_DISP			(ERR_BASE+999)

#define OFFSEND_TC		0x01
#define OFFSEND_TRAN	0x02

#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

void SetCommReqField(void);
void TRUST_SetCommReqField(void);
void TRUST_ISO8583_ADIB(void);
int TransInit(uchar ucTranType);
int TransCapture(void);
int InstallmentMenu(void);
int TransSale(uchar ucTypeFlag);
int TransSaleType(uchar ucInstallment,uchar ucTranType);
int TransCash(void);
int TransAuth(uchar ucTranType);
int FinishOffLine(void);
int TranReversal(void);
int OfflineSend(uchar ucTypeFlag);
int TranSaleComplete(void);
int TransRefund(void);
int TransOffSale(void);
int TransVoid(void);
int TransVoidAuthADIB(void);
int TransOther(void);
int TransAdjust(void);
int TransEchoTest(void);
int TransSettle(void);
#ifdef ENABLE_DCC
int TransDccRateSub(void);
int TransDccRateInit(void);
int TransDccRate(void);
#endif // ENABLE_DCC
int TransLoyaltyMenu(void);
int TransSaleInquiryAuto(void);
int TransLoyaltyInquiry(void);

int TransBalanceInquiry(void);
int TransPreAuthCompletion(void);
int TransVoidPreAuth(void);

void SetTranCurrencyCode(void);

void Field63Set(char *field63);
int Field63Parser(const char *field63, const char *Tag, char *value);

#ifdef __cplusplus
}
#endif /* __cplusplus */

#endif	// _TRANPROC_H

// end of file
