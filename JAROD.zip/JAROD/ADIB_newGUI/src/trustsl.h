/*------------------------------------------------------------
* FileName: trustsl.h
* Author: FOURA
* Date: 2016-03-16
------------------------------------------------------------*/
#ifndef TRUSTSL_H
#define TRUSTSL_H

int getDataTPK(uchar*strTemp,uchar*szIndex,uchar*szVALUE,uchar*szKCV);

int getDataTPKTMK(uchar*strTemp,uchar*szIndex1,uchar*szVALUE1,uchar*szKCV1,uchar*szIndex2,uchar*szVALUE2,uchar*szKCV2);

void setFeePN(uchar*strFeeValue,uchar*pszFeeP,uchar*pszFeeN);
uchar isFound(uchar*azParam,uchar chrParam);

uchar isKCV(uchar*strKey,uchar*strKCV);
uchar isKCVTRUST(uchar*strKey,uchar*strKCV);

void fffFOURA(uchar*strData);
void fffFOURATMK(uchar*strData);
void hhhHasan(int inData);
void hhhHasanHEX(int inData);
void hhhHasanHEXPIN(uchar *DATAPIN);
void gggGETTag(unsigned short Tag);
uchar isIssuerLocalCurrency(void);


void injectManual(dvoid);
void readSNTRM(voi);

void sssShowSendMSG(void);
void sssShowReciveMSG(void);


void injectCUP(int intSrcKeyIdx);
void injectJCB(int intSrcKeyIdx);
void injectTMKs(void);
void injectTMKsTMS(int inData);
void injectTPKs(void);
void injectTPKsTMS(uchar*inData);
void injectMASTER(int intSrcKeyIdx);
void injectMESTRO(int intSrcKeyIdx);
void injectLOYALITY(int intSrcKeyIdx);
int updatePreAuthPeriod (uchar*inData);
int updatetTimeSettle(uchar*inData);
int updatetMAXSettle(uchar*inData);
void UpdateF52(void);

int	CheckSrvCode(uchar *service_code, uchar *pin_required, uchar * pin_feasible);
uchar SaveSvcCode(uchar *pszTrack2,uchar *serviceCode);

void dddoHentFMessage(int intParam);

void send2ECR(uchar *psData);


int injectTMKTRUST(void);
int SetInjectRestore(void);
void setAutoSettlements(void);
void setTimeAutoSettlement(void);
int updatetADIB_TID(uchar*inData);
int updatetADIB_MID(uchar*inData);
int updatetADIB_NII(uchar*inData);
uchar  getRuleSettelment(int iSettlTime,int iCurrTime);
void PrintFoura(const char*strAName);

int ReadDCCStan(uchar *dccstan);


uchar luhnFoura(uchar*inData);

int gettotal(int y);

#endif
