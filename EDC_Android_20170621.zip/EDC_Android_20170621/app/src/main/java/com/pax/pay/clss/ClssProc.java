/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-4-20
 * Module Author: linhb
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import com.pax.abl.utils.TrackUtils;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.Clss_PreProcInfo;
import com.pax.jemv.clcommon.Clss_PreProcInterInfo;
import com.pax.jemv.clcommon.Clss_TransParam;
import com.pax.jemv.clcommon.EMV_CAPK;
import com.pax.jemv.clcommon.EMV_REVOCLIST;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.clcommon.TransactionPath;
import com.pax.jemv.emv.api.EMVApi;
import com.pax.jemv.emv.model.EmvParam;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Issuer;
import com.pax.pay.emv.EmvCapk;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;

import java.util.ArrayList;
import java.util.List;

abstract class ClssProc {

    protected static final String TAG = "ClssProc";

    protected Clss_PreProcInterInfo clssPreProcInterInfo;
    protected Clss_PreProcInfo[] mClssPreProcInfo;
    protected Clss_TransParam clssTransParam;
    protected byte[] aid;
    protected int aidLen;
    protected byte[] finalSelectData = new byte[256];
    protected int finalSelectDataLen;
    protected byte[] aucAuthData = new byte[16];        // authentication data from issuer
    protected int iAuthDataLen;
    protected byte[] aucIssuerScript = new byte[300];    // issuer script
    protected int iScriptLen;

    protected TransactionPath transactionPath = new TransactionPath();

    protected ClssProc() {
        //do nothing
    }

    public static ClssProc generate(int kernelType) {
        switch (kernelType) {
            case KernType.KERNTYPE_VIS:
                return new ClssProcVis();
            case KernType.KERNTYPE_MC:
                return new ClssProcMc();
            default:
                throw new IllegalArgumentException("Unsupported Kernel " + kernelType);
        }
    }

    protected void addCapkRevList() {
        ByteArray keyIdTLVDataList = new ByteArray(1);
        ByteArray aidTLVDataList = new ByteArray(17);
        if (getClssTlv(ClssTlvTag.CAPK_ID, keyIdTLVDataList) == RetCode.EMV_OK &&
                getClssTlv(ClssTlvTag.CAPK_RID, aidTLVDataList) == RetCode.EMV_OK) {
            byte index = keyIdTLVDataList.data[0];
            byte[] tempAid = new byte[5];
            System.arraycopy(aidTLVDataList.data, 0, tempAid, 0, 5);
            EMV_CAPK emvCapk = null;
            List<EmvCapk> capkList = FinancialApplication.getEmvDbHelper().findAllCAPK();
            for (EmvCapk capk : capkList) {
                if (capk.getRID().equals(FinancialApplication.getConvert().bcdToStr(tempAid))
                        && (byte) capk.getKeyID() == index) {
                    emvCapk = genCapk(FinancialApplication.getConvert().strToBcd(capk.getRID(), EPaddingPosition.PADDING_LEFT),
                            (byte) capk.getKeyID(), (byte) capk.getHashInd(), (byte) capk.getArithInd(),
                            (byte) (capk.getModule().length() / 2),
                            FinancialApplication.getConvert().strToBcd(capk.getModule(), EPaddingPosition.PADDING_LEFT),
                            (byte) (capk.getExponent().length() / 2),
                            FinancialApplication.getConvert().strToBcd(capk.getExponent(), EPaddingPosition.PADDING_LEFT),
                            FinancialApplication.getConvert().strToBcd(capk.getExpDate(), EPaddingPosition.PADDING_LEFT),
                            FinancialApplication.getConvert().strToBcd(capk.getCheckSum(), EPaddingPosition.PADDING_LEFT));
                }
            }
            EMV_REVOCLIST emvRevocList = new EMV_REVOCLIST(tempAid, index, new byte[]{0x00, 0x07, 0x11});
            if (emvCapk != null) {
                onAddCapkRevList(emvCapk, emvRevocList);
            }
        }
    }

    // bug from constructor of EMV_CAPK, modulLen should be short
    private EMV_CAPK genCapk(byte[] rID, byte keyID, byte hashInd, byte arithInd, short modulLen, byte[] modul, byte exponentLen, byte[] exponent, byte[] expDate, byte[] checkSum) {
        EMV_CAPK emvCapk = new EMV_CAPK();
        emvCapk.rID = rID;
        emvCapk.keyID = keyID;
        emvCapk.hashInd = hashInd;
        emvCapk.arithInd = arithInd;
        emvCapk.modulLen = modulLen;
        emvCapk.modul = modul;
        emvCapk.exponentLen = exponentLen;
        emvCapk.exponent = exponent;
        emvCapk.expDate = expDate;
        emvCapk.checkSum = checkSum;
        return emvCapk;
    }

    public int getTransPath() {
        return transactionPath.path;
    }

    public ClssProc setClssPreProcInfo(Clss_PreProcInfo[] clssPreProcInfo) {
        this.mClssPreProcInfo = clssPreProcInfo;
        return this;
    }

    public ClssProc setClssPreProcInterInfo(Clss_PreProcInterInfo clssPreProcInterInfo) {
        this.clssPreProcInterInfo = clssPreProcInterInfo;
        return this;
    }

    public ClssProc setClssTransParam(Clss_TransParam clssTransParam) {
        this.clssTransParam = clssTransParam;
        return this;
    }

    public ClssProc setAid(byte[] aid, int aidLen) {
        this.aid = new byte[aidLen];
        System.arraycopy(aid, 0, this.aid, 0, aidLen);
        this.aidLen = aidLen;
        return this;
    }

    public ClssProc setFinalSelectData(byte[] finalSelectData, int finalSelectDataLen) {
        this.finalSelectData = finalSelectData;
        this.finalSelectDataLen = finalSelectDataLen;
        return this;
    }

    public void resultProcess(CTransResult result, TransData transData) {
        updateCardInfo(transData);
        updateEmvInfo(transData);

        List<ClssDE55Tag> clssDE55TagList = new ArrayList<>();
        ClssDE55Tag.addClssDE55Tags(clssDE55TagList);

        //FIXME
        if (result.getTransResult() == OutcomeParam.CLSS_OC_ONLINE_REQUEST) {
            setDetData(ClssTlvTag.CRYPTO, new byte[]{(byte) 0x80});

            // prepare online DE55 data
            if (setStdDe55(result, transData, clssDE55TagList) != 0) {
                transData.setClssResult(CTransResult.ONLINE_FAILED);
            }
        } else if (result.getTransResult() == OutcomeParam.CLSS_OC_APPROVED) {
            // save for upload
            setStdDe55(result, transData, clssDE55TagList);
            transData.setOfflineSendState(TransData.OfflineStatus.OFFLINE_NOT_SENT);
            transData.setReversalStatus(TransData.ReversalStatus.NORMAL);
            FinancialApplication.getTransDataDbHelper().insertTransData(transData);

            // increase trans no.
            Component.incTransNo();
        }
    }

    private void updateCardInfo(TransData transData) {
        //FIXME
        setTrack2(transData);
        String pan = TrackUtils.getPan(transData.getTrack2());
        transData.setPan(pan);

        Issuer issuer = FinancialApplication.getAcqManager().findIssuerByPan(pan);
        if (issuer != null && FinancialApplication.getAcqManager().isIssuerSupported(issuer)) {
            transData.setIssuer(issuer);
        } else {
            transData.setClssResult(TransResult.ERR_CARD_UNSUPPORTED);
            return;
        }

        String expDate = TrackUtils.getExpDate(transData.getTrack2());
        transData.setExpDate(expDate);
        if (!Issuer.validPan(transData.getIssuer(), pan) ||
                !Issuer.validCardExpiry(transData.getIssuer(), expDate)) {
            transData.setClssResult(TransResult.ERR_CARD_EXPIRED);
            return;
        }

        //PanSeqNo
        ByteArray value = new ByteArray();
        int ret = getClssTlv(ClssTlvTag.PAN_SEQ_NO, value);
        if (ret == RetCode.EMV_OK) {
            String cardSerialNo = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setCardSerialNo(cardSerialNo.substring(0, value.length * 2));
        }
    }

    private void updateEmvInfo(TransData transData) {
        int ret;
        //AppLabel
        ByteArray value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.APP_LABEL, value);
        if (ret == RetCode.EMV_OK) {
            String appLabel = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setEmvAppLabel(appLabel.substring(0, value.length * 2));
        }

        //TVR
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.TVR, value);
        if (ret == RetCode.EMV_OK) {
            String tvr = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setTvr(tvr.substring(0, value.length * 2));
        }

        //TSI
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.TSI, value);
        if (ret == RetCode.EMV_OK) {
            String tsi = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setTsi(tsi.substring(0, value.length * 2));
        }

        //ATC
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.ATC, value);
        if (ret == RetCode.EMV_OK) {
            String atc = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setAtc(atc.substring(0, value.length * 2));
        }

        //AppCrypto
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.APP_CRYPTO, value);
        if (ret == RetCode.EMV_OK) {
            String arqc = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setArqc(arqc.substring(0, value.length * 2));
        }

        //AppName
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.APP_NAME, value);
        if (ret == RetCode.EMV_OK) {
            String appName = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setEmvAppName(appName.substring(0, value.length * 2));
        }

        //AID
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.CAPK_RID, value);
        if (ret == RetCode.EMV_OK) {
            String aidStr = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setAid(aidStr.substring(0, value.length * 2));
        }

        //TC
        value = new ByteArray();
        ret = getClssTlv(ClssTlvTag.APP_CRYPTO, value);
        if (ret == RetCode.EMV_OK) {
            String tc = FinancialApplication.getConvert().bcdToStr(value.data);
            transData.setTc(tc.substring(0, value.length * 2));
        }
    }

    // set ADVT/TIP bit 55
    private int setStdDe55(CTransResult result, TransData transData, List<ClssDE55Tag> clssDE55TagList) {
        ByteArray f55DataArray = new ByteArray();
        f55DataArray.length = 0;
        if (transactionPath.path == TransactionPath.CLSS_MC_MAG) {
            return 0;
        }

        for (ClssDE55Tag i : clssDE55TagList) {
            ByteArray value = new ByteArray();
            if (i.getEmvTag() == new byte[]{(byte) 0x9F, 0x33}) {
                EmvParam emvParam = new EmvParam();
                EMVApi.EMVGetParameter(emvParam);
                System.arraycopy(emvParam.capability, 0, value.data, 0, 3);
                value.length = 3;
                buildCLSSTLVString(i.getEmvTag(), value, f55DataArray);
            } else {
                int ret = getClssTlv(i.getEmvTag(), value);
                if (ret == RetCode.EMV_OK) {
                    buildCLSSTLVString(i.getEmvTag(), value, f55DataArray);
                } else if (i.getOption() == ClssDE55Tag.DE55_MUST_SET) {
                    value = new ByteArray();
                    value.length = 0;
                    buildCLSSTLVString(i.getEmvTag(), value, f55DataArray);
                }
            }
        }

        handleTccSpecialCase(result, transData, f55DataArray);

        if (f55DataArray.length > 255) {
            return -1;
        }
        byte[] iccData = new byte[f55DataArray.length];
        System.arraycopy(f55DataArray.data, 0, iccData, 0, f55DataArray.length);
        transData.setSendIccData(FinancialApplication.getConvert().bcdToStr(iccData));
        return 0;
    }

    // Build Clss basic TLV data, exclude structure/template.
    protected void buildCLSSTLVString(byte[] tag, ByteArray in, ByteArray outputData) {
        byte[] tempData = new byte[300];
        int index = 0;
        if (in.length < 0) {
            return;
        }

        if (outputData.length != 0) {
            System.arraycopy(outputData.data, 0, tempData, index, outputData.length);
            index = index + outputData.length;
        }
        // write tag
        System.arraycopy(tag, 0, tempData, index, tag.length);
        index = index + tag.length;

        // write length
        if (in.length <= 0x7F) {
            tempData[index++] = (byte) in.length;
        } else {
            tempData[index++] = (byte) 0x81;
            tempData[index++] = (byte) in.length;
        }

        // write value
        if (in.length > 0) {
            System.arraycopy(in.data, 0, tempData, index, in.length);
            index = index + in.length;
        }

        outputData.length = index;
        System.arraycopy(tempData, 0, outputData.data, 0, outputData.length);
    }

    protected abstract void setDetData(byte[] tag, byte[] data);

    protected abstract CTransResult process(TransData transData, TransProcessListener transProcessListener);

    protected abstract int getClssTlv(byte[] tag, ByteArray value);

    protected abstract void onAddCapkRevList(EMV_CAPK emvCapk, EMV_REVOCLIST emvRevoclist);

    protected abstract void setTrack2(TransData transData);

    protected abstract void completeTrans(TransData transData);

    protected abstract void handleTccSpecialCase(CTransResult result, TransData transData, ByteArray f55DataArray);
}
