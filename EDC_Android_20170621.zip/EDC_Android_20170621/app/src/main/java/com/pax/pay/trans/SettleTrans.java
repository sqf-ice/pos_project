/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans;

import android.content.Context;

import com.pax.abl.core.AAction;
import com.pax.abl.core.AAction.ActionStartListener;
import com.pax.abl.core.ActionResult;
import com.pax.abl.utils.EncUtils;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.action.ActionInputPassword;
import com.pax.pay.trans.action.ActionSelectAcquirer;
import com.pax.pay.trans.action.ActionSettle;
import com.pax.pay.trans.model.ETransType;
import com.pax.settings.SysParam;

import java.util.ArrayList;

public class SettleTrans extends BaseTrans {

    private ArrayList<String> selectAcqs;

    public SettleTrans(Context context, TransEndListener listener) {
        super(context, ETransType.SETTLE, listener);
    }

    @Override
    protected void bindStateOnAction() {

        ActionInputPassword inputPasswordAction = new ActionInputPassword(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionInputPassword) action).setParam(getCurrentContext(), 6,
                        getString(R.string.prompt_settle_pwd), null);
            }
        });
        bind(State.INPUT_PWD.toString(), inputPasswordAction, true);

        ActionSelectAcquirer actionSelectAcquirer = new ActionSelectAcquirer(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionSelectAcquirer) action).setParam(getCurrentContext(),
                        getString(R.string.settle_select_acquirer));
            }
        });
        bind(State.SELECT_ACQ.toString(), actionSelectAcquirer, true);

        ActionSettle settleAction = new ActionSettle(new ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionSettle) action).setParam(getCurrentContext(),
                        getString(R.string.trans_settle), selectAcqs);
            }

        });

        bind(State.SETTLE.toString(), settleAction);

        //结算是否需要输入密码
        if (FinancialApplication.getSysParam().get(SysParam.BooleanParam.OTHTC_VERIFY)) {
            gotoState(State.INPUT_PWD.toString());
        } else {
            gotoState(State.SETTLE.toString());
        }
    }

    enum State {
        INPUT_PWD,
        SELECT_ACQ,
        SETTLE
    }

    @Override
    public void onActionResult(String currentState, ActionResult result) {
        State state = State.valueOf(currentState);
        switch (state) {
            case INPUT_PWD:
                String data = EncUtils.sha1((String) result.getData());
                if (!data.equals(FinancialApplication.getSysParam().get(SysParam.StringParam.SEC_SETTLE_PWD))) {
                    if (selectAcqs != null)
                        selectAcqs.clear();
                    transEnd(new ActionResult(TransResult.ERR_PASSWORD, null));
                    return;
                }
                gotoState(State.SELECT_ACQ.toString());
                break;
            case SELECT_ACQ:
                //noinspection unchecked
                selectAcqs = (ArrayList<String>) result.getData();
                gotoState(State.SETTLE.toString());
                break;
            case SETTLE:
                if (result.getRet() == TransResult.ERR_USER_CANCEL) {
                    gotoState(State.SELECT_ACQ.toString());
                } else {
                    if (selectAcqs != null)
                        selectAcqs.clear();
                    transEnd(result);
                }
                break;
        }
    }

}
