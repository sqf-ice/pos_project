package com.pax.pay.utils;

import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import android.widget.TextView;

import com.pax.pay.app.FinancialApplication;

/**
 * Created by linhb on 5/19/2017.
 */

public abstract class EditorActionListener implements TextView.OnEditorActionListener {

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE) {
            FinancialApplication.getApp().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onKeyOk();
                }
            });
        } else if (actionId == EditorInfo.IME_ACTION_NONE) {
            FinancialApplication.getApp().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    onKeyCancel();
                }
            });
        }
        return false;
    }

    protected abstract void onKeyOk();

    protected abstract void onKeyCancel();
}
