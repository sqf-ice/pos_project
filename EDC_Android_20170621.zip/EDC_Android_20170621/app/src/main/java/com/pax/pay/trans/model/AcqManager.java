/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-6
 * Module Author: Frose.L
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.model;

import android.util.Log;

import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.base.CardRange;
import com.pax.pay.base.Issuer;
import com.pax.pay.db.AcqDb;
import com.pax.settings.SysParam;

import java.sql.SQLException;
import java.util.List;

public class AcqManager {

    private static final String TAG = "AcqManager";

    private static AcqManager acqmanager;
    private static AcqDb acqDbHelper;
    private Acquirer acquirer;

    public static synchronized AcqManager getInstance() {
        if (acqmanager == null) {
            acqmanager = new AcqManager();
            init();
        }
        return acqmanager;
    }

    public void setCurAcq(Acquirer acq) {
        acquirer = acq;
    }

    public Acquirer getCurAcq() {
        return acquirer;
    }

    public boolean isIssuerSupported(final Acquirer acquirer, final Issuer issuer) {
        try {
            List<Issuer> issuers = acqDbHelper.lookupIssuersForAcquirer(acquirer);
            return issuers.contains(issuer);
        } catch (SQLException e) {
            Log.e(TAG, "", e);
        }
        return false;
    }

    public boolean isIssuerSupported(final Issuer issuer) {
        try {
            List<Issuer> issuers = acqDbHelper.lookupIssuersForAcquirer(acqmanager.acquirer);
            for (Issuer tmp : issuers) {
                if (tmp.getName().equals(issuer.getName())) {
                    return true;
                }
            }
            return false;
        } catch (SQLException e) {
            Log.e(TAG, "", e);
        }
        return false;
    }

    public Issuer findIssuerByPan(final String pan) {
        if (pan == null || pan.isEmpty())
            return null;
        CardRange cardRange = acqDbHelper.findCardRange(pan);
        if (cardRange == null) {
            return null;
        } else {
            return cardRange.getIssuer();
        }
    }

    public Issuer findIssuerByPan(final Acquirer acquirer, final String pan) {
        try {
            List<Issuer> issuers = acqDbHelper.lookupIssuersForAcquirer(acquirer);
            Issuer issuer = findIssuerByPan(pan);
            if (issuer != null && issuers.contains(issuer)) {
                return issuer;
            }
        } catch (SQLException e) {
            Log.e(TAG, "", e);
        }
        return null;
    }

    public void insertAcquirer(final Acquirer acquirer) {
        acqDbHelper.insertAcquirer(acquirer);
    }

    public Acquirer findAcquirer(final String acquirerName) {
        return acqDbHelper.findAcquirer(acquirerName);
    }

    public List<Acquirer> findAllAcquirers() {
        return acqDbHelper.findAllAcquirers();
    }

    public void updateAcquirer(final Acquirer acquirer) {
        acqDbHelper.updateAcquirer(acquirer);
    }

    public void deleteAcquirer(final int id) {
        acqDbHelper.deleteAcquirer(id);
    }

    public void insertIssuer(final Issuer issuer) {
        acqDbHelper.insertIssuer(issuer);
    }

    public Issuer findIssuer(final String issuerName) {
        return acqDbHelper.findIssuer(issuerName);
    }

    public List<Issuer> findAllIssuers() {
        return acqDbHelper.findAllIssuers();
    }

    public void bind(final Acquirer root, final Issuer issuer) {
        acqDbHelper.bind(root, issuer);
    }

    public void updateIssuer(final Issuer issuer) {
        acqDbHelper.updateIssuer(issuer);
    }

    public void deleteIssuer(final int id) {
        acqDbHelper.deleteIssuer(id);
    }

    public void insertCardRange(final CardRange cardRange) {
        acqDbHelper.insertCardRange(cardRange);
    }

    public void updateCardRange(final CardRange cardRange) {
        acqDbHelper.updateCardRange(cardRange);
    }

    public CardRange findCardRange(final long low, final long high) {
        return acqDbHelper.findCardRange(low, high);
    }

    public List<CardRange> findCardRange(final Issuer issuer) {
        return acqDbHelper.findCardRange(issuer);
    }

    public List<CardRange> findAllCardRanges() {
        return acqDbHelper.findAllCardRanges();
    }

    public void deleteCardRange(final int id) {
        acqDbHelper.deleteCardRange(id);
    }

    private static void init() {
        String name = FinancialApplication.getSysParam().get(SysParam.StringParam.ACQ_NAME);
        acqDbHelper = AcqDb.getInstance();
        if (!"".equals(name)) {
            Acquirer acquirer = acqDbHelper.findAcquirer(name);
            if (acquirer != null) {
                acqmanager.setCurAcq(acquirer);
            }
        }
    }
}
