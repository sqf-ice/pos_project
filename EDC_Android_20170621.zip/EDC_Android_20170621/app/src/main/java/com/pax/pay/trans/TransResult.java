/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans;

import android.util.SparseIntArray;

import com.pax.edc.R;
import com.pax.pay.utils.Utils;


public class TransResult {
    /**
     * 交易成功
     */
    public static final int SUCC = 0;
    /**
     * 结算对账平,不需要批上送
     */
    public static final int SUCC_NOREQ_BATCH = 1;
    /**
     * 超时
     */
    public static final int ERR_TIMEOUT = -1;
    /**
     * fail to connect
     */
    public static final int ERR_CONNECT = -2;
    /**
     * 发送失败
     */
    public static final int ERR_SEND = -3;
    /**
     * 接收失败
     */
    public static final int ERR_RECV = -4;
    /**
     * 打包失败
     */
    public static final int ERR_PACK = -5;
    /**
     * 解包失败
     */
    public static final int ERR_UNPACK = -6;
    /**
     * 非法包
     */
    public static final int ERR_BAG = -7;
    /**
     * 解包mac错
     */
    public static final int ERR_MAC = -8;
    /**
     * 处理码不一致
     */
    public static final int ERR_PROC_CODE = -9;
    /**
     * 消息类型不一致
     */
    public static final int ERR_MSG = -10;
    /**
     * 交易金额不符
     */
    public static final int ERR_TRANS_AMT = -11;
    /**
     * 流水号不一致
     */
    public static final int ERR_TRACE_NO = -12;
    /**
     * 终端号不一致
     */
    public static final int ERR_TERM_ID = -13;
    /**
     * 商户号不一致
     */
    public static final int ERR_MERCH_ID = -14;
    /**
     * 无交易
     */
    public static final int ERR_NO_TRANS = -15;
    /**
     * 无原始交易
     */
    public static final int ERR_NO_ORIG_TRANS = -16;
    /**
     * 此交易已撤销
     */
    public static final int ERR_HAS_VOIDED = -17;
    /**
     * 此交易不可撤销
     */
    public static final int ERR_VOID_UNSUPPORTED = -18;
    /**
     * 打开通讯口错误
     */
    public static final int ERR_COMM_CHANNEL = -19;
    /**
     * 失败
     */
    public static final int ERR_HOST_REJECT = -20;
    /**
     * 交易终止（终端不需要提示信息）
     */
    public static final int ERR_ABORTED = -21;
    /**
     * 交易终止（User cancel）
     */
    public static final int ERR_USER_CANCEL = -22;
    /**
     * 预处理相关 交易笔数超限，立即结算
     */
    public static final int ERR_NEED_SETTLE_NOW = -23;
    /**
     * 预处理相关 交易笔数超限，稍后结算
     */
    public static final int ERR_NEED_SETTLE_LATER = -24;
    /**
     * 预处理相关 存储空间不足
     */
    public static final int ERR_NO_FREE_SPACE = -25;
    /**
     * 预处理相关 终端不支持该交易
     */
    public static final int ERR_NOT_SUPPORT_TRANS = -26;
    /**
     * 卡号不一致
     */
    public static final int ERR_CARD_NO = -27;
    /**
     * 密码错误
     */
    public static final int ERR_PASSWORD = -28;
    /**
     * 参数错误
     */
    public static final int ERR_PARAM = -29;

    /**
     * 终端批上送未完成
     */
    public static final int ERR_BATCH_UP_NOT_COMPLETED = -31;
    /**
     * 金额超限
     */
    public static final int ERR_AMOUNT = -33;
    /**
     * 平台批准卡片拒绝
     */
    public static final int ERR_CARD_DENIED = -34;
    /**
     * 此交易不可调整
     */
    public static final int ERR_ADJUST_UNSUPPORTED = -36;
    /**
     * 此交易不支持该卡
     */
    public static final int ERR_CARD_UNSUPPORTED = -37;

    /**
     * expired card
     */
    public static final int ERR_CARD_EXPIRED = -38;

    /**
     * invalid card no
     */
    public static final int ERR_CARD_INVALID = -39;

    /**
     * Unsupported function
     */
    public static final int ERR_UNSUPPORTED_FUNC = -40;

    /**
     * 非接设备预处理失败
     */
    public static final int ERR_CLSS_PRE_PROC = -41;

    /**
     * fall back
     */
    public static final int NEED_FALL_BACK = -42;

    private static final SparseIntArray messageMap = new SparseIntArray();

    static {
        messageMap.put(SUCC, R.string.dialog_trans_succ);
        messageMap.put(ERR_TIMEOUT, R.string.err_timeout);
        messageMap.put(ERR_CONNECT, R.string.err_connect);
        messageMap.put(ERR_SEND, R.string.err_send);
        messageMap.put(ERR_RECV, R.string.err_recv);
        messageMap.put(ERR_PACK, R.string.err_pack);
        messageMap.put(ERR_UNPACK, R.string.err_unpack);
        messageMap.put(ERR_BAG, R.string.err_bag);
        messageMap.put(ERR_MAC, R.string.err_mac);
        messageMap.put(ERR_PROC_CODE, R.string.err_proc_code);
        messageMap.put(ERR_MSG, R.string.err_msg);
        messageMap.put(ERR_TRANS_AMT, R.string.err_trans_amt);
        messageMap.put(ERR_TRACE_NO, R.string.err_trace_no);
        messageMap.put(ERR_TERM_ID, R.string.err_term_id);
        messageMap.put(ERR_MERCH_ID, R.string.err_merch_id);
        messageMap.put(ERR_NO_TRANS, R.string.err_no_trans);
        messageMap.put(ERR_NO_ORIG_TRANS, R.string.err_no_orig_trans);
        messageMap.put(ERR_HAS_VOIDED, R.string.err_has_voided);
        messageMap.put(ERR_VOID_UNSUPPORTED, R.string.err_un_voided);
        messageMap.put(ERR_COMM_CHANNEL, R.string.err_comm_channel);
        messageMap.put(ERR_HOST_REJECT, R.string.err_host_reject);
        messageMap.put(ERR_USER_CANCEL, R.string.err_user_cancel);
        messageMap.put(ERR_NEED_SETTLE_NOW, R.string.err_need_settle_now);
        messageMap.put(ERR_NEED_SETTLE_LATER, R.string.err_need_settle_later);
        messageMap.put(ERR_NO_FREE_SPACE, R.string.err_no_free_space);
        messageMap.put(ERR_NOT_SUPPORT_TRANS, R.string.err_unsupported_trans);
        messageMap.put(ERR_BATCH_UP_NOT_COMPLETED, R.string.err_batch_up_break_need_continue);
        messageMap.put(ERR_CARD_NO, R.string.err_original_cardno);
        messageMap.put(ERR_PASSWORD, R.string.err_password);
        messageMap.put(ERR_PARAM, R.string.err_param);
        messageMap.put(ERR_AMOUNT, R.string.err_amount);
        messageMap.put(ERR_CARD_DENIED, R.string.err_card_denied);
        messageMap.put(ERR_ADJUST_UNSUPPORTED, R.string.err_unadjusted);
        messageMap.put(ERR_CARD_UNSUPPORTED, R.string.err_card_unsupported);
        messageMap.put(ERR_CARD_EXPIRED, R.string.err_expired_card);
        messageMap.put(ERR_CARD_INVALID, R.string.err_card_pan);
        messageMap.put(ERR_UNSUPPORTED_FUNC, R.string.err_unsupported_func);
        messageMap.put(ERR_CLSS_PRE_PROC, R.string.err_clee_preproc_fail);
    }

    private TransResult() {

    }

    public static String getMessage(int ret) {
        String message;
        int resourceId = messageMap.get(ret, -1);
        if (resourceId == -1) {
            message = Utils.getString(R.string.err_undefine) + "[" + ret + "]";
        } else {
            message = Utils.getString(resourceId);
        }
        return message;
    }
}
