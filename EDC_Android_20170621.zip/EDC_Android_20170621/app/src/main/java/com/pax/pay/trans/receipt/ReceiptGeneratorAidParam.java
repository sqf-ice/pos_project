/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.receipt;

import android.annotation.SuppressLint;
import android.content.Context;

import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.gl.page.IPage;
import com.pax.gl.page.IPage.EAlign;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.emv.EmvAid;
import com.pax.pay.utils.Utils;

import java.util.ArrayList;
import java.util.List;

/**
 * receipt generator
 *
 * @author Steven.W
 */
@SuppressLint("SimpleDateFormat")
class ReceiptGeneratorAidParam extends ReceiptGeneratorParam implements IReceiptGenerator {

    public ReceiptGeneratorAidParam() {
        //do nothing
    }

    @Override
    protected List<IPage> generatePages(Context context) {
        List<IPage> pages = new ArrayList<>();
        List<EmvAid> aids = FinancialApplication.getEmvDbHelper().findAllAID();

        IPage page = Device.generatePage();
        page.addLine().addUnit("\nAPP\n", FONT_NORMAL, EAlign.CENTER);
        pages.add(page);

        for (EmvAid i : aids) {
            page = Device.generatePage();
            //appName
            page.addLine().addUnit("App Name", FONT_NORMAL, (float) 4)
                    .addUnit(i.getAppName(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //aid
            page.addLine().addUnit("AID", FONT_NORMAL, (float) 1)
                    .addUnit(i.getAid(), FONT_NORMAL, EAlign.RIGHT, (float) 3);
            //selFlag
            String temp = EmvAid.PART_MATCH == i.getSelFlag() ? "Part match" : "Full match";
            page.addLine().addUnit("SelFlag", FONT_NORMAL, (float) 4)
                    .addUnit(temp, FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //priority
            page.addLine().addUnit("Priority", FONT_NORMAL, (float) 4)
                    .addUnit(Integer.toString(i.getPriority()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //targetPer
            page.addLine().addUnit("Target%", FONT_NORMAL, (float) 4)
                    .addUnit(Integer.toString(i.getTargetPer()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //maxTargetPer
            page.addLine().addUnit("Max Target%", FONT_NORMAL, (float) 4)
                    .addUnit(Integer.toString(i.getMaxTargetPer()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //floorLimitCheck
            page.addLine().addUnit("Floor Limit Check", FONT_NORMAL, (float) 3)
                    .addUnit(getYesNo(i.getFloorLimitCheck()), FONT_NORMAL, EAlign.RIGHT, (float) 2);
            //randTransSel
            page.addLine().addUnit("RandTransSel", FONT_NORMAL, (float) 3)
                    .addUnit(getYesNo(i.getRandTransSel()), FONT_NORMAL, EAlign.RIGHT, (float) 2);
            //velocityCheck
            page.addLine().addUnit("Velocity Check", FONT_NORMAL, (float) 3)
                    .addUnit(getYesNo(i.getVelocityCheck()), FONT_NORMAL, EAlign.RIGHT, (float) 2);
            //floorLimit
            page.addLine().addUnit("Floor Limit", FONT_NORMAL, (float) 4)
                    .addUnit(Long.toString(i.getFloorLimit()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //threshold
            page.addLine().addUnit("Threshold", FONT_NORMAL, (float) 4)
                    .addUnit(Long.toString(i.getThreshold()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //tacDenial
            page.addLine().addUnit("tac Denial", FONT_NORMAL, (float) 4)
                    .addUnit(i.getTacDenial(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //tacOnline
            page.addLine().addUnit("tac Online", FONT_NORMAL, (float) 4)
                    .addUnit(i.getTacOnline(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //tacDefault
            page.addLine().addUnit("tac Default", FONT_NORMAL, (float) 4)
                    .addUnit(i.getTacDefault(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //acquirerId
            page.addLine().addUnit("Acquirer Id", FONT_NORMAL, (float) 4)
                    .addUnit(i.getAcquirerId(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //dDOL
            page.addLine().addUnit("DDOL", FONT_NORMAL, (float) 4)
                    .addUnit(i.getDDOL(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //tDOL
            page.addLine().addUnit("TDOL", FONT_NORMAL, (float) 4)
                    .addUnit(i.getTDOL(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //version
            page.addLine().addUnit("Version", FONT_NORMAL, (float) 4)
                    .addUnit(i.getVersion(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //riskManageData
            page.addLine().addUnit("Risk Manage Data", FONT_NORMAL, (float) 4)
                    .addUnit(i.getRiskManageData(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            pages.add(page);
        }

        page = Device.generatePage();
        page.addLine().addUnit("\n\n\n\n", FONT_NORMAL);
        pages.add(page);
        return pages;
    }

    private String getYesNo(int value) {
        return value == 0 ? Utils.getString(R.string.no) : Utils.getString(R.string.yes);
    }
}
