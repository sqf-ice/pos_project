/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-12-1
 * Module Author: Kim.L
 * Description:
 *
 * AET-98
 *
 * ============================================================================
 */
package com.pax.view;

import android.annotation.SuppressLint;
import android.app.Instrumentation;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.media.AudioManager;
import android.support.annotation.ColorInt;
import android.support.annotation.DrawableRes;
import android.support.annotation.StringRes;
import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;

import java.util.ArrayList;
import java.util.List;

import static android.content.Context.AUDIO_SERVICE;
import static android.view.View.MeasureSpec.EXACTLY;
import static android.view.View.MeasureSpec.makeMeasureSpec;

//FIXME  Kim workaround
public class SoftKeyboardPwdStyle extends ViewGroup {

    private Context mContext;
    private boolean isFistInitView = true;
    private OnItemClickListener listener;
    private OnClickListener onClickListener = new OnClickListener() {
        @Override
        public void onClick(final View v) {
            FinancialApplication.getApp().runInBackground(new KeyRunnable(v));
        }
    };

    private static final List<Res> res = new ArrayList<>();

    static {
        res.add(new Res(KeyEvent.KEYCODE_1, R.drawable.selection_button, R.string.num_1));
        res.add(new Res(KeyEvent.KEYCODE_2, R.drawable.selection_button, R.string.num_2));
        res.add(new Res(KeyEvent.KEYCODE_3, R.drawable.selection_button, R.string.num_3));
        res.add(new Res(KeyEvent.KEYCODE_4, R.drawable.selection_button, R.string.num_4));
        res.add(new Res(KeyEvent.KEYCODE_5, R.drawable.selection_button, R.string.num_5));
        res.add(new Res(KeyEvent.KEYCODE_6, R.drawable.selection_button, R.string.num_6));
        res.add(new Res(KeyEvent.KEYCODE_7, R.drawable.selection_button, R.string.num_7));
        res.add(new Res(KeyEvent.KEYCODE_8, R.drawable.selection_button, R.string.num_8));
        res.add(new Res(KeyEvent.KEYCODE_9, R.drawable.selection_button, R.string.num_9));
        res.add(new Res(KeyEvent.KEYCODE_DEL, R.drawable.selection_btn_delete));
        res.add(new Res(KeyEvent.KEYCODE_0, R.drawable.selection_button, R.string.num_0));
        res.add(new Res(KeyEvent.KEYCODE_ENTER, R.drawable.selection_button_confirm, R.string.dialog_ok, Color.WHITE));
    }

    @SuppressLint("Recycle")
    public SoftKeyboardPwdStyle(Context context, AttributeSet attrs, int defStyle) {

        super(context, attrs, defStyle);
        mContext = context;
    }

    @SuppressLint("Recycle")
    public SoftKeyboardPwdStyle(Context context, AttributeSet attrs) {
        this(context, attrs, 0);
    }

    public SoftKeyboardPwdStyle(Context context) {
        this(context, null);
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {

        if (isFistInitView)
            initView();
        isFistInitView = false;
        int count = getChildCount();
        if (count == 0) {
            super.onMeasure(widthMeasureSpec, heightMeasureSpec);
            return;
        }

        for (int i = 0; i < count; i++) {
            final View child = getChildAt(i);
            if (child.getVisibility() == GONE) {
                continue;
            }
            child.measure(MeasureSpec.UNSPECIFIED, MeasureSpec.UNSPECIFIED);
        }

        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
    }

    @Override
    protected void onLayout(boolean changed, int l, int t, int r, int b) {

        int height = b - t;// 布局区域高度
        int width = r - l;// 布局区域宽度
        int rows = 4;
        int columns = 3;
        int gridW = width / columns;// 格子宽度
        int gridH = height / rows;// 格子高度
        int top = 1;

        for (int i = 0; i < rows; i++) {// 遍历行
            for (int j = 0; j < columns; j++) {// 遍历每一行的元素

                View child = this.getChildAt(i * columns + j);
                if (child == null)
                    return;
                int left = j * (gridW + 1);
                // 如果当前布局宽度和测量宽度不一样，就直接用当前布局的宽度重新测量
                if (gridW != child.getMeasuredWidth() || gridH != child.getMeasuredHeight()) {
                    child.measure(makeMeasureSpec(gridW, EXACTLY), makeMeasureSpec(gridH, EXACTLY));
                }
                child.layout(left, top, left + gridW, top + gridH);

            }
            top += gridH + 1;
        }
    }

    private void initView() {
        for (final Res i : res) {
            Button button = new Button(getContext());
            button.setTag(i);
            button.setWidth(android.view.WindowManager.LayoutParams.MATCH_PARENT);
            button.setHeight(android.view.WindowManager.LayoutParams.MATCH_PARENT);
            button.setOnClickListener(onClickListener);
            button.setTextSize(mContext.getResources().getDimension(R.dimen.font_size_input_dialog));
            button.setBackgroundResource(i.getDrawableRes());
            if (i.getTextRes() != null) {
                button.setText(i.getTextRes());
            }
            if (i.getTextColorRes() != null) {
                button.setTextColor(i.getTextColorRes());
            }
            if (i.getKeyCode() == KeyEvent.KEYCODE_DEL) {
                button.setLongClickable(true);
            }
            button.setFocusable(false);
            button.setTypeface(Typeface.DEFAULT, Typeface.NORMAL);
            button.setGravity(Gravity.CENTER);
            addView(button);
        }
    }

    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public interface OnItemClickListener {

        void onItemClick(View v, int index);
    }

    private static class Res {
        private int keyCode;
        @DrawableRes
        private Integer drawableRes = null;
        @StringRes
        private Integer textRes = null;
        @ColorInt
        private Integer textColorRes = null;

        Res(int keyCode, @DrawableRes int drawableRes) {
            this.keyCode = keyCode;
            this.drawableRes = drawableRes;
        }

        Res(int keyCode, @DrawableRes int drawableRes, @StringRes Integer textRes) {
            this.keyCode = keyCode;
            this.drawableRes = drawableRes;
            this.textRes = textRes;
        }

        Res(int keyCode, @DrawableRes int drawableRes, @StringRes Integer textRes, @ColorInt Integer textColorRes) {
            this.keyCode = keyCode;
            this.drawableRes = drawableRes;
            this.textRes = textRes;
            this.textColorRes = textColorRes;
        }

        int getKeyCode() {
            return keyCode;
        }

        @DrawableRes
        Integer getDrawableRes() {
            return drawableRes;
        }

        @StringRes
        Integer getTextRes() {
            return textRes;
        }

        @ColorInt
        Integer getTextColorRes() {
            return textColorRes;
        }
    }

    private class KeyRunnable implements Runnable {
        private final View v;

        KeyRunnable(View v) {
            this.v = v;
        }

        @Override
        public void run() {
            Instrumentation inst = new Instrumentation();
            Res button = (Res) v.getTag();
            playClick(button.getKeyCode());
            inst.sendKeyDownUpSync(button.getKeyCode());
            if (button.getKeyCode() == KeyEvent.KEYCODE_ENTER && listener != null) {
                listener.onItemClick(v, KeyEvent.KEYCODE_ENTER);
            }
        }

        private void playClick(int keyCode) {
            AudioManager am = (AudioManager) mContext.getSystemService(AUDIO_SERVICE);
            switch (keyCode) {
                case 12:
                    am.playSoundEffect(AudioManager.FX_KEYPRESS_RETURN);
                    break;
                case 10:
                    am.playSoundEffect(AudioManager.FX_KEYPRESS_DELETE);
                    break;
                default:
                    am.playSoundEffect(AudioManager.FX_KEYPRESS_STANDARD);
            }
        }
    }
}
