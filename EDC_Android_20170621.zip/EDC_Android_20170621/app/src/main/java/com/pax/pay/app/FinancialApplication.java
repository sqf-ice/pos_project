/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.app;

import android.app.Application;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.os.Handler;
import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.dal.IDAL;
import com.pax.device.GeneralParam;
import com.pax.eventbus.Event;
import com.pax.glwrapper.IGL;
import com.pax.glwrapper.convert.IConvert;
import com.pax.glwrapper.impl.GL;
import com.pax.glwrapper.packer.IPacker;
import com.pax.neptunelite.api.NeptuneLiteUser;
import com.pax.pay.constant.Constants;
import com.pax.pay.db.CardBinDb;
import com.pax.pay.db.EmvDb;
import com.pax.pay.db.TornLogDb;
import com.pax.pay.db.TransDataDb;
import com.pax.pay.db.TransTotalDb;
import com.pax.pay.trans.model.AcqManager;
import com.pax.pay.trans.model.Controller;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.ResponseCode;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;
import com.pax.view.dialog.DialogUtils;
import com.squareup.leakcanary.LeakCanary;

import org.greenrobot.eventbus.EventBus;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;

public class FinancialApplication extends Application {
    public static final String TAG = "FinancialApplication";
    private static FinancialApplication mApp;
    private static SysParam sysParam;
    private static Controller controller;
    private static ResponseCode rspCode;
    private static GeneralParam generalParam;
    private static AcqManager acqManager;
    private static CardBinDb cardBinDb;
    private static EmvDb emvDbHelper;
    private static TransDataDb transDataDbHelper;
    private static TransTotalDb transTotalDbHelper;
    private static TornLogDb tornLogDbHelper;

    // 获取IPPI常用接口
    private static IDAL dal;
    private static IGL gl;
    private static IConvert convert;
    private static IPacker packer;

    // 应用版本号
    private static String version;

    private Handler handler;
    private ExecutorService backgroundExecutor;

    private static final SysParam.UpdateListener updateListener = new SysParam.UpdateListener() {

        @Override
        public void onErr(String prompt) {
            DialogUtils.showUpdateDialog(getApp(), prompt);
        }
    };


    static {
        System.loadLibrary("F_DEVICE_LIB_Android");
        System.loadLibrary("F_PUBLIC_LIB_Android");
        System.loadLibrary("JniEntry_V1.00.00_20170616");
        System.loadLibrary("F_ENTRY_LIB_Android");
    }

    @Override
    public void onCreate() {
        super.onCreate();
        if (LeakCanary.isInAnalyzerProcess(this)) {
            // This process is dedicated to LeakCanary for heap analysis.
            // You should not init your app in this process.
            return;
        }
        LeakCanary.install(this);
        FinancialApplication.mApp = this;
        version = updateVersion();
        CrashHandler.getInstance();
        init();
        initData();

        handler = new Handler();
        backgroundExecutor = Executors.newFixedThreadPool(10, new ThreadFactory() {
            @Override
            public Thread newThread(@NonNull Runnable runnable) {
                Thread thread = new Thread(runnable, "Background executor service");
                thread.setPriority(Thread.MIN_PRIORITY);
                thread.setDaemon(true);
                return thread;
            }
        });
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        //AET-149
        if (FinancialApplication.getSysParam() != null) {
            Utils.changeAppLanguage(FinancialApplication.getApp(), CurrencyConverter.setDefCurrency(FinancialApplication.getSysParam().get(SysParam.StringParam.EDC_CURRENCY_LIST)));
        }
    }

    public static void init() {
        // 获取IPPI常用接口
        Log.i("EDC", "before NeptuneUser");
        try {
            dal = NeptuneLiteUser.getInstance().getDal(getApp());
        } catch (Exception e) {
            Log.w(TAG, e);
        }
        Log.i("EDC", "after NeptuneUser");
        gl = GL.getInstance(getApp());
        convert = getGl().getConvert();
        packer = getGl().getPacker();

        cardBinDb = CardBinDb.getInstance();
        emvDbHelper = EmvDb.getInstance();
        transDataDbHelper = TransDataDb.getInstance();
        transTotalDbHelper = TransTotalDb.getInstance();
        tornLogDbHelper = TornLogDb.getInstance();

        // 初始化是参数对象
        sysParam = SysParam.getInstance();
        SysParam.setUpdateListener(updateListener);
        // 初始化控制对象
        controller = new Controller();
        //初始化通用参数
        generalParam = new GeneralParam();
        //初始化当前收单行
        acqManager = AcqManager.getInstance();
    }

    public static void initData() {
        new Thread(new Runnable() {

            @Override
            public void run() {
                // 初始化平台应答码
                rspCode = ResponseCode.getInstance();
                getRspCode().init();
                // 拷贝打印字体
                try {
                    Utils.install(FinancialApplication.getApp(), Constants.FONT_NAME, Constants.FONT_PATH);
                } catch (IOException e) {
                    Log.w(TAG, "", e);
                }
            }
        }).start();
    }

    /**
     * 获取软件版本号
     */
    private String updateVersion() {
        try {
            PackageManager manager = getPackageManager();
            PackageInfo info = manager.getPackageInfo(getPackageName(), 0);
            return info.versionName;
        } catch (Exception e) {
            Log.w(TAG, e);
            return null;
        }
    }

    public static FinancialApplication getApp() {
        return mApp;
    }

    /**
     * 系统参数
     */
    public static SysParam getSysParam() {
        return sysParam;
    }

    /**
     * 系统控制参数
     */
    public static Controller getController() {
        return controller;
    }

    /**
     * 平台应答码解析
     */
    public static ResponseCode getRspCode() {
        return rspCode;
    }

    public static GeneralParam getGeneralParam() {
        return generalParam;
    }

    /**
     * the acquirer manager
     */
    public static AcqManager getAcqManager() {
        return acqManager;
    }

    public static CardBinDb getCardBinDb() {
        return cardBinDb;
    }

    public static EmvDb getEmvDbHelper() {
        return emvDbHelper;
    }

    public static TransDataDb getTransDataDbHelper() {
        return transDataDbHelper;
    }

    public static TransTotalDb getTransTotalDbHelper() {
        return transTotalDbHelper;
    }

    public static TornLogDb getTornLogDbHelper() {
        return tornLogDbHelper;
    }

    public static IDAL getDal() {
        return dal;
    }

    public static IGL getGl() {
        return gl;
    }

    public static IConvert getConvert() {
        return convert;
    }

    public static IPacker getPacker() {
        return packer;
    }

    public static String getVersion() {
        return version;
    }

    public void runInBackground(final Runnable runnable) {
        backgroundExecutor.submit(runnable);
    }

    public void runOnUiThread(final Runnable runnable) {
        handler.post(runnable);
    }

    public void runOnUiThreadDelay(final Runnable runnable, long delayMillis) {
        handler.postDelayed(runnable, delayMillis);
    }

    public void register(Object obj) {
        EventBus.getDefault().register(obj);
    }

    public void unregister(Object obj) {
        EventBus.getDefault().unregister(obj);
    }

    public void doEvent(Event event) {
        EventBus.getDefault().post(event);
    }
}
