/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.method.NumberKeyListener;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.action.ActionInputTransData.EInputType;
import com.pax.pay.trans.component.Component;
import com.pax.pay.utils.EnterAmountTextWatcher;
import com.pax.pay.utils.ToastUtils;
import com.pax.view.keyboard.CustomKeyboardEditText;

import java.text.ParseException;
import java.text.SimpleDateFormat;

@SuppressLint("SimpleDateFormat")
public class InputTransData1Activity extends BaseActivityWithTickForAction {

    private ImageView headerBack;
    private Button confirmBtn;

    private String prompt;
    private String navTitle;

    private EInputType inputType;

    private boolean isVoidLastTrans;
    private boolean isPaddingZero;

    private int maxLen;
    private int minLen;

    private CustomKeyboardEditText mEditText = null;

    private TextView mPromptDoLast;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setEditText();
    }

    @Override
    protected void onResume() {
        super.onResume();
        mEditText.setText("");
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_input_trans_data1;
    }

    @Override
    protected void loadParam() {
        prompt = getIntent().getStringExtra(EUIParamKeys.PROMPT_1.toString());
        inputType = (EInputType) getIntent().getSerializableExtra(EUIParamKeys.INPUT_TYPE_1.toString());
        maxLen = getIntent().getIntExtra(EUIParamKeys.INPUT_MAX_LEN_1.toString(), 6);
        minLen = getIntent().getIntExtra(EUIParamKeys.INPUT_MIN_LEN_1.toString(), 0);
        navTitle = getIntent().getStringExtra(EUIParamKeys.NAV_TITLE.toString());
        isVoidLastTrans = getIntent().getBooleanExtra(EUIParamKeys.VOID_LAST_TRANS_UI.toString(), false);
        isPaddingZero = getIntent().getBooleanExtra(EUIParamKeys.INPUT_PADDING_ZERO.toString(), true);
    }

    @Override
    protected void initViews() {
        headerBack = (ImageView) findViewById(R.id.header_back);

        TextView headerText = (TextView) findViewById(R.id.header_title);
        headerText.setText(navTitle);

        TextView promptText = (TextView) findViewById(R.id.prompt_amount);
        promptText.setText(prompt);

        confirmBtn = (Button) findViewById(R.id.info_confirm);
        mPromptDoLast = (TextView) findViewById(R.id.prompt_do_last);
        if (!isVoidLastTrans) {
            mPromptDoLast.setVisibility(View.INVISIBLE);
        }
    }

    private void setEditText() {
        switch (inputType) {
            case DATE:
                setEditTextDate();
                break;
            case NUM:
                setEditTextNum();
                break;
            case ALPHA_NUM:
                setEditTextAlphaNum();
                break;
            default:
                break;
        }
        if (mEditText != null) {
            mEditText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                @Override
                public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                    if (actionId == EditorInfo.IME_ACTION_DONE) {
                        onClick(confirmBtn);
                    } else if (actionId == EditorInfo.IME_ACTION_NONE) {
                        onClick(headerBack);
                    }
                    return false;
                }
            });
        }
    }

    // 数字
    private void setEditTextNum() {
        mEditText = (CustomKeyboardEditText) findViewById(R.id.input_data_1);
        mEditText.requestFocus();
        mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLen)});
        if (minLen == 0) {
            confirmBtn.setEnabled(true);
            confirmBtn.setBackgroundResource(R.drawable.button_background);
        } else {
            mEditText.addTextChangedListener(new EnterAmountTextWatcher() {

                @Override
                public void afterTextChanged(Editable s) {
                    confirmBtnChange();
                }
            });
        }

    }

    // 日期
    private void setEditTextDate() {
        mEditText = (CustomKeyboardEditText) findViewById(R.id.input_data_1);
        mEditText.requestFocus();
        mPromptDoLast.setVisibility(View.INVISIBLE);
        mEditText.setHint(getString(R.string.prompt_date_default2));
        mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
        mEditText.addTextChangedListener(new EnterAmountTextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                confirmBtnChange();
            }
        });
    }

    // 数字加字母
    private void setEditTextAlphaNum() {
        mEditText = (CustomKeyboardEditText) findViewById(R.id.input_data_1);
        mEditText.requestFocus();
        mEditText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(maxLen)});
        mEditText.setKeyListener(new NumberKeyListener() {
            @Override
            protected char[] getAcceptedChars() {
                return "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM1234567890".toCharArray();
            }

            @Override
            public int getInputType() {
                return InputType.TYPE_TEXT_VARIATION_PASSWORD;
            }
        });
        mEditText.addTextChangedListener(new EnterAmountTextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                confirmBtnChange();
            }
        });
    }

    @Override
    protected void setListeners() {
        headerBack.setOnClickListener(this);
        confirmBtn.setOnClickListener(this);
    }

    @Override
    public void onClickProtected(View v) {

        switch (v.getId()) {
            case R.id.header_back:
                finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
                break;
            case R.id.info_confirm:
                String content = process();
                onConfirmResult(content);
                finish(new ActionResult(TransResult.SUCC, content));
                break;
            default:
                break;
        }

    }

    private void onConfirmResult(String content) {
        switch (inputType) {
            case NUM:
            case ALPHA_NUM:
                if (minLen > 0 && (content == null || content.isEmpty())) {
                    ToastUtils.showMessage(InputTransData1Activity.this, getString(R.string.please_input_again));
                    return;
                }
                break;
            default:
                break;
        }
    }

    /**
     * 输入数值检查
     */
    private String process() {
        String content = mEditText.getText().toString().trim();

        if (content.isEmpty()) {
            return null;
        }

        switch (inputType) {
            case DATE:
                return checkData(content) ? content : null;
            case NUM:
            case ALPHA_NUM:
                if (content.length() >= minLen && content.length() <= maxLen) {
                    if (isPaddingZero) {
                        content = Component.getPaddedString(content, maxLen, '0');
                    }
                } else {
                    return null;
                }
                break;
            default:
                break;
        }
        return content;
    }

    private boolean checkData(String content) {
        if (content.length() != 4) {
            return false;
        }
        SimpleDateFormat dateFormat = new SimpleDateFormat("MMdd");
        dateFormat.setLenient(false);
        try {
            dateFormat.parse(content);
        } catch (ParseException e) {
            Log.w(TAG, "", e);
            return false;
        }
        return true;
    }

    private void confirmBtnChange() {
        String content = mEditText.getText().toString();
        confirmBtn.setEnabled(!content.isEmpty());
    }

    @Override
    protected boolean onKeyBackDown() {
        finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
        return true;
    }
}