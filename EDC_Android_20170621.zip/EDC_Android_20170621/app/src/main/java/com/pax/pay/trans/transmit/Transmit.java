/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.transmit;

import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.utils.ResponseCode;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

public class Transmit {

    private Online online = new Online();

    public int transmit(TransData transData, TransProcessListener listener) {
        int ret = 0;
        int i = 0;
        ETransType transType = transData.getTransType();

        // 处理冲正
        if (transType.isDupSendAllowed()) {
            ret = sendReversal(listener);
            if (ret != 0) {
                i = 3;
            }
        }

        if (listener != null) {
            listener.onUpdateProgressTitle(transType.getTransName());
        }


        // 只有平台返回密码错时， 才会下次循环
        for (int j = i; j < 3; j++) {
            if (j != 0) {
                // 输入密码
                if (listener != null) {
                    ret = listener.onInputOnlinePin(transData);
                    if (ret != 0) {
                        return TransResult.ERR_ABORTED;
                    }
                } else {
                    return TransResult.ERR_HOST_REJECT;
                }
                transData.setTraceNo(FinancialApplication.getSysParam().get(SysParam.NumberParam.EDC_TRACE_NO));
            }
            if (listener != null) {
                listener.onUpdateProgressTitle(transType.getTransName());
            }

            ret = online.online(transData, listener);
            if (ret == TransResult.SUCC) {
                ResponseCode responseCode = transData.getResponseCode();
                String retCode = responseCode.getCode();

                if ("00".equals(retCode)) {
                    // write transaction record
                    transData.setReversalStatus(TransData.ReversalStatus.NORMAL);
                    transData.setDupReason("");
                    FinancialApplication.getTransDataDbHelper().updateTransData(transData);
                    return TransResult.SUCC;
                } else {
                    FinancialApplication.getTransDataDbHelper().deleteDupRecord();
                    if ("55".equals(retCode)) {
                        if (listener != null) {
                            listener.onShowErrMessageWithConfirm(
                                    Utils.getString(R.string.err_password_reenter),
                                    Constants.FAILED_DIALOG_SHOW_TIME);
                        }
                        continue;
                    }
                    if (listener != null) {
                        listener.onShowErrMessageWithConfirm(
                                Utils.getString(R.string.prompt_err_code) + retCode
                                        + "\n"
                                        + responseCode.getMessage(), Constants.FAILED_DIALOG_SHOW_TIME);
                    }
                    return TransResult.ERR_HOST_REJECT;
                }
            }

            break;
        }
        if (i == 3) {
            return TransResult.ERR_ABORTED;
        }

        return ret;
    }

    /**
     * 冲正处理
     *
     * @return
     */
    public int sendReversal(TransProcessListener listener) {
        TransData dupTransData = FinancialApplication.getTransDataDbHelper().findFirstDupRecord();
        if (dupTransData == null) {
            return TransResult.SUCC;
        }
        int ret = 0;
        long transNo = dupTransData.getTraceNo();
        String dupReason = dupTransData.getDupReason();

        ETransType transType = dupTransData.getTransType();
        if (transType == ETransType.VOID) {
            dupTransData.setOrigAuthCode(dupTransData.getOrigAuthCode());
        } else {
            dupTransData.setOrigAuthCode(dupTransData.getAuthCode());
        }

        Component.transInit(dupTransData);

        dupTransData.setTraceNo(transNo);
        dupTransData.setDupReason(dupReason);

        int retry = FinancialApplication.getSysParam().get(SysParam.NumberParam.EDC_REVERSAL_RETRY);
        if (listener != null) {
            listener.onUpdateProgressTitle(Utils.getString(R.string.prompt_reverse));
        }

        for (int i = 0; i < retry; i++) {
            //AET-126
            dupTransData.setReversalStatus(TransData.ReversalStatus.REVERSAL);
            ret = online.online(dupTransData, listener);
            if (ret == TransResult.SUCC) {
                String retCode = dupTransData.getResponseCode().getCode();
                // 冲正收到响应码12或者25的响应码，应默认为冲正成功
                if ("00".equals(retCode) || "12".equals(retCode) || "25".equals(retCode)) {
                    FinancialApplication.getTransDataDbHelper().deleteDupRecord();
                    return TransResult.SUCC;
                }
                dupTransData.setReversalStatus(TransData.ReversalStatus.PENDING);
                dupTransData.setDupReason(TransData.DUP_REASON_OTHERS);
                FinancialApplication.getTransDataDbHelper().updateTransData(dupTransData);
                continue;
            }
            if (ret == TransResult.ERR_CONNECT || ret == TransResult.ERR_PACK || ret == TransResult.ERR_SEND) {
                if (listener != null) {
                    listener.onShowErrMessageWithConfirm(
                            TransResult.getMessage(ret),
                            Constants.FAILED_DIALOG_SHOW_TIME);
                }

                return TransResult.ERR_ABORTED;
            }
            if (ret == TransResult.ERR_RECV) {
                dupTransData.setReversalStatus(TransData.ReversalStatus.PENDING);
                dupTransData.setDupReason(TransData.DUP_REASON_NO_RECV);
                FinancialApplication.getTransDataDbHelper().updateTransData(dupTransData);
                break;
            }
        }
        if (listener != null) {
            listener.onShowErrMessageWithConfirm(Utils.getString(R.string.err_reverse),
                    Constants.FAILED_DIALOG_SHOW_TIME);
        }
        FinancialApplication.getTransDataDbHelper().deleteDupRecord();
        return ret;
    }

    /**
     * 脱机交易上送
     *
     * @param isOnline 是否为在下笔联机交易到来之前上送
     * @return
     */
    public int sendOfflineTrans(TransProcessListener listener, boolean isOnline, boolean isSettlement) {
        int ret = new TransOnline().offlineTransSend(listener, isOnline, isSettlement);
        if (ret == TransResult.ERR_ABORTED) {
            return ret;
        }
        if (ret != TransResult.SUCC) {
            if (listener != null) {
                listener.onShowErrMessageWithConfirm(
                        TransResult.getMessage(ret),
                        Constants.FAILED_DIALOG_SHOW_TIME);
            }
        }
        return ret;
    }

}
