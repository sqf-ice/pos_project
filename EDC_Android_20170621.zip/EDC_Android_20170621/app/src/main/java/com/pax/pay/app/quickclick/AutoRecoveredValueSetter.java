/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.app.quickclick;

import android.os.SystemClock;

import com.pax.pay.app.FinancialApplication;

/**
 * 快速点击保护， 主要用在界面功能选择
 *
 * @author Steven.W
 */
class AutoRecoveredValueSetter<T> {

    T value;
    T recoveredTo;
    long timeoutMs;

    protected void setValue(T value) {
        this.value = value;
    }

    protected T getValue() {
        return value;
    }

    protected void setRecoverTo(T value) {
        this.recoveredTo = value;
    }

    protected void setTimeoutMs(long timeoutMs) {
        this.timeoutMs = timeoutMs;
    }

    protected void recover() {
        this.value = recoveredTo;
    }

    protected void autoRecover() {
        FinancialApplication.getApp().runInBackground(new Runnable() {
            @Override
            public void run() {
                SystemClock.sleep(timeoutMs);
                setValue(recoveredTo);
            }
        });
    }

}
