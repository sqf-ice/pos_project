/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.pack;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.abl.core.ipacker.IPacker;
import com.pax.abl.core.ipacker.PackListener;
import com.pax.gl.pack.IIso8583;
import com.pax.gl.pack.exception.Iso8583Exception;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;

import org.xmlpull.v1.XmlPullParserException;

import java.io.IOException;
import java.util.Calendar;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

public abstract class PackIso8583 implements IPacker<TransData, byte[]> {

    protected static final String TAG = "PackIso8583";

    private IIso8583 iso8583;
    private IIso8583.IIso8583Entity entity;
    protected PackListener listener;

    private static final Map<TransData.EnterMode, String> enterModeMap = new EnumMap<>(TransData.EnterMode.class);

    static {
        enterModeMap.put(TransData.EnterMode.MANUAL, "01");
        enterModeMap.put(TransData.EnterMode.SWIPE, "02");
        enterModeMap.put(TransData.EnterMode.INSERT, "05");
        enterModeMap.put(TransData.EnterMode.CLSS, "07");
        enterModeMap.put(TransData.EnterMode.FALLBACK, "80");
    }

    public PackIso8583(PackListener listener) {
        this.listener = listener;
        initEntity();
    }

    /**
     * 获取打包entity
     *
     * @return
     */
    private void initEntity() {
        iso8583 = FinancialApplication.getPacker().getIso8583();
        try {
            entity = iso8583.getEntity();
            entity.loadTemplate(FinancialApplication.getApp().getResources().getAssets().open("edc8583.xml"));
        } catch (Iso8583Exception | IOException | XmlPullParserException e) {
            Log.e(TAG, "", e);
        }
    }

    protected final void setBitData(String field, String value) throws Iso8583Exception {
        if (value != null && !value.isEmpty()) {
            entity.setFieldValue(field, value);
        }
    }

    protected final void setBitData(String field, byte[] value) throws Iso8583Exception {
        if (value != null && value.length > 0) {
            entity.setFieldValue(field, value);
        }
    }

    @NonNull
    protected
    byte[] pack(boolean isNeedMac) {
        try {
            if (isNeedMac) {
                setBitData("64", new byte[]{0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00});
            }
            // for debug entity.dump();
            byte[] packData = iso8583.pack();

            if (isNeedMac) {
                if (packData == null || packData.length == 0) {
                    return "".getBytes();
                }

                int len = packData.length;

                byte[] calMacBuf = new byte[len - 11 - 8];//去掉header和mac
                System.arraycopy(packData, 11, calMacBuf, 0, len - 11 - 8);
                byte[] mac = listener.onCalcMac(calMacBuf);
                if (mac.length == 0) {
                    return "".getBytes();
                }
                System.arraycopy(mac, 0, packData, len - 8, 8);
            }

            return packData;
        } catch (Iso8583Exception e) {
            Log.e(TAG, "", e);
        }
        return "".getBytes();
    }

    @Override
    public int unpack(@NonNull TransData transData, final byte[] rsp) {

        HashMap<String, byte[]> map;
        try {
            map = iso8583.unpack(rsp, true);
            // 调试信息， 日志输入解包后数据
            entity.dump();
        } catch (Iso8583Exception e) {
            Log.e(TAG, "", e);
            return TransResult.ERR_UNPACK;
        }

        // 报文头
        byte[] header = map.get("h");
        // TPDU检查
        String rspTpdu = new String(header).substring(0, 10);
        String reqTpdu = transData.getTpdu();
        if (!rspTpdu.substring(2, 6).equals(reqTpdu.substring(6, 10))
                || !rspTpdu.substring(6, 10).equals(reqTpdu.substring(2, 6))) {
            return TransResult.ERR_UNPACK;
        }
        transData.setHeader(new String(header).substring(10));

        ETransType transType = transData.getTransType();

        byte[] buff;
        // 检查39域应答码
        buff = map.get("39");
        if (buff == null) {
            return TransResult.ERR_BAG;
        }
        transData.setResponseCode(FinancialApplication.getRspCode().parse(new String(buff)));

        // 检查返回包的关键域， 包含field4
        boolean isCheckAmt = true;
        if (transType == ETransType.SETTLE) {
            isCheckAmt = false;
        }
        int ret = checkRecvData(map, transData, isCheckAmt);
        if (ret != TransResult.SUCC) {
            return ret;
        }

        // field 2 主账号

        // field 3 交易处理码
        buff = map.get("3");
        if (buff != null && buff.length > 0) {
            String origField3 = transData.getField3();
            if (origField3 != null && !origField3.isEmpty() && !origField3.equals(new String(buff))) {
                return TransResult.ERR_PROC_CODE;
            }
        }
        // field 4 交易金额
        buff = map.get("4");
        if (buff != null && buff.length > 0) {
            transData.setAmount(new String(buff));
        }

        // field 11 流水号
        buff = map.get("11");
        if (buff != null && buff.length > 0) {
            transData.setTraceNo(Long.parseLong(new String(buff)));
        }

        // field 13 受卡方所在地日期
        String dateTime = "";
        buff = map.get("13");
        if (buff != null) {
            Calendar calendar = Calendar.getInstance();
            int year = calendar.get(Calendar.YEAR);
            dateTime = Integer.toString(year) + new String(buff);
        }

        // field 12 受卡方所在地时间
        buff = map.get("12");
        if (buff != null && buff.length > 0) {
            transData.setDateTime(dateTime + new String(buff));
        }

        // field 14 卡有效期
        buff = map.get("14");
        if (buff != null && buff.length > 0) {
            String expDate = new String(buff);
            if (!"0000".equals(expDate)) {
                transData.setExpDate(expDate);
            }
        }

        // field 22

        // field 23 卡片序列号
        buff = map.get("23");
        if (buff != null && buff.length > 0) {
            transData.setCardSerialNo(new String(buff));
        }
        // field 25
        // field 26

        // field 35
        // field 36

        // field 37 检索参考号
        buff = map.get("37");
        if (buff != null && buff.length > 0) {
            transData.setRefNo(new String(buff));
        }

        // field 38 授权码
        buff = map.get("38");
        if (buff != null && buff.length > 0) {
            transData.setAuthCode(new String(buff));
        }

        // field 44
        buff = map.get("44");
        if (buff != null && buff.length > 11) {
            String temp = new String(buff).substring(0, 11).trim();
            transData.setIssuerCode(temp);
            if (buff.length > 11) {
                temp = new String(buff).substring(11).trim();
                transData.setAcqCode(temp);
            }
        }
        // field 48
        buff = map.get("48");
        if (buff != null && buff.length > 0) {
            transData.setField48(new String(buff));
        }

        // field 52

        // field 53

        // field 54

        // field 55
        buff = map.get("55");
        if (buff != null && buff.length > 0) {
            transData.setRecvIccData(FinancialApplication.getConvert().bcdToStr(buff));
        }

        // field 58

        // field 60
        buff = map.get("60");
        if (buff != null && buff.length > 0) {
            transData.setBatchNo(Long.parseLong(new String(buff).substring(2, 8)));
        }
        // field 61
        // field 62
        buff = map.get("62");
        if (buff != null && buff.length > 0) {
            transData.setField62(FinancialApplication.getConvert().bcdToStr(buff));
        }

        // field 64
        // 解包校验mac
        byte[] data = new byte[rsp.length - 11 - 8];
        System.arraycopy(rsp, 11, data, 0, data.length);
        buff = map.get("64");
        if (buff != null && buff.length > 0 && listener != null) {
            byte[] mac = listener.onCalcMac(data);
            if (!FinancialApplication.getConvert().isByteArrayValueSame(buff, 0, mac, 0, 8)) {
                return TransResult.ERR_MAC;
            }
        }

        return TransResult.SUCC;
    }

    /**
     * 设置公共数据
     * <p>
     * 设置域： h,m, field 3, field 25, field 41,field 42
     *
     * @param transData
     * @return
     */
    protected void setMandatoryData(@NonNull TransData transData) throws Iso8583Exception {
        // h
        String pHeader = transData.getTpdu() + transData.getHeader();
        entity.setFieldValue("h", pHeader);
        // m
        ETransType transType = transData.getTransType();
        if (transData.getReversalStatus() == TransData.ReversalStatus.REVERSAL) {
            entity.setFieldValue("m", transType.getDupMsgType());
        } else {
            entity.setFieldValue("m", transType.getMsgType());
        }

        // field 3/25 交易处理码/服务码
        setBitData3(transData);
        setBitData25(transData);

        // field 24 NII
        transData.setNii(FinancialApplication.getAcqManager().getCurAcq().getNii());
        setBitData24(transData);

        // field 41 终端号
        setBitData41(transData);

        // field 42 商户号
        setBitData42(transData);
    }

    /**
     * 设置field 2, 4, 11, 14, 22, 23, 26, 35,36,49,52, 53
     *
     * @param transData
     * @return
     */
    protected void setCommonData(@NonNull TransData transData) throws Iso8583Exception {
        TransData.EnterMode enterMode = transData.getEnterMode();

        if (enterMode == TransData.EnterMode.MANUAL) {
            // 手工输入
            // [2]主账号,[14]有效期
            setBitData2(transData);

            setBitData14(transData);

        } else if (enterMode == TransData.EnterMode.SWIPE || enterMode == TransData.EnterMode.FALLBACK) {
            // 刷卡

            // [35]二磁道,[36]三磁道
            setBitData35(transData);
            setBitData36(transData);

            //[54]tip amount  by lixc
            setBitData54(transData);

        } else if (enterMode == TransData.EnterMode.INSERT || enterMode == TransData.EnterMode.CLSS) {
            // [2]主账号
            setBitData2(transData);

            // [14]有效期
            setBitData14(transData);

            // [23]卡序列号
            setBitData23(transData);

            // [35]二磁道
            setBitData35(transData);
        }

        // field amount
        setBitData4(transData);

        // field 11 流水号
        setBitData11(transData);

        // field 22 服务点输入方式码
        setBitData22(transData);

        // [52]PIN
        setBitData52(transData);
    }

    /**
     * 设置金融类数据
     * <p>
     * 设置域
     * <p>
     * field 2, field 4,field 14, field 22,field 23,field 26, field 35,field 36,field 49, field 52,field 53, field 55
     *
     * @param transData
     */
    protected void setFinancialData(@NonNull TransData transData) throws Iso8583Exception {
        setMandatoryData(transData);
        setCommonData(transData);
        // field 55 ICC
        setBitData55(transData);
    }

    /**
     * 检查请求和返回的关键域field4, field11, field41, field42
     *
     * @param map        解包后的map
     * @param transData  请求
     * @param isCheckAmt 是否检查field4
     * @return
     */
    protected int checkRecvData(@NonNull HashMap<String, byte[]> map, @NonNull TransData transData, boolean isCheckAmt) {
        // 交易金额
        if (isCheckAmt && !checkAmount(map, transData)) {
            return TransResult.ERR_TRANS_AMT;
        }

        // 校验11域
        if (!checkTraceNo(map, transData))
            return TransResult.ERR_TRACE_NO;

        // 校验终端号
        if (!checkTerminalId(map, transData))
            return TransResult.ERR_TERM_ID;

        // 校验商户号
        if (!checkMerchantId(map, transData))
            return TransResult.ERR_MERCH_ID;

        return TransResult.SUCC;
    }

    protected void setBitData1(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData2(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("2", transData.getPan());
    }

    protected void setBitData3(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("3", transData.getTransType().getProcCode());
    }

    protected void setBitData4(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("4", transData.getAmount());
    }

    protected void setBitData5(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData6(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData7(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData8(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData9(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData10(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData11(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("11", String.valueOf(transData.getTraceNo()));
    }

    protected void setBitData12(@NonNull TransData transData) throws Iso8583Exception {
        String temp = transData.getDateTime();
        if (temp != null && !temp.isEmpty()) {
            String date = temp.substring(4, 8);
            String time = temp.substring(8, temp.length());
            setBitData("12", time);
            setBitData("13", date);
        }
    }

    protected void setBitData13(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData14(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("14", transData.getExpDate());
    }

    protected void setBitData15(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData16(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData17(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData18(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData19(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData20(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData21(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData22(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("22", getInputMethod(transData.getEnterMode(), transData.isHasPin()));
    }

    protected void setBitData23(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("23", transData.getCardSerialNo());
    }

    protected void setBitData24(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("24", transData.getNii());
    }

    protected void setBitData25(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("25", transData.getTransType().getServiceCode());
    }

    protected void setBitData26(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData27(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData28(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData29(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData30(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData31(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData32(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData33(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData34(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData35(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("35", transData.getTrack2());
    }

    protected void setBitData36(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("36", transData.getTrack3());
    }

    protected void setBitData37(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("37", transData.getRefNo());
    }

    protected void setBitData38(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("38", transData.getOrigAuthCode());
    }

    protected void setBitData39(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData40(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData41(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("41", transData.getAcquirer().getTerminalId());
    }

    protected void setBitData42(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("42", transData.getAcquirer().getMerchantId());
    }

    protected void setBitData43(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData44(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData45(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    protected void setBitData48(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("48", transData.getField48());
    }

    protected void setBitData52(@NonNull TransData transData) throws Iso8583Exception {
        if (transData.isHasPin()) {
            setBitData("52", FinancialApplication.getConvert().strToBcd(transData.getPin(), EPaddingPosition.PADDING_LEFT));
        }
    }

    protected void setBitData54(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("54", transData.getTipAmount());
    }

    protected void setBitData55(@NonNull TransData transData) throws Iso8583Exception {
        String temp = transData.getSendIccData();
        if (temp != null && temp.length() > 0) {
            setBitData("55", FinancialApplication.getConvert().strToBcd(temp, EPaddingPosition.PADDING_LEFT));
        }
    }

    protected void setBitData60(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("60", Component.getPaddedNumber(transData.getBatchNo(), 6));
    }

    protected void setBitData61(@NonNull TransData transData) throws Iso8583Exception {
        //do nothing
    }

    // set field 63
    protected void setBitData63(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("63", transData.getField63());
    }

    /**
     * @param enterMode
     * @param hasPin
     * @return
     */
    protected final String getInputMethod(TransData.EnterMode enterMode, boolean hasPin) {
        if (enterMode == null) //AET-40
            return null;
        String inputMethod;
        try {
            inputMethod = enterModeMap.get(enterMode);
        } catch (Exception e) {
            Log.w(TAG, "", e);
            return null;
        }

        if (hasPin) {
            inputMethod += "1";
        } else {
            inputMethod += "2";
        }

        return inputMethod;
    }

    private boolean checkAmount(@NonNull final HashMap<String, byte[]> map, @NonNull final TransData transData) {
        byte[] data = map.get("4");
        if (data != null && data.length > 0) {
            String temp = new String(data);
            if (Long.parseLong(temp) != Long.parseLong(transData.getAmount())) {
                return false;
            }
        }
        return true;
    }

    private boolean checkTraceNo(@NonNull final HashMap<String, byte[]> map, @NonNull final TransData transData) {
        byte[] data = map.get("11");
        if (data != null && data.length > 0) {
            String temp = new String(data);
            if (!temp.equals(Component.getPaddedNumber(transData.getTraceNo(), 6))) {
                return false;
            }
        }
        return true;
    }

    private boolean checkTerminalId(@NonNull final HashMap<String, byte[]> map, @NonNull final TransData transData) {
        byte[] data = map.get("41");
        if (data != null && data.length > 0) {
            String temp = new String(data);
            if (!temp.equals(transData.getAcquirer().getTerminalId())) {
                return false;
            }
        }
        return true;
    }

    private boolean checkMerchantId(@NonNull final HashMap<String, byte[]> map, @NonNull final TransData transData) {
        byte[] data = map.get("42");
        if (data != null && data.length > 0) {
            String temp = new String(data);
            if (!temp.equals(transData.getAcquirer().getMerchantId())) {
                return false;
            }
        }
        return true;
    }
}
