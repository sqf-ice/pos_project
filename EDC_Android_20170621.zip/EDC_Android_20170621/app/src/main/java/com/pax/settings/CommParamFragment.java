/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-30
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.settings;

import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.Preference;
import android.preference.PreferenceScreen;
import android.preference.RingtonePreference;
import android.provider.Settings;
import android.support.annotation.XmlRes;
import android.util.Log;
import android.widget.Toast;

import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.glwrapper.convert.IConvert;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.model.Controller;
import com.pax.pay.utils.Utils;

public class CommParamFragment extends BasePreferenceFragment {

    @Override
    public boolean onPreferenceTreeClick(PreferenceScreen preferenceScreen, Preference preference) {
        if(preference.getTitleRes() == R.string.open_wifi){
            Utils.callSystemSettings(getActivity(), Settings.ACTION_WIFI_SETTINGS);
            return true;
        }
        return super.onPreferenceTreeClick(preferenceScreen, preference);
    }

    @Override
    @XmlRes
    protected
    int getResourceId() {
        return R.xml.comm_para_pref;
    }

    @Override
    protected void initPreference() {
        bindPreference(SysParam.StringParam.COMM_TYPE);
        bindPreference(SysParam.NumberParam.COMM_TIMEOUT);
        bindPreference(SysParam.StringParam.MOBILE_TEL_NO);
        bindPreference(SysParam.StringParam.MOBILE_APN);

        bindPreference(SysParam.StringParam.MOBILE_USER);
        bindPreference(SysParam.StringParam.MOBILE_PWD);
    }

    @Override
    protected boolean onCheckBoxPreferenceChanged(CheckBoxPreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    @Override
    protected boolean onEditTextPreferenceChanged(EditTextPreference preference, Object value, boolean isInitLoading) {
        String stringValue = value.toString();
        preference.setSummary(stringValue);
        return true;
    }

    @Override
    protected boolean onRingtonePreferenceChanged(RingtonePreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    @Override
    protected boolean onListPreferenceChanged(ListPreference preference, Object value, boolean isInitLoading) {
        // For list preferences, look up the correct display value in
        // the preference's 'entries' list.
        Log.i("CommParamFragment", value.toString());
        String stringValue = value.toString();
        int index = preference.findIndexOfValue(stringValue);

        // Set the summary to reflect the new value.
        if (!isInitLoading && FinancialApplication.getTransDataDbHelper().countOf() > 0) {
            Toast.makeText(ActivityStack.getInstance().top(), R.string.has_trans_for_settle, Toast.LENGTH_LONG).show();
            return false;
        } else {
            if ("DEMO".equals(stringValue)) {
                boolean isFirstRun = FinancialApplication.getController().getBoolean(Controller.IS_FIRST_RUN);
                if (isFirstRun) {
                    int keyIndex = FinancialApplication.getSysParam().get(SysParam.NumberParam.MK_INDEX);
                    Device.writeTMK((byte) keyIndex,
                            FinancialApplication.getConvert().strToBcd("1234567890123456", IConvert.EPaddingPosition.PADDING_LEFT));
                    Device.writeTPK(FinancialApplication.getConvert().strToBcd("1234567890123456",
                            IConvert.EPaddingPosition.PADDING_LEFT), null);
                    Device.writeTAK(FinancialApplication.getConvert().strToBcd("1234567890123456",
                            IConvert.EPaddingPosition.PADDING_LEFT), null);
                }
            }

            preference.setSummary(index >= 0 ? preference.getEntries()[index] : null);
        }
        return true;
    }

    @Override
    protected boolean onMultiSelectListPreferenceChanged(MultiSelectListPreference preference, Object value, boolean isInitLoading) {
        return false;
    }

}
