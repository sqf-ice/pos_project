/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.receipt;

import android.annotation.SuppressLint;
import android.content.res.AssetManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;

import com.pax.abl.utils.PanUtils;
import com.pax.dal.entity.ETermInfoKey;
import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.eemv.enums.ETransResult;
import com.pax.gl.page.IPage;
import com.pax.gl.page.IPage.EAlign;
import com.pax.glwrapper.imgprocessing.IImgProcessing;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransData.EnterMode;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.TimeConverter;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

import java.io.IOException;
import java.io.InputStream;
import java.util.Map;

/**
 * receipt generator
 *
 * @author Steven.W
 */
@SuppressLint("SimpleDateFormat")
public class ReceiptGeneratorTrans implements IReceiptGenerator {

    int receiptNo = 0;
    private TransData transData;
    private boolean isRePrint = false;
    private int receiptMax = 0;
    private boolean isPrintPreview = false;

    /**
     * @param transData        ：transData
     * @param currentReceiptNo : currentReceiptNo
     * @param receiptMax       ：generate which one, start from 0
     * @param isReprint        ：is reprint?
     */
    public ReceiptGeneratorTrans(TransData transData, int currentReceiptNo, int receiptMax, boolean isReprint) {
        this.transData = transData;
        this.receiptNo = currentReceiptNo;
        this.isRePrint = isReprint;
        this.receiptMax = receiptMax;
    }

    public ReceiptGeneratorTrans(TransData transData, int currentReceiptNo, int receiptMax, boolean isReprint, boolean isPrintPreview) {
        this.transData = transData;
        this.receiptNo = currentReceiptNo;
        this.isRePrint = isReprint;
        this.receiptMax = receiptMax;
        this.isPrintPreview = isPrintPreview;
    }

    @Override
    public Bitmap generateBitmap() {
        boolean isPrintSign = false;
        // 生成第几张凭单不合法时， 默认0
        if (receiptNo > receiptMax) {
            receiptNo = 0;
        }
        // the first copy print signature, if three copies, the second copy should print signature too
        if (receiptNo == 0 || ((receiptMax == 3) && receiptNo == 1)) {
            isPrintSign = true;
        }

        IPage page = Device.generatePage();
        // transaction type
        ETransType transType = transData.getTransType();
        TransData.ETransStatus transStatus = transData.getTransState();

        SysParam sysParam = FinancialApplication.getSysParam();
        Acquirer acquirer = FinancialApplication.getAcqManager().getCurAcq();

        String temp;

        // title
        page.addLine().addUnit(getImageFromAssetsFile("pax_logo_normal.png"), EAlign.CENTER);
        page.addLine().addUnit("\n", FONT_NORMAL);
        if (isRePrint) {
            page.addLine().addUnit("----" + Utils.getString(R.string.receipt_print_again) + "----", FONT_BIG, EAlign.CENTER);
        }

        // merchant ID
        page.addLine().addUnit(Utils.getString(R.string.receipt_merchant_code), FONT_SMALL, (float) 4)
                .addUnit(acquirer.getMerchantId(), FONT_NORMAL, EAlign.RIGHT, (float) 6);

        // terminal ID/operator ID
        page.addLine()
                .addUnit(Utils.getString(R.string.receipt_terminal_code_space), FONT_SMALL, (float) 4)
                .addUnit(acquirer.getTerminalId(), FONT_NORMAL, EAlign.RIGHT, (float) 4);
        page.addLine().addUnit(" ", FONT_NORMAL);

        // card NO
        if (transType == ETransType.PREAUTH) {
            temp = transData.getPan();
        } else {
            if (!transData.isOnlineTrans()) {
                temp = transData.getPan();
            } else {
                temp = PanUtils.maskCardNo(transData.getPan(), transData.getIssuer().getPanMaskPattern());
            }
        }

        TransData.EnterMode enterMode = transData.getEnterMode();
        if (enterMode == EnterMode.MANUAL) {
            temp += " /M";
        } else if (enterMode == EnterMode.SWIPE) {
            temp += " /S";
        } else if (enterMode == EnterMode.INSERT) {
            temp += " /I";
        } else if (enterMode == EnterMode.CLSS) {
            temp += " /C";
        } else if (enterMode == EnterMode.FALLBACK) {
            temp += " /F";
        }

        String temp1 = transData.getExpDate();
        if (temp1 != null && !temp1.isEmpty()) {
            if (transData.getIssuer().isRequireMaskExpiry()) {
                temp1 = "**/**";
            } else {
                temp1 = temp1.substring(2) + "/" + temp1.substring(0, 2);// 将yyMM转换成MMyy
            }
        } else {
            temp1 = "";
        }

        //card NO/expiry date
        page.addLine().addUnit(Utils.getString(R.string.receipt_card_no) + "/" + Utils.getString(R.string.receipt_card_date),
                FONT_SMALL);
        page.addLine().addUnit(temp, FONT_NORMAL, EAlign.LEFT, (float) 4.6)
                .addUnit(temp1, FONT_NORMAL, EAlign.RIGHT, (float) 1.0);


        page.addLine().addUnit(Utils.getString(R.string.receipt_trans_type), FONT_SMALL);
        temp = transStatus.equals(TransData.ETransStatus.NORMAL) ? "" : " (" + transStatus.toString() + ")";
        page.addLine().addUnit(transType.getTransName() + temp, FONT_BIG);

        // batch NO/transaction N0
        temp = Component.getPaddedNumber(transData.getTraceNo(), 6);

        page.addLine()
                .addUnit(Utils.getString(R.string.receipt_batch_num_colon), FONT_SMALL)
                .addUnit(Utils.getString(R.string.receipt_trans_no), FONT_SMALL, EAlign.RIGHT);
        page.addLine()
                .addUnit(Component.getPaddedNumber(transData.getBatchNo(), 6), FONT_BIG)
                .addUnit(temp, FONT_BIG, EAlign.RIGHT);

        // date/time
        String formattedDate = TimeConverter.convert(transData.getDateTime(), Constants.TIME_PATTERN_TRANS,
                Constants.TIME_PATTERN_DISPLAY);
        page.addLine().addUnit(Utils.getString(R.string.receipt_date), FONT_SMALL);
        page.addLine().addUnit(formattedDate, FONT_BIG);

        // reference NO
        temp = transData.getRefNo();
        if (temp == null) {
            temp = "";
        }
        temp1 = transData.getAuthCode();

        page.addLine().addUnit(Utils.getString(R.string.receipt_ref_no), FONT_SMALL).addUnit(Utils.getString(R.string.receipt_app_code), FONT_SMALL, EAlign.RIGHT);
        page.addLine().addUnit(temp, FONT_BIG, (float) 4).addUnit(temp1, FONT_BIG, EAlign.RIGHT, (float) 3);
        page.addLine().addUnit(" ", FONT_NORMAL);

        //base & tip
        if (transType.isAdjustAllowed()) {
            long base = Long.parseLong(transData.getAmount()) - Long.parseLong(transData.getTipAmount());
            temp = CurrencyConverter.convert(base, transData.getCurrency());
            page.addLine().addUnit(Utils.getString(R.string.receipt_amount_base), FONT_BIG, (float) 4)
                    .addUnit(temp, FONT_BIG, EAlign.RIGHT, (float) 9);

            long tips = Long.parseLong(transData.getTipAmount());
            temp = CurrencyConverter.convert(tips, transData.getCurrency());
            page.addLine().addUnit(Utils.getString(R.string.receipt_amount_tip), FONT_BIG, (float) 4)
                    .addUnit(temp, FONT_BIG, EAlign.RIGHT, (float) 6);
            page.addLine().addUnit(" ", FONT_NORMAL);
        }

        // amount
        long amount = Long.parseLong(transData.getAmount());
        if (transType.isSymbolNegative())
            amount = -amount;
        temp = CurrencyConverter.convert(amount, transData.getCurrency());
        page.addLine().addUnit(Utils.getString(R.string.receipt_amount), FONT_NORMAL, (float) 4)
                .addUnit(temp, FONT_BIG, EAlign.RIGHT, (float) 9);
        page.addLine().addUnit(" ", FONT_NORMAL);

        if (transType == ETransType.VOID) {
            page.addLine().addUnit(
                    Utils.getString(R.string.receipt_orig_trans_no)
                            + Component.getPaddedNumber(transData.getOrigTransNo(), 6), FONT_NORMAL);
        }

        if ((enterMode == EnterMode.INSERT || enterMode == EnterMode.CLSS) &&
                (transType == ETransType.SALE || transType == ETransType.PREAUTH)) {
            if (transData.getEmvResult() == ETransResult.OFFLINE_APPROVED.ordinal()) {
                page.addLine().addUnit("TC:", FONT_NORMAL)
                        .addUnit(transData.getTc(), FONT_NORMAL, EAlign.RIGHT);
            } else {
                page.addLine().addUnit("ARQC:", FONT_NORMAL, (float) 4)
                        .addUnit(transData.getArqc(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            }

            page.addLine().addUnit("TSI:  " + transData.getTsi(), FONT_NORMAL)
                    .addUnit("ATC:  " + transData.getAtc(), FONT_NORMAL, EAlign.RIGHT);
            page.addLine().addUnit("TVR:", FONT_NORMAL).addUnit(transData.getTvr(), FONT_NORMAL, EAlign.RIGHT);
            page.addLine().addUnit("APP LABEL:", FONT_NORMAL).addUnit(transData.getEmvAppLabel(), FONT_NORMAL, EAlign.RIGHT);
            page.addLine().addUnit("AID:", FONT_NORMAL, (float) 4)
                    .addUnit(transData.getAid(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            page.addLine().addUnit(" ", FONT_NORMAL);
        }

        long pinFreeAmtLong = sysParam.get(SysParam.NumberParam.QUICK_PASS_TRANS_PIN_FREE_AMOUNT);
        long signFreeAmtLong = sysParam.get(SysParam.NumberParam.QUICK_PASS_TRANS_SIGN_FREE_AMOUNT);
        boolean isPinFree = transData.isPinFree();
        boolean isSignFree = transData.isSignFree();

        if (isPinFree && isSignFree) {// sign free and pin free
            if (pinFreeAmtLong > signFreeAmtLong) {
                page.addLine().addUnit(
                        Utils.getString(R.string.receipt_amount_prompt_start)
                                + CurrencyConverter.convert(signFreeAmtLong, transData.getCurrency())
                                + Utils.getString(R.string.receipt_amount_prompt_end), FONT_NORMAL, EAlign.LEFT);
            } else {
                page.addLine().addUnit(
                        Utils.getString(R.string.receipt_amount_prompt_start)
                                + CurrencyConverter.convert(pinFreeAmtLong, transData.getCurrency())
                                + Utils.getString(R.string.receipt_amount_prompt_end), FONT_NORMAL, EAlign.LEFT);
            }
        } else if (isSignFree) {// only sign free
            page.addLine().addUnit(
                    Utils.getString(R.string.receipt_amount_prompt_start)
                            + CurrencyConverter.convert(signFreeAmtLong, transData.getCurrency())
                            + Utils.getString(R.string.receipt_amount_prompt_end_sign), FONT_NORMAL, EAlign.LEFT);

        } else if (isPinFree && !transData.isCDCVM()) {// pin free
            page.addLine().addUnit(
                    Utils.getString(R.string.receipt_amount_prompt_start)
                            + CurrencyConverter.convert(pinFreeAmtLong, transData.getCurrency())
                            + Utils.getString(R.string.receipt_amount_prompt_end_pin), FONT_NORMAL,
                    EAlign.LEFT);
        }

        if (!isSignFree && isPrintSign) {
            page.addLine().addUnit(Utils.getString(R.string.receipt_sign), FONT_SMALL, EAlign.LEFT);
            Bitmap bitmap = loadSignature(transData);
            if (bitmap != null) {
                page.addLine().addUnit(loadSignature(transData), EAlign.CENTER);
            } else {
                page.addLine().addUnit("\n", FONT_NORMAL);
            }

        }
        page.addLine().addUnit(Utils.getString(R.string.receipt_sign_line), FONT_NORMAL, EAlign.CENTER);
        page.addLine().addUnit(Utils.getString(R.string.receipt_verify), FONT_SMALL, EAlign.CENTER);

        if (receiptMax == 3) {
            if (receiptNo == 0) {
                page.addLine()
                        .addUnit(Utils.getString(R.string.receipt_stub_acquire), FONT_NORMAL, EAlign.CENTER, (float) 1);
                page.addLine()
                        .addUnit(getTerminalAndAppVersion(), FONT_SMALL, EAlign.LEFT, (float) 2);
            } else if (receiptNo == 1) {
                page.addLine()
                        .addUnit(Utils.getString(R.string.receipt_stub_merchant), FONT_NORMAL, EAlign.CENTER, (float) 1);
                page.addLine()
                        .addUnit(getTerminalAndAppVersion(), FONT_SMALL, EAlign.LEFT, (float) 2);
            } else {
                page.addLine()
                        .addUnit(Utils.getString(R.string.receipt_stub_user), FONT_NORMAL, EAlign.CENTER, (float) 1);
                page.addLine()
                        .addUnit(getTerminalAndAppVersion(), FONT_SMALL, EAlign.LEFT, (float) 2);
            }
        } else {
            if (receiptNo == 0) {
                page.addLine()
                        .addUnit(Utils.getString(R.string.receipt_stub_merchant), FONT_NORMAL, EAlign.CENTER, (float) 1);
                page.addLine()
                        .addUnit(getTerminalAndAppVersion(), FONT_SMALL, EAlign.LEFT, (float) 2);
            } else {
                page.addLine()
                        .addUnit(Utils.getString(R.string.receipt_stub_user), FONT_NORMAL, EAlign.RIGHT, (float) 1);
                page.addLine().addUnit(getTerminalAndAppVersion(), FONT_SMALL, EAlign.LEFT, (float) 2);
            }
        }

        String commType = FinancialApplication.getSysParam().get(SysParam.StringParam.COMM_TYPE);
        if (SysParam.Constant.CommType.DEMO.toString().equals(commType)) {
            page.addLine().addUnit(Utils.getString(R.string.demo_mode), FONT_NORMAL, EAlign.CENTER);
        }

        if (!isPrintPreview) {
            page.addLine().addUnit("\n\n\n\n", FONT_NORMAL);
        }

        IImgProcessing imgProcessing = FinancialApplication.getGl().getImgProcessing();
        return imgProcessing.pageToBitmap(page, 384);
    }

    private Bitmap getImageFromAssetsFile(String fileName) {
        Bitmap image = null;
        AssetManager am = FinancialApplication.getApp().getResources().getAssets();
        try {
            InputStream is = am.open(fileName);
            image = BitmapFactory.decodeStream(is);
            is.close();
        } catch (IOException e) {
            Log.e(TAG, "", e);
        }

        return image;

    }

    private Bitmap loadSignature(TransData transData) {
        byte[] signData = transData.getSignData();
        if (signData == null) {
            return null;
        }
        return FinancialApplication.getGl().getImgProcessing().jbigToBitmap(signData);
    }

    /***
     * // generate bar code
     * private void generateBarCode(TransData transData, IPage page) {
     * <p>
     * ETransType transType = ETransType.valueOf(transData.getTransType());
     * if (transType == ETransType.AUTH || transType == ETransType.SALE) {
     * if (transData.getTransState().equals(ETransStatus.VOIDED)) {
     * return;
     * }
     * try {
     * JSONObject json = new JSONObject();
     * <p>
     * json.put("authCode", transData.getAuthCode());
     * json.put("date", transData.getDateTime().substring(4, 8));
     * json.put("transNo", transData.getTraceNo());
     * json.put("refNo", transData.getRefNo());
     * <p>
     * JSONArray array = new JSONArray();
     * array.put(json);
     * <p>
     * page.addLine().addUnit(
     * FinancialApplication.gl.getImgProcessing().generateBarCode(array.toString(), 230, 230,
     * BarcodeFormat.QR_CODE), EAlign.CENTER);
     * } catch (JSONException e) {
     * e.printStackTrace();
     * }
     * <p>
     * }
     * }
     ***/

    private String getTerminalAndAppVersion() {
        Map<ETermInfoKey, String> map = FinancialApplication.getDal().getSys().getTermInfo();
        return map.get(ETermInfoKey.MODEL) + " " + FinancialApplication.getVersion();
    }

    @Override
    public String generateString() {
        return "Card No:" + transData.getPan() + "\nTrans Type:" + transData.getTransType().toString()
                + "\nAmount:" + CurrencyConverter.convert(Long.parseLong(transData.getAmount()), transData.getCurrency())
                + "\nTip:" + CurrencyConverter.convert(Long.parseLong(transData.getTipAmount()), transData.getCurrency())
                + "\nTransData:" + transData.getDateTime();
    }
}
