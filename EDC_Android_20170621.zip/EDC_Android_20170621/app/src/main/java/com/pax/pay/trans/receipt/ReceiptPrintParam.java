/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.receipt;

import com.pax.edc.R;
import com.pax.pay.utils.Utils;

/**
 * print receipt
 *
 * @author Steven.W
 */
public class ReceiptPrintParam extends AReceiptPrint {
    public enum Type {
        AID,
        CAPK,
    }

    public int print(Type type, PrintListener listener) {
        this.listener = listener;
        if (listener != null)
            listener.onShowMessage(null, Utils.getString(R.string.wait_print));

        ReceiptGeneratorParam receiptGeneratorParam;
        switch (type) {
            case AID:
                receiptGeneratorParam = new ReceiptGeneratorAidParam();
                break;
            case CAPK:
                receiptGeneratorParam = new ReceiptGeneratorCapkParam();
                break;
            default:
                return -1;
        }

        int ret = printBitmap(receiptGeneratorParam.generateBitmaps());
        if (listener != null) {
            listener.onEnd();
        }
        return ret;
    }

}
