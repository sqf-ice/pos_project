/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-11
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.EditorActionListener;
import com.pax.pay.utils.EnterAmountTextWatcher;
import com.pax.view.keyboard.CustomKeyboardEditText;

public class EnterAmountActivity extends BaseActivityWithTickForAction {

    private LinearLayout tipAmountLL;
    private TextView textBaseAmount;//base amount text
    private TextView promptTip;
    private TextView textTipAmount;//tip amount text
    private CustomKeyboardEditText editAmount;//total amount edit text

    private String title;
    private boolean hasTip;
    private float percent;

    private boolean isTipMode = false;

    private EnterAmountTextWatcher amountWatcher = null;

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        editAmount.requestFocus();
    }

    @Override
    protected void loadParam() {
        title = getIntent().getStringExtra(EUIParamKeys.NAV_TITLE.toString());
        hasTip = getIntent().getBooleanExtra(EUIParamKeys.HAS_TIP.toString(), false);
        if (hasTip) {
            percent = getIntent().getFloatExtra(EUIParamKeys.TIP_PERCENT.toString(), 0.0f);
        }
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_enter_amount;
    }

    @Override
    protected void initViews() {
        ImageView headerBack = (ImageView) findViewById(R.id.header_back);
        headerBack.setVisibility(View.INVISIBLE);

        TextView titleTv = (TextView) findViewById(R.id.header_title);
        titleTv.setText(title);

        textBaseAmount = (TextView) findViewById(R.id.base_amount_input_text);
        tipAmountLL = (LinearLayout) findViewById(R.id.tip_amount_ll);
        promptTip = (TextView) findViewById(R.id.prompt_tip);
        textTipAmount = (TextView) findViewById(R.id.tip_amount_input_text);

        editAmount = (CustomKeyboardEditText) findViewById(R.id.amount_edit);
        editAmount.setText(CurrencyConverter.convert(0L)); //AET-64
        editAmount.requestFocus();
    }

    @Override
    protected void setListeners() {

        amountWatcher = new EnterAmountTextWatcher();
        amountWatcher.setOnTipListener(new EnterAmountTextWatcher.OnTipListener() {
            @Override
            public void onUpdateTipListener(long baseAmount, long tipAmount) {
                textTipAmount.setText(CurrencyConverter.convert(tipAmount));
            }

            @Override
            public boolean onVerifyTipListener(long baseAmount, long tipAmount) {
                return !isTipMode || (baseAmount * percent / 100 >= tipAmount); //AET-33
            }
        });
        editAmount.addTextChangedListener(amountWatcher);

        editAmount.setOnEditorActionListener(new EnterAmountEditorActionListener());
    }


    @Override
    protected boolean onKeyBackDown() {
        finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
        return true;
    }

    private class EnterAmountEditorActionListener extends EditorActionListener {
        @Override
        public void onKeyCancel() {
            updateAmount(false);
            finish(new ActionResult(TransResult.ERR_USER_CANCEL, null)); // AET-64
        }

        @Override
        public void onKeyOk() {
            if (!isTipMode) {
                if ("0".equals(CurrencyConverter.parse(editAmount.getText().toString().trim()).toString())) {
                    return;
                }
                if (hasTip) {
                    updateAmount(true);
                    return;
                }
            }
            finish(new ActionResult(TransResult.SUCC,
                    CurrencyConverter.parse(editAmount.getText().toString().trim()),
                    CurrencyConverter.parse(textTipAmount.getText().toString().trim()))
            );
        }

        //update total amount
        private synchronized void updateAmount(boolean isTipMode) {
            EnterAmountActivity.this.isTipMode = isTipMode;
            editAmount.requestFocus();
            if (isTipMode) {
                textBaseAmount.setVisibility(View.VISIBLE);
                tipAmountLL.setVisibility(View.VISIBLE);
                textBaseAmount.setText(editAmount.getText());
                promptTip.setText(getString(R.string.prompt_tip) + "(max:" + percent + "%)");
                textTipAmount.setText("");
                if (amountWatcher != null)
                    amountWatcher.setAmount(CurrencyConverter.parse(editAmount.getText().toString().trim()), 0L);
            } else {
                textBaseAmount.setVisibility(View.INVISIBLE);
                tipAmountLL.setVisibility(View.INVISIBLE);
                textBaseAmount.setText("");
                textTipAmount.setText("");
                if (amountWatcher != null)
                    amountWatcher.setAmount(0L, 0L);
                editAmount.setText("");
            }
        }
    }
}
