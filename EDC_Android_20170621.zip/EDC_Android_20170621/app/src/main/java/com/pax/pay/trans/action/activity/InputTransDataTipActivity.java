/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-13
 * Module Author: qixw
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.EnterAmountTextWatcher;
import com.pax.pay.utils.ToastUtils;
import com.pax.view.keyboard.CustomKeyboardEditText;

public class InputTransDataTipActivity extends BaseActivityWithTickForAction {

    private ImageView headerBack;

    private TextView mOriTips;
    private TextView mTotalAmount;
    private CustomKeyboardEditText mEditNewTips;

    private Button confirmBtn;

    private String navTitle;

    private long totalAmountLong = 0L;
    private long tipAmountLong = 0L;
    private long baseAmountLong = 0L;
    private float adjustPercent = 0L;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setEditText();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_input_info12;
    }

    @Override
    protected void loadParam() {
        navTitle = getIntent().getStringExtra(EUIParamKeys.NAV_TITLE.toString());

        String oriTransAmount = getIntent().getStringExtra(EUIParamKeys.TRANS_AMOUNT.toString());
        String oriTips = getIntent().getStringExtra(EUIParamKeys.ORI_TIPS.toString());
        totalAmountLong = Long.parseLong(oriTransAmount);
        tipAmountLong = Long.parseLong(oriTips);
        baseAmountLong = totalAmountLong - tipAmountLong;
        adjustPercent = getIntent().getFloatExtra(EUIParamKeys.TIP_PERCENT.toString(), 0.0f);

    }

    @Override
    protected void initViews() {
        headerBack = (ImageView) findViewById(R.id.header_back);

        TextView headerText = (TextView) findViewById(R.id.header_title);
        headerText.setText(navTitle);
        TextView mBaseAmount = (TextView) findViewById(R.id.value_base_amount);
        mOriTips = (TextView) findViewById(R.id.value_oritips);
        mTotalAmount = (TextView) findViewById(R.id.value_totalamount);

        mBaseAmount.setText(CurrencyConverter.convert(baseAmountLong));
        mOriTips.setText(CurrencyConverter.convert(tipAmountLong));
        mTotalAmount.setText(CurrencyConverter.convert(totalAmountLong));

        mEditNewTips = (CustomKeyboardEditText) findViewById(R.id.prompt_edit_newtips);
        mEditNewTips.setText(CurrencyConverter.convert(tipAmountLong));
        mEditNewTips.setFocusable(true);
        mEditNewTips.requestFocus();

        confirmBtn = (Button) findViewById(R.id.info_confirm);
    }

    private void setEditText() {
        mEditNewTips.setHint(getString(R.string.amount_default));
        mEditNewTips.requestFocus();

        confirmBtnChange(); //AET-19

        EnterAmountTextWatcher amountWatcher = new EnterAmountTextWatcher();
        amountWatcher.setOnTipListener(new EnterAmountTextWatcher.OnTipListener() {
            @Override
            public void onUpdateTipListener(long baseAmount, long tipAmount) {
                tipAmountLong = tipAmount;
                totalAmountLong = baseAmountLong + tipAmountLong;
                confirmBtnChange();
                mTotalAmount.setText(CurrencyConverter.convert(totalAmountLong));
            }

            @Override
            public boolean onVerifyTipListener(long baseAmount, long tipAmount) {
                return baseAmountLong * adjustPercent / 100 >= tipAmount;
            }
        });
        mEditNewTips.addTextChangedListener(amountWatcher);
    }

    private void confirmBtnChange() {
        boolean enable = !mOriTips.getText().toString().equals(mEditNewTips.getText().toString());
        confirmBtn.setEnabled(enable);
    }

    @Override
    protected void setListeners() {
        headerBack.setOnClickListener(this);
        confirmBtn.setOnClickListener(this);
    }

    @Override
    public void onClickProtected(View v) {

        switch (v.getId()) {
            case R.id.header_back:
                finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
                break;
            case R.id.info_confirm:
                String content = process();
                if (content == null || content.isEmpty()) {
                    ToastUtils.showMessage(InputTransDataTipActivity.this,
                            getString(R.string.please_input_again));
                    return;
                }
                finish(new ActionResult(TransResult.SUCC, totalAmountLong, tipAmountLong));
                break;
            default:
                break;
        }

    }

    /**
     * 输入数值检查
     */
    private String process() {
        String content = mEditNewTips.getText().toString().trim();

        if (content.isEmpty()) {
            return null;
        }

        //tip can be 0, so don't need to check here
        return CurrencyConverter.parse(mEditNewTips.getText().toString().trim()).toString();
    }

    @Override
    protected boolean onKeyBackDown() {
        finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
        return true;
    }
}
