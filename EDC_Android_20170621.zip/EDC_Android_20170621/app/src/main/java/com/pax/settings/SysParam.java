/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-30
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.settings;

import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.preference.PreferenceManager;
import android.util.Log;

import com.pax.abl.utils.EncUtils;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.Constants;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.Utils;
import com.pax.settings.spupgrader.SpUpgrader;
import com.pax.settings.spupgrader.Upgrade1To2;

import java.io.File;
import java.io.FileInputStream;
import java.util.Locale;

public class SysParam {

    private static final String TAG = "SysParam";

    private static final String UPGRADER_PATH = "com.pax.setting.spupgrader";

    private static final String IS_PARAM_FILE_EXIST = "IS_PARAM_FILE_EXIST";
    private static final String VERSION_TAG = "PARAM_VERSION";
    private static final int VERSION = 1;

    private static final String INIT_FILE_NAME = "param.ini";

    public enum NumberParam {
        COMM_TIMEOUT(Utils.getString(R.string.COMM_TIMEOUT)),
        MOBILE_LOGIN_WAIT_TIME(Utils.getString(R.string.MOBILE_LOGIN_WAIT_TIME)),
        MOBILE_HOST_PORT(Utils.getString(R.string.MOBILE_HOST_PORT)),
        MOBILE_HOST_PORT_BAK(Utils.getString(R.string.MOBILE_HOST_PORT_BAK)),
        LAN_HOST_PORT(Utils.getString(R.string.LAN_HOST_PORT)),
        LAN_HOST_PORT_BAK(Utils.getString(R.string.LAN_HOST_PORT_BAK)),
        COMM_REDIAL_TIMES(Utils.getString(R.string.COMM_REDIAL_TIMES)),
        EDC_RECEIPT_NUM(Utils.getString(R.string.EDC_RECEIPT_NUM)),
        EDC_SMTP_SSL_PORT(Utils.getString(R.string.EDC_SMTP_SSL_PORT)),
        EDC_SMTP_PORT(Utils.getString(R.string.EDC_SMTP_PORT)),
        EDC_REVERSAL_RETRY(Utils.getString(R.string.EDC_REVERSAL_RETRY)),
        MAX_TRANS_COUNT(Utils.getString(R.string.MAX_TRANS_COUNT)),
        MK_INDEX(Utils.getString(R.string.MK_INDEX)),
        MK_INDEX_MANUAL(Utils.getString(R.string.MK_INDEX_MANUAL)),
        OFFLINE_TC_UPLOAD_TIMES(Utils.getString(R.string.OFFLINE_TC_UPLOAD_TIMES)),  // 离线上送次数
        OFFLINE_TC_UPLOAD_NUM(Utils.getString(R.string.OFFLINE_TC_UPLOAD_NUM)), // 自动上送累计笔数
        EDC_TRACE_NO(Utils.getString(R.string.EDC_TRACE_NO)),

        QUICK_PASS_TRANS_PIN_FREE_AMOUNT(Utils.getString(R.string.QUICK_PASS_TRANS_PIN_FREE_AMOUNT)),
        QUICK_PASS_TRANS_SIGN_FREE_AMOUNT(Utils.getString(R.string.QUICK_PASS_TRANS_SIGN_FREE_AMOUNT)),;

        private String str;

        NumberParam(String str){
            this.str = str;
        }

        @Override
        public String toString() {
            return str;
        }
    }

    public enum StringParam {
        /**
         * 通讯方式
         */
        COMM_TYPE(Utils.getString(R.string.COMM_TYPE)),
        COMM_TYPE_SSL(Utils.getString(R.string.COMM_TYPE_SSL)),

        /**
         * 移动网络
         */
        MOBILE_TEL_NO(Utils.getString(R.string.MOBILE_TEL_NO)),
        MOBILE_APN(Utils.getString(R.string.MOBILE_APN)),
        MOBILE_USER(Utils.getString(R.string.MOBILE_USER)),
        MOBILE_PWD(Utils.getString(R.string.MOBILE_PWD)),
        MOBILE_SIM_PIN(Utils.getString(R.string.MOBILE_SIM_PIN)),
        MOBILE_AUTH(Utils.getString(R.string.MOBILE_AUTH)),
        MOBILE_HOST_IP(Utils.getString(R.string.MOBILE_HOST_IP)),
        MOBILE_HOST_IP_BAK(Utils.getString(R.string.MOBILE_HOST_IP_BAK)),
        MOBILE_DOMAIN_NAME(Utils.getString(R.string.MOBILE_DOMAIN_NAME)),

        // 以太网参数
        LAN_LOCAL_IP(Utils.getString(R.string.LAN_LOCAL_IP)),
        LAN_NETMASK(Utils.getString(R.string.LAN_NETMASK)),
        LAN_GATEWAY(Utils.getString(R.string.LAN_GATEWAY)),
        LAN_DNS1(Utils.getString(R.string.LAN_DNS1)),
        LAN_DNS2(Utils.getString(R.string.LAN_DNS2)),
        LAN_HOST_IP(Utils.getString(R.string.LAN_HOST_IP)),
        LAN_HOST_IP_BAK(Utils.getString(R.string.LAN_HOST_IP_BAK)),

        EDC_MERCHANT_NAME_EN(Utils.getString(R.string.EDC_MERCHANT_NAME_EN)),
        EDC_MERCHANT_ADDRESS(Utils.getString(R.string.EDC_MERCHANT_ADDRESS)),
        EDC_CURRENCY_LIST(Utils.getString(R.string.EDC_CURRENCY_LIST)),
        EDC_PED_MODE(Utils.getString(R.string.EDC_PED_MODE)),

        EDC_SMTP_HOST(Utils.getString(R.string.EDC_SMTP_HOST)),
        EDC_SMTP_USERNAME(Utils.getString(R.string.EDC_SMTP_USERNAME)),
        EDC_SMTP_PASSWORD(Utils.getString(R.string.EDC_SMTP_PASSWORD)),
        EDC_SMTP_FROM(Utils.getString(R.string.EDC_SMTP_FROM)),
        KEY_ALGORITHM(Utils.getString(R.string.KEY_ALGORITHM)),

        SEC_SYS_PWD(Utils.getString(R.string.SEC_SYS_PWD)),
        SEC_MERCHANT_PWD(Utils.getString(R.string.SEC_MERCHANT_PWD)),
        SEC_TERMINAL_PWD(Utils.getString(R.string.SEC_TERMINAL_PWD)),
        SEC_VOID_PWD(Utils.getString(R.string.SEC_VOID_PWD)),
        SEC_REFUND_PWD(Utils.getString(R.string.SEC_REFUND_PWD)),
        SEC_ADJUST_PWD(Utils.getString(R.string.SEC_ADJUST_PWD)),
        SEC_SETTLE_PWD(Utils.getString(R.string.SEC_SETTLE_PWD)),

        ACQ_NAME(Utils.getString(R.string.ACQ_NAME)),  //当前收单行名字

        MK_VALUE(Utils.getString(R.string.MK_VALUE)),
        PK_VALUE(Utils.getString(R.string.PK_VALUE)),
        AK_VALUE(Utils.getString(R.string.AK_VALUE)),;

        private String str;

        StringParam(String str){
            this.str = str;
        }

        @Override
        public String toString() {
            return str;
        }
    }

    public enum BooleanParam {
        LAN_DHCP(Utils.getString(R.string.LAN_DHCP)),
        MOBILE_KEEP_ALIVE(Utils.getString(R.string.MOBILE_KEEP_ALIVE)),

        EDC_SUPPORT_TIP(Utils.getString(R.string.EDC_SUPPORT_TIP)), // 支持小费
        EDC_SUPPORT_KEYIN(Utils.getString(R.string.EDC_SUPPORT_KEYIN)), // 允许手输卡号
        SUPPORT_USER_AGREEMENT(Utils.getString(R.string.SUPPORT_USER_AGREEMENT)), // 支持用户须知阅读

        EDC_ENABLE_PAPERLESS(Utils.getString(R.string.EDC_ENABLE_PAPERLESS)),
        EDC_SMTP_ENABLE_SSL(Utils.getString(R.string.EDC_SMTP_ENABLE_SSL)),

        OTHTC_VERIFY(Utils.getString(R.string.OTHTC_VERIFY)),  // 撤销退货类交易输入主管密码

        /**
         * 银行卡闪付 参数
         **/
        QUICK_PASS_TRANS_PIN_FREE_SWITCH(Utils.getString(R.string.QUICK_PASS_TRANS_PIN_FREE_SWITCH)),
        QUICK_PASS_TRANS_FLAG(Utils.getString(R.string.QUICK_PASS_TRANS_FLAG)),
        QUICK_PASS_TRANS_SWITCH(Utils.getString(R.string.QUICK_PASS_TRANS_SWITCH)),

        QUICK_PASS_TRANS_CDCVM_FLAG(Utils.getString(R.string.QUICK_PASS_TRANS_CDCVM_FLAG)),

        QUICK_PASS_TRANS_SIGN_FREE_FLAG(Utils.getString(R.string.QUICK_PASS_TRANS_SIGN_FREE_FLAG)),

        TTS_SALE(Utils.getString(R.string.TTS_SALE)),
        TTS_VOID(Utils.getString(R.string.TTS_VOID)),
        TTS_REFUND(Utils.getString(R.string.TTS_REFUND)),
        TTS_PREAUTH(Utils.getString(R.string.TTS_PREAUTH)),
        TTS_ADJUST(Utils.getString(R.string.TTS_ADJUST)),;

        private String str;

        BooleanParam(String str){
            this.str = str;
        }

        @Override
        public String toString() {
            return str;
        }
    }

    private static SysParam mSysParam;

    private static UpdateListener updateListener;

    private SysParam() {
        if (!init())
            load(); // 加载参数内容到SysParam中
    }

    public static synchronized SysParam getInstance() {
        if (mSysParam == null) {
            mSysParam = new SysParam();
        }
        return mSysParam;
    }

    public interface UpdateListener {
        void onErr(String prompt);
    }

    public static void setUpdateListener(UpdateListener listener) {
        updateListener = listener;
    }

    /**
     * 下载文件param.ini到files目录的方式初始化参数
     *
     */
    public boolean init() {
        File file = new File(FinancialApplication.getApp().getFilesDir() + File.separator + INIT_FILE_NAME);
        if (!file.exists() || file.length() == 0) {
            return false;
        }
        if (FinancialApplication.getTransDataDbHelper().countOf() > 0) {
            if (updateListener != null) {
                updateListener.onErr(FinancialApplication.getApp().getString(R.string.param_need_update_please_settle));
            }
            return false;
        }
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        Editor editor = sharedPreferences.edit();
        try (FileInputStream input = new FileInputStream(file)) {
            byte[] buf = new byte[(int) file.length()];
            int len = input.read(buf);
            input.close();

            if (len <= 0 || buf.length <= 0) {
                return false;
            }

            /*
              From https://github.com/android/platform_external_apache-http/blob/master/src/org/apache/http/util/EncodingUtils.java
              EncodingUtils.get is just new String(data, offset, length, charset) with argument check
             */
            //String allParams = EncodingUtils.get(buf, "UTF-8"); // outdated
            String allParams = new String(buf, "UTF-8");
            String[] paramArr = allParams.split("\r\n");
            if (paramArr.length == 0)
                return false;
            for (String param : paramArr) {
                if (param.contains("####"))
                    continue;
                String[] item = param.split("=", 2);
                if (item.length == 0) { // 文件格式不对
                    return false;

                } else if (item.length == 2) {
                    switch (item[1]) {
                        case "Y":
                            editor.putBoolean(item[0], true);
                            break;
                        case "N":
                            editor.putBoolean(item[0], false);
                            break;
                        default:
                            editor.putString(item[0], item[1]);
                            break;
                    }
                } else {
                    editor.putString(item[0], "");
                }

            }
            editor.apply();

        } catch (Exception e) {
            Log.e(TAG, "", e);
            return false;
        }
        file.delete();
        return true;
    }

    // 系统参数加载，如果db中不存在则添加
    private void load() {
        // 设置默认参数值
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        Editor editor = sharedPreferences.edit();

        if (isParamFileExist()) {
            try {
                for (int i = getVersion(); i < VERSION; ++i) {
                    SpUpgrader.upgrade(editor, i, i + 1, UPGRADER_PATH);
                    editor.putInt(SysParam.VERSION_TAG, i + 1);
                    editor.apply();
                }
            } catch (IllegalArgumentException e) {
                Log.w(TAG, "", e);
            }
            return;
        }

        if (editor != null) {
            editor.putBoolean(SysParam.IS_PARAM_FILE_EXIST, true);
            editor.putInt(SysParam.VERSION_TAG, VERSION);

            // 通讯参数
            // TPDU

            // 超时时间
            int commTimeout = Integer.parseInt(FinancialApplication.getApp().getResources().getStringArray(R.array.edc_connect_time_entries)[0]);
            set(editor, NumberParam.COMM_TIMEOUT, commTimeout);
            set(editor, NumberParam.COMM_REDIAL_TIMES, 3);
            // 通讯方式
            set(editor, StringParam.COMM_TYPE, Constant.CommType.WIFI.toString());
            set(editor, StringParam.COMM_TYPE_SSL, Constant.CommSslType.NO_SSL.toString());

            // MOBILE参数
            set(editor, StringParam.MOBILE_TEL_NO, "8888888");
            set(editor, StringParam.MOBILE_APN, "szjrln.gd");
            set(editor, StringParam.MOBILE_USER, "");
            set(editor, StringParam.MOBILE_PWD, "");
            set(editor, StringParam.MOBILE_HOST_IP, "144.144.21.12");
            set(editor, NumberParam.MOBILE_HOST_PORT, 8998);
            set(editor, StringParam.MOBILE_HOST_IP_BAK, "0.0.0.0");
            set(editor, NumberParam.MOBILE_HOST_PORT_BAK, 0);

            // 以太网参数
            set(editor, StringParam.LAN_LOCAL_IP, "172.16.10.125");
            set(editor, StringParam.LAN_NETMASK, "255.255.255.0");
            set(editor, StringParam.LAN_GATEWAY, "172.16.10.1");
            set(editor, StringParam.LAN_HOST_IP_BAK, "0.0.0.0");
            set(editor, NumberParam.LAN_HOST_PORT_BAK, 0);
            set(editor, BooleanParam.LAN_DHCP, false);
            set(editor, StringParam.LAN_HOST_IP, "116.228.223.216");
            set(editor, NumberParam.LAN_HOST_PORT, 10021);
            set(editor, StringParam.LAN_DNS1, "192.168.0.111");
            set(editor, StringParam.LAN_DNS2, "192.168.0.112");

            // 商户参数
            set(editor, StringParam.EDC_MERCHANT_NAME_EN, "Merchant Name"); // 英文商户名
            set(editor, StringParam.EDC_MERCHANT_ADDRESS, "Merchant Addr");
            set(editor, StringParam.EDC_CURRENCY_LIST, CurrencyConverter.getDefCurrency().getDisplayName(Locale.US));
            set(editor, StringParam.EDC_PED_MODE, FinancialApplication.getApp().getResources().getStringArray(R.array.edc_ped_mode_value_entries)[0]);
            set(editor, NumberParam.EDC_RECEIPT_NUM, 1);
            set(editor, NumberParam.EDC_TRACE_NO, 1);
            set(editor, BooleanParam.EDC_SUPPORT_TIP, true);
            set(editor, NumberParam.EDC_REVERSAL_RETRY, 3); // 冲正控制

            set(editor, BooleanParam.SUPPORT_USER_AGREEMENT, false);
            set(editor, BooleanParam.EDC_ENABLE_PAPERLESS, true);
            set(editor, StringParam.EDC_SMTP_HOST, "");
            set(editor, NumberParam.EDC_SMTP_PORT, 25);
            set(editor, StringParam.EDC_SMTP_USERNAME, "");
            set(editor, StringParam.EDC_SMTP_PASSWORD, "");
            set(editor, BooleanParam.EDC_SMTP_ENABLE_SSL, false);
            set(editor, NumberParam.EDC_SMTP_SSL_PORT, 443);
            set(editor, StringParam.EDC_SMTP_FROM, "");

            // 系统参数
            set(editor, NumberParam.MAX_TRANS_COUNT, 500);

            // 终端密钥管理
            set(editor, NumberParam.MK_INDEX, 1); // 主密码索引
            set(editor, StringParam.KEY_ALGORITHM, Constant.Des.TRIP_DES.toString()); // 密钥算法

            // 离线交易控制
            set(editor, NumberParam.OFFLINE_TC_UPLOAD_TIMES, 3); // 离线上送次数
            set(editor, NumberParam.OFFLINE_TC_UPLOAD_NUM, 10); // 自动上送累计笔数
            // 其它交易控制
            set(editor, BooleanParam.OTHTC_VERIFY, true); // 撤销退货类交易输入主管密码
            set(editor, BooleanParam.EDC_SUPPORT_KEYIN, true); // 允许手输卡号

            // 密码管理
            set(editor, StringParam.SEC_SYS_PWD, EncUtils.sha1(Constants.DEF_ADMIN_PWD)); // 系统管理员密码
            set(editor, StringParam.SEC_MERCHANT_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));
            set(editor, StringParam.SEC_TERMINAL_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));
            set(editor, StringParam.SEC_VOID_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));
            set(editor, StringParam.SEC_REFUND_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));
            set(editor, StringParam.SEC_ADJUST_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));
            set(editor, StringParam.SEC_SETTLE_PWD, EncUtils.sha1(Constants.DEF_TRANS_PWD));

            set(editor, BooleanParam.QUICK_PASS_TRANS_PIN_FREE_SWITCH, false);
            set(editor, BooleanParam.QUICK_PASS_TRANS_SWITCH, false);
            set(editor, BooleanParam.QUICK_PASS_TRANS_CDCVM_FLAG, false);
            set(editor, BooleanParam.QUICK_PASS_TRANS_FLAG, false);
            set(editor, NumberParam.QUICK_PASS_TRANS_PIN_FREE_AMOUNT, 30000);
            set(editor, BooleanParam.QUICK_PASS_TRANS_SIGN_FREE_FLAG, false);
            set(editor, NumberParam.QUICK_PASS_TRANS_SIGN_FREE_AMOUNT, 30000);

            //当前收单行参数
            set(editor, StringParam.ACQ_NAME, "");

            // 交易开关
            // 传统交易开关
            set(editor, BooleanParam.TTS_SALE, true); // 消费开关_传统交易
            set(editor, BooleanParam.TTS_VOID, true); // 消费撤销开关_传统交易
            set(editor, BooleanParam.TTS_REFUND, true); // 退货开关_传统交易
            set(editor, BooleanParam.TTS_PREAUTH, true); // 预授权开关_传统交易
            set(editor, BooleanParam.TTS_ADJUST, true); // 调整开关_传统交易

            if (VERSION >= 2) {
                new Upgrade1To2().upgrade(editor);
            }

            editor.apply();
        }

    }

    public synchronized int get(NumberParam name) {
        return get(name, 0);
    }

    public synchronized int get(NumberParam name, int defValue) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        String temp = sharedPreferences.getString(name.toString(), null);
        if (temp != null) {
            try {
                return Integer.parseInt(temp);
            } catch (NumberFormatException e) {
                Log.w(TAG, "", e);
            }
        }
        return defValue;
    }

    public synchronized String get(StringParam name) {
        return get(name, null);
    }

    public synchronized String get(StringParam name, String defValue) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        return sharedPreferences.getString(name.toString(), defValue);
    }

    public synchronized boolean get(BooleanParam name) {
        return get(name, false);
    }

    public synchronized boolean get(BooleanParam name, boolean defValue) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        return sharedPreferences.getBoolean(name.toString(), defValue);
    }

    public synchronized void set(NumberParam name, int value) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        Editor editor = sharedPreferences.edit();
        set(editor, name, value);
    }

    private synchronized void set(Editor editor, NumberParam name, int value) {
        editor.putString(name.toString(), String.valueOf(value));
        editor.apply();
    }

    public synchronized void set(StringParam name, String value) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        Editor editor = sharedPreferences.edit();
        set(editor, name, value);
    }

    private synchronized void set(Editor editor, StringParam name, String value) {
        editor.putString(name.toString(), value);
        editor.apply();
    }

    public synchronized void set(BooleanParam name, boolean value) {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        Editor editor = sharedPreferences.edit();
        set(editor, name, value);
    }

    private synchronized void set(Editor editor, BooleanParam name, boolean value) {
        editor.putBoolean(name.toString(), value);
        editor.apply();
    }


    private boolean isParamFileExist() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        return sharedPreferences.getBoolean(SysParam.IS_PARAM_FILE_EXIST, false);
    }

    private int getVersion() {
        SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(FinancialApplication.getApp());
        return sharedPreferences.getInt(SysParam.VERSION_TAG, 1);
    }

    public static class Constant {
        /**
         * 通讯类型
         */
        public enum CommType{
            LAN(Utils.getString(R.string.wifi)),
            MOBILE(Utils.getString(R.string.mobile)),
            WIFI(Utils.getString(R.string.wifi)),
            DEMO(Utils.getString(R.string.demo)),;

            private final String str;

            CommType(String str){
                this.str = str;
            }

            @Override
            public String toString() {
                return str;
            }
        }

        /**
         * SSL
         */
        public enum CommSslType{
            NO_SSL(Utils.getString(R.string.NO_SSL)),;

            private final String str;

            CommSslType(String str){
                this.str = str;
            }

            @Override
            public String toString() {
                return str;
            }
        }

        /**
         * des算法
         */
        public enum Des{
            DES(Utils.getString(R.string.keyManage_menu_des)),
            TRIP_DES(Utils.getString(R.string.keyManage_menu_3des));

            private final String str;

            Des(String str){
                this.str = str;
            }

            @Override
            public String toString() {
                return str;
            }
        }

        private Constant() {
            //do nothing
        }
    }

}
