/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans;

import android.content.Context;
import android.widget.Toast;

import com.pax.abl.core.AAction;
import com.pax.abl.core.AAction.ActionStartListener;
import com.pax.abl.core.ActionResult;
import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.eemv.enums.ETransResult;
import com.pax.jemv.clcommon.CvmType;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.clss.CTransResult;
import com.pax.pay.emv.EmvTags;
import com.pax.pay.trans.action.ActionAdjustTip;
import com.pax.pay.trans.action.ActionClssComplete;
import com.pax.pay.trans.action.ActionClssPreProc;
import com.pax.pay.trans.action.ActionClssProcess;
import com.pax.pay.trans.action.ActionEmvProcess;
import com.pax.pay.trans.action.ActionEnterAmount;
import com.pax.pay.trans.action.ActionEnterPin;
import com.pax.pay.trans.action.ActionInputTransData;
import com.pax.pay.trans.action.ActionInputTransData.EInputType;
import com.pax.pay.trans.action.ActionOfflineSend;
import com.pax.pay.trans.action.ActionPrintPreview;
import com.pax.pay.trans.action.ActionPrintTransReceipt;
import com.pax.pay.trans.action.ActionSearchCard;
import com.pax.pay.trans.action.ActionSearchCard.CardInformation;
import com.pax.pay.trans.action.ActionSearchCard.SearchMode;
import com.pax.pay.trans.action.ActionSendEmail;
import com.pax.pay.trans.action.ActionSendSMS;
import com.pax.pay.trans.action.ActionSignature;
import com.pax.pay.trans.action.ActionTransOnline;
import com.pax.pay.trans.action.ActionUserAgreement;
import com.pax.pay.trans.action.activity.PrintPreviewActivity;
import com.pax.pay.trans.action.activity.UserAgreementActivity;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransData.EnterMode;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.settings.SysParam;
import com.pax.view.dialog.CustomAlertDialog;

import java.util.ArrayList;
import java.util.List;

public class SaleTrans extends BaseTrans {
    private byte searchCardMode = -1; // search card mode
    private String amount;
    private String tipAmount;
    private float percent;

    private boolean isFreePin;
    private boolean isSupportBypass = true;
    private boolean hasTip = false;
    private boolean needFallBack = false;


    private byte currentMode;


    /**
     * @param context   :context
     * @param amount    :total amount
     * @param isFreePin
     * @param mode      {@link com.pax.pay.trans.action.ActionSearchCard.SearchMode}, 如果等于-1，
     */
    public SaleTrans(Context context, String amount, byte mode, boolean isFreePin,
                     TransEndListener transListener) {
        super(context, ETransType.SALE, transListener);
        setParam(amount, "0", mode, isFreePin, false);
    }

    /**
     * @param context   :context
     * @param amount    :total amount
     * @param tipAmount :tip amount
     * @param isFreePin
     * @param mode      {@link com.pax.pay.trans.action.ActionSearchCard.SearchMode}, 如果等于-1，
     */
    public SaleTrans(Context context, String amount, String tipAmount, byte mode, boolean isFreePin,
                     TransEndListener transListener) {
        super(context, ETransType.SALE, transListener);
        setParam(amount, tipAmount, mode, isFreePin, true);
    }

    private void setParam(String amount, String tipAmount, byte mode, boolean isFreePin, boolean hasTip) {
        this.searchCardMode = mode;
        this.amount = amount;
        this.tipAmount = tipAmount;
        this.isFreePin = isFreePin;
        this.hasTip = hasTip;

        if (searchCardMode == -1) { // 待机银行卡消费入口
            searchCardMode = Component.getCardReadMode(ETransType.SALE);
            this.transType = ETransType.SALE;
        } else if (searchCardMode == -3) { // entrance of quick pass by pin
            this.searchCardMode = SearchMode.WAVE;
            this.isFreePin = false;
        }
    }

    @Override
    public void bindStateOnAction() {
        if (amount != null && !amount.isEmpty()) {
            transData.setAmount(amount.replace(".", ""));
        }
        if (tipAmount != null && !tipAmount.isEmpty()) {
            transData.setTipAmount(tipAmount.replace(".", ""));
        }

        // enter trans amount action(This action is mainly used to handle bank card consumption and flash close paid deals)
        ActionEnterAmount amountAction = new ActionEnterAmount(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionEnterAmount) action).setParam(getCurrentContext(),
                        getString(R.string.trans_sale), false);
            }
        });
        bind(State.ENTER_AMOUNT.toString(), amountAction, true);

        // search card action
        ActionSearchCard searchCardAction = new ActionSearchCard(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionSearchCard) action).setParam(getCurrentContext(), getString(R.string.trans_sale), searchCardMode, transData.getAmount(),
                        null, "");
            }
        });

        bind(State.CHECK_CARD.toString(), searchCardAction, true);

        //adjust tip action
        ActionAdjustTip adjustTipAction = new ActionAdjustTip(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                amount = String.valueOf(Long.parseLong(transData.getAmount()) - Long.parseLong(transData.getTipAmount()));
                ((ActionAdjustTip) action).setParam(getCurrentContext(), getString(R.string.trans_sale), amount, percent);
            }
        });
        bind(State.ADJUST_TIP.toString(), adjustTipAction, true);

        // enter pin action
        ActionEnterPin enterPinAction = new ActionEnterPin(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {

                // if flash pay by pwd,set isSupportBypass=false,need to enter pin
                if (!isFreePin) {
                    isSupportBypass = false;
                }
                ((ActionEnterPin) action).setParam(getCurrentContext(), getString(R.string.trans_sale),
                        transData.getPan(), isSupportBypass, getString(R.string.prompt_pin),
                        getString(R.string.prompt_no_pin), transData.getAmount(), transData.getTipAmount(),
                        ActionEnterPin.EEnterPinType.ONLINE_PIN);
            }
        });
        bind(State.ENTER_PIN.toString(), enterPinAction, true);

        // emv process action
        ActionEmvProcess emvProcessAction = new ActionEmvProcess(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionEmvProcess) action).setParam(getCurrentContext(), emv, transData);
            }
        });
        bind(State.EMV_PROC.toString(), emvProcessAction);

        //clss process action
        ActionClssProcess clssProcessAction = new ActionClssProcess(new AAction.ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionClssProcess) action).setParam(getCurrentContext(), clssTransProcess, transData);
            }
        });
        bind(State.CLSS_PROC.toString(), clssProcessAction, true);

        //clss preprocess action
        ActionClssPreProc clssPreProcAction = new ActionClssPreProc(new AAction.ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionClssPreProc) action).setParam(clssTransProcess, transData);
            }
        });
        bind(State.CLSS_PREPROC.toString(), clssPreProcAction);

        //clss complete trans
        ActionClssComplete clssCompleteAction = new ActionClssComplete(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionClssComplete) action).setParam(getCurrentContext(), clssTransProcess, transData);
            }
        });
        //even it failed on the 2nd tap, it will continue current transaction, so the 3rd argv is false
        bind(State.CLSS_COMPLETE.toString(), clssCompleteAction);

        // online action
        ActionTransOnline transOnlineAction = new ActionTransOnline(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionTransOnline) action).setParam(getCurrentContext(), transData);
            }
        });

        bind(State.ONLINE.toString(), transOnlineAction, true);

        // signature action
        ActionSignature signatureAction = new ActionSignature(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionSignature) action).setParam(getCurrentContext(), transData.getAmount());
            }
        });
        bind(State.SIGNATURE.toString(), signatureAction);

        // Agreement action
        ActionUserAgreement userAgreementAction = new ActionUserAgreement(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionUserAgreement) action).setParam(getCurrentContext());
            }
        });
        bind(State.USER_AGREEMENT.toString(), userAgreementAction, true);

        //offline send
        ActionOfflineSend offlineSendAction = new ActionOfflineSend(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionOfflineSend) action).setParam(getCurrentContext());
            }
        });
        //even it failed to upload offline, it will continue current transaction, so the 3rd argv is false
        bind(State.OFFLINE_SEND.toString(), offlineSendAction);

        //print preview action
        ActionPrintPreview printPreviewAction = new ActionPrintPreview(
                new AAction.ActionStartListener() {

                    @Override
                    public void onStart(AAction action) {
                        ((ActionPrintPreview) action).setParam(getCurrentContext(), transData);
                    }
                });
        bind(State.PRINT_PREVIEW.toString(), printPreviewAction);

        // get Telephone num
        ActionInputTransData phoneAction = new ActionInputTransData(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionInputTransData) action).setParam(getCurrentContext(), getString(R.string.paperless)).setInputLine1(
                        getString(R.string.prompt_phone_number), EInputType.PHONE, 20, false);
            }
        }, 1);
        bind(State.ENTER_PHONE_NUM.toString(), phoneAction);

        // get email address
        ActionInputTransData emailAction = new ActionInputTransData(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionInputTransData) action).setParam(getCurrentContext(), getString(R.string.paperless)).setInputLine1(
                        getString(R.string.prompt_email_address), EInputType.EMAIL, 100, false);
            }
        }, 1);
        bind(State.ENTER_EMAIL.toString(), emailAction);

        // print action
        ActionPrintTransReceipt printTransReceiptAction = new ActionPrintTransReceipt(
                new AAction.ActionStartListener() {

                    @Override
                    public void onStart(AAction action) {
                        ((ActionPrintTransReceipt) action).setParam(getCurrentContext(), transData);
                    }
                });
        bind(State.PRINT_TICKET.toString(), printTransReceiptAction, true);

        ActionSendSMS sendSMSAction = new ActionSendSMS(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionSendSMS) action).setParam(getCurrentContext(), transData);
            }
        });
        bind(State.SEND_SMS.toString(), sendSMSAction);

        ActionSendEmail sendEmailAction = new ActionSendEmail(new ActionStartListener() {
            @Override
            public void onStart(AAction action) {
                ((ActionSendEmail) action).setParam(getCurrentContext(), transData);
            }
        });
        bind(State.SEND_EMAIL.toString(), sendEmailAction);

        // perform the first action
        if (amount == null || amount.isEmpty()) {
            gotoState(State.ENTER_AMOUNT.toString());
        } else {
            if (FinancialApplication.getSysParam().get(SysParam.BooleanParam.SUPPORT_USER_AGREEMENT)) {
                gotoState(State.USER_AGREEMENT.toString());
            } else {
                gotoState(State.CLSS_PREPROC.toString());
            }
        }

    }

    enum State {
        ENTER_AMOUNT,
        CHECK_CARD,
        ADJUST_TIP,
        ENTER_PIN,
        ONLINE,
        EMV_PROC,
        CLSS_PREPROC,
        CLSS_PROC,
        CLSS_COMPLETE,
        SIGNATURE,
        USER_AGREEMENT,
        OFFLINE_SEND,
        PRINT_PREVIEW,
        PRINT_TICKET,
        ENTER_PHONE_NUM,
        ENTER_EMAIL,
        SEND_SMS,
        SEND_EMAIL,
    }

    @Override
    public void onActionResult(String currentState, ActionResult result) {
        int ret = result.getRet();
        State state = State.valueOf(currentState);
        if (state == State.EMV_PROC) {
            // 不管emv处理结果成功还是失败，都更新一下冲正
            byte[] f55Dup = EmvTags.getF55(emv, transType, true);
            if (f55Dup.length > 0) {
                TransData dupTransData = FinancialApplication.getTransDataDbHelper().findFirstDupRecord();
                if (dupTransData != null) {
                    dupTransData.setDupIccData(FinancialApplication.getConvert().bcdToStr(f55Dup));
                    FinancialApplication.getTransDataDbHelper().updateTransData(dupTransData);
                }
            }
            if (ret == TransResult.NEED_FALL_BACK) {
                needFallBack = true;
                searchCardMode &= 0x01;
                gotoState(State.CHECK_CARD.toString());
                return;
            } else if (ret != TransResult.SUCC) {
                transEnd(result);
                return;
            }
        }

        if (state == State.CLSS_PREPROC && ret != TransResult.SUCC) {
            searchCardMode &= 0x03;
        }

        switch (state) {
            case ENTER_AMOUNT:
                // save trans amount
                transData.setAmount(result.getData().toString());
                gotoState(State.CHECK_CARD.toString());
                break;
            case CHECK_CARD: // subsequent processing of check card
                onCheckCard(result);
                break;
            case ADJUST_TIP:
                onAdjustTip(result);
                break;
            case ENTER_PIN: // subsequent processing of enter pin
                onEnterPin(result);
                break;
            case ONLINE: // subsequent processing of online
                if (transData.getEnterMode() == EnterMode.CLSS) {
                    gotoState(State.CLSS_COMPLETE.toString());
                } else {
                    // determine whether need electronic signature or print
                    toSignOrPrint();
                }
                break;
            case EMV_PROC: // emv后续处理
                // TODO 判断芯片卡交易是完整流程还是简单流程，如果是简单流程，接下来是联机处理，完整流程接下来是签名
                //get trans result
                ETransResult transResult = (ETransResult) result.getData();
                // EMV完整流程 脱机批准或联机批准都进入签名流程
                afterEMVProcess(transResult);
                break;
            case CLSS_PREPROC:
                gotoState(State.CHECK_CARD.toString());
                break;
            case CLSS_PROC:
                CTransResult clssResult = (CTransResult) result.getData();
                afterClssProcess(clssResult);
                break;
            case CLSS_COMPLETE:
                if (!transData.isSignFree()) {
                    gotoState(State.SIGNATURE.toString());
                } else {
                    //check offline trans
                    checkOfflineTrans();
                }
                break;
            case SIGNATURE:
                // save signature data
                byte[] signData = (byte[]) result.getData();

                if (signData != null && signData.length > 0) {
                    transData.setSignData(signData);
                    // update trans data，save signature
                    FinancialApplication.getTransDataDbHelper().updateTransData(transData);
                }

                //check offline trans
                checkOfflineTrans();
                break;
            case USER_AGREEMENT:
                String agreement = (String) result.getData();
                if (agreement != null && agreement.equals(UserAgreementActivity.ENTER_BUTTON)) {
                    gotoState(State.CLSS_PREPROC.toString());
                } else {
                    transEnd(result);
                }
                break;
            case OFFLINE_SEND:
                gotoState(State.PRINT_PREVIEW.toString());
                break;
            case PRINT_PREVIEW:
                goPrintBranch(result);
                break;
            case ENTER_PHONE_NUM:
                if (result.getRet() == TransResult.SUCC) {
                    transData.setPhoneNum((String) result.getData());
                    gotoState(State.SEND_SMS.toString());
                } else {
                    gotoState(State.PRINT_PREVIEW.toString());
                }
                break;
            case ENTER_EMAIL:
                if (result.getRet() == TransResult.SUCC) {
                    transData.setEmail((String) result.getData());
                    gotoState(State.SEND_EMAIL.toString());
                } else {
                    gotoState(State.PRINT_PREVIEW.toString());
                }
                break;
            case SEND_SMS:
            case SEND_EMAIL:
                if (result.getRet() == TransResult.SUCC) {
                    // end trans
                    transEnd(result);
                } else {
                    dispResult(transType.getTransName(), result, null);
                    gotoState(State.PRINT_PREVIEW.toString());
                }
                break;
            case PRINT_TICKET:
            default:
                transEnd(result);
                break;
        }
    }

    private void onCheckCard(ActionResult result) {
        CardInformation cardInfo = (CardInformation) result.getData();
        saveCardInfo(cardInfo, transData);
        transData.setTransType(ETransType.SALE);
        if (needFallBack) {
            transData.setEnterMode(EnterMode.FALLBACK);
        }
        // enter card number manually
        currentMode = cardInfo.getSearchMode();
        if (currentMode == SearchMode.SWIPE || currentMode == SearchMode.KEYIN) {
            goTipBranch();
        } else if (currentMode == SearchMode.INSERT) {
            needRemoveCard = true;
            // EMV process
            gotoState(State.EMV_PROC.toString());
        } else if (currentMode == SearchMode.WAVE) {
            needRemoveCard = true;
            // AET-15
            gotoState(State.CLSS_PROC.toString());
        }
    }

    private void onAdjustTip(ActionResult result) {
        //get total amount
        String totalAmountStr = String.valueOf(CurrencyConverter.parse(result.getData().toString()));
        transData.setAmount(totalAmountStr);
        //get tip amount
        String tip = String.valueOf(CurrencyConverter.parse(result.getData1().toString()));
        transData.setTipAmount(tip);
        if (currentMode == SearchMode.SWIPE || currentMode == SearchMode.KEYIN) {
            // enter pin
            gotoState(State.ENTER_PIN.toString());
        }
    }

    private void onEnterPin(ActionResult result) {
        String pinBlock = (String) result.getData();
        transData.setPin(pinBlock);
        if (pinBlock != null && !pinBlock.isEmpty()) {
            transData.setHasPin(true);
        }

        if (transData.getEnterMode() == EnterMode.SWIPE &&
                transData.getIssuer().getFloorLimit() > Long.parseLong(transData.getAmount())) {
            // save trans data
            transData.setTransType(ETransType.OFFLINE_TRANS_SEND);
            transData.setOfflineSendState(TransData.OfflineStatus.OFFLINE_NOT_SENT);
            transData.setReversalStatus(TransData.ReversalStatus.NORMAL);
            FinancialApplication.getTransDataDbHelper().insertTransData(transData);
            //increase trans no.
            Component.incTransNo();
            toSignOrPrint();
            return;
        }

        //clss process
        if (transData.getEnterMode() == EnterMode.CLSS &&
                transData.getClssResult() == OutcomeParam.CLSS_OC_APPROVED) {
            if (!transData.isSignFree()) {
                gotoState(State.SIGNATURE.toString());
            } else {
                gotoState(State.PRINT_PREVIEW.toString());
            }
            return;
        }

        // online process
        gotoState(State.ONLINE.toString());
    }

    private void checkOfflineTrans() {
        //get offline trans data list
        List<TransData.OfflineStatus> filter = new ArrayList<>();
        filter.add(TransData.OfflineStatus.OFFLINE_NOT_SENT);
        List<TransData> offlineTransList = FinancialApplication.getTransDataDbHelper().findOfflineTransData(filter);
        //AET-150
        if ((transData.getTransType().equals(ETransType.SALE) &&
                !offlineTransList.isEmpty() && offlineTransList.get(0).getId() != transData.getId())) { //AET-92
            if (transData.getEnterMode() == EnterMode.CLSS &&
                    transData.getClssResult() != OutcomeParam.CLSS_OC_ONLINE_REQUEST) {
                gotoState(State.PRINT_PREVIEW.toString());
                return;
            }
            //offline send
            gotoState(State.OFFLINE_SEND.toString());
        } else {
            // if terminal does not support signature ,card holder does not sign or time out，print preview directly.
            gotoState(State.PRINT_PREVIEW.toString());
        }
    }

    private void goTipBranch() {
        boolean enableTip = FinancialApplication.getSysParam().get(SysParam.BooleanParam.EDC_SUPPORT_TIP);
        //adjust tip
        long totalAmount = Long.parseLong(transData.getAmount());
        tipAmount = transData.getTipAmount();
        long lTipAmountLong = Long.parseLong(tipAmount);
        long baseAmount = totalAmount - lTipAmountLong;
        percent = transData.getIssuer().getAdjustPercent();

        if (enableTip) {
            if (!hasTip)
                gotoState(State.ADJUST_TIP.toString());
            else if (baseAmount * percent / 100 < lTipAmountLong)
                showAdjustTipDialog(getCurrentContext());
        } else {
            // enter pin
            gotoState(State.ENTER_PIN.toString());
        }
    }

    private void goPrintBranch(ActionResult result) {
        String string = (String) result.getData();
        if (string != null && string.equals(PrintPreviewActivity.PRINT_BUTTON)) {
            //print ticket
            gotoState(State.PRINT_TICKET.toString());
        } else if (string != null && string.equals(PrintPreviewActivity.SMS_BUTTON)) {
            gotoState(State.ENTER_PHONE_NUM.toString());
        } else if (string != null && string.equals(PrintPreviewActivity.EMAIL_BUTTON)) {
            gotoState(State.ENTER_EMAIL.toString());
        } else {
            //end trans directly, not print
            transEnd(result);
        }
    }

    // need electronic signature or send
    private void toSignOrPrint() {
        if (Component.isSignatureFree(transData)) {// signature free
            transData.setSignFree(true);
            // print preview
            gotoState(State.PRINT_PREVIEW.toString());
        } else {
            transData.setSignFree(false);
            gotoState(State.SIGNATURE.toString());
        }
        FinancialApplication.getTransDataDbHelper().updateTransData(transData);
    }

    private void afterEMVProcess(ETransResult transResult) {
        Component.emvTransResultProcess(transResult, emv, transData);
        if (transResult == ETransResult.ONLINE_APPROVED || transResult == ETransResult.OFFLINE_APPROVED) {// 联机批准/脱机批准处理
            if (transResult == ETransResult.ONLINE_APPROVED) {
                toSignOrPrint();
                return;
            }

            toSignOrPrint();
        } else if (transResult == ETransResult.ARQC) { // request online
            if (!Component.isQpbocNeedOnlinePin(emv)) {
                gotoState(State.ONLINE.toString());
                return;
            }
            if (isFreePin && Component.clssQPSProcess(emv, transData)) { // pin free
                transData.setPinFree(true);
                gotoState(State.ONLINE.toString());
            } else {
                // enter pwd
                transData.setPinFree(false);
                gotoState(State.ENTER_PIN.toString());
            }
        } else if (transResult == ETransResult.SIMPLE_FLOW_END) { // simplify the process
            // trans not support simplified process
            // end trans
            transEnd(new ActionResult(TransResult.ERR_ABORTED, null));
        } else if (transResult == ETransResult.ONLINE_DENIED) { // refuse online
            // end trans
            transEnd(new ActionResult(TransResult.ERR_HOST_REJECT, null));
        } else if (transResult == ETransResult.ONLINE_CARD_DENIED) {// 平台批准卡片拒绝
            transEnd(new ActionResult(TransResult.ERR_CARD_DENIED, null));
        } else if (transResult == ETransResult.ABORT_TERMINATED ||
                transResult == ETransResult.OFFLINE_DENIED) { // emv interrupt
            Device.beepErr();
            transEnd(new ActionResult(TransResult.ERR_ABORTED, null));
        }
    }

    private void afterClssProcess(CTransResult transResult) {
        if (transResult.getTransResult() == OutcomeParam.CLSS_OC_TRY_AGAIN) {
            FinancialApplication.getApp().runInBackground(new Runnable() {
                @Override
                public void run() {
                    removeCard();
                    FinancialApplication.getApp().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(ActivityStack.getInstance().top(), R.string.prompt_wave_card, Toast.LENGTH_LONG).show();
                        }
                    });
                    //AET-175
                    gotoState(State.CLSS_PREPROC.toString());
                }
            });
            return;
        }

        clssTransProcess.resultProcess(transResult, transData);

        if (transData.getClssResult() != 0 && transData.getClssResult() != OutcomeParam.CLSS_OC_APPROVED
                && transData.getClssResult() != OutcomeParam.CLSS_OC_ONLINE_REQUEST) {
            transEnd(new ActionResult(transData.getClssResult(), null));
            return;
        }

        if (transResult.getCvmResult() == CvmType.RD_CVM_ONLINE_PIN) {
            transData.setSignFree(true);
            transData.setPinFree(false);
            gotoState(State.ENTER_PIN.toString());
            return;
        } else if (transResult.getCvmResult() == CvmType.RD_CVM_SIG) {
            //FIXME 不上送电子签名
            //do signature after online
            transData.setSignFree(false);
            transData.setPinFree(true);
        } else {
            transData.setSignFree(true);
            transData.setPinFree(true);
        }

        if (transResult.getTransResult() == OutcomeParam.CLSS_OC_APPROVED) {
            transData.setOnlineTrans(false);
            if (!transData.isSignFree()) {
                gotoState(State.SIGNATURE.toString());
            } else {
                gotoState(State.PRINT_PREVIEW.toString());
            }
        } else if (transResult.getTransResult() == OutcomeParam.CLSS_OC_ONLINE_REQUEST) {
            transData.setOnlineTrans(true);
            gotoState(State.ONLINE.toString());
        }
    }

    public void showAdjustTipDialog(final Context context) {

        final CustomAlertDialog dialog = new CustomAlertDialog(context, CustomAlertDialog.NORMAL_TYPE);
        dialog.setCancelClickListener(new CustomAlertDialog.OnCustomClickListener() {
            @Override
            public void onClick(CustomAlertDialog alertDialog) {
                dialog.dismiss();
                transEnd(new ActionResult(TransResult.ERR_ABORTED, null));
            }
        });
        dialog.setConfirmClickListener(new CustomAlertDialog.OnCustomClickListener() {
            @Override
            public void onClick(CustomAlertDialog alertDialog) {
                dialog.dismiss();
                gotoState(State.ADJUST_TIP.toString());
            }
        });
        dialog.show();
        dialog.setNormalText(getString(R.string.prompt_tip_exceed));
        dialog.showCancelButton(true);
        dialog.showConfirmButton(true);
    }
}
