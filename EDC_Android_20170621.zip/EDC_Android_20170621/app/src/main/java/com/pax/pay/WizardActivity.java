/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-12-27
 * Module Author: xiawh
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.model.Controller;

public class WizardActivity extends BaseActivity implements View.OnClickListener {
    private ImageView headerBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        loadParam();
        initViews();
        setListeners();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_wizard;
    }

    @Override
    protected void initViews() {
        TextView tvTitle = (TextView) findViewById(R.id.header_title);
        tvTitle.setText(getString(R.string.settings_title));

        headerBack = (ImageView) findViewById(R.id.header_back);
    }

    @Override
    protected void setListeners() {
        headerBack.setOnClickListener(this);
    }

    @Override
    protected void loadParam() {
        // do nothing
    }

    @Override
    public void onClickProtected(View v) {
        if (v.getId() == R.id.header_back) {
            FinancialApplication.getController().set(Controller.NEED_SET_WIZARD, Controller.Constant.NO);
            Intent intent = getIntent();
            setResult(InitializeInputPwdActivity.REQ_WIZARD, intent);
            finish();
        }
    }

}
