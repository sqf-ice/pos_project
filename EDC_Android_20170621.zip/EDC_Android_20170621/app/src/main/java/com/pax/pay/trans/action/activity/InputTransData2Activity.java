/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.annotation.SuppressLint;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.InputType;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.SpannedString;
import android.text.TextWatcher;
import android.text.method.NumberKeyListener;
import android.text.style.AbsoluteSizeSpan;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.abl.core.ActionResult;
import com.pax.dal.IScanner;
import com.pax.dal.entity.EScannerType;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.action.ActionInputTransData.EInputType;
import com.pax.pay.trans.component.Component;
import com.pax.pay.utils.ToastUtils;
import com.pax.view.keyboard.CustomKeyboardEditText;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.text.ParseException;
import java.text.SimpleDateFormat;

@SuppressLint("SimpleDateFormat")
public class InputTransData2Activity extends BaseActivityWithTickForAction {
    private ImageView headerBack;

    private CustomKeyboardEditText mEditNum;
    private CustomKeyboardEditText mEditExtraNum;

    private String prompt1;
    private String prompt2;
    private EInputType inputType1;
    private EInputType inputType2;
    private int maxLen1;
    private int minLen1;
    private int maxLen2;
    private int minLen2;
    private ImageButton scannerBtn;
    private Button confirmBtn;
    private String navTitle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setEditText();
        setEtraEditText();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_input_info;
    }

    @Override
    protected void loadParam() {
        navTitle = getIntent().getStringExtra(EUIParamKeys.NAV_TITLE.toString());
        prompt1 = getIntent().getStringExtra(EUIParamKeys.PROMPT_1.toString());
        inputType1 = (EInputType) getIntent().getSerializableExtra(EUIParamKeys.INPUT_TYPE_1.toString());
        maxLen1 = getIntent().getIntExtra(EUIParamKeys.INPUT_MAX_LEN_1.toString(), 6);
        minLen1 = getIntent().getIntExtra(EUIParamKeys.INPUT_MIN_LEN_1.toString(), 0);
        prompt2 = getIntent().getStringExtra(EUIParamKeys.PROMPT_2.toString());
        inputType2 = (EInputType) getIntent().getSerializableExtra(EUIParamKeys.INPUT_TYPE_2.toString());
        maxLen2 = getIntent().getIntExtra(EUIParamKeys.INPUT_MAX_LEN_2.toString(), 6);
        minLen2 = getIntent().getIntExtra(EUIParamKeys.INPUT_MIN_LEN_2.toString(), 0);
    }

    @Override
    protected void initViews() {
        headerBack = (ImageView) findViewById(R.id.header_back);

        TextView headerText = (TextView) findViewById(R.id.header_title);
        headerText.setText(navTitle);

        TextView promptNum = (TextView) findViewById(R.id.prompt_num);
        promptNum.setText(prompt1);
        TextView promptExtraNum = (TextView) findViewById(R.id.prompt_extraNum);
        promptExtraNum.setText(prompt2);

        mEditNum = (CustomKeyboardEditText) findViewById(R.id.prompt_edit_num);
        mEditNum.setFocusable(true);
        mEditNum.requestFocus();

        mEditExtraNum = (CustomKeyboardEditText) findViewById(R.id.prompt_edit_extraNum);
        mEditExtraNum.setFocusable(true);

        scannerBtn = (ImageButton) findViewById(R.id.start_scanner);

        confirmBtn = (Button) findViewById(R.id.infos_confirm);
        confirmBtn.setEnabled(false);
    }

    private void setEditText() {
        switch (inputType1) {
            case DATE:
                setEditTextDate(mEditNum);
                break;
            case NUM:
                setEditTextNum(mEditNum, maxLen1);
                break;
            case ALPHA_NUM:
                setEditTextAlphaNum(mEditNum, maxLen1);
                break;
            case TEXT:
                setEditTextString(mEditNum, maxLen1);
                break;
            default:
                break;
        }
    }

    private void setEtraEditText() {
        switch (inputType2) {
            case DATE:
                setEditTextDate(mEditExtraNum);
                break;
            case NUM:
                setEditTextNum(mEditExtraNum, maxLen2);
                break;
            case ALPHA_NUM:
                setEditTextAlphaNum(mEditExtraNum, maxLen2);
                break;
            case TEXT:
                setEditTextString(mEditExtraNum, maxLen2);
                break;
            default:
                break;
        }
    }

    // 数字
    private void setEditTextNum(EditText editText, int len) {
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(len)});
        editText.setInputType(InputType.TYPE_NUMBER_FLAG_DECIMAL);
    }

    // 日期
    private void setEditTextDate(EditText editText) {
        SpannableString ss = new SpannableString(getString(R.string.prompt_date_default2));
        AbsoluteSizeSpan ass = new AbsoluteSizeSpan(getResources().getDimensionPixelOffset(R.dimen.font_size_large),
                false);
        ss.setSpan(ass, 0, ss.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        editText.setHint(new SpannedString(ss)); // 一定要进行转换,否则属性会消失
        editText.setHintTextColor(getResources().getColor(R.color.textEdit_hint));
        editText.setInputType(InputType.TYPE_CLASS_NUMBER);
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(4)});
    }

    // 数字加字母
    private void setEditTextAlphaNum(EditText editText, int len) {
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(len)});
        editText.setKeyListener(new NumberKeyListener() {
            @Override
            protected char[] getAcceptedChars() {
                return "qwertyuioplkjhgfdsazxcvbnmQWERTYUIOPLKJHGFDSAZXCVBNM1234567890".toCharArray();
            }

            @Override
            public int getInputType() {
                return InputType.TYPE_TEXT_VARIATION_PASSWORD;
            }
        });
    }

    // 所有输入形式
    private void setEditTextString(EditText editText, int len) {
        editText.setFilters(new InputFilter[]{new InputFilter.LengthFilter(len)});
    }

    @Override
    protected void setListeners() {
        headerBack.setOnClickListener(this);
        scannerBtn.setOnClickListener(this);

        // 输入框数值监听
        mEditNum.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                confirmBtnChange();
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                // do nothing
            }

            @Override
            public void afterTextChanged(Editable e) {
                // do nothing
            }
        });

        mEditExtraNum.addTextChangedListener(new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                confirmBtnChange();
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1, int arg2, int arg3) {
                // do nothing
            }

            @Override
            public void afterTextChanged(Editable arg0) {
                // do nothing
            }
        });
        confirmBtn.setOnClickListener(this);
    }

    @Override
    public void onClickProtected(View v) {

        switch (v.getId()) {
            case R.id.header_back:
                finish(new ActionResult(TransResult.ERR_ABORTED, null));
                break;
            case R.id.infos_confirm:

                String content = process(mEditNum, inputType1, maxLen1, minLen1);
                if (content == null) {
                    mEditNum.setText("");
                    mEditNum.requestFocus();
                    return;
                }
                if (content.isEmpty()) {
                    ToastUtils.showMessage(InputTransData2Activity.this, getString(R.string.please_input_again));
                    mEditNum.requestFocus();
                    return;
                }

                String extraContent = process(mEditExtraNum, inputType2, maxLen2, minLen2);
                if (extraContent == null) {
                    mEditExtraNum.requestFocus();
                    return;
                }
                if (extraContent.isEmpty()) {
                    ToastUtils.showMessage(InputTransData2Activity.this, getString(R.string.prompt_card_date_err));
                    mEditExtraNum.requestFocus();
                    return;
                }

                if (!content.isEmpty() && !extraContent.isEmpty()) {
                    finish(new ActionResult(TransResult.SUCC, new String[]{content, extraContent}));
                }
                break;
            case R.id.start_scanner:
                FinancialApplication.getApp().runInBackground(new Runnable() {

                    @Override
                    public void run() {
                        final IScanner scanner = FinancialApplication.getDal().getScanner(EScannerType.REAR);
                        scanner.open();
                        scanner.start(new ScannerListener());
                    }
                });
                break;
            default:
                break;
        }

    }

    private void confirmBtnChange() {
        String content = process(mEditNum, inputType1, maxLen1, minLen1);
        String extraContent = process(mEditExtraNum, inputType2, maxLen2, minLen2);
        confirmBtn.setEnabled(content != null || extraContent != null);
    }

    /**
     * 输入数值检查
     */
    private String process(EditText editText, EInputType inputType, int maxLen, int minLen) {
        String content = editText.getText().toString().trim();

        if (content.isEmpty()) {
            return null;
        }

        switch (inputType) {
            case DATE:
                if (content.length() != 4) {
                    return "";
                }

                SimpleDateFormat dateFormat = new SimpleDateFormat("MMdd");
                dateFormat.setLenient(false);
                try {
                    dateFormat.parse(content);
                } catch (ParseException e) {
                    Log.w(TAG, "", e);
                    return "";
                }
                return content;
            case NUM:
                if (content.length() >= minLen && content.length() <= maxLen) {
                    return content;
                } else {
                    return "";
                }
            case ALPHA_NUM:
                if (content.length() >= minLen && content.length() <= maxLen) {
                    content = Component.getPaddedString(content, maxLen, '0');
                } else {
                    return "";
                }
                break;
            default:
                break;
        }
        return content;
    }

    // 扫描
    private class ScannerListener implements IScanner.IScanListener {

        @Override
        public void onCancel() {
            final IScanner scanner = FinancialApplication.getDal().getScanner(EScannerType.REAR);
            scanner.close();
        }

        @Override
        public void onFinish() {
            final IScanner scanner = FinancialApplication.getDal().getScanner(EScannerType.REAR);
            scanner.close();

        }

        @Override
        public void onRead(final String result) {
            FinancialApplication.getApp().runOnUiThread(new ReadRunnable(result));
        }

        private class ReadRunnable implements Runnable{
            private final String result;
            private String code = "";
            private String date = "";
            private String refNo = "";

            ReadRunnable(final String result){
                this.result = result;
            }

            private void getAuthCode(JSONObject resultObj){
                try {
                    code = resultObj.getString("authCode");
                } catch (JSONException e) {
                    Log.e(TAG, "", e);
                }
            }

            private void getDate(JSONObject resultObj){
                try {
                    date = resultObj.getString("date");
                } catch (JSONException e) {
                    Log.e(TAG, "", e);
                }
            }

            private void getRefNo(JSONObject resultObj){
                try {
                    refNo = resultObj.getString("refNo");
                } catch (JSONException e) {
                    Log.e(TAG, "", e);
                }
            }

            private void updateTextBox1(){
                // 设置第一个框
                switch (inputType1) {
                    case NUM:
                        mEditNum.setText(refNo);
                        break;
                    case DATE:
                        mEditNum.setText(date);
                        break;
                    case ALPHA_NUM:
                        mEditNum.setText(code);
                        break;
                    default:
                        break;
                }
            }

            private void updateTextBox2(){
                // 设置第二个框
                switch (inputType2) {
                    case NUM:
                        mEditExtraNum.setText(refNo);
                        break;
                    case DATE:
                        mEditExtraNum.setText(date);
                        break;
                    case ALPHA_NUM:
                        mEditExtraNum.setText(code);
                        break;
                    default:
                        break;
                }
            }

            @Override
            public void run() {

                try {
                    JSONArray resultArray = new JSONArray(result);
                    JSONObject resultObj = resultArray.optJSONObject(0);

                    getAuthCode(resultObj);

                    getDate(resultObj);

                    getRefNo(resultObj);

                    updateTextBox1();
                    updateTextBox2();
                } catch (JSONException e) {
                    Log.w(TAG, "", e);
                }

            }
        }
    }
}
