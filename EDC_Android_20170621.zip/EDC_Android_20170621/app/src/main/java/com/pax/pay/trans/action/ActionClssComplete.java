/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-5-2
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.content.Context;
import android.util.Log;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.dal.ICardReaderHelper;
import com.pax.dal.entity.EReaderType;
import com.pax.edc.R;
import com.pax.eventbus.SearchCardEvent;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.TransactionPath;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.clss.ClssTransProcess;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.trans.transmit.TransProcessListenerImpl;
import com.pax.settings.SysParam;

public class ActionClssComplete extends AAction {
    private Context context;
    private TransData transData;
    private ClssTransProcess clssTransProcess;

    public ActionClssComplete(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(Context context, ClssTransProcess clssTransProcess, TransData transData) {
        this.context = context;
        this.clssTransProcess = clssTransProcess;
        this.transData = transData;
    }

    @Override
    protected void process() {
        //don't do 2nd tap for demo mode
        String commType = FinancialApplication.getSysParam().get(SysParam.StringParam.COMM_TYPE);
        if (SysParam.Constant.CommType.DEMO.toString().equals(commType)) {
            setResult(new ActionResult(TransResult.SUCC, null));
            return;
        }

        if (clssTransProcess.getKernType() == KernType.KERNTYPE_MC
                || clssTransProcess.getTransPath() == TransactionPath.CLSS_VISA_MSD) {
            setResult(new ActionResult(TransResult.SUCC, null));
            return;
        }

        FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.CLSS_LIGHT_STATUS_COMPLETE));

        FinancialApplication.getApp().runInBackground(new Runnable() {
            @Override
            public void run() {
                TransProcessListener transProcessListener = new TransProcessListenerImpl(context);
                if (transData.getEnterMode() == TransData.EnterMode.CLSS) {
                    transProcessListener.onShowProgress(context.getString(R.string.prompt_wave_card), 30);
                }
                try {
                    //tap card
                    ICardReaderHelper helper = FinancialApplication.getDal().getCardReaderHelper();
                    helper.polling(EReaderType.PICC, 30 * 1000);
                    helper.stopPolling();

                    clssTransProcess.completeTrans(transData);
                } catch (Exception e) {
                    Log.e(TAG, "", e);
                } finally {
                    transProcessListener.onHideProgress();
                    setResult(new ActionResult(TransResult.SUCC, null));
                }
            }
        });
    }
}
