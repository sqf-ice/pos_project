/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.emv;

import android.annotation.SuppressLint;
import android.util.Log;

import com.pax.eemv.IEmv;
import com.pax.eemv.IEmvListener;
import com.pax.eemv.entity.Config;
import com.pax.eemv.entity.InputParam;
import com.pax.eemv.enums.EFlowType;
import com.pax.eemv.enums.ETransResult;
import com.pax.eemv.exception.EmvException;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransData.EnterMode;
import com.pax.pay.utils.CountryCode;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.settings.SysParam;

import java.util.Currency;

public class EmvTransProcess {

    private static final String TAG = "EmvTransProcess";

    private IEmv emv;

    public EmvTransProcess(IEmv emv) {
        this.emv = emv;
    }

    public ETransResult transProcess(TransData transData, IEmvListener listener) throws EmvException {
        emv.setListener(listener);
        ETransResult result = emv.emvProcess(toInputParam(transData));

        // 将交易类型恢复
        Log.i("TAG", "EMV PROC:" + result.toString());
        return result;
    }

    /**
     * EMV初始化，设置aid，capk和emv配置
     */
    public void init() {
        try {
            emv.emvInit();
            setEmvConfig();
        } catch (EmvException e) {
            Log.e(TAG, "", e);
        }
        emv.setAidParamList(EmvAid.toAidParams());
        emv.setCapkList(EmvCapk.toCapk());
    }

    private void setEmvConfig() throws EmvException {
        Config cfg = emv.getConfig();

        Currency current = Currency.getInstance(CurrencyConverter.getDefCurrency());
        byte[] currency = FinancialApplication.getConvert().strToBcd(String.valueOf(
                CountryCode.getByCode(CurrencyConverter.getDefCurrency().getCountry()).getCurrencyNumeric()),
                EPaddingPosition.PADDING_LEFT);

        cfg.setCapability(new byte[]{(byte) 0xE0, (byte) 0xF0, (byte) 0xC8});
        cfg.setCountryCode(currency);
        cfg.setExCapability(new byte[]{(byte) 0xE0, 0x00, (byte) 0xF0, (byte) 0xA0, 0x01});
        cfg.setForceOnline((byte) 0);
        cfg.setGetDataPIN((byte) 1);
        cfg.setMerchCateCode(new byte[]{0x00, 0x00});
        cfg.setReferCurrCode(currency);
        cfg.setReferCurrCon(1000);
        cfg.setReferCurrExp((byte) current.getDefaultFractionDigits());
        cfg.setSurportPSESel((byte) 1);
        cfg.setTermType((byte) 0x22);
        cfg.setTransCurrCode(currency);
        cfg.setTransCurrExp((byte) current.getDefaultFractionDigits());
        cfg.setTransType((byte) 0);
        cfg.setTermId(FinancialApplication.getAcqManager().getCurAcq().getTerminalId());
        cfg.setMerchId(FinancialApplication.getAcqManager().getCurAcq().getMerchantId());
        cfg.setMerchName(FinancialApplication.getSysParam().get(SysParam.StringParam.EDC_MERCHANT_NAME_EN));
        cfg.setTermAIP(new byte[]{0x08, 0x00});
        cfg.setBypassPin((byte) 1); // 输密码支持bypass
        cfg.setBatchCapture((byte) 1);
        cfg.setUseTermAIPFlag((byte) 1);
        cfg.setBypassAllFlag((byte) 1);
        emv.setConfig(cfg);
    }

    @SuppressLint("DefaultLocale")
    private InputParam toInputParam(TransData transData) {
        InputParam inputParam = new InputParam();
        ETransType transType = transData.getTransType();

        String amount = transData.getAmount();
        if (amount == null || amount.isEmpty()) {
            amount = "0";
        }
        inputParam.setAmount(Component.getPaddedNumber(Long.parseLong(amount), 12));
        inputParam.setCashBackAmount("0");
        if ((transData.getTransType().equals(ETransType.SALE))
                || (transData.getTransType().equals(ETransType.PREAUTH))) {
            if (transData.getEnterMode() == EnterMode.INSERT) {
                inputParam.setFlowType(EFlowType.COMPLETE);
            } else {
                inputParam.setFlowType(EFlowType.QPBOC);
            }
            inputParam.setIsCardAuth(true);
            inputParam.setIsSupportCvm(true);

        } else {
            // 联机Q非消费，余额查询，预授权均走简单Q流程
            inputParam.setFlowType(EFlowType.SIMPLE);

            inputParam.setIsCardAuth(false);
            inputParam.setIsSupportCvm(false);
        }
        byte[] procCode = FinancialApplication.getConvert()
                .strToBcd(transType.getProcCode(), EPaddingPosition.PADDING_RIGHT);
        inputParam.setTag9CValue(procCode[0]);

        // 根据交易类型判断是否强制联机
        inputParam.setIsForceOnline(true);
        inputParam.setIsSupportEC(false);
        inputParam.setIsSupportSM(true);

        inputParam.setTransDate(transData.getDateTime().substring(0, 8));
        inputParam.setTransTime(transData.getDateTime().substring(8));
        inputParam.setTransTraceNo(Component.getPaddedNumber(transData.getTraceNo(), 6));

        return inputParam;

    }
}
