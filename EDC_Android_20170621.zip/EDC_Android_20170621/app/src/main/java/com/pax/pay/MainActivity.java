/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay;

import android.app.ActionBar.LayoutParams;
import android.content.DialogInterface;
import android.content.DialogInterface.OnDismissListener;
import android.content.Intent;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.bumptech.glide.Glide;
import com.pax.abl.core.ATransaction;
import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.AdConstants;
import com.pax.pay.menu.AuthMenuActivity;
import com.pax.pay.menu.ManageMenuActivity;
import com.pax.pay.trans.AdjustTrans;
import com.pax.pay.trans.OfflineSaleTrans;
import com.pax.pay.trans.RefundTrans;
import com.pax.pay.trans.SaleTrans;
import com.pax.pay.trans.SaleVoidTrans;
import com.pax.pay.trans.SettleTrans;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.Controller;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.EditorActionListener;
import com.pax.pay.utils.EnterAmountTextWatcher;
import com.pax.settings.SysParam;
import com.pax.view.MenuPage;
import com.pax.view.dialog.DialogUtils;
import com.pax.view.keyboard.CustomKeyboardEditText;
import com.pax.view.widget.AmountWidget;

import java.util.ArrayList;

import cn.bingoogolapple.bgabanner.BGABanner;

public class MainActivity extends BaseActivity {
    private boolean needSelfTest = true;

    public static final int REQ_INITIALIZE = 1;
    public static final int REQ_SELF_TEST = 2;

    private boolean isFromWidget;

    // AET-87 remove payType

    private CustomKeyboardEditText edtAmount; // input amount
    private MenuPage menuPage;

    private boolean isInstalledNeptune = true;

    private ATransaction.TransEndListener listener = new ATransaction.TransEndListener() {

        @Override
        public void onEnd(ActionResult result) {
            FinancialApplication.getApp().runOnUiThread(new Runnable() {

                @Override
                public void run() {
                    resetUI();
                }
            });

        }
    };

    private class MainEditorActionListener extends EditorActionListener {
        @Override
        public void onKeyOk() {
            String amount = CurrencyConverter.parse(edtAmount.getText().toString().trim()).toString();
            if (!"0".equals(amount)) {
                doSale(amount, (byte) -1);
            } else {
                updateAmount();
            }
        }

        @Override
        public void onKeyCancel() {
            updateAmount();
        }

        /**
         * @param amount         "like 12313"
         * @param searchCardMode {@link com.pax.pay.trans.action.ActionSearchCard.SearchMode}
         */
        private void doSale(String amount, byte searchCardMode) {
            new SaleTrans(MainActivity.this, amount, searchCardMode, true, listener).execute();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        isInstalledNeptune = Component.neptuneInstalled(this, new OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface arg0) {
                android.os.Process.killProcess(android.os.Process.myPid());
            }
        });

        if (!isInstalledNeptune) {
            return;
        }
        FinancialApplication.getController().set(Controller.NEED_SET_WIZARD, Controller.Constant.YES);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (!isInstalledNeptune) {
            return;
        }
        ActivityStack.getInstance().popAllButBottom();

        FinancialApplication.getApp().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                onCheckInit();
            }
        });

        resetUI();

        FinancialApplication.getSysParam().init();
    }

    @Override
    protected void loadParam() {
        //If widget call MainActivity, need to show keyboard immediately.
        Intent intent = getIntent();
        isFromWidget = intent.getBooleanExtra(AmountWidget.KEY, false);

        CurrencyConverter.setDefCurrency(FinancialApplication.getSysParam().get(SysParam.StringParam.EDC_CURRENCY_LIST));
    }

    /**
     * reset MainActivity
     */
    private void resetUI() {
        menuPage.setCurrentPager(0);
        updateAmount();
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_main;
    }

    @Override
    protected void initViews() {
        // set amount input box
        edtAmount = (CustomKeyboardEditText) findViewById(R.id.amount_editText);
        edtAmount.setText("");

        LinearLayout mLayout = (LinearLayout) findViewById(R.id.ll_gallery);
        android.widget.LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT);

        menuPage = createMenu();
        mLayout.addView(menuPage, params);

        BGABanner banner = (BGABanner) findViewById(R.id.banner_guide_content);
        banner.setAdapter(new BGABanner.Adapter<ImageView, String>() {
            @Override
            public void fillBannerItem(BGABanner banner, ImageView itemView, String model, int position) {
                Glide.with(MainActivity.this)
                        .load(model)
                        .centerCrop()
                        .dontAnimate()
                        .into(itemView);
            }
        });

        banner.setData(new ArrayList<>(AdConstants.getAd().keySet()), null);
        banner.setDelegate(new BGABanner.Delegate<ImageView, String>() {
            @Override
            public void onBannerItemClick(BGABanner banner, ImageView itemView, String model, int position) {
                edtAmount.clearFocus(); //AET-78
                Intent intent = new Intent(MainActivity.this, WebViewActivity.class);
                intent.putExtra(WebViewActivity.KEY, AdConstants.getAd().get(model));
                intent.putExtra(WebViewActivity.IS_FROM_WIDGET, false);
                startActivity(intent);
            }
        });

        if (isFromWidget) {
            edtAmount.requestFocus();
        } else {
            edtAmount.clearFocus();
        }
    }

    /*
     * create menu
     */
    private MenuPage createMenu() {
        MenuPage.Builder builder = new MenuPage.Builder(MainActivity.this, 9, 3)
                // void
                .addTransItem(getString(R.string.trans_void), R.drawable.app_void,
                        new SaleVoidTrans(MainActivity.this, listener))
                // refund
                .addTransItem(getString(R.string.trans_refund), R.drawable.app_refund,
                        new RefundTrans(MainActivity.this, listener))
                // pre-authorization
                .addMenuItem(getString(R.string.trans_preAuth), R.drawable.app_auth, AuthMenuActivity.class)
                //offline
                .addTransItem(getString(R.string.trans_offline), R.drawable.app_sale,
                        new OfflineSaleTrans(MainActivity.this, listener))
                //adjust
                .addTransItem(getString(R.string.trans_adjust), R.drawable.app_adjust,
                        new AdjustTrans(MainActivity.this, listener))
                // 结算 AET-14
                .addTransItem(getString(R.string.trans_settle), R.drawable.app_settle,
                        new SettleTrans(MainActivity.this, null))
                // management
                .addMenuItem(getString(R.string.trans_manage), R.drawable.app_manage, ManageMenuActivity.class);


        return builder.create();
    }

    @Override
    protected void setListeners() {
        EnterAmountTextWatcher amountWatcher = new EnterAmountTextWatcher();
        edtAmount.addTextChangedListener(amountWatcher);
        edtAmount.setOnEditorActionListener(new MainEditorActionListener());
    }

    private void onCheckLog() {
        if (FinancialApplication.getController().get(Controller.CLEAR_LOG) == Controller.Constant.YES
                && FinancialApplication.getTransDataDbHelper().deleteAllTransData()
                && FinancialApplication.getTransTotalDbHelper().deleteAllTransTotal()) {
            FinancialApplication.getController().set(Controller.CLEAR_LOG, Controller.Constant.NO);
            FinancialApplication.getController().set(Controller.BATCH_UP_STATUS, Controller.Constant.WORKED);
        }
    }

    private void onCheckInit() {
        if (FinancialApplication.getController().getBoolean(Controller.IS_FIRST_RUN)) {
            Intent intent = new Intent(this, InitializeInputPwdActivity.class);
            startActivityForResult(intent, REQ_INITIALIZE);
        }
    }

    private void onSelfTest() {
        if (needSelfTest) {
            Intent intent = new Intent(this, SelfTestActivity.class);
            startActivityForResult(intent, REQ_SELF_TEST);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQ_SELF_TEST:
                needSelfTest = false;
                break;
            case REQ_INITIALIZE:
            default:
                break;
        }
    }

    @Override
    protected boolean onKeyBackDown() {
        // exit current app
        DialogUtils.showExitAppDialog(MainActivity.this);
        return true;
    }

    // AET-48
    private synchronized void updateAmount() {
        edtAmount.setText("");
    }

}
