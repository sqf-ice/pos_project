/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.app.quickclick;

/**
 * 快速点击保护， 主要用在界面功能选择
 *
 * @author Steven.W
 */
abstract class AQuickClickProtection extends AutoRecoveredValueSetter<Boolean> {

    public AQuickClickProtection(long timeoutMs) {
        setTimeoutMs(timeoutMs);
        setValue(false);
        setRecoverTo(false);
    }

    /**
     * 默认500ms
     */
    public AQuickClickProtection() {
        setTimeoutMs(500);
        setValue(false);
        setRecoverTo(false);
    }

    public boolean isStarted() {
        return getValue();
    }

    public void start() {
        setValue(true);
        autoRecover();
    }

    public void stop() {
        recover();
    }
}
