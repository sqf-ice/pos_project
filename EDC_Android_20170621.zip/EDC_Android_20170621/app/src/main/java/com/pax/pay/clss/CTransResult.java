/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-3-2
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import android.util.SparseIntArray;

import com.pax.edc.R;
import com.pax.jemv.clcommon.CvmType;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.jemv.clcommon.RetCode;
import com.pax.pay.utils.Utils;

public class CTransResult {

    private int transResult;
    private byte cvmResult;

    public static final int UNSUPPORTED_KERNEL = -300;

    public static final int ONLINE_FAILED = -301;//Online Return code (Online Failed)
    public static final int ONLINE_REFER = -302;//Online Return code (Online Reference)
    public static final int ONLINE_DENIAL = -303;//Online Return code (Online Denial)

    private static final SparseIntArray messageMap = new SparseIntArray();

    static {
        messageMap.put(RetCode.EMV_OK, R.string.dialog_trans_succ);
        messageMap.put(RetCode.ICC_CMD_ERR, R.string.dialog_icc_cmd_err);
        messageMap.put(RetCode.EMV_NO_APP, R.string.dialog_emv_no_app);
        messageMap.put(RetCode.EMV_NO_APP_PPSE_ERR, R.string.dialog_emv_no_app_ppse_err);
        messageMap.put(RetCode.CLSS_PARAM_ERR, R.string.dialog_clss_param_err);
        messageMap.put(RetCode.CLSS_USE_CONTACT, R.string.dialog_clss_use_contact);
        messageMap.put(RetCode.CLSS_TERMINATE, R.string.dialog_clss_terminate);
        messageMap.put(OutcomeParam.CLSS_OC_DECLINED, R.string.dialog_clss_declined);
        messageMap.put(OutcomeParam.CLSS_OC_TRY_ANOTHER_INTERFACE, R.string.dialog_clss_try_contact);
        messageMap.put(UNSUPPORTED_KERNEL, R.string.err_card_unsupported);
    }

    public CTransResult() {
        this.transResult = RetCode.EMV_OK;
        this.cvmResult = CvmType.RD_CVM_NO;
    }

    public CTransResult(int transResult) {
        this.transResult = transResult;
        this.cvmResult = CvmType.RD_CVM_NO;
    }

    public String getMessage(int ret) {
        if (messageMap.get(ret) > 0) {
            return Utils.getString(messageMap.get(ret));
        }
        return Utils.getString(R.string.err_undefine) + "[" + ret + "]";
    }

    public int getTransResult() {
        return transResult;
    }

    public void setTransResult(int transResult) {
        this.transResult = transResult;
    }

    public byte getCvmResult() {
        return cvmResult;
    }

    public void setCvmResult(byte cvmResult) {
        this.cvmResult = cvmResult;
    }
}
