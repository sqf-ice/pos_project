/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.transmit;

import android.util.Log;

import com.pax.edc.R;
import com.pax.gl.commhelper.ISslKeyStore;
import com.pax.gl.commhelper.exception.CommException;
import com.pax.glwrapper.comm.ICommHelper;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.TransResult;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

public class TcpCupSsl extends ATcp {

    private InputStream keyStoreStream;

    public TcpCupSsl(InputStream keyStoreStream) {
        this.keyStoreStream = keyStoreStream;
    }

    @Override
    public int onConnect() {
        int ret = setCommParam();
        if (ret != TransResult.SUCC) {
            return ret;
        }

        int timeout = FinancialApplication.getSysParam().get(SysParam.NumberParam.COMM_TIMEOUT) * 1000;
        // 启用主通讯地址
        hostIp = getMainHostIp();
        hostPort = getMainHostPort();
        onShowMsg(Utils.getString(R.string.wait_connect));
        ret = connectCupSLL(hostIp, hostPort, timeout);
        if (ret != TransResult.ERR_CONNECT) {
            return ret;
        }
        hostIp = getBackHostIp();
        hostPort = getBackHostPort();
        // 启用备用通讯地址
        onShowMsg(Utils.getString(R.string.wait_connect_other));
        ret = connectCupSLL(hostIp, hostPort, timeout);
        return ret;
    }

    @Override
    public int onSend(byte[] data) {
        try {
            onShowMsg(Utils.getString(R.string.wait_send));
            client.send(getCupSslPackage(data));
            return TransResult.SUCC;
        } catch (CommException e) {
            Log.e(TAG, "", e);
        }
        return TransResult.ERR_SEND;
    }

    @Override
    public TcpResponse onRecv() {
        onShowMsg(Utils.getString(R.string.wait_recv));
        try {
            byte[] lenBuf = client.recv(2);
            if (lenBuf == null || lenBuf.length != 2) {
                return new TcpResponse(TransResult.ERR_RECV, null);
            }
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            int len = (((lenBuf[0] << 8) & 0xff00) | (lenBuf[1] & 0xff));
            byte[] rsp = client.recv(len);
            if (rsp == null || rsp.length != len) {
                return new TcpResponse(TransResult.ERR_RECV, null);
            }
            baos.write(rsp);
            rsp = baos.toByteArray();
            return new TcpResponse(TransResult.SUCC, rsp);
        } catch (IOException | CommException e) {
            Log.e(TAG, "", e);
        }
        return new TcpResponse(TransResult.ERR_RECV, null);
    }

    @Override
    public void onClose() {
        try {
            client.disconnect();
        } catch (Exception e) {
            Log.e(TAG, "", e);
        }
    }

    private int connectCupSLL(String hostIp, int port, int timeout) {
        if (hostIp == null || hostIp.isEmpty() || "0.0.0.0".equals(hostIp)) {
            return TransResult.ERR_CONNECT;
        }

        ICommHelper commHelper = FinancialApplication.getGl().getCommHelper();
        ISslKeyStore keyStore = commHelper.createSslKeyStore();
        if (keyStoreStream != null) {
            try {
                keyStoreStream.reset();
            } catch (IOException e) {
                Log.e(TAG, "", e);
            }
        }
        keyStore.setTrustStore(keyStoreStream);
        client = commHelper.createSslClient(hostIp, port, keyStore);
        client.setConnectTimeout(timeout);
        client.setRecvTimeout(timeout);
        try {
            client.connect();
            return TransResult.SUCC;
        } catch (CommException e) {
            Log.e(TAG, "", e);
        }
        return TransResult.ERR_CONNECT;
    }

    private byte[] getCupSslPackage(byte[] req) {
        String cupHostName = hostIp + ":" + hostPort;
        String cupUrl = "http://" + cupHostName + "/unp/webtrans/VPB_lb";

        String httpsReq = "POST ";
        httpsReq += cupUrl + " HTTP/1.1" + "\r\n";
        httpsReq += "HOST: " + cupHostName + "\r\n";
        httpsReq += "User-Agent: Donjin Http 0.1\r\n";
        httpsReq += "Cache-Control: no-cache\r\n";
        httpsReq += "Content-Type: x-ISO-TPDU/x-auth\r\n";
        httpsReq += "Accept: */*\r\n";
        httpsReq += "Content-Length: " + req.length + "\r\n\r\n";
        byte[] header = httpsReq.getBytes();
        byte[] bReq = byteMerger(header, req);
        return byteMerger(bReq, "\r\n".getBytes());
    }

    private byte[] byteMerger(byte[] paramArrayOfByte1, byte[] paramArrayOfByte2) {
        byte[] arrayOfByte = new byte[paramArrayOfByte1.length + paramArrayOfByte2.length];
        System.arraycopy(paramArrayOfByte1, 0, arrayOfByte, 0, paramArrayOfByte1.length);
        System.arraycopy(paramArrayOfByte2, 0, arrayOfByte, paramArrayOfByte1.length, paramArrayOfByte2.length);
        return arrayOfByte;
    }
}
