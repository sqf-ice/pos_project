/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-3-23
 * Module Author: Kim.L
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.db;

import android.support.annotation.NonNull;
import android.util.Log;

import com.j256.ormlite.dao.RuntimeExceptionDao;
import com.j256.ormlite.stmt.DeleteBuilder;
import com.j256.ormlite.stmt.QueryBuilder;
import com.j256.ormlite.stmt.Where;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransTotal;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import static com.pax.pay.trans.model.TransData.ETransStatus.ADJUSTED;
import static com.pax.pay.trans.model.TransData.ETransStatus.NORMAL;
import static com.pax.pay.trans.model.TransData.ETransStatus.VOIDED;

public class TransTotalDb {

    private static final String TAG = "TransTotalDb";

    private RuntimeExceptionDao<TransTotal, Integer> transDao = null;

    private final BaseDbHelper dbHelper;

    private static TransTotalDb instance;

    private static final List<TransData.ETransStatus> filter = new ArrayList<>();

    static {
        filter.add(NORMAL);
        filter.add(ADJUSTED);
    }

    private TransTotalDb() {
        dbHelper = BaseDbHelper.getInstance();
    }

    /**
     * get the Singleton of the DB Helper
     *
     * @return the Singleton of DB helper
     */
    public static synchronized TransTotalDb getInstance() {
        if (instance == null) {
            instance = new TransTotalDb();
        }

        return instance;
    }

    /***************************************
     * Dao
     ******************************************/
    private RuntimeExceptionDao<TransTotal, Integer> getTotalDao() {
        if (transDao == null) {
            transDao = dbHelper.getRuntimeExceptionDao(TransTotal.class);
        }
        return transDao;
    }

    /*-----------------------------Trans Data------------------------*/

    /**
     * insert a transTotal
     *
     * @return
     */
    public boolean insertTransTotal(TransTotal transTotal) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            dao.create(transTotal);
            return true;
        } catch (RuntimeException e) {
            Log.e(TAG, "", e);
        }

        return false;
    }

    /**
     * update a transTotal
     *
     * @return
     */
    public boolean updateTransTotal(TransTotal transTotal) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            dao.update(transTotal);
            return true;
        } catch (RuntimeException e) {
            Log.e(TAG, "", e);
        }

        return false;
    }

    /**
     * find transTotal by id
     *
     * @param id
     * @return
     */
    public TransTotal findTransTotal(int id) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            return dao.queryForId(id);
        } catch (RuntimeException e) {
            Log.w(TAG, "", e);
        }

        return null;
    }

    /**
     * find transTotal by batch No
     *
     * @param acquirer
     * @param batchNo
     * @return
     */
    public TransTotal findTransTotalByBatchNo(Acquirer acquirer, long batchNo) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            QueryBuilder<TransTotal, Integer> queryBuilder = dao.queryBuilder();
            queryBuilder.where().eq(TransTotal.BATCHNO_FIELD_NAME, batchNo)
                    .and().eq(Acquirer.ID_FIELD_NAME, acquirer);
            return queryBuilder.queryForFirst();
        } catch (SQLException e) {
            Log.w(TAG, "", e);
        }

        return null;
    }


    /**
     * find the last transTotal
     *
     * @return
     */
    public TransTotal findLastTransTotal(Acquirer acquirer, boolean isClosed) {
        try {
            List<TransTotal> list = findAllTransTotal(acquirer, isClosed);
            if (!list.isEmpty()) {
                return list.get(list.size() - 1);
            }
        } catch (RuntimeException e) {
            Log.w(TAG, "", e);
        }

        return null;
    }

    /**
     * find transTotal by batch No
     *
     * @return
     */
    @NonNull
    public
    List<TransTotal> findAllTransTotal(Acquirer acquirer, boolean isClosed) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            QueryBuilder<TransTotal, Integer> queryBuilder = dao.queryBuilder();
            Where<TransTotal, Integer> where = queryBuilder.where().eq(TransTotal.IS_CLOSED_FIELD_NAME, isClosed);
            if (acquirer != null)
                where.and().eq(Acquirer.ID_FIELD_NAME, acquirer);
            return queryBuilder.query();
        } catch (SQLException e) {
            Log.w(TAG, "", e);
        }

        return new ArrayList<>(0);
    }

    /**
     * delete TransTotal by id
     */
    public boolean deleteTransTotal(int id) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            dao.deleteById(id);
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "", e);
        }
        return false;
    }

    /**
     * delete transTotal by batch no
     */
    public boolean deleteTransTotalByBatchNo(Acquirer acquirer, long batchNo) {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            DeleteBuilder<TransTotal, Integer> deleteBuilder = dao.deleteBuilder();
            deleteBuilder.where().eq(TransTotal.BATCHNO_FIELD_NAME, batchNo)
                    .and().eq(Acquirer.ID_FIELD_NAME, acquirer);
            dao.delete(deleteBuilder.prepare());
            return true;
        } catch (SQLException e) {
            Log.w(TAG, "", e);
        }
        return false;
    }

    /**
     * delete all transTotal
     */
    public boolean deleteAllTransTotal() {
        try {
            RuntimeExceptionDao<TransTotal, Integer> dao = getTotalDao();
            List<TransTotal> list = dao.queryForAll();
            dao.delete(list);
            return true;
        } catch (RuntimeException e) {
            Log.w(TAG, "", e);
        }
        return false;
    }

    public TransTotal calcTotal() {
        TransTotal total = new TransTotal();

        // 消费
        long[] obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.SALE, filter);
        total.setSaleTotalNum(obj[0]);
        total.setSaleTotalAmt(obj[1]);

        // 撤销
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.VOID, NORMAL);
        total.setVoidTotalNum(obj[0]);
        total.setVoidTotalAmt(obj[1]);
        // 退货
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.REFUND, NORMAL);
        total.setRefundTotalNum(obj[0]);
        total.setRefundTotalAmt(obj[1]);
        //sale void total
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.SALE, VOIDED);
        total.setSaleVoidTotalNum(obj[0]);
        total.setSaleVoidTotalAmt(obj[1]);
        //refund void total
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.REFUND, VOIDED);
        total.setRefundVoidTotalNum(obj[0]);
        total.setRefundVoidTotalAmt(obj[1]);
        // 预授权
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.PREAUTH, NORMAL);
        total.setAuthTotalNum(obj[0]);
        total.setAuthTotalAmt(obj[1]);

        // 脱机 AET-75
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(ETransType.OFFLINE_TRANS_SEND, filter);
        total.setOfflineTotalNum(obj[0]);
        total.setOfflineTotalAmt(obj[1]);

        return total;
    }

    public TransTotal calcTotal(Acquirer acquirer) {
        TransTotal total = new TransTotal();

        // 消费
        long[] obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.SALE, filter);
        total.setSaleTotalNum(obj[0]);
        total.setSaleTotalAmt(obj[1]);

        // 撤销
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.VOID, NORMAL);
        total.setVoidTotalNum(obj[0]);
        total.setVoidTotalAmt(obj[1]);

        // 退货
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.REFUND, NORMAL);
        total.setRefundTotalNum(obj[0]);
        total.setRefundTotalAmt(obj[1]);

        //sale void total
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.SALE, VOIDED);
        total.setSaleVoidTotalNum(obj[0]);
        total.setSaleVoidTotalAmt(obj[1]);
        //refund void total
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.REFUND, VOIDED);
        total.setRefundVoidTotalNum(obj[0]);
        total.setRefundVoidTotalAmt(obj[1]);

        // 预授权
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.PREAUTH, NORMAL);
        total.setAuthTotalNum(obj[0]);
        total.setAuthTotalAmt(obj[1]);

        // 脱机 AET-75
        obj = FinancialApplication.getTransDataDbHelper().countSumOf(acquirer, ETransType.OFFLINE_TRANS_SEND, filter);
        total.setOfflineTotalNum(obj[0]);
        total.setOfflineTotalAmt(obj[1]);

        return total;
    }

}
