/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.model;

import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;

import com.pax.pay.app.FinancialApplication;

public class Controller {
    public static class Constant {
        public static final int YES = 1;
        public static final int NO = 0;
        /**
         * batch upload status
         */
        public static final int WORKED = 0;
        public static final int BATCH_UP = 1;

        private Constant() {
            //do nothing
        }
    }

    private static final String IS_PARAM_FILE_EXIST = "IS_PARAM_FILE_EXIST";

    public static final String IS_FIRST_RUN = "IS_FIRST_RUN";
    //add by xiawh if need setting wizard of not
    public static final String NEED_SET_WIZARD = "need_set_wizard";
    /**
     * is need download capk  NO: not need YES: need
     */
    public static final String NEED_DOWN_CAPK = "need_down_capk";
    /**
     * is need download aid NO: not need YES: need
     */
    public static final String NEED_DOWN_AID = "need_down_aid";
    /**
     * batch upload status {@link Constant#WORKED}not in batch upload , {@link Constant#BATCH_UP}:in batch upload
     */
    public static final String BATCH_UP_STATUS = "batch_up_status";

    /**
     * check result
     */
    public static final String RESULT = "result";
    /**
     * batch upload number
     */
    public static final String BATCH_NUM = "batch_num";
    /**
     * whether need to clear transaction record: NO: not clear, YES: clear
     */
    public static final String CLEAR_LOG = "clearLog";

    private static final String FILE_NAME = "control";

    public Controller() {
        if (isParamFileExisted()) {
            return;
        }
        SharedPreferences sp = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();

        editor.putBoolean(IS_PARAM_FILE_EXIST, true);

        editor.putBoolean(IS_FIRST_RUN, true);
        editor.putInt(NEED_DOWN_CAPK, Constant.YES);
        editor.putInt(NEED_DOWN_AID, Constant.YES);
        editor.putInt(BATCH_UP_STATUS, Constant.NO);
        editor.apply();
    }

    public int get(String key) {
        SharedPreferences sp = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        return sp.getInt(key, Constant.NO);
    }

    public boolean getBoolean(String key) {
        SharedPreferences sp = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        if (key.equals(IS_FIRST_RUN))
            return sp.getBoolean(key, true);
        return sp.getBoolean(key, false);
    }

    public void set(String key, int value) {
        SharedPreferences sp = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putInt(key, value);
        editor.apply();
    }

    public void set(String key, boolean value) {
        SharedPreferences sp = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, Context.MODE_PRIVATE);
        Editor editor = sp.edit();
        editor.putBoolean(key, value);
        editor.apply();
    }

    private boolean isParamFileExisted() {
        SharedPreferences control = FinancialApplication.getApp().getSharedPreferences(FILE_NAME, 0);
        return control.getBoolean(IS_PARAM_FILE_EXIST, false);
    }

}
