/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.menu;

import android.app.ActionBar.LayoutParams;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.pax.edc.R;
import com.pax.pay.BaseActivity;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.view.MenuPage;

public abstract class BaseMenuActivity extends BaseActivity implements OnClickListener {
    /**
     * 返回按钮
     */
    private ImageView headerBack;

    /**
     * 显示的抬头
     */
    private String navTitle;
    /**
     * 是否显示返回按钮
     */
    private boolean navBack;

    @Override
    protected int getLayoutId() {
        return R.layout.menu_layout;
    }

    @Override
    protected void loadParam() {
        navTitle = getIntent().getStringExtra(EUIParamKeys.NAV_TITLE.toString());
        navBack = getIntent().getBooleanExtra(EUIParamKeys.NAV_BACK.toString(), false);
    }

    @Override
    protected void initViews() {
        TextView tvTitle = (TextView) findViewById(R.id.header_title);
        tvTitle.setText(navTitle);
        headerBack = (ImageView) findViewById(R.id.header_back);
        LinearLayout llContainer = (LinearLayout) findViewById(R.id.ll_container);

        android.widget.LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(LayoutParams.MATCH_PARENT,
                LayoutParams.MATCH_PARENT);

        llContainer.addView(createMenuPage(), params);

    }

    public abstract MenuPage createMenuPage();

    @Override
    protected void setListeners() {

        if (!navBack) {
            headerBack.setVisibility(View.GONE);
        } else {
            headerBack.setOnClickListener(this);
        }

    }

    @Override
    public void onClickProtected(View v) {
        if (v.getId() == R.id.header_back) {
            finish();
        }
    }
}
