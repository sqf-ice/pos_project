/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.pack;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.abl.core.ipacker.PackListener;
import com.pax.gl.pack.exception.Iso8583Exception;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.TransData;

public class PackSaleVoid extends PackIso8583 {

    public PackSaleVoid(PackListener listener) {
        super(listener);
    }

    @Override
    @NonNull
    public
    byte[] pack(@NonNull TransData transData) {
        try {
            setCommonData(transData);
            setBitData60(transData);

            return pack(true);

        } catch (Exception e) {
            Log.e(TAG, "", e);
        }
        return "".getBytes();
    }

    /**
     * 设置撤销类交易 设置域
     * <p>
     * field 2, field 4, field 14,field 22, field 23,field 26,field 35,field 36,
     * <p>
     * field 37,field 38, field 49,field 53,field 61
     *
     * @param transData
     * @return
     */
    @Override
    protected void setCommonData(@NonNull TransData transData) throws Iso8583Exception {
        setMandatoryData(transData);
        super.setCommonData(transData);

        // [37]原参考号
        setBitData37(transData);

        // [38]原授权码
        setBitData38(transData);

        // field 61
        setBitData61(transData);

    }

    @Override
    protected void setBitData60(@NonNull TransData transData) throws Iso8583Exception {
        String f60 = Component.getPaddedNumber(transData.getBatchNo(), 6); // f60.2
        f60 += "600";
        setBitData("60", f60);
    }

    @Override
    protected void setBitData61(@NonNull TransData transData) throws Iso8583Exception {
        String f61 = "";
        String temp = Component.getPaddedNumber(transData.getOrigBatchNo(), 6);
        if (temp != null && !temp.isEmpty()) {
            f61 += temp;
        } else {
            f61 += "000000";
        }
        temp = Component.getPaddedNumber(transData.getOrigTransNo(), 6);
        if (temp != null && !temp.isEmpty()) {
            f61 += temp;
        } else {
            f61 += "000000";
        }
        setBitData("61", f61);
    }
}
