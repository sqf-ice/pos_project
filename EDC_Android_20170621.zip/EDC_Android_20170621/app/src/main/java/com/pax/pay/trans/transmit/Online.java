/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.transmit;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.abl.core.ipacker.IPacker;
import com.pax.abl.core.ipacker.PackListener;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

public class Online {

    private class PackListenerImpl implements PackListener {
        private TransProcessListener listener;

        public PackListenerImpl(TransProcessListener listener) {
            this.listener = listener;
        }

        @Override
        @NonNull
        public
        byte[] onCalcMac(byte[] data) {
            if (listener != null) {
                return listener.onCalcMac(data);
            }
            Log.v("Online", "listener == null");
            return "".getBytes();
        }

        @Override
        @NonNull
        public
        byte[] onEncTrack(byte[] track) {
            if (listener != null) {
                return listener.onEncTrack(track);
            }
            return "".getBytes();
        }

    }

    private TransProcessListener listener;
    private ATcp tcp;

    public int online(TransData transData, final TransProcessListener listener) {
        return this.online(transData, listener, true, true);
    }

    public int online(TransData transData, final TransProcessListener listener, final boolean reconnect, final boolean forceClose) {
        try {
            this.listener = listener;
            onShowMsg(Utils.getString(R.string.wait_process));
            ETransType transType = transData.getTransType();
            // 准备打包器
            IPacker<TransData, byte[]> packager = transType.getPackager(new PackListenerImpl(listener));
            IPacker<TransData, byte[]> dupPackager = transType.getDupPackager(new PackListenerImpl(listener));

            int ret;
            if (reconnect) {
                tcp = getTcpClient();
                if (tcp == null)
                    return TransResult.ERR_CONNECT;
            }
            tcp.setTransProcessListener(listener);
            if (reconnect) {
                // 连接
                ret = tcp.onConnect();
                if (ret != 0) {
                    return TransResult.ERR_CONNECT;
                }
            }
            // 打包
            byte[] req;
            if (transData.getReversalStatus() == TransData.ReversalStatus.REVERSAL) {
                req = dupPackager.pack(transData);
            } else {
                req = packager.pack(transData);
            }
            if (req.length == 0) {
                return TransResult.ERR_PACK;
            }
            byte[] sendData = new byte[2 + req.length];
            sendData[0] = (byte) (req.length / 256);
            sendData[1] = (byte) (req.length % 256);
            System.arraycopy(req, 0, sendData, 2, req.length);

            // 联机交易标识
            transData.setOnlineTrans(true);

            // 发送数据
            Log.i("TAG", "SEND:" + FinancialApplication.getConvert().bcdToStr(sendData));
            ret = tcp.onSend(sendData);
            if (ret != 0) {
                return TransResult.ERR_SEND;
            }

            // 冲正处理
            if (dupPackager != null && transData.getReversalStatus() == TransData.ReversalStatus.NORMAL) {
                // 保存冲正
                transData.setReversalStatus(TransData.ReversalStatus.PENDING);
                if (transData.getOfflineSendState() != null)
                    FinancialApplication.getTransDataDbHelper().updateTransData(transData);
                else
                    FinancialApplication.getTransDataDbHelper().insertTransData(transData);
            }

            //AET-32、AET31
            // AET-126只要发送成功保存了交易就要增加流水号，避免流水号复用
            // 冲正交易不需要增加流水号
            if (transData.getReversalStatus() != TransData.ReversalStatus.REVERSAL &&
                    (transType != ETransType.OFFLINE_TRANS_SEND) &&
                    (transType != ETransType.SETTLE) &&
                    (transType != ETransType.BATCH_UP)) {
                Component.incTransNo();
            }

            // 接收数据
            TcpResponse tcpResponse = tcp.onRecv();

            if (tcpResponse.getRetCode() != TransResult.SUCC) {
                // 更新冲正原因
                if (dupPackager != null && transData.getReversalStatus() != TransData.ReversalStatus.REVERSAL) {
                    transData.setReversalStatus(TransData.ReversalStatus.PENDING);
                    transData.setDupReason(TransData.DUP_REASON_NO_RECV);
                    FinancialApplication.getTransDataDbHelper().updateTransData(transData);
                }
                return TransResult.ERR_RECV;
            }

            if (TcpDemoMode.class.equals(tcp.getClass())) {
                createDummyRecvData(transData);
                return TransResult.SUCC;
            }

            Log.i("TAG", "RECV:" + FinancialApplication.getConvert().bcdToStr(tcpResponse.getData()));
            if (dupPackager != null && transData.getReversalStatus() == TransData.ReversalStatus.REVERSAL) {
                return dupPackager.unpack(transData, tcpResponse.getData());
            }
            ret = packager.unpack(transData, tcpResponse.getData());
            // 更新冲正原因
            if (ret == TransResult.ERR_MAC && dupPackager != null &&
                    transData.getReversalStatus() != TransData.ReversalStatus.REVERSAL) {
                transData.setReversalStatus(TransData.ReversalStatus.PENDING);
                transData.setDupReason(TransData.DUP_REASON_MACWRONG);
                transData.setDateTime(transData.getDateTime());
                FinancialApplication.getTransDataDbHelper().updateTransData(transData);
            }
            // 如果39域返回null,删除冲正文件, 或者解包3， 4， 11， 41，42域与请求不同时，删除冲正(BCTC要求下笔交易不发冲正)
            if (ret == TransResult.ERR_BAG || ret == TransResult.ERR_PROC_CODE || ret == TransResult.ERR_TRANS_AMT
                    || ret == TransResult.ERR_TRACE_NO || ret == TransResult.ERR_TERM_ID
                    || ret == TransResult.ERR_MERCH_ID) {
                FinancialApplication.getTransDataDbHelper().deleteDupRecord();
            }
            return ret;
        } finally {
            if (forceClose) {
                close();
            }
        }
    }

    public void close() {
        if (tcp != null) {
            tcp.onClose();
        }
    }

    private void onShowMsg(String msg) {
        if (listener != null) {
            listener.onShowProgress(msg, FinancialApplication.getSysParam().get(SysParam.NumberParam.COMM_TIMEOUT));
        }
    }

    private ATcp getTcpClient() {
        String commType = FinancialApplication.getSysParam().get(SysParam.StringParam.COMM_TYPE);
        String sslType = FinancialApplication.getSysParam().get(SysParam.StringParam.COMM_TYPE_SSL);
        if (SysParam.Constant.CommType.DEMO.toString().equals(commType)) {
            return new TcpDemoMode();
        } else if (SysParam.Constant.CommSslType.NO_SSL.toString().equals(sslType)) {
            return new TcpNoSsl();
        }
        return null;
    }

    private void createDummyRecvData(TransData transData) {
        if (!ETransType.VOID.equals(transData.getTransType())) {
            transData.setAuthCode(transData.getDateTime().substring(8));
        } else {
            transData.setAuthCode("      ");
        }

        transData.setRefNo(transData.getDateTime().substring(2));
        transData.setResponseCode(FinancialApplication.getRspCode().parse("00"));
        if (ETransType.SETTLE.equals(transData.getTransType())) {
            transData.setResponseCode(FinancialApplication.getRspCode().parse("95"));
        }
        // 测试交易上送， 模拟平台下发脚本
        String rspF55 = "72289F1804AABBCCDD86098424000004AABBCCDD86098418000004AABBCCDD86098416000004AABBCCDD";
        transData.setRecvIccData(rspF55);
    }
}
