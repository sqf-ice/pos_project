/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.emv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.ConditionVariable;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.util.Log;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.abl.utils.TrackUtils;
import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.eemv.IEmv;
import com.pax.eemv.IEmvListener;
import com.pax.eemv.entity.Amounts;
import com.pax.eemv.entity.CandList;
import com.pax.eemv.enums.EOnlineResult;
import com.pax.eemv.exception.EEmvExceptions;
import com.pax.eemv.exception.EmvException;
import com.pax.eventbus.SearchCardEvent;
import com.pax.gl.pack.ITlv;
import com.pax.gl.pack.exception.TlvException;
import com.pax.glwrapper.convert.IConvert;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Issuer;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.action.ActionEnterPin;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.Online;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.trans.transmit.Transmit;
import com.pax.pay.utils.CurrencyConverter;

import java.util.List;

public class EmvListenerImpl implements IEmvListener {
    private ConditionVariable cv;
    private int intResult;
    private static final String TAG = EmvListenerImpl.class.getSimpleName();
    private Context context;
    private TransData transData;
    private IConvert convert = FinancialApplication.getConvert();
    private IEmv emv;
    private TransProcessListener transProcessListener;

    public EmvListenerImpl(Context context, IEmv emv, TransData transData, TransProcessListener listener) {
        this.context = context;
        this.emv = emv;
        this.transData = transData;
        this.intResult = -1;
        this.transProcessListener = listener;
    }

    @Override
    public int onCardHolderPwd(final boolean isOnlinePin, final int offlinePinLeftTimes, byte[] pinData) {
        if (transProcessListener != null) {
            transProcessListener.onHideProgress();
        }
        cv = new ConditionVariable();
        intResult = 0;

        if (pinData != null && pinData[0] != 0) {
            return pinData[0];
        }

        enterPin(isOnlinePin, offlinePinLeftTimes);

        cv.block(); // for the Offline pin case, block it for make sure the PIN activity is ready, otherwise, may get the black screen.
        return intResult;
    }

    @Override
    public boolean onChkExceptionFile() {
        Log.e("TAG", "onChkExceptionFile");
        byte[] track2 = emv.getTlv(0x57);
        String strTrack2 = FinancialApplication.getConvert().bcdToStr(track2);
        strTrack2 = strTrack2.split("F")[0];
        // 卡号
        String pan = TrackUtils.getPan(strTrack2);
        boolean ret = FinancialApplication.getCardBinDb().isBlack(pan);
        if (ret) {
            transProcessListener.onShowErrMessageWithConfirm(context.getString(R.string.emv_card_in_black_list), Constants.FAILED_DIALOG_SHOW_TIME);
            return true;
        }
        return false;
    }

    @Override
    public int onConfirmCardNo(final String cardno) {
        if (transProcessListener != null) {
            transProcessListener.onHideProgress();
        }

        Issuer issuer = FinancialApplication.getAcqManager().findIssuerByPan(cardno);
        if (issuer != null && FinancialApplication.getAcqManager().isIssuerSupported(issuer)) {
            transData.setIssuer(issuer);
        } else {
            intResult = EEmvExceptions.EMV_ERR_DATA.getErrCodeFromBasement();
            return intResult;
        }

        cv = new ConditionVariable();

        byte[] holderNameBCD = emv.getTlv(0x5F20);
        byte[] expDateBCD = emv.getTlv(0x5F24);
        String expDate = FinancialApplication.getConvert().bcdToStr(expDateBCD);
        FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.ICC_UPDATE_CARD_INFO, new CardInfo(cardno, new String(holderNameBCD), expDate, transData.getIssuer().getAdjustPercent())));

        if (!Issuer.validPan(transData.getIssuer(), cardno) ||
                !Issuer.validCardExpiry(transData.getIssuer(), expDate)) {
            intResult = EEmvExceptions.EMV_ERR_DATA.getErrCodeFromBasement();
            return intResult;
        }

        FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.ICC_CONFIRM_CARD_NUM));

        cv.block();

        return intResult;
    }

    @Override
    public Amounts onGetAmounts() {
        Amounts amt = new Amounts();
        amt.setTransAmount(transData.getAmount());
        return amt;
    }

    @Override
    public EOnlineResult onOnlineProc() {
        try {
            ETransType transType = transData.getTransType();
            // read ARQC
            byte[] arqc = emv.getTlv(0x9f26);
            if (arqc != null && arqc.length > 0) {
                transData.setArqc(convert.bcdToStr(arqc));
            }

            // 处理冲正
            new Transmit().sendReversal(transProcessListener);

            // 生成联机的55域数据
            byte[] f55 = EmvTags.getF55(emv, transType, false);
            byte[] f55Dup = EmvTags.getF55(emv, transType, true);

            transData.setSendIccData(convert.bcdToStr(f55));
            if (f55Dup.length > 0) {
                transData.setDupIccData(convert.bcdToStr(f55Dup));
            }
            Component.saveCardInfoAndCardSeq(emv, transData);

            // 联机通讯
            int commResult;
            if (transProcessListener != null) {
                transProcessListener.onUpdateProgressTitle(transType.getTransName());
            }
            int ret = new Online().online(transData, transProcessListener);
            Log.i(TAG, "Online  ret = " + ret);
            if (ret == TransResult.SUCC) {
                commResult = 1;
                if (!"00".equals(transData.getResponseCode().getCode())) {
                    commResult = 2; // 联机拒绝
                }
            } else {
                //AET-146 :ignore display error in online process, display in emv process
                return EOnlineResult.ABORT;
            }

            String rspF55 = transData.getRecvIccData();
            Log.i(TAG, "rspF55 = " + rspF55);
            ITlv tlv = FinancialApplication.getPacker().getTlv();

            if (rspF55 != null && !rspF55.isEmpty()) {
                // 设置授权数据
                byte[] resp55 = convert.strToBcd(rspF55, EPaddingPosition.PADDING_LEFT);
                ITlv.ITlvDataObjList list = tlv.unpack(resp55);

                byte[] value91 = list.getValueByTag(0x91);
                if (value91 != null && value91.length > 0) {
                    emv.setTlv(0x91, value91);
                }
                // 设置脚本 71
                byte[] value71 = list.getValueByTag(0x71);
                if (value71 != null && value71.length > 0) {
                    emv.setTlv(0x71, value71);
                }

                // 设置脚本 72
                byte[] value72 = list.getValueByTag(0x72);
                if (value72 != null && value72.length > 0) {
                    emv.setTlv(0x72, value72);
                }
            }

            if (commResult != 1) {
                FinancialApplication.getTransDataDbHelper().deleteDupRecord();
                Device.beepErr();
                //AET-146 :ignore display error in online process, display in emv process
                return EOnlineResult.DENIAL;
            }
            // 设置授权码
            String authCode = transData.getAuthCode();
            if (authCode != null && !authCode.isEmpty()) {
                emv.setTlv(0x89, authCode.getBytes());
            }
            emv.setTlv(0x8A, "00".getBytes());
            // write transaction record
            transData.setReversalStatus(TransData.ReversalStatus.NORMAL);
            transData.setDupReason("");
            FinancialApplication.getTransDataDbHelper().updateTransData(transData);
            return EOnlineResult.APPROVE;

        } catch (EmvException | TlvException e) {
            Log.e(TAG, "", e);
        } finally {
            if (transProcessListener != null)
                transProcessListener.onHideProgress();
        }

        return EOnlineResult.FAILED;
    }

    @Override
    public int onSetParam(byte onlinePin, byte[] aid) {
        return 0;
    }

    @Override
    public int onWaitAppSelect(final boolean isFirstSelect, final List<CandList> candList) {
        if (transProcessListener != null) {
            transProcessListener.onHideProgress();
        }
        cv = new ConditionVariable();
        // ignore Sonar's lambda suggestion cuz the Sonar runs JAVA8, but EDC runs JAVA7,
        // there are same cases, ignore them as well.
        FinancialApplication.getApp().runOnUiThread(new SelectAppRunnable(isFirstSelect, candList));

        cv.block();
        return intResult;
    }

    private class SelectAppRunnable implements Runnable{
        private final boolean isFirstSelect;
        private final List<CandList> candList;

        SelectAppRunnable(final boolean isFirstSelect, final List<CandList> candList){
            this.isFirstSelect = isFirstSelect;
            this.candList = candList;
        }

        @Override
        public void run() {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            if (isFirstSelect) {
                builder.setTitle(context.getString(R.string.emv_application_choose));
            } else {
                SpannableString sstr = new SpannableString(context.getString(R.string.emv_application_choose_again));
                sstr.setSpan(new ForegroundColorSpan(Color.RED), 5, 9, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
                builder.setTitle(sstr);
            }
            String[] appNames = new String[candList.size()];
            for (int i = 0; i < appNames.length; i++) {
                appNames[i] = candList.get(i).getAppName();
            }
            builder.setSingleChoiceItems(appNames, -1, new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {
                    intResult = which;
                    close(dialog);
                }
            });

            builder.setPositiveButton(context.getString(R.string.dialog_cancel),
                    new DialogInterface.OnClickListener() {

                        @Override
                        public void onClick(DialogInterface dialog, int which) {
                            intResult = EEmvExceptions.EMV_ERR_USER_CANCEL.getErrCodeFromBasement();
                            close(dialog);
                        }
                    });
            builder.setCancelable(false);
            builder.create().show();
        }

        private void close(DialogInterface dialog){
            dialog.dismiss();
            cv.open();
        }
    }

    private void enterPin(boolean isOnlinePin, int offlinePinLeftTimes) {
        final String header;
        final String subHeader = context.getString(R.string.prompt_no_pin);

        final String totalAmount = transData.getTransType().isSymbolNegative() ? "-" + transData.getAmount() : transData.getAmount();
        final String tipAmount = transData.getTransType().isSymbolNegative() ? null : transData.getTipAmount();

        if (isOnlinePin) { // 联机密码
            header = context.getString(R.string.prompt_pin);
            doOnlineAction(header, subHeader, totalAmount, tipAmount);

        } else {
            header = context.getString(R.string.prompt_pin) + "(" + offlinePinLeftTimes + ")";
            doOfflineAction(header, subHeader, totalAmount, tipAmount);
        }
    }

    private void doOnlineAction(final String header, final String subHeader,
                                final String totalAmount, final String tipAmount){
        ActionEnterPin actionEnterPin = new ActionEnterPin(new AAction.ActionStartListener() {
            @Override
            public void onStart(AAction action) {

                byte[] track2 = emv.getTlv(0x57);
                String strTrack2 = convert.bcdToStr(track2);
                strTrack2 = strTrack2.split("F")[0];
                String pan = strTrack2.split("D")[0];

                ((ActionEnterPin) action).setParam(context, transData.getTransType()
                                .getTransName(), pan, true, header, subHeader,
                        totalAmount, tipAmount, ActionEnterPin.EEnterPinType.ONLINE_PIN);
            }
        });

        actionEnterPin.setEndListener(new OnlineEndAction());
        actionEnterPin.execute();
    }

    private class OnlineEndAction implements AAction.ActionEndListener{
        @Override
        public void onEnd(AAction action, ActionResult result) {
            int ret = result.getRet();
            if (ret == TransResult.SUCC) {
                String data = (String) result.getData();
                transData.setPin(data);
                if (data != null && !data.isEmpty()) {
                    transData.setHasPin(true);
                    intResult = EEmvExceptions.EMV_OK.getErrCodeFromBasement();
                } else {
                    intResult = EEmvExceptions.EMV_ERR_NO_PASSWORD.getErrCodeFromBasement(); // bypass
                }
            } else {
                intResult = EEmvExceptions.EMV_ERR_USER_CANCEL.getErrCodeFromBasement();
            }
            if (cv != null)
                cv.open();
            ActivityStack.getInstance().popTo((Activity) context);
        }
    }

    private void doOfflineAction(final String header, final String subHeader,
                                 final String totalAmount, final String tipAmount){
        ActionEnterPin actionEnterPin = new ActionEnterPin(new AAction.ActionStartListener() {
            @Override
            public void onStart(AAction action) {

                byte[] track2 = emv.getTlv(0x57);
                String strTrack2 = convert.bcdToStr(track2);
                strTrack2 = strTrack2.split("F")[0];
                String pan = strTrack2.split("D")[0];

                ((ActionEnterPin) action).setParam(context, transData.getTransType()
                                .getTransName(), pan, true, header, subHeader,
                        totalAmount, tipAmount, ActionEnterPin.EEnterPinType.OFFLINE_PCI_MODE);
            }
        });

        actionEnterPin.setEndListener(new AAction.ActionEndListener() {

            @Override
            public void onEnd(AAction action, ActionResult result) {
                ActivityStack.getInstance().popTo((Activity) context);
            }
        });
        actionEnterPin.execute();
    }

    public void offlinePinEnterReady() {
        cv.open();
    }

    public void cardNumConfigErr() {
        intResult = EEmvExceptions.EMV_ERR_USER_CANCEL.getErrCodeFromBasement();
        cv.open();
    }

    public void cardNumConfigSucc() {
        intResult = EEmvExceptions.EMV_OK.getErrCodeFromBasement();
        cv.open();
    }

    public void cardNumConfigSucc(String[] amount) {
        if (amount != null && amount.length == 2) {
            transData.setAmount(String.valueOf(CurrencyConverter.parse(amount[0])));
            transData.setTipAmount(String.valueOf(CurrencyConverter.parse(amount[1])));
        }
        cardNumConfigSucc();
    }

    public static class CardInfo {
        private String cardNum;
        private String holderName;
        private String expDate;
        private float adjustPercent;

        CardInfo(String cardNum, String holderName, String expDate, float adjustPercent) {
            this.cardNum = cardNum;
            this.holderName = holderName;
            this.expDate = expDate;
            this.adjustPercent = adjustPercent;
        }

        public String getCardNum() {
            return cardNum;
        }

        public String getHolderName() {
            return holderName;
        }

        public String getExpDate() {
            return expDate;
        }

        public float getAdjustPercent() {
            return adjustPercent;
        }
    }
}
