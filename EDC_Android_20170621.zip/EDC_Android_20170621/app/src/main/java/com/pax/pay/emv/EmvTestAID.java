/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-12-1
 * Module Author: Kim.L
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.emv;

import com.pax.pay.app.FinancialApplication;

public class EmvTestAID extends EmvAid {

    public static final EmvTestAID EMV = new EmvTestAID(
            "",
            "A0000000999090",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0010000000",
            "D84004F800",
            "D84000A800",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "008c",
            null
    );

    public static final EmvTestAID JCB_TEST = new EmvTestAID(
            "",
            "F1234567890123",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0010000000",
            "D84004F800",
            "D84000A800",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "008c",
            null
    );


    public static final EmvTestAID JCB_TSET_1 = new EmvTestAID(
            "",
            "A0000000651010",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0010000000",
            "FC60ACF800",
            "FC6024A800",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0200",
            null
    );

    public static final EmvTestAID VISA_VSDC = new EmvTestAID(
            "VISA CREDIT",
            "A0000000031010",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0010000000",
            "D84004F800",
            "D84000A800",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "008c",
            null
    );

    public static final EmvTestAID VISA_ELECTRON = new EmvTestAID(
            "VISA ELECTRON",
            "A0000000032010",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0010000000",
            "D84004F800",
            "D84000A800",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "008c",
            null
    );


    public static final EmvTestAID MASTER_MCHIP = new EmvTestAID(
            "MCHIP",
            "A0000000041010",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MCHIP_1 = new EmvTestAID(
            "MCHIP",
            "A0000000041010D05601",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MCHIP_2 = new EmvTestAID(
            "MCHIP",
            "A0000000041010C123456789",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO = new EmvTestAID(
            "MAESTRO",
            "A0000000043060",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO_1 = new EmvTestAID(
            "MAESTRO",
            "A0000000043060D05602",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO_2 = new EmvTestAID(
            "MAESTRO",
            "A0000000042203C123456789",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO_3 = new EmvTestAID(
            "MAESTRO",
            "A0000000043060C123456789",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO_US = new EmvTestAID(
            "MAESTRO",
            "A0000000042203",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_MAESTRO_US_1 = new EmvTestAID(
            "MAESTRO",
            "A0000000042203D84002",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_CIRRUS = new EmvTestAID(
            "CIRRUS",
            "A0000000046000",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MASTER_CIRRUS1 = new EmvTestAID(
            "CIRRUS",
            "A0000000046000C123456789",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MCC_4 = new EmvTestAID(
            "",
            "A0000000046010",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID MCC_5 = new EmvTestAID(
            "",
            "A0000000101030",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0400000000",
            "F850ACF800",
            "FC50ACA000",
            "000000123456",
            "039F3704",
            "0F9F02065F2A029A039C0195059F3704",
            "0002",
            null
    );

    public static final EmvTestAID AMEX_LIVE = new EmvTestAID(
            "",
            "A00000002501",
            PART_MATCH, 0, 0, 0, 1, 1, 1,
            0, 0,
            "0000000000",
            "0000000000",
            "0000000000",
            "000000123456",
            "039F3704",
            "9F3704",
            "0001",
            null
    );

    public static final EmvTestAID DPAS_LIVE = new EmvTestAID(
            "",
            "A0000001523010",
            PART_MATCH, 0, 0, 0, 1, 0, 1,    // random=off
            0, 0,
            "0000000000",
            "0000000000",
            "0000000000",
            "000000123456",
            "039F3704",
            "9F3704",
            "008C",
            null
    );

    public static final EmvTestAID DPAS_LIVE_1 = new EmvTestAID(
            "",
            "A0000003241010",
            PART_MATCH, 0, 0, 0, 1, 0, 1,    // random=off
            0, 0,
            "0000000000",
            "0000000000",
            "0000000000",
            "000000123456",
            "039F3704",
            "9F3704",
            "008c",
            null
    );

    private EmvTestAID(String appName, String aid, int selFlag, int priority, int targetPer, int maxTargetPer,
                       int floorLimitCheck, int randTransSel, int velocityCheck, long floorLimit, long threshold,
                       String tacDenial, String tacOnline, String tacDefault, String acquierId, String dDOL, String tDOL, String version, String riskManData) {

        setAppName(appName);
        setAid(aid);
        setSelFlag(selFlag);
        setVersion(version);
        setTacDefault(tacDefault);
        setRandTransSel(randTransSel);
        setVelocityCheck(velocityCheck);
        setTacOnline(tacOnline);
        setTacDenial(tacDenial);
        setFloorLimit(floorLimit);
        setFloorLimitCheck(floorLimitCheck);
        setThreshold(threshold);
        setMaxTargetPer(maxTargetPer);
        setTargetPer(targetPer);
        setDDOL(dDOL);
        setTDOL(tDOL);

        setPriority(priority);
        setOnlinePin(0);

        setRdClssFLmt(floorLimit);
        setRdClssFLmtFlg(floorLimitCheck);
        setAcquirerId(acquierId);
        setRdClssTxnLmtFlg(0);
        setRdCVMLmtFlg(0);
        setRiskManageData(riskManData);
    }

    public static void load() {
        // test apps
        FinancialApplication.getEmvDbHelper().insertAID(EMV);
        FinancialApplication.getEmvDbHelper().insertAID(JCB_TEST);
        FinancialApplication.getEmvDbHelper().insertAID(JCB_TSET_1);

        FinancialApplication.getEmvDbHelper().insertAID(VISA_VSDC);
        FinancialApplication.getEmvDbHelper().insertAID(VISA_ELECTRON);

        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MCHIP);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MCHIP_1);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MCHIP_2);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO_1);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO_2);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO_3);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO_US);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_MAESTRO_US_1);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_CIRRUS);
        FinancialApplication.getEmvDbHelper().insertAID(MASTER_CIRRUS1);
        FinancialApplication.getEmvDbHelper().insertAID(MCC_4);
        FinancialApplication.getEmvDbHelper().insertAID(MCC_5);

        FinancialApplication.getEmvDbHelper().insertAID(AMEX_LIVE);
        FinancialApplication.getEmvDbHelper().insertAID(DPAS_LIVE);
        FinancialApplication.getEmvDbHelper().insertAID(DPAS_LIVE_1);
    }
}
