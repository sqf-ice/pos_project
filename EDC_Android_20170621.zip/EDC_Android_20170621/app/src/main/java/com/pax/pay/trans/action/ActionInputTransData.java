/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;

import com.pax.abl.core.AAction;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.action.activity.InputTransData1Activity;
import com.pax.pay.trans.action.activity.InputTransData2Activity;
import com.pax.pay.trans.action.activity.InputTransDataTipActivity;
import com.pax.pay.trans.action.activity.PaperlessActivity;

import java.util.Map;

public class ActionInputTransData extends AAction {
    private Context context;
    private String title;
    private String prompt1;
    private EInputType inputType1;
    private int maxLen1;
    private int minLen1;
    private String prompt2;
    private EInputType inputType2;
    private int maxLen2;
    private int minLen2;
    private int lineNum;
    private boolean isVoidLastTrans;
    private boolean isAuthZero;
    private Map<String, String> map;

    public ActionInputTransData(ActionStartListener listener, int lineNum) {
        super(listener);
        this.lineNum = lineNum;
    }

    /**
     * 输入数据类型定义
     *
     * @author Steven.W
     */
    public enum EInputType {
        AMOUNT,
        DATE,
        NUM, // 数字
        ALPHA_NUM, // 数字加字母
        TEXT, // 所有类型
        PHONE,
        EMAIL,
    }

    public ActionInputTransData setParam(Context context, String title) {
        this.context = context;
        this.title = title;
        return this;
    }

    public ActionInputTransData setParam(Context context, String title, Map<String, String> map) {
        this.context = context;
        this.title = title;
        this.map = map;
        return this;
    }

    public ActionInputTransData setInputLine1(String prompt, EInputType inputType, int maxLen, boolean isVoidLastTrans) {
        return setInputLine1(prompt, inputType, maxLen, 0, isVoidLastTrans);
    }

    public ActionInputTransData setInputLine1(String prompt, EInputType inputType, int maxLen, int minLen,
                                              boolean isVoidLastTrans) {
        this.prompt1 = prompt;
        this.inputType1 = inputType;
        this.maxLen1 = maxLen;
        this.minLen1 = minLen;
        this.isVoidLastTrans = isVoidLastTrans;
        return this;
    }

    public ActionInputTransData setInputLine1(String prompt, EInputType inputType, int maxLen, int minLen,
                                              boolean isVoidLastTrans, boolean isAuthZero) {
        this.prompt1 = prompt;
        this.inputType1 = inputType;
        this.maxLen1 = maxLen;
        this.minLen1 = minLen;
        this.isVoidLastTrans = isVoidLastTrans;
        this.isAuthZero = isAuthZero;
        return this;
    }

    public ActionInputTransData setInputLine2(String prompt, EInputType inputType, int maxLen) {
        return setInputLine2(prompt, inputType, maxLen, 0);
    }

    public ActionInputTransData setInputLine2(String prompt, EInputType inputType, int maxLen, int minLen) {
        this.prompt2 = prompt;
        this.inputType2 = inputType;
        this.maxLen2 = maxLen;
        this.minLen2 = minLen;
        return this;
    }

    @Override
    protected void process() {

        FinancialApplication.getApp().runOnUiThread(new ProcessRunnable());
    }

    private class ProcessRunnable implements Runnable {

        @Override
        public void run() {
            if (lineNum == 1) {
                if (inputType1 == EInputType.PHONE || inputType1 == EInputType.EMAIL) {
                    runPaperless();
                } else {
                    runStyle1();
                }
            } else if (lineNum == 2) {
                runStyle2();
            } else if (lineNum == 4) {
                runTipStyle();
            }
        }

        private void runPaperless() {
            Intent intent = new Intent(context, PaperlessActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString(EUIParamKeys.NAV_TITLE.toString(), title);
            bundle.putString(EUIParamKeys.PROMPT_1.toString(), prompt1);
            bundle.putSerializable(EUIParamKeys.INPUT_TYPE_1.toString(), inputType1);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }

        private void runStyle1() {
            Intent intent = new Intent(context, InputTransData1Activity.class);
            Bundle bundle = new Bundle();
            bundle.putString(EUIParamKeys.NAV_TITLE.toString(), title);
            bundle.putString(EUIParamKeys.PROMPT_1.toString(), prompt1);
            bundle.putInt(EUIParamKeys.INPUT_MAX_LEN_1.toString(), maxLen1);
            bundle.putInt(EUIParamKeys.INPUT_MIN_LEN_1.toString(), minLen1);
            bundle.putSerializable(EUIParamKeys.INPUT_TYPE_1.toString(), inputType1);
            bundle.putBoolean(EUIParamKeys.VOID_LAST_TRANS_UI.toString(), isVoidLastTrans);
            bundle.putBoolean(EUIParamKeys.INPUT_PADDING_ZERO.toString(), isAuthZero);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }

        private void runStyle2() {
            Intent intent = new Intent(context, InputTransData2Activity.class);
            Bundle bundle = new Bundle();
            bundle.putString(EUIParamKeys.NAV_TITLE.toString(), title);
            bundle.putBoolean(EUIParamKeys.NAV_BACK.toString(), true);
            bundle.putString(EUIParamKeys.PROMPT_1.toString(), prompt1);
            bundle.putInt(EUIParamKeys.INPUT_MAX_LEN_1.toString(), maxLen1);
            bundle.putInt(EUIParamKeys.INPUT_MIN_LEN_1.toString(), minLen1);
            bundle.putSerializable(EUIParamKeys.INPUT_TYPE_1.toString(), inputType1);
            bundle.putString(EUIParamKeys.PROMPT_2.toString(), prompt2);
            bundle.putInt(EUIParamKeys.INPUT_MAX_LEN_2.toString(), maxLen2);
            bundle.putInt(EUIParamKeys.INPUT_MIN_LEN_2.toString(), minLen2);
            bundle.putSerializable(EUIParamKeys.INPUT_TYPE_2.toString(), inputType2);
            intent.putExtras(bundle);
            context.startActivity(intent);
        }

        private void runTipStyle() {
            Intent intent = new Intent(context, InputTransDataTipActivity.class);
            Bundle bundle = new Bundle();
            bundle.putString(EUIParamKeys.NAV_TITLE.toString(), title);
            bundle.putBoolean(EUIParamKeys.NAV_BACK.toString(), true);
            if (map != null) {
                String totalAmount = map.get(context.getString(R.string.prompt_total_amount));
                String oriTips = map.get(context.getString(R.string.prompt_ori_tips));
                String adjustPercent = map.get(context.getString(R.string.prompt_adjust_percent));
                bundle.putString(EUIParamKeys.TRANS_AMOUNT.toString(), totalAmount);
                bundle.putString(EUIParamKeys.ORI_TIPS.toString(), oriTips);
                bundle.putFloat(EUIParamKeys.TIP_PERCENT.toString(), Float.valueOf(adjustPercent));
            }
            intent.putExtras(bundle);
            context.startActivity(intent);
        }
    }
}
