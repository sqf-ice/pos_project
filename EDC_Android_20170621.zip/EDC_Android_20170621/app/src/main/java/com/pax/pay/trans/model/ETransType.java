/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.model;

import com.pax.abl.core.ipacker.PackListener;
import com.pax.edc.R;
import com.pax.pay.trans.action.ActionSearchCard.SearchMode;
import com.pax.pay.trans.pack.PackBatchUp;
import com.pax.pay.trans.pack.PackBatchUpNotice;
import com.pax.pay.trans.pack.PackEcho;
import com.pax.pay.trans.pack.PackIso8583;
import com.pax.pay.trans.pack.PackOfflineBat;
import com.pax.pay.trans.pack.PackOfflineTransSend;
import com.pax.pay.trans.pack.PackPreAuth;
import com.pax.pay.trans.pack.PackRefund;
import com.pax.pay.trans.pack.PackReversal;
import com.pax.pay.trans.pack.PackSale;
import com.pax.pay.trans.pack.PackSaleVoid;
import com.pax.pay.trans.pack.PackSettle;
import com.pax.pay.utils.Utils;

public enum ETransType {
    /*
     * 管理类
     */

    /**
     * 回响功能
     */
    ECHO("0820", "", "", "",
            Utils.getString(R.string.trans_echo), (byte) 0x00,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackEcho(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }
    },
    SETTLE("0500", "", "920000", "",
            Utils.getString(R.string.trans_settle), (byte) 0x00,
            true, true, true, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackSettle(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },

    BATCH_UP("0320", "", "000001", "",
            Utils.getString(R.string.trans_batch_up), (byte) 0x00,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackBatchUp(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },
    REFUND_BAT("0320", "", "200000", "00",
            Utils.getString(R.string.trans_batch_up), (byte) 0x00,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackBatchUpNotice(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },
    SETTLE_END("0500", "", "960000", "",
            Utils.getString(R.string.trans_settle_end), (byte) 0x00,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackSettle(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },
    /************************************************
     * 交易类
     ****************************************************/

    SALE("0200", "0400", "000000", "00",
            Utils.getString(R.string.trans_sale), ETransType.READ_MODE_ALL,
            true, true, true, true, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackSale(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return new PackReversal(listener);
        }
    },

    /**********************************************************************************************************/
    VOID("0200", "0400", "020000", "00",
            Utils.getString(R.string.trans_void), ETransType.READ_MODE_ALL,
            true, true, false, false, true) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackSaleVoid(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return new PackReversal(listener);
        }

    },
    /**********************************************************************************************************/
    //AET-103
    REFUND("0200", "0400", "200000", "00",
            Utils.getString(R.string.trans_refund), (byte) (SearchMode.SWIPE | SearchMode.KEYIN),
            true, true, false, true, true) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackRefund(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            //AET-42
            return new PackReversal(listener);
        }

    },
    /**********************************************************************************************************/
    ADJUST("", "", "000000", "",
            Utils.getString(R.string.trans_adjust), (byte) 0x00,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return null;
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },
    /**********************************************************************************************************/
    PREAUTH("0100", "0400", "030000", "06",
            Utils.getString(R.string.trans_preAuth), ETransType.READ_MODE_ALL,
            true, true, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackPreAuth(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return new PackReversal(listener);
        }

    },

    READCARDNO("", "", "000000", "",
            Utils.getString(R.string.trans_readCard), ETransType.READ_MODE_ALL,
            false, false, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return null;
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }

    },
    /***************************************************************************************************************/
    OFFLINE_TRANS_SEND("0220", "", "000000", "00",
            Utils.getString(R.string.trans_offline_send), (byte) (SearchMode.SWIPE | SearchMode.KEYIN),
            true, true, true, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackOfflineTransSend(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }
    },
    /***************************************************************************************************************/
    OFFLINE_TRANS_SEND_BAT("0220", "", "000000", "00",
            Utils.getString(R.string.trans_offline_send_bat), (byte) 0x00,
            true, true, false, false, false) {
        @Override
        public PackIso8583 getPackager(PackListener listener) {
            return new PackOfflineBat(listener);
        }

        @Override
        public PackIso8583 getDupPackager(PackListener listener) {
            return null;
        }
    },;

    private static final byte READ_MODE_ALL = (byte) (SearchMode.SWIPE | SearchMode.INSERT | SearchMode.WAVE | SearchMode.KEYIN);

    private String msgType;
    private String dupMsgType;
    private String procCode;
    private String serviceCode;
    private String transName;
    private byte readMode;
    private boolean isDupSendAllowed;
    private boolean isScriptSendAllowed;
    private boolean isAdjustAllowed;
    private boolean isVoidAllowed;
    private boolean isSymbolNegative;

    /**
     * @param msgType             ：消息类型码
     * @param dupMsgType          : 冲正消息类型码
     * @param procCode            : 处理码
     * @param serviceCode         ：服务码
     * @param readMode            : read mode
     * @param transName           : 交易名称
     * @param isDupSendAllowed    ：是否冲正上送
     * @param isScriptSendAllowed ：是否脚本结果上送
     * @param isAdjustAllowed     ：is allowed to adjust
     * @param isVoidAllowed       : is allowed to void
     * @param isSymbolNegative    : is symbol negative
     */
    ETransType(String msgType, String dupMsgType, String procCode, String serviceCode,
               String transName, byte readMode, boolean isDupSendAllowed, boolean isScriptSendAllowed,
               boolean isAdjustAllowed, boolean isVoidAllowed, boolean isSymbolNegative) {
        this.msgType = msgType;
        this.dupMsgType = dupMsgType;
        this.procCode = procCode;
        this.serviceCode = serviceCode;
        this.transName = transName;
        this.readMode = readMode;
        this.isDupSendAllowed = isDupSendAllowed;
        this.isScriptSendAllowed = isScriptSendAllowed;
        this.isAdjustAllowed = isAdjustAllowed;
        this.isVoidAllowed = isVoidAllowed;
        this.isSymbolNegative = isSymbolNegative;
    }

    public String getMsgType() {
        return msgType;
    }

    public String getDupMsgType() {
        return dupMsgType;
    }

    public String getProcCode() {
        return procCode;
    }

    public String getServiceCode() {
        return serviceCode;
    }

    public String getTransName() {
        return transName;
    }

    public byte getReadMode() {
        return readMode;
    }

    public boolean isDupSendAllowed() {
        return isDupSendAllowed;
    }

    public boolean isScriptSendAllowed() {
        return isScriptSendAllowed;
    }

    public boolean isAdjustAllowed() {
        return isAdjustAllowed;
    }

    public boolean isVoidAllowed() {
        return isVoidAllowed;
    }

    public boolean isSymbolNegative() {
        return isSymbolNegative;
    }

    public abstract PackIso8583 getPackager(PackListener listener);

    public abstract PackIso8583 getDupPackager(PackListener listener);
}