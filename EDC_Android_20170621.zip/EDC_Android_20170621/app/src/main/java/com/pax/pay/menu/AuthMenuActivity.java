/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-26
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.menu;

import com.pax.edc.R;
import com.pax.pay.trans.PreAuthTrans;
import com.pax.view.MenuPage;

public class AuthMenuActivity extends BaseMenuActivity {

    /**
     * 预授权，
     */
    public MenuPage createMenuPage() {

        MenuPage.Builder builder = new MenuPage.Builder(AuthMenuActivity.this, 3, 3)
                .addTransItem(getString(R.string.trans_preAuth), R.drawable.app_auth,
                        new PreAuthTrans(AuthMenuActivity.this, true, null));
        return builder.create();
    }
}
