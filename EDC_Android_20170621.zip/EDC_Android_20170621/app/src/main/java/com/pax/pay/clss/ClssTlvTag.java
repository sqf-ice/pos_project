/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-3-16
 * Module Author: laiyi
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

class ClssTlvTag {
    static final byte[] APP_VER = new byte[]{(byte) 0x9F, (byte) 0x09};

    static final byte[] CARD_DATA = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x17};
    static final byte[] CVM_REQ = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x18};
    static final byte[] CVM_NO = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x19};
    static final byte[] DEF_UDOL = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x1F};
    static final byte[] SEC = new byte[]{(byte) 0xDF, (byte) 0x81, 0x1A};
    static final byte[] MAG_CVM_REQ = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x1E};
    static final byte[] MAG_CVM_NO = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x2C};

    static final byte[] AMOUNT = new byte[]{(byte) 0x9F, (byte) 0x02};
    static final byte[] AMOUNT_OTHER = new byte[]{(byte) 0x9F, (byte) 0x03};

    static final byte[] TRANS_TYPE = new byte[]{(byte) 0x9C};
    static final byte[] TRANS_DATE = new byte[]{(byte) 0x9A};
    static final byte[] TRANS_TIME = new byte[]{(byte) 0x9F, (byte) 0x21};

    //TAC Online
    static final byte[] TERM_DEFAULT = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x20};
    static final byte[] TERM_DENIAL = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x21};
    static final byte[] TERM_ONLINE = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x22};

    //limit  set for AID
    static final byte[] FLOOR_LIMIT = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x23};
    static final byte[] TRANS_LIMIT = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x24};
    static final byte[] TRANS_CVM_LIMIT = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x25};
    static final byte[] CVM_LIMIT = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x26};

    static final byte[] MAX_TORN = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x1D};

    static final byte[] COUNTRY_CODE = new byte[]{(byte) 0x9F, (byte) 0x1A};
    static final byte[] CURRENCY_CODE = new byte[]{(byte) 0x5F, (byte) 0x2A};

    static final byte[] KERNEL_CFG = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x1B};

    static final byte[] CAPK_ID = new byte[]{(byte) 0x8F};
    static final byte[] CAPK_RID = new byte[]{(byte) 0x4F};

    static final byte[] PRO_ID = new byte[]{(byte) 0x9F, (byte) 0x5A};

    static final byte[] TRACK1 = new byte[]{(byte) 0x56};
    static final byte[] TRACK2 = new byte[]{(byte) 0x57};
    static final byte[] TRACK2_1 = new byte[]{(byte) 0x9F, 0x6B};

    static final byte[] PAN_SEQ_NO = new byte[]{(byte) 0x5F, (byte) 0x34};
    static final byte[] APP_LABEL = new byte[]{(byte) 0x50};
    static final byte[] TVR = new byte[]{(byte) 0x95};
    static final byte[] TSI = new byte[]{(byte) 0x9B};
    static final byte[] ATC = new byte[]{(byte) 0x9F, (byte) 0x36};
    static final byte[] APP_CRYPTO = new byte[]{(byte) 0x9F, (byte) 0x26};
    static final byte[] APP_NAME = new byte[]{(byte) 0x9F, (byte) 0x12};

    static final byte[] LIST = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x29};

    static final byte[] CRYPTO = new byte[]{(byte) 0x9F, (byte) 0x27};

    static final byte[] ACCOUNT_TYPE = new byte[]{0x5F, 0x57, 0x00};
    static final byte[] ACQUIRER_ID = new byte[]{(byte) 0x9F, 0x01, 0x00};
    static final byte[] INTER_DEV_NUM = new byte[]{(byte) 0x9F, 0x1E, 0x08, 0x11, 0x22, 0x33, 0x44, 0x55, 0x66, 0x77, (byte) 0x88};
    static final byte[] MERCHANT_CATEGORY_CODE = new byte[]{(byte) 0x9F, 0x15, 0x02, 0x00, 0x01};
    static final byte[] MERCHANT_ID = new byte[]{(byte) 0x9F, 0x16, 0x00};
    static final byte[] MERCHANT_NAME_LOCATION = new byte[]{(byte) 0x9F, 0x4E, 0x00};
    static final byte[] TERMINAL_CAPABILITY = new byte[]{(byte) 0x9F, 0x33, 0x00};
    static final byte[] TERMINAL_ID = new byte[]{(byte) 0x9F, 0x1C, 0x00};

    static final byte[] BALANCE_BEFORE_GAC = new byte[]{(byte) 0xDF, (byte) 0x81, 0x04};
    static final byte[] BALANCE_AFTER_GAC = new byte[]{(byte) 0xDF, (byte) 0x81, 0x05};
    static final byte[] MESS_HOLD_TIME = new byte[]{(byte) 0xDF, (byte) 0x81, 0x2D};
    static final byte[] MOB_SUP = new byte[]{(byte) 0x9F, 0x7E, 0x00};

    static final byte[] DS_AC_TYPE = new byte[]{(byte) 0xDF, (byte) 0x81, 0x08, 0x00};
    static final byte[] DS_INPUT_CARD = new byte[]{(byte) 0xDF, 0x60, 0x00};
    static final byte[] DS_INPUT_TERMINAL = new byte[]{(byte) 0xDF, (byte) 0x81, 0x09, 0x00};
    static final byte[] DS_ODS_INFO = new byte[]{(byte) 0xDF, 0x62, 0x00};
    static final byte[] DS_ODS_READER = new byte[]{(byte) 0xDF, (byte) 0x81, 0x0A, 0x00};
    static final byte[] DS_ODS_TERMINAL = new byte[]{(byte) 0xDF, 0x63, 0x00};

    static final byte[] FST_WRITE = new byte[]{(byte) 0xDF, (byte) 0x81, 0x10};
    static final byte[] READ = new byte[]{(byte) 0xDF, (byte) 0x81, 0x12};
    static final byte[] WIRTE_BEFORE_AC = new byte[]{(byte) 0xFF, (byte) 0x81, 0x02};
    static final byte[] WIRTE_AFTER_AC = new byte[]{(byte) 0xFF, (byte) 0x81, 0x03};
    static final byte[] TIMEOUT = new byte[]{(byte) 0xDF, (byte) 0x81, 0x27};

    static final byte[] ADDITIONAL_CAPABILITY = new byte[]{(byte) 0x9F, 0x40};
    static final byte[] DS_OPERATOR_ID = new byte[]{(byte) 0x9F, (byte) 0x5C};

    private ClssTlvTag() {

    }
}

