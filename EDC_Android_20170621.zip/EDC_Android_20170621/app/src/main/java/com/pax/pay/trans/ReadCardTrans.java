/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans;

import android.content.Context;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.eemv.enums.ETransResult;
import com.pax.pay.trans.action.ActionEmvProcess;
import com.pax.pay.trans.action.ActionSearchCard;
import com.pax.pay.trans.action.ActionSearchCard.CardInformation;
import com.pax.pay.trans.action.ActionSearchCard.SearchMode;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.ETransType;

public class ReadCardTrans extends BaseTrans {

    public ReadCardTrans(Context context, TransEndListener transListener) {
        super(context, ETransType.READCARDNO, transListener);
    }

    @Override
    protected void bindStateOnAction() {
        // search card
        ActionSearchCard searchCardAction = new ActionSearchCard(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionSearchCard) action).setParam(getCurrentContext(), getString(R.string.trans_readCard),
                        Component.getCardReadMode(ETransType.READCARDNO), null, null, "");
            }
        });
        bind(State.CHECK_CARD.toString(), searchCardAction, true);

        // EMV
        ActionEmvProcess emvProcessAction = new ActionEmvProcess(new AAction.ActionStartListener() {

            @Override
            public void onStart(AAction action) {
                ((ActionEmvProcess) action).setParam(getCurrentContext(), emv, transData);
            }
        });
        bind(State.EMV_PROC.toString(), emvProcessAction, true);

        gotoState(State.CHECK_CARD.toString());

    }

    enum State {
        CHECK_CARD,
        EMV_PROC,
    }

    @Override
    public void onActionResult(String currentState, ActionResult result) {
        State state = State.valueOf(currentState);
        switch (state) {
            case CHECK_CARD: // 检测卡的后续处理
                onCheckCard(result);
                break;
            case EMV_PROC: // emv后续处理
                onEmvProc(result);
                break;
            default:
                transEnd(result);
                break;
        }

    }

    private void onCheckCard(ActionResult result) {
        CardInformation cardInfo = (CardInformation) result.getData();
        saveCardInfo(cardInfo, transData);
        byte mode = cardInfo.getSearchMode();
        if (mode == SearchMode.SWIPE) {
            transEnd(new ActionResult(TransResult.SUCC, cardInfo));
        } else if (mode == SearchMode.INSERT || mode == SearchMode.WAVE) {
            // EMV处理
            gotoState(State.EMV_PROC.toString());
        }
    }

    private void onEmvProc(ActionResult result) {
        ETransResult transResult = (ETransResult) result.getData();
        Component.emvTransResultProcess(transResult, emv, transData);

        CardInformation sResult = new CardInformation(transData.getPan());
        transEnd(new ActionResult(TransResult.SUCC, sResult));
    }
}
