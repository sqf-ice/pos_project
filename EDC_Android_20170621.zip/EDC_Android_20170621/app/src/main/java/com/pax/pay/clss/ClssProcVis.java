/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-4-20
 * Module Author: linhb
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import android.util.Log;

import com.pax.device.DeviceImplNeptune;
import com.pax.edc.R;
import com.pax.eemv.EmvImpl;
import com.pax.eventbus.SearchCardEvent;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.jemv.clcommon.ACType;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.Clss_PreProcInfo;
import com.pax.jemv.clcommon.Clss_ProgramID;
import com.pax.jemv.clcommon.Clss_ReaderParam;
import com.pax.jemv.clcommon.Clss_VisaAidParam;
import com.pax.jemv.clcommon.CvmType;
import com.pax.jemv.clcommon.DDAFlag;
import com.pax.jemv.clcommon.EMV_CAPK;
import com.pax.jemv.clcommon.EMV_REVOCLIST;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.clcommon.TransactionPath;
import com.pax.jemv.device.model.ApduRespL2;
import com.pax.jemv.device.model.ApduSendL2;
import com.pax.jemv.entrypoint.api.ClssEntryApi;
import com.pax.jemv.paywave.api.ClssWaveApi;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.utils.CountryCode;
import com.pax.pay.utils.Utils;

import java.util.Arrays;

class ClssProcVis extends ClssProc {

    private Clss_PreProcInfo clssPreProcInfo;
    private Clss_ReaderParam clssReaderParam;
    private String track2;

    static {
        System.loadLibrary("JniWave_V1.00.00_20170616");
        System.loadLibrary("F_WAVE_LIB_Android");
    }

    ClssProcVis() {
        super();
    }

    private int init(TransData transData) {
        int ret = ClssWaveApi.Clss_CoreInit_Wave();
        Log.i("clssWaveCoreInit", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        ret = ClssWaveApi.Clss_SetFinalSelectData_Wave(finalSelectData, finalSelectDataLen);
        Log.i("WaveSetFinalSelectData", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        clssReaderParam = new Clss_ReaderParam();
        ret = ClssWaveApi.Clss_GetReaderParam_Wave(clssReaderParam);
        Log.i("WaveGetReaderParam", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        clssReaderParam = toClssReaderParam(transData);
        return ClssWaveApi.Clss_SetReaderParam_Wave(clssReaderParam);
    }

    private int setTransParam() {
        int ret = ClssWaveApi.Clss_SetVisaAidParam_Wave(getClssVisaAidParam());
        Log.i("clssWaveSetVisaAidParam", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        //FIXME
        String string = "123";
        ret = ClssWaveApi.Clss_SetTLVData_Wave((short) 0x9F5A, string.getBytes(), 3);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }
        ByteArray proID = new ByteArray();
        ret = getClssTlv(ClssTlvTag.PRO_ID, proID);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        for (Clss_PreProcInfo i : mClssPreProcInfo) {
            if (Arrays.equals(aid, i.aucAID)) {
                clssPreProcInfo = i;
                break;
            }
        }

        if (clssPreProcInfo != null) {
            Clss_ProgramID clssProgramID = new Clss_ProgramID(clssPreProcInfo.ulRdClssTxnLmt, clssPreProcInfo.ulRdCVMLmt,
                    clssPreProcInfo.ulRdClssFLmt, clssPreProcInfo.ulTermFLmt, proID.data, (byte) proID.length,
                    clssPreProcInfo.ucRdClssFLmtFlg, clssPreProcInfo.ucRdClssTxnLmtFlg, clssPreProcInfo.ucRdCVMLmtFlg,
                    clssPreProcInfo.ucTermFLmtFlg, clssPreProcInfo.ucStatusCheckFlg, (byte) 0, new byte[4]);
            ret = ClssWaveApi.Clss_SetDRLParam_Wave(clssProgramID);
            Log.i("clssWaveSetDRLParam", "ret = " + ret);
            if (ret != RetCode.EMV_OK) {
                return ret;
            }
        }

        ClssWaveApi.Clss_SetTLVData_Wave((short) 0x9c, new byte[]{clssTransParam.ucTransType}, 1);
        ret = ClssWaveApi.Clss_SetTransData_Wave(clssTransParam, clssPreProcInterInfo);
        Log.i("clssWaveSetTransData", "ret = " + ret);
        return ret;
    }

    private int processMSD(TransData transData) {
        byte msdType = ClssWaveApi.Clss_GetMSDType_Wave();
        Log.i("clssWaveGetMSDType", "msdType = " + msdType);
        //get MSD track 2 data
        ByteArray waveGetTrack2List = new ByteArray();
        int ret = ClssWaveApi.Clss_nGetTrack2MapData_Wave(waveGetTrack2List);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }
        track2 = FinancialApplication.getConvert().bcdToStr(waveGetTrack2List.data).substring(0, 2 * waveGetTrack2List.length).split("F")[0];
        transData.setTrack2(track2);
        return RetCode.EMV_OK;
    }

    private int processQVSDC(TransData transData, ACType acType, CTransResult result) {
        int ret = ClssWaveApi.Clss_ProcRestric_Wave();
        Log.i("clssWaveProcRestric", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        if ((acType.type == com.pax.jemv.clcommon.ACType.AC_TC)
                && (!transData.getTransType().equals(ETransType.REFUND))) {

            // TODO: Exception file check

            //according to EDC
            ClssWaveApi.Clss_DelAllRevocList_Wave();
            ClssWaveApi.Clss_DelAllCAPK_Wave();
            addCapkRevList();

            DDAFlag flag = new DDAFlag();
            ret = ClssWaveApi.Clss_CardAuth_Wave(acType, flag);
            Log.i("clssWaveCardAuth", "ret = " + ret);
            if (ret != RetCode.EMV_OK) {
                result.setTransResult(ret);
                return ret;
            } else if (acType.type == com.pax.jemv.clcommon.ACType.AC_AAC) {
                result.setTransResult(OutcomeParam.CLSS_OC_DECLINED);
                return -1;
            } else if (flag.flag == DDAFlag.FAIL) {
                result.setTransResult(RetCode.CLSS_TERMINATE);
                return -1;
            }
        }
        return RetCode.EMV_OK;
    }

    private int processWAVE2(ACType acType, CTransResult result) {
        // TODO: Exception file check
        result.setTransResult(OutcomeParam.CLSS_OC_APPROVED);
        //according to EDC
        ClssWaveApi.Clss_DelAllRevocList_Wave();
        ClssWaveApi.Clss_DelAllCAPK_Wave();
        addCapkRevList();

        DDAFlag flag = new DDAFlag();
        int ret = ClssWaveApi.Clss_CardAuth_Wave(acType, flag);
        Log.i("clssWaveCardAuth", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return ret;
        } else if (acType.type == com.pax.jemv.clcommon.ACType.AC_AAC) {
            result.setTransResult(OutcomeParam.CLSS_OC_DECLINED);
            return -1;
        } else if (flag.flag == DDAFlag.FAIL) {
            result.setTransResult(RetCode.CLSS_TERMINATE);
            return -1;
        }
        return RetCode.EMV_OK;
    }

    private boolean continueUpdateResult(TransData transData, ACType acType, CTransResult result) {
        if (acType.type == com.pax.jemv.clcommon.ACType.AC_AAC) {
            result.setTransResult(OutcomeParam.CLSS_OC_DECLINED);
            return false;
        }

        int ret;
        if (transactionPath.path == TransactionPath.CLSS_VISA_MSD
                || transactionPath.path == TransactionPath.CLSS_VISA_MSD_CVN17
                || transactionPath.path == TransactionPath.CLSS_VISA_MSD_LEGACY) {

            if (transactionPath.path == TransactionPath.CLSS_VISA_MSD) {
                ret = processMSD(transData);
                if (ret != RetCode.EMV_OK) {
                    result.setTransResult(ret);
                    return false;
                }
            }
        } else if (transactionPath.path == TransactionPath.CLSS_VISA_QVSDC) {
            if (processQVSDC(transData, acType, result) != RetCode.EMV_OK) {
                return false;
            }
        } else if (transactionPath.path == TransactionPath.CLSS_VISA_WAVE2
                && acType.type == com.pax.jemv.clcommon.ACType.AC_TC) {
            if (processWAVE2(acType, result) != RetCode.EMV_OK) {
                return false;
            }
        } else {
            result.setTransResult(RetCode.CLSS_TERMINATE);
            return false;
        }

        if (acType.type == ACType.AC_TC) {
            result.setTransResult(OutcomeParam.CLSS_OC_APPROVED);
        } else if (acType.type == ACType.AC_ARQC) {
            result.setTransResult(OutcomeParam.CLSS_OC_ONLINE_REQUEST);
        }
        return true;
    }

    @Override
    protected CTransResult process(TransData transData, TransProcessListener transProcessListener) {
        CTransResult result = new CTransResult();
        int ret = init(transData);
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        ret = setTransParam();
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        ACType acType = new ACType();
        ret = ClssWaveApi.Clss_Proctrans_Wave(transactionPath, acType);    // output parameter?
        Log.i("clssWaveProcTrans", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            if (ret == RetCode.CLSS_REFER_CONSUMER_DEVICE
                    && clssPreProcInfo != null && (clssPreProcInfo.aucReaderTTQ[0] & 0x20) == 0x20) {
                ret = OutcomeParam.CLSS_OC_TRY_AGAIN;
            }
            result.setTransResult(ret);
            return result;
        }
        Log.i("clssWaveProcTrans", "TransPath = " + transactionPath.path + ", ACType = " + acType.type);

        FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.CLSS_LIGHT_STATUS_REMOVE_CARD));

        if (transProcessListener != null) {
            transProcessListener.onHideProgress();
            transProcessListener.onShowNormalMessageWithConfirm(Utils.getString(R.string.wait_remove_card),
                    Constants.SUCCESS_DIALOG_SHOW_TIME);
        }

        if (!continueUpdateResult(transData, acType, result)) {
            return result;
        }

        byte cvmType = ClssWaveApi.Clss_GetCvmType_Wave();
        Log.i("clssWaveGetCvmType", "CVMType = " + cvmType);
        result.setCvmResult(cvmType);

        transData.setClssResult(result.getTransResult());
        return result;
    }

    private Clss_ReaderParam toClssReaderParam(TransData transData) {
        clssReaderParam.aucTmCap = new byte[]{(byte) 0xE0, (byte) 0xE1, (byte) 0xC8};
        clssReaderParam.aucTmCapAd = new byte[]{(byte) 0xE0, (byte) 0x00, (byte) 0xF0, (byte) 0xA0, (byte) 0x01};
        clssReaderParam.ucTmType = 0x22;
        int code = CountryCode.getByCode(transData.getCurrency().getCountry()).getNumeric();
        clssReaderParam.aucTmCntrCode = FinancialApplication.getConvert().strToBcd(String.valueOf(code), EPaddingPosition.PADDING_LEFT);
        code = CountryCode.getByCode(transData.getCurrency().getCountry()).getCurrencyNumeric();
        clssReaderParam.aucTmRefCurCode = FinancialApplication.getConvert().strToBcd(String.valueOf(code), EPaddingPosition.PADDING_LEFT);
        clssReaderParam.aucTmTransCur = FinancialApplication.getConvert().strToBcd(String.valueOf(code), EPaddingPosition.PADDING_LEFT);
        return clssReaderParam;
    }

    private Clss_VisaAidParam getClssVisaAidParam() {
        byte[] cvmReq = new byte[2];
        cvmReq[0] = CvmType.RD_CVM_REQ_SIG;
        cvmReq[1] = CvmType.RD_CVM_REQ_ONLINE_PIN;
        return new Clss_VisaAidParam(10000, (byte) 0, (byte) 2, cvmReq, (byte) 0);
    }

    @Override
    protected void setDetData(byte[] tag, byte[] data) {
        if (tag.length > 2) {
            return;
        }
        short waveTag = tag.length == 2 ? (short) ((tag[1] & 0xFF) | ((tag[0] & 0xFF) << 8)) : (short) (tag[0] & 0xFF);
        ClssWaveApi.Clss_SetTLVData_Wave(waveTag, data, data.length);
    }

    @Override
    protected int getClssTlv(byte[] tag, ByteArray list) {
        int ret;
        if (tag.length > 2) {
            ret = RetCode.CLSS_PARAM_ERR;
        } else {
            short waveTag = tag.length == 2 ? (short) ((tag[1] & 0xFF) | ((tag[0] & 0xFF) << 8)) : (short) (tag[0] & 0xFF);
            ret = ClssWaveApi.Clss_GetTLVData_Wave(waveTag, list);
        }
        return ret;
    }

    @Override
    protected void onAddCapkRevList(EMV_CAPK emvCapk, EMV_REVOCLIST emvRevoclist) {
        ClssWaveApi.Clss_AddCAPK_Wave(emvCapk);
        ClssWaveApi.Clss_AddRevocList_Wave(emvRevoclist);
        Log.i("ClssProc", "set VISA capk and revoclist");
    }

    @Override
    protected void setTrack2(TransData transData) {
        //track1
        ByteArray waveGetTrack1List = new ByteArray();
        ClssWaveApi.Clss_nGetTrack1MapData_Wave(waveGetTrack1List);
        String track1 = FinancialApplication.getConvert().bcdToStr(waveGetTrack1List.data);
        transData.setTrack1(track1.substring(0, 2 * waveGetTrack1List.length));
        //track2
        if (track2 == null) {
            ByteArray waveGetTrack2List = new ByteArray();
            getClssTlv(ClssTlvTag.TRACK2, waveGetTrack2List);
            track2 = FinancialApplication.getConvert().bcdToStr(waveGetTrack2List.data).substring(0, 2 * waveGetTrack2List.length).split("F")[0];
            transData.setTrack2(track2);
        }
    }

    @Override
    protected void completeTrans(TransData transData) {
        // 脚本结果处理
        String iCCData = transData.getRecvIccData();
        if (iCCData != null && !iCCData.isEmpty()) {
            issScrCon(transData);
        }

        //get and save Issuer Authentication Data
        ByteArray issuScript91 = new ByteArray();
        int ret = ClssWaveApi.Clss_GetTLVData_Wave((short) 0x91, issuScript91);
        if (ret == RetCode.EMV_OK && issuScript91.length > 0) {
            iAuthDataLen = Math.min(issuScript91.length, 16);
            System.arraycopy(issuScript91.data, 0, aucAuthData, 0, iAuthDataLen);
            Log.i("saveRspICCData", "aucAuthData = " + aucAuthData + "iAuthDataLen = " + iAuthDataLen);
        }
        //get and save Issuer script
        ByteArray issuScript71 = new ByteArray();
        ByteArray issuScript72 = new ByteArray();
        ClssWaveApi.Clss_GetTLVData_Wave((short) 0x71, issuScript71);
        ClssWaveApi.Clss_GetTLVData_Wave((short) 0x72, issuScript72);
        ByteArray issuScript = EmvImpl.combine917172(null, issuScript71, issuScript72);
        if (issuScript.length > 0) {
            iScriptLen = issuScript.length;
            System.arraycopy(issuScript.data, 0, aucIssuerScript, 0, iScriptLen);
            Log.i("saveRspICCData", "aucIssuerScript = " + aucIssuerScript + "iScriptLen = " + iScriptLen);
        }

        clssCompleteTrans();
    }

    private int issScrCon(TransData transData) {
        ApduSendL2 apduSendL2 = new ApduSendL2();
        ApduRespL2 apduRespL2 = new ApduRespL2();
        byte[] sendCommand = new byte[]{(byte) 0x00, (byte) 0xA4, (byte) 0x04, (byte) 0x00};
        System.arraycopy(sendCommand, 0, apduSendL2.command, 0, sendCommand.length);
        apduSendL2.lc = 14;
        String sendDataIn = "1PAY.SYS.DDF01";
        System.arraycopy(sendDataIn.getBytes(), 0, apduSendL2.dataIn, 0, sendDataIn.getBytes().length);
        apduSendL2.le = 256;
        int ret = (int) DeviceImplNeptune.getInstance().iccCommand(apduSendL2, apduRespL2);
        if (ret != RetCode.EMV_OK)
            return ret;

        if (apduRespL2.swa != (byte) 0x90 || apduRespL2.swb != 0x00)
            return ret;

        apduSendL2 = new ApduSendL2();
        apduRespL2 = new ApduRespL2();
        System.arraycopy(sendCommand, 0, apduSendL2.command, 0, sendCommand.length);
        apduSendL2.lc = 14;
        System.arraycopy(transData.getAid().getBytes(), 0, apduSendL2.dataIn, 0, transData.getAid().getBytes().length);
        apduSendL2.le = 256;
        ret = (int) DeviceImplNeptune.getInstance().iccCommand(apduSendL2, apduRespL2);
        if (ret != RetCode.EMV_OK)
            return ret;

        if (apduRespL2.swa != (byte) 0x90 || apduRespL2.swb != 0x00)
            return ret;

        ByteArray iccData = new ByteArray();
        iccData.length = transData.getRecvIccData().getBytes().length;
        System.arraycopy(transData.getRecvIccData().getBytes(), 0, iccData.data, 0, iccData.length);

        ByteArray issuScript91 = new ByteArray();
        ByteArray issuScript71 = new ByteArray();
        ByteArray issuScript72 = new ByteArray();
        ClssWaveApi.Clss_GetTLVData_Wave((short) 0x91, issuScript91);
        ClssWaveApi.Clss_GetTLVData_Wave((short) 0x71, issuScript71);
        ClssWaveApi.Clss_GetTLVData_Wave((short) 0x72, issuScript72);
        ByteArray script = EmvImpl.combine917172(issuScript91, issuScript71, issuScript72);

        ret = ClssWaveApi.Clss_IssScriptProc_Wave(script.data, script.length);
        return ret;
    }

    private int clssCompleteTrans() {
        ByteArray aucCTQ = new ByteArray();
        KernType kernType = new KernType();
        ByteArray sltData = new ByteArray();

        if (iAuthDataLen == 0 && iScriptLen == 0) {
            return RetCode.EMV_NO_DATA;
        }

        int ret = ClssWaveApi.Clss_GetTLVData_Wave((short) 0x9F6C, aucCTQ);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        if ((clssPreProcInfo.aucReaderTTQ[2] & 0x80) == 0x80 && (aucCTQ.data[1] & 0x40) != 0x40) {
            ret = ClssEntryApi.Clss_FinalSelect_Entry(kernType, sltData);
            Log.i("Clss_FinalSelect_Entry", "ret = " + ret);
            if (ret != RetCode.EMV_OK) {
                return ret;
            }

            ret = ClssWaveApi.Clss_IssuerAuth_Wave(aucAuthData, iAuthDataLen);
            Log.i("clssWaveIssuerAuth", "ret = " + ret);
            if (ret != RetCode.EMV_OK) {
                return ret;
            }

            ret = ClssWaveApi.Clss_IssScriptProc_Wave(aucIssuerScript, iScriptLen);
            Log.i("clssWaveIssScriptProc", "ret = " + ret);
            if (ret != RetCode.EMV_OK) {
                return ret;
            }
        }

        return RetCode.EMV_OK;
    }

    @Override
    protected void handleTccSpecialCase(CTransResult result, TransData transData, ByteArray f55DataArray) {
        //do nothing
    }
}
