/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-4-20
 * Module Author: linhb
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.jemv.clcommon.ACType;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.CLSS_TORN_LOG_RECORD;
import com.pax.jemv.clcommon.Clss_PreProcInfo;
import com.pax.jemv.clcommon.Clss_TransParam;
import com.pax.jemv.clcommon.CvmType;
import com.pax.jemv.clcommon.EMV_CAPK;
import com.pax.jemv.clcommon.EMV_REVOCLIST;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.clcommon.TransactionPath;
import com.pax.jemv.device.model.ApduRespL2;
import com.pax.jemv.device.model.ApduSendL2;
import com.pax.jemv.paypass.api.ClssPassApi;
import com.pax.jemv.paypass.listener.ClssPassCBFunApi;
import com.pax.jemv.paypass.listener.IClssPassCBFun;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.emv.EmvAid;
import com.pax.pay.emv.EmvTestAID;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.utils.CountryCode;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.Utils;

import java.util.ArrayList;
import java.util.List;

import static com.pax.glwrapper.convert.IConvert.EPaddingPosition;

class ClssProcMc extends ClssProc {

    private static final byte[] ERR_INDICATION = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x15};
    private static final byte[] USER_INTER_REQ = new byte[]{(byte) 0xDF, (byte) 0x81, (byte) 0x16};
    private ClssPassListener clssPassListener = new ClssPassListener();
    private ClssPassCBFunApi passCBFun = ClssPassCBFunApi.getInstance();

    static {
        System.loadLibrary("JniMC_V1.00.00_20170616");
        System.loadLibrary("F_MC_LIB_Android");
    }

    ClssProcMc() {
        super();
    }

    private int init() {
        int ret = ClssPassApi.Clss_CoreInit_MC((byte) 0x01);
        Log.i(TAG, "Clss_CoreInit_MC = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        ret = ClssPassApi.Clss_SetParam_MC(new byte[]{0x01, 0x01, 0x04}, 3);
        Log.i(TAG, "Clss_SetParam_MC = " + ret);

        passCBFun.setICBFun(clssPassListener);
        ret = ClssPassApi.Clss_SetCBFun_SendTransDataOutput_MC();
        Log.i(TAG, "Clss_SetCBFun_SendTransDataOutput_MC = " + ret);
        ret = ClssPassApi.Clss_SetFinalSelectData_MC(finalSelectData, finalSelectDataLen);
        Log.i(TAG, "Clss_SetFinalSelectData_MC = " + ret);
        return ret;
    }

    private int selectApp() {
        String id = FinancialApplication.getConvert().bcdToStr(aid);
        Log.i(TAG, "aid :" + id);
        EmvAid aid = FinancialApplication.getEmvDbHelper().findAID(id);
        if (aid == null) {
            return RetCode.EMV_NO_APP;
        }
        for (Clss_PreProcInfo info : mClssPreProcInfo) {
            if (info != null && FinancialApplication.getConvert().bcdToStr(info.aucAID).equals(id))
                setMcTermParam(clssTransParam, aid, info);
        }

        int ret = ClssPassApi.Clss_InitiateApp_MC();
        Log.i(TAG, "Clss_InitiateApp_MC = " + ret);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        ret = ClssPassApi.Clss_ReadData_MC(transactionPath);    // PathTypeOut
        Log.i(TAG, "Clss_ReadData_MC = " + ret);
        return ret;
    }

    private int processMChip(ACType acType) {
        ClssPassApi.Clss_DelAllRevocList_MC_MChip();
        ClssPassApi.Clss_DelAllCAPK_MC_MChip();
        addCapkRevList();

        List<ClssTornLog> logList = FinancialApplication.getTornLogDbHelper().findAllTornLog();
        if (!logList.isEmpty()) {
            int tornSum = logList.size();
            Log.i(TAG, "ClssTornLog = " + tornSum);
            CLSS_TORN_LOG_RECORD[] records = new CLSS_TORN_LOG_RECORD[tornSum];
            for (int i = 0; i < tornSum; ++i) {
                records[i] = logList.get(i).parse();
            }
            ClssPassApi.Clss_SetTornLog_MC_MChip(records, tornSum);
        }

        int ret = ClssPassApi.Clss_TransProc_MC_MChip(acType);
        Log.i(TAG, "Clss_TransProc_MC_MChip = " + ret + "  ACType = " + acType.type);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        CLSS_TORN_LOG_RECORD[] records = new CLSS_TORN_LOG_RECORD[5];
        int[] updateFlg = new int[2];
        ret = ClssPassApi.Clss_GetTornLog_MC_MChip(records, updateFlg);
        Log.i(TAG, "Clss_GetTornLog_MC_MChip = " + ret);
        if (ret == RetCode.EMV_OK && updateFlg[1] == 1) {
            FinancialApplication.getTornLogDbHelper().deleteAllTornLog();
            List<ClssTornLog> tornList = new ArrayList<>();
            for (int i = 0; i < updateFlg[0]; ++i) {
                ClssTornLog tmp = new ClssTornLog(records[i]);
                tornList.add(tmp);
            }
            FinancialApplication.getTornLogDbHelper().insertTornLog(tornList);
        }
        return RetCode.EMV_OK;
    }

    private int processMag(ACType acType) {
        int ret = ClssPassApi.Clss_TransProc_MC_Mag(acType);
        Log.i(TAG, "Clss_TransProc_MC_Mag = " + ret + "  ACType = " + acType.type);
        return ret;
    }

    private void updateTransResult(CTransResult result) {

        Log.i(TAG, FinancialApplication.getConvert().bcdToStr(clssPassListener.outcomeParamSet.data));
        switch (clssPassListener.outcomeParamSet.data[0] & 0xF0) {
            case 0x10:
                result.setTransResult(OutcomeParam.CLSS_OC_APPROVED);
                Log.i(TAG, "Clss result = CLSS_APPROVE");
                break;
            case 0x30:
                result.setTransResult(OutcomeParam.CLSS_OC_ONLINE_REQUEST);
                Log.i(TAG, "Clss result = CLSS_ONLINE_REQUEST");
                break;
            case 0x60:
                result.setTransResult(OutcomeParam.CLSS_OC_TRY_ANOTHER_INTERFACE);
                Log.i(TAG, "Clss result = CLSS_TRY_ANOTHER_INTERFACE");
                break;
            case 0x20:
            default:
                result.setTransResult(OutcomeParam.CLSS_OC_DECLINED);
                Log.i(TAG, "Clss result = CLSS_DECLINED");
                break;
        }
    }

    private void updateCVMResult(CTransResult result) {
        switch (clssPassListener.outcomeParamSet.data[3] & 0x30) {
            case 0x10:
                result.setCvmResult((byte) CvmType.RD_CVM_SIG);
                Log.i(TAG, "CVM = signature");
                break;
            case 0x20:
                result.setCvmResult((byte) CvmType.RD_CVM_ONLINE_PIN);
                Log.i(TAG, "CVM = online pin");
                break;
            default:
                result.setCvmResult((byte) CvmType.RD_CVM_NO);
                Log.i(TAG, "CVM = no cvm");
                break;
        }
    }

    @Override
    protected CTransResult process(TransData transData, TransProcessListener transProcessListener) {
        CTransResult result = new CTransResult();

        int ret = init();
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        ret = selectApp();
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        ACType acType = new ACType();
        if (transactionPath.path == TransactionPath.CLSS_MC_MCHIP) {// MChip = 6
            ret = processMChip(acType);

        } else if (transactionPath.path == TransactionPath.CLSS_MC_MAG) {// mag = 5
            ret = processMag(acType);
        }

        if (ret != RetCode.EMV_OK) {
            Log.i(TAG, "Clss_GetDebugInfo_MC = " + ClssPassApi.Clss_GetDebugInfo_MC());
            result.setTransResult(ret);
            return result;
        }

        if (acType.type == ACType.AC_AAC) {
            result.setTransResult(OutcomeParam.CLSS_OC_DECLINED);
            return result;
        }

        Log.i(TAG, "setDetData :" + FinancialApplication.getConvert().bcdToStr(clssPassListener.outcomeParamSet.data));
        if (clssPassListener.outcomeParamSet.data[0] == 0x70 || clssPassListener.outcomeParamSet.data[1] != (byte) 0xF0) {
            result.setTransResult(OutcomeParam.CLSS_OC_TRY_AGAIN);
            return result;
        }

        updateTransResult(result);
        updateCVMResult(result);

        passCBFun.setICBFun(null);  //fix leaks
        transData.setClssResult(result.getTransResult());
        return result;
    }

    @Override
    protected void setDetData(byte[] tag, byte[] data) {
        byte[] buf = new byte[tag.length + 1 + data.length];

        System.arraycopy(tag, 0, buf, 0, tag.length);
        buf[tag.length] = (byte) data.length;
        System.arraycopy(data, 0, buf, tag.length + 1, data.length);
        ClssPassApi.Clss_SetTLVDataList_MC(buf, buf.length);
    }

    private void setMcTermParam(Clss_TransParam clssTransParam, EmvAid aid, Clss_PreProcInfo info) {

        setDetData(ClssTlvTag.CARD_DATA, new byte[]{(byte) 0xE0});
        setDetData(ClssTlvTag.CVM_REQ, new byte[]{(byte) 0xF8});//ONLINE PIN :40 /SIG:20 /OFFLINE PIN : 10
        setDetData(ClssTlvTag.CVM_NO, new byte[]{(byte) 0xF8});
        setDetData(ClssTlvTag.DEF_UDOL, new byte[]{(byte) 0x08});//08:CDA      //40:DDA
        //ONLINE ONLY : 21  OFFLINE ONLY : 23   ONLINE/OFFLINE : 22
        setDetData(new byte[]{(byte) 0x9F, (byte) 0x35}, new byte[]{0x22});

        setDetData(ClssTlvTag.SEC, new byte[]{(byte) 0x9F, 0x6A, 0x04});

        setDetData(ClssTlvTag.MAG_CVM_REQ, new byte[]{(byte) 0x20});
        setDetData(ClssTlvTag.MAG_CVM_NO, new byte[]{(byte) 0x00});

        byte[] tmp = FinancialApplication.getConvert().strToBcd(Long.toString(clssTransParam.ulAmntAuth), EPaddingPosition.PADDING_LEFT);
        byte[] amount = new byte[6];
        System.arraycopy(tmp, 0, amount, 6 - tmp.length, tmp.length);
        setDetData(ClssTlvTag.AMOUNT, amount);

        tmp = FinancialApplication.getConvert().strToBcd(Long.toString(clssTransParam.ulAmntOther), EPaddingPosition.PADDING_LEFT);
        amount = new byte[6];
        System.arraycopy(tmp, 0, amount, 6 - tmp.length, tmp.length);
        setDetData(ClssTlvTag.AMOUNT_OTHER, amount);

        setDetData(ClssTlvTag.TRANS_TYPE, new byte[]{clssTransParam.ucTransType});
        setDetData(ClssTlvTag.TRANS_DATE, clssTransParam.aucTransDate);
        setDetData(ClssTlvTag.TRANS_TIME, clssTransParam.aucTransTime);

        setDetData(ClssTlvTag.APP_VER, FinancialApplication.getConvert().strToBcd(aid.getVersion(), EPaddingPosition.PADDING_LEFT));
        setDetData(ClssTlvTag.TERM_DEFAULT, FinancialApplication.getConvert().strToBcd(aid.getTacDefault(), EPaddingPosition.PADDING_LEFT));
        setDetData(ClssTlvTag.TERM_DENIAL, FinancialApplication.getConvert().strToBcd(aid.getTacDenial(), EPaddingPosition.PADDING_LEFT));
        setDetData(ClssTlvTag.TERM_ONLINE, FinancialApplication.getConvert().strToBcd(aid.getTacOnline(), EPaddingPosition.PADDING_LEFT));

        byte[] aucBuff = new byte[6];
        System.arraycopy(Utils.str2Bcd(Component.getPaddedNumber(info.ulRdClssFLmt, 12)), 0, aucBuff, 0, 6);
        setDetData(ClssTlvTag.FLOOR_LIMIT, aucBuff);
        System.arraycopy(Utils.str2Bcd(Component.getPaddedNumber(info.ulRdClssTxnLmt, 12)), 0, aucBuff, 0, 6);
        setDetData(ClssTlvTag.TRANS_LIMIT, aucBuff);
        System.arraycopy(Utils.str2Bcd(Component.getPaddedNumber(info.ulRdClssTxnLmt, 12)), 0, aucBuff, 0, 6);
        setDetData(ClssTlvTag.TRANS_CVM_LIMIT, aucBuff);
        System.arraycopy(Utils.str2Bcd(Component.getPaddedNumber(info.ulRdCVMLmt, 12)), 0, aucBuff, 0, 6);
        setDetData(ClssTlvTag.CVM_LIMIT, aucBuff);

        setDetData(ClssTlvTag.MAX_TORN, new byte[]{(byte) 0x00});

        int code = CountryCode.getByCode(CurrencyConverter.getDefCurrency().getCountry()).getNumeric();
        byte[] countryCode = FinancialApplication.getConvert().strToBcd(String.valueOf(code), EPaddingPosition.PADDING_LEFT);
        code = CountryCode.getByCode(CurrencyConverter.getDefCurrency().getCountry()).getCurrencyNumeric();
        byte[] currencyCode = FinancialApplication.getConvert().strToBcd(String.valueOf(code), EPaddingPosition.PADDING_LEFT);
        setDetData(ClssTlvTag.COUNTRY_CODE, countryCode);
        setDetData(ClssTlvTag.CURRENCY_CODE, currencyCode);

        if (EmvTestAID.MASTER_MCHIP.getAid().equals(aid.getAid())) {
            setDetData(ClssTlvTag.KERNEL_CFG, new byte[]{(byte) 0x20});
            Log.i(TAG, "MASTER_MCHIP");
        } else if (EmvTestAID.MASTER_MAESTRO.getAid().equals(aid.getAid())) {
            setDetData(ClssTlvTag.KERNEL_CFG, new byte[]{(byte) 0xA0});
            Log.i(TAG, "MASTER_MAESTRO");
        }

        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.ACCOUNT_TYPE, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.ACQUIRER_ID, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.INTER_DEV_NUM, 11);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.MERCHANT_CATEGORY_CODE, 5);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.MERCHANT_ID, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.MERCHANT_NAME_LOCATION, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.TERMINAL_CAPABILITY, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.TERMINAL_ID, 3);

        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.BALANCE_BEFORE_GAC, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.BALANCE_AFTER_GAC, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.MESS_HOLD_TIME, (byte) 0);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.MOB_SUP, 3);

        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_AC_TYPE, 4);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_INPUT_CARD, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_INPUT_TERMINAL, 4);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_ODS_INFO, 3);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_ODS_READER, 4);
        ClssPassApi.Clss_SetTLVDataList_MC(ClssTlvTag.DS_ODS_TERMINAL, 3);

        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.FST_WRITE, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.READ, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.WIRTE_BEFORE_AC, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.WIRTE_AFTER_AC, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(ClssTlvTag.TIMEOUT, (byte) 0);

        setDetData(ClssTlvTag.DS_OPERATOR_ID, new byte[]{(byte) 0x7A, 0x45, 0x12, 0x3E, (byte) 0xE5, (byte) 0x9C, 0x7F, 0x40});
        ClssPassApi.Clss_SetTagPresent_MC(new byte[]{(byte) 0xDF, (byte) 0x81, 0x0D}, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(new byte[]{(byte) 0x9F, (byte) 0x70}, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(new byte[]{(byte) 0x9F, (byte) 0x75}, (byte) 0);

        setDetData(ClssTlvTag.ADDITIONAL_CAPABILITY, new byte[]{(byte) 0x00, 0x00, 0x00, 0x00, 0x00});//additional capability
        setDetData(new byte[]{(byte) 0x9F, (byte) 0x6D}, new byte[]{0x00, 0x01});

        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x1C}, new byte[]{0x00, 0x00});
        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x0C}, new byte[]{0x02});
        ClssPassApi.Clss_SetTagPresent_MC(new byte[]{(byte) 0xDF, (byte) 0x81, 0x30}, (byte) 0);
        ClssPassApi.Clss_SetTagPresent_MC(new byte[]{(byte) 0xDF, (byte) 0x81, 0x2D}, (byte) 0);

        //AET-164
        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x1A}, new byte[] {(byte) 0x9F, (byte) 0x6A, (byte) 0x04});
        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x1E}, new byte[] {(byte) 0x20});
        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x2C}, new byte[] {(byte) 0x00});
        setDetData(new byte[]{(byte) 0xDF, (byte) 0x81, 0x1B}, new byte[] {(byte) 0x00});
        setDetData(new byte[]{(byte) 0x9F, 0x1D}, new byte[] {(byte) 0x40, (byte) 0x00, (byte) 0x80, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00, (byte) 0x00});
    }

    @Override
    protected int getClssTlv(byte[] tag, @NonNull ByteArray value) {
        int ret = ClssPassApi.Clss_GetTLVDataList_MC(tag, (byte) tag.length, value.length, value);
        Log.i(TAG, " getClssTlv_MC  tag :" + FinancialApplication.getConvert().bcdToStr(tag)
                + " value: " + FinancialApplication.getConvert().bcdToStr(value.data).substring(0, 2 * value.length) + " ret :" + ret);
        return ret;
    }

    @Override
    protected void onAddCapkRevList(EMV_CAPK emvCapk, EMV_REVOCLIST emvRevoclist) {
        int ret = ClssPassApi.Clss_AddCAPK_MC_MChip(emvCapk);
        Log.i(TAG, "set MC capk ret :" + ret);
        ret = ClssPassApi.Clss_AddRevocList_MC_MChip(emvRevoclist);
        Log.i(TAG, "set MC revoclist ret :" + ret);
    }

    @Override
    protected void setTrack2(TransData transData) {
        ByteArray track = new ByteArray();
        int ret = getClssTlv(ClssTlvTag.TRACK1, track);
        if (ret == RetCode.EMV_OK)
            transData.setTrack1(FinancialApplication.getConvert().bcdToStr(track.data).substring(0, 2 * track.length));

        track = new ByteArray();
        if (transactionPath.path == TransactionPath.CLSS_MC_MCHIP) {
            ret = getClssTlv(ClssTlvTag.TRACK2, track);
        } else if (transactionPath.path == TransactionPath.CLSS_MC_MAG) {
            ret = getClssTlv(ClssTlvTag.TRACK2_1, track);
        }

        if (ret == RetCode.EMV_OK) {
            //AET-173
            String track2 = FinancialApplication.getConvert().bcdToStr(track.data).substring(0, 2 * track.length).split("F")[0];
            transData.setTrack2(track2);
        }
    }

    @Override
    protected void completeTrans(TransData transData) {
        //do nothing
    }

    @Override
    protected void handleTccSpecialCase(CTransResult result, TransData transData, ByteArray f55DataArray) {
        if (transData.getPan().getBytes()[0] != '5') {
            return;
        }
        ByteArray tempByteArray = new ByteArray();
        tempByteArray.data[0] = (byte) 0x82;
        tempByteArray.length = 1;
        buildCLSSTLVString(new byte[]{(byte) 0x9F, 0x53}, tempByteArray, f55DataArray);
        if (result.getTransResult() == OutcomeParam.CLSS_OC_APPROVED) {
            byte[] tag = new byte[]{(byte) 0x91};
            ByteArray value = new ByteArray();
            int ret = getClssTlv(tag, value);
            if (ret == RetCode.EMV_OK) {
                buildCLSSTLVString(tag, value, f55DataArray);
            }
        }
    }

    private class ClssPassListener implements IClssPassCBFun {
        ByteArray outcomeParamSet = new ByteArray(8);
        ByteArray userInterReqData = new ByteArray(22);
        ByteArray errIndication = new ByteArray(6);

        @Override
        public int sendDEKData(byte[] bytes, int i) {
            return 0;
        }

        @Override
        public int receiveDETData(ByteArray byteArray, byte[] bytes) {
            return 0;
        }

        @Override
        public int addAPDUToTransLog(ApduSendL2 apduSendL2, ApduRespL2 apduRespL2) {
            return 0;
        }

        @Override
        public int sendTransDataOutput(byte b) {
            if ((b & 0x01) != 0) {
                getClssTlv(ClssTlvTag.LIST, outcomeParamSet);
            }

            if ((b & 0x04) != 0) {
                getClssTlv(USER_INTER_REQ, userInterReqData);
            }

            if ((b & 0x02) != 0) {
                getClssTlv(ERR_INDICATION, errIndication);
            }
            return RetCode.EMV_OK;
        }
    }
}
