/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-12-28
 * Module Author: caowb
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;


import android.content.Context;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.TextView;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.TransTotal;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.ToastUtils;
import com.pax.view.BaseViewHolder;
import com.tjerkw.slideexpandable.library.AbstractSlideExpandableListAdapter;
import com.tjerkw.slideexpandable.library.ActionSlideExpandableListView;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class SelectAcqActivity extends BaseActivityWithTickForAction {

    private static final String ACQ_NAME = "acq_name";

    private ImageView headerBack;
    private CheckBox mCheck;
    private Button mSettle;
    private ActionSlideExpandableListView mList;

    private AcquirerListAdapter acquirerListAdapter;

    private List<String> checkedAcqs;

    @Override
    protected int getLayoutId() {
        return R.layout.activity_selectacq_layout;
    }

    @Override
    protected void loadParam() {
        Bundle bundle = getIntent().getExtras();
        if (bundle != null) {
            checkedAcqs = bundle.getStringArrayList(Constants.ACQUIRER_NAME);
        }

        if(checkedAcqs == null)
            checkedAcqs = new ArrayList<>();

        List<Acquirer> acquirers = FinancialApplication.getAcqManager().findAllAcquirers();
        ArrayList<HashMap<String, String>> myListArray = new ArrayList<>();

        for (Acquirer i : acquirers) {
            HashMap<String, String> map = new HashMap<>();
            map.put(ACQ_NAME, i.getName());
            myListArray.add(map);
        }
        acquirerListAdapter = new AcquirerListAdapter(SelectAcqActivity.this, myListArray);
    }

    @Override
    protected void initViews() {
        TextView titleTv = (TextView) findViewById(R.id.header_title);
        headerBack = (ImageView) findViewById(R.id.header_back);
        mCheck = (CheckBox) findViewById(R.id.item_select_acq_check);
        mList = (ActionSlideExpandableListView) findViewById(R.id.select_acq_list);
        mSettle = (Button) findViewById(R.id.select_acq_settle);

        confirmBtnChange();

        titleTv.setText(getString(R.string.settle_select_acquirer));
    }

    private void setListListener(){
        mList.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                tickTimer.start();
                return false;
            }
        });
        mList.setAdapter(acquirerListAdapter, new AbstractSlideExpandableListAdapter.OnItemExpandCollapseListener() {

            @Override
            public void onExpand(View itemView, int position) {
                updateValueTable(itemView, position);
            }

            @Override
            public void onCollapse(View itemView, int position) {
                //do nothing
            }
        });
        mList.setItemActionListener(new ActionSlideExpandableListView.OnActionClickListener() {
            @Override
            public void onActionItemClick(View itemView, View clickedView, final int position) {
                if(R.id.settle_confirm == clickedView.getId()){
                    checkedAcqs.clear();
                    checkedAcqs.add(findAcquirer(position));
                    finish(new ActionResult(TransResult.SUCC, checkedAcqs));
                }
            }
        }, R.id.settle_confirm);
    }

    @Override
    protected void setListeners() {
        headerBack.setOnClickListener(this);
        mSettle.setOnClickListener(this);

        setListListener();

        mCheck.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                tickTimer.start();
                //AET-39
                if (isChecked) {
                    List<Acquirer> acqList = FinancialApplication.getAcqManager().findAllAcquirers();
                    for (Acquirer acquirer : acqList) {
                        if (!checkedAcqs.contains(acquirer.getName())) {
                            checkedAcqs.add(acquirer.getName());
                        }
                    }
                } else {
                    if (checkedAcqs.size() == FinancialApplication.getAcqManager().findAllAcquirers().size()) {
                        checkedAcqs.clear();
                    }
                }
                confirmBtnChange();
                acquirerListAdapter.notifyDataSetChanged();
            }
        });

        //AET-39
        if (checkedAcqs != null && checkedAcqs.size() == FinancialApplication.getAcqManager().findAllAcquirers().size()) {
            mCheck.setChecked(true);
        }
    }

    @Override
    protected boolean onKeyBackDown() {
        finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
        return true;
    }

    @Override
    public void onClickProtected(View v) {
        switch (v.getId()) {
            case R.id.header_back:
                finish(new ActionResult(TransResult.ERR_USER_CANCEL, null));
                break;
            case R.id.select_acq_settle:
                finish2SettleAcq();
                break;
            default:
                break;
        }
    }

    private void finish2SettleAcq(){
        if (checkedAcqs.isEmpty()) {
            ToastUtils.showMessage(SelectAcqActivity.this, getString(R.string.err_settle_select_acq));
            return;
        }
        finish(new ActionResult(TransResult.SUCC, checkedAcqs));
    }

    private class AcquirerListAdapter extends BaseAdapter {

        private LayoutInflater mContainer;
        private List<HashMap<String, String>> mList;

        AcquirerListAdapter(Context context, List<HashMap<String, String>> list) {
            mContainer = LayoutInflater.from(context);
            this.mList = list;
        }

        @Override
        public int getCount() {
            return mList.size();
        }

        @Override
        public Object getItem(int position) {
            return mList.get(position);
        }

        @Override
        public long getItemId(int position) {
            return position;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            final int pos = position;
            if (convertView == null) {
                convertView = mContainer.inflate(R.layout.selectacq_item, parent, false);
            }

            TextView textView = BaseViewHolder.get(convertView, R.id.expandable_toggle_button);
            CheckBox checkBox = BaseViewHolder.get(convertView, R.id.item_select_acq_check);

            textView.setText(mList.get(position).get(ACQ_NAME));
            checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
                @Override
                public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                    tickTimer.start();
                    Log.d("SelectAcq", "onCheckedChanged  " + pos);
                    if (isChecked) {
                        if (!checkedAcqs.contains(mList.get(pos).get(ACQ_NAME)))
                            checkedAcqs.add(mList.get(pos).get(ACQ_NAME));
                    } else {
                        checkedAcqs.remove(mList.get(pos).get(ACQ_NAME));
                    }
                    confirmBtnChange();
                    //AET-39
                    mCheck.setChecked(checkedAcqs.size() == FinancialApplication.getAcqManager().findAllAcquirers().size());
                }
            });

            //AET-39
            checkBox.setChecked(checkedAcqs.contains(mList.get(pos).get(ACQ_NAME)));
            return convertView;
        }
    }

    // AET-114
    private void confirmBtnChange() {
        mSettle.setEnabled(!checkedAcqs.isEmpty());
    }

    @SuppressWarnings("unchecked")
    private String findAcquirer(int position) {
        return ((HashMap<String, String>) acquirerListAdapter.getItem(position)).get(ACQ_NAME);
    }

    private void updateValueTable(View view, int position) {
        String acquirerName = findAcquirer(position);
        Acquirer acquirer = FinancialApplication.getAcqManager().findAcquirer(acquirerName);
        TransTotal total = FinancialApplication.getTransTotalDbHelper().calcTotal(acquirer);

        view.findViewById(R.id.settle_acquirer_name).setVisibility(View.GONE);
        TextView acqName = (TextView) view.findViewById(R.id.settle_acquirer_name);
        TextView merchantName = (TextView) view.findViewById(R.id.settle_merchant_name);
        TextView merchantId = (TextView) view.findViewById(R.id.settle_merchant_id);
        TextView terminalId = (TextView) view.findViewById(R.id.settle_terminal_id);
        TextView batchNo = (TextView) view.findViewById(R.id.settle_batch_num);

        acqName.setText(acquirer.getName());
        merchantName.setText(getString(R.string.settle_merchant_name));
        merchantId.setText(acquirer.getMerchantId());
        terminalId.setText(acquirer.getTerminalId());
        batchNo.setText(String.valueOf(acquirer.getCurrBatchNo()));

        String saleAmt = CurrencyConverter.convert(total.getSaleTotalAmt());
        //AET-18
        String refundAmt = CurrencyConverter.convert(0 - total.getRefundTotalAmt());
        String voidSaleAmt = CurrencyConverter.convert(0 - total.getSaleVoidTotalAmt());
        String voidRefundAmt = CurrencyConverter.convert(0 - total.getRefundVoidTotalAmt());

        ((TextView) view.findViewById(R.id.settle_sale_total_sum)).setText(String.valueOf(total.getSaleTotalNum()));
        ((TextView) view.findViewById(R.id.settle_sale_total_amount)).setText(saleAmt);
        ((TextView) view.findViewById(R.id.settle_refund_total_sum)).setText(String.valueOf(total.getRefundTotalNum()));
        ((TextView) view.findViewById(R.id.settle_refund_total_amount)).setText(refundAmt);

        ((TextView) view.findViewById(R.id.settle_void_sale_total_sum)).setText(String.valueOf(total.getSaleVoidTotalNum()));
        ((TextView) view.findViewById(R.id.settle_void_sale_total_amount)).setText(voidSaleAmt);
        ((TextView) view.findViewById(R.id.settle_void_refund_total_sum)).setText(String.valueOf(total.getRefundVoidTotalNum()));
        ((TextView) view.findViewById(R.id.settle_void_refund_total_amount)).setText(voidRefundAmt);
    }
}
