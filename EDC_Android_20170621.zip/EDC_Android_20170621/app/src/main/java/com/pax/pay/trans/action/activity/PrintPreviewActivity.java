/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-6
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;
import com.pax.view.dialog.MenuPopupWindow;

public class PrintPreviewActivity extends BaseActivityWithTickForAction {
    private Bitmap bitmap;
    private ImageView imageView;
    private Button btnCancel;
    private Button btnPrint;
    private ImageButton receiptModeBtn;

    public static final String CANCEL_BUTTON = "CANCEL";
    public static final String PRINT_BUTTON = "PRINT";
    public static final String SMS_BUTTON = "SMS";
    public static final String EMAIL_BUTTON = "EMAIL";

    private Animation receiptOutAnim;

    private MenuPopupWindow popupWindow = null;

    @Override
    protected void loadParam() {
        //get data
        Intent intent = getIntent();
        if (intent != null) {
            //byte data to
            byte[] bis = intent.getByteArrayExtra(EUIParamKeys.BITMAP.toString());
            bitmap = BitmapFactory.decodeByteArray(bis, 0, bis.length);
        }
    }

    private void initMenuPopupWindow() {
        boolean enableSMS = Utils.isSimReady(PrintPreviewActivity.this);
        boolean enableEmail = Utils.isNetworkAvailable(PrintPreviewActivity.this);
        if (!enableSMS && !enableEmail) {
            receiptModeBtn.setVisibility(View.GONE);
            return;
        }
        popupWindow = new MenuPopupWindow(this, ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        if (enableSMS)
            popupWindow.addAction(new MenuPopupWindow.ActionItem(this, R.string.dialog_sms, R.drawable.ic29));
        if (enableEmail)
            popupWindow.addAction(new MenuPopupWindow.ActionItem(this, R.string.dialog_email, R.drawable.ic29));
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_print_preview_layout;
    }

    @Override
    protected void initViews() {
        TextView headerText = (TextView) findViewById(R.id.header_title);
        headerText.setText(R.string.receipt_preview);
        ImageView headerBack = (ImageView) findViewById(R.id.header_back);
        headerBack.setVisibility(View.GONE);

        imageView = (ImageView) findViewById(R.id.printPreview);
        imageView.setImageBitmap(bitmap);
        btnCancel = (Button) findViewById(R.id.cancel_button);
        btnPrint = (Button) findViewById(R.id.print_button);
        receiptModeBtn = (ImageButton) findViewById(R.id.receipt_mode_btn);

        if (FinancialApplication.getSysParam().get(SysParam.BooleanParam.EDC_ENABLE_PAPERLESS)) {
            receiptModeBtn.setVisibility(View.VISIBLE);
            initMenuPopupWindow();
        } else {
            receiptModeBtn.setVisibility(View.GONE);
        }

        receiptOutAnim = AnimationUtils.loadAnimation(this, R.anim.receipt_out);
    }

    @Override
    protected void setListeners() {
        btnCancel.setOnClickListener(this);
        btnPrint.setOnClickListener(this);
        receiptModeBtn.setOnClickListener(this);
        if (popupWindow != null)
            popupWindow.setItemOnClickListener(new MenuPopupWindow.OnItemOnClickListener() {
                @Override
                public void onItemClick(MenuPopupWindow.ActionItem item, int position) {
                    switch (item.getId()) {
                        case R.string.dialog_sms:
                            finish(new ActionResult(TransResult.SUCC, SMS_BUTTON));
                            break;
                        case R.string.dialog_email:
                            finish(new ActionResult(TransResult.SUCC, EMAIL_BUTTON));
                            break;
                        default:
                            break;
                    }
                }
            });
    }

    @Override
    public void onClickProtected(View v) {
        Log.i("On Click", v.toString());
        switch (v.getId()) {
            case R.id.cancel_button:
                //end trans
                finish(new ActionResult(TransResult.SUCC, CANCEL_BUTTON));
                break;
            case R.id.print_button:
                //print
                FinancialApplication.getApp().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        imageView.startAnimation(receiptOutAnim);
                    }
                });
                finish(new ActionResult(TransResult.SUCC, PRINT_BUTTON));
                break;
            case R.id.receipt_mode_btn:
                //sms or email
                if (popupWindow != null) {
                    popupWindow.show(v);
                } else {
                    Toast.makeText(PrintPreviewActivity.this, R.string.err_unsupported_func, Toast.LENGTH_LONG).show();
                }
                break;
            default:
                break;
        }

    }

    @Override
    protected boolean onKeyBackDown() {
        // AET-91
        Toast.makeText(PrintPreviewActivity.this, R.string.err_not_allowed, Toast.LENGTH_SHORT).show();
        return true;
    }

    // AET-102
    @Override
    protected void onTimerFinish() {
        onClick(btnPrint);
    }
}
