/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-12-27
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay;

import android.content.Context;
import android.content.Intent;
import android.text.InputType;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;

import com.pax.abl.utils.EncUtils;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.base.CardRange;
import com.pax.pay.base.Issuer;
import com.pax.pay.constant.Constants;
import com.pax.pay.emv.EmvTestAID;
import com.pax.pay.emv.EmvTestCAPK;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.AcqManager;
import com.pax.pay.trans.model.Controller;
import com.pax.pay.utils.KeyBoardUtils;
import com.pax.settings.SysParam;
import com.pax.view.SoftKeyboardPwdStyle;
import com.pax.view.SoftKeyboardPwdStyle.OnItemClickListener;
import com.pax.view.dialog.DialogUtils;
import com.pax.view.dialog.InputPwdDialog;

public class InitializeInputPwdActivity extends BaseActivity implements OnItemClickListener {

    public static final int REQ_WIZARD = 1;

    private EditText edtPwd;

    private FrameLayout flKeyboardContainer;
    private SoftKeyboardPwdStyle softKeyboard;

    @Override
    protected void onResume() {
        super.onResume();
        KeyBoardUtils.show(InitializeInputPwdActivity.this, flKeyboardContainer);
    }

    @Override
    protected void loadParam() {
        // do nothing
    }

    @Override
    protected int getLayoutId() {
        return R.layout.activity_initialize_pwd_layout;
    }

    @Override
    protected void initViews() {
        edtPwd = (EditText) findViewById(R.id.operator_pwd_edt);

        flKeyboardContainer = (FrameLayout) findViewById(R.id.fl_trans_softKeyboard);
        softKeyboard = (SoftKeyboardPwdStyle) findViewById(R.id.soft_keyboard_view);

        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(edtPwd.getWindowToken(), 0);
        edtPwd.setInputType(InputType.TYPE_NULL);
        edtPwd.setFocusable(true);
        edtPwd.setTransformationMethod(new InputPwdDialog.WordReplacement());
    }

    @Override
    protected void setListeners() {
        edtPwd.setOnTouchListener(new View.OnTouchListener() {

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                KeyBoardUtils.show(InitializeInputPwdActivity.this, flKeyboardContainer);
                return true;
            }
        });
        softKeyboard.setOnItemClickListener(this);
    }

    @Override
    protected boolean onKeyBackDown() {
        // exit app
        DialogUtils.showExitAppDialog(InitializeInputPwdActivity.this);
        return true;
    }

    /**
     * check password
     */
    private void process() {
        String password = edtPwd.getText().toString().trim();
        if (password.isEmpty()) {
            edtPwd.setFocusable(true);
            edtPwd.requestFocus();
            return;
        }
        if (!EncUtils.sha1(password).equals(FinancialApplication.getSysParam().get(SysParam.StringParam.SEC_TERMINAL_PWD))) {
            Toast.makeText(InitializeInputPwdActivity.this, R.string.error_password, Toast.LENGTH_LONG).show();
            edtPwd.setText("");
            edtPwd.setFocusable(true);
            edtPwd.requestFocus();
            return;
        }

        //start wizard activity
        Intent intent = new Intent(this, WizardActivity.class);
        startActivityForResult(intent, REQ_WIZARD);
    }

    protected void onReqWizard() {
        //remain for process result
        Intent intent = getIntent();
        setResult(MainActivity.REQ_INITIALIZE, intent);
        insertAcquirer();
        initEMVParam();
        FinancialApplication.getController().set(Controller.IS_FIRST_RUN, false);
        finish();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_WIZARD) {
            onReqWizard();
        }
    }

    @Override
    public void onItemClick(View v, int index) {
        if (index == KeyEvent.KEYCODE_ENTER) {
            FinancialApplication.getApp().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    process();
                }
            });
        } else if (index == Constants.KEY_EVENT_CANCEL) {
            FinancialApplication.getApp().runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    DialogUtils.showExitAppDialog(InitializeInputPwdActivity.this);
                }
            });
        }
    }

    private int initEMVParam() {
        FinancialApplication.getApp().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                // emv公钥下载
                Controller controller = FinancialApplication.getController();
                if (controller.get(Controller.NEED_DOWN_CAPK) == Controller.Constant.YES) {
                    EmvTestCAPK.load();
                    controller.set(Controller.NEED_DOWN_CAPK, Controller.Constant.NO);
                }
                // emv 参数下载
                if (controller.get(Controller.NEED_DOWN_AID) == Controller.Constant.YES) {
                    EmvTestAID.load();
                    controller.set(Controller.NEED_DOWN_AID, Controller.Constant.NO);
                }

                Toast.makeText(FinancialApplication.getApp(), R.string.emv_init_succ, Toast.LENGTH_LONG).show();
            }
        });
        return TransResult.SUCC;
    }

    private void insertAcquirer() {
        AcqManager acqManager = FinancialApplication.getAcqManager();
        Acquirer acquirer = new Acquirer("acquirer0");
        acquirer.setNii("019");
        acquirer.setMerchantId("123456789012345");
        acquirer.setTerminalId("12345678");
        acquirer.setCurrBatchNo(1);
        acquirer.setIp("192.168.191.1");
        acquirer.setPort((short) 10001);
        FinancialApplication.getSysParam().set(SysParam.StringParam.ACQ_NAME, "acquirer0");
        acqManager.insertAcquirer(acquirer);
        acqManager.setCurAcq(acquirer);

        Acquirer acquirer2 = new Acquirer("acquirer1");
        acquirer2.setNii("020");
        acquirer2.setMerchantId("222456789012345");
        acquirer2.setTerminalId("22245678");
        acquirer2.setCurrBatchNo(1);
        acquirer2.setIp("192.168.191.1");
        acquirer2.setPort((short) 10001);
        acqManager.insertAcquirer(acquirer2);

        Issuer issuer = new Issuer("VISA");
        issuer.setPanMaskPattern(Constants.DEF_PAN_MASK_PATTERN);
        issuer.setFloorLimit(0);
        issuer.setAllowManualPan(true);
        issuer.setAdjustPercent(10);
        acqManager.insertIssuer(issuer);
        acqManager.bind(acquirer, issuer);

        CardRange cardRang = new CardRange("VISA", "4000000000", "4999999999", 0, issuer);
        acqManager.insertCardRange(cardRang);

        issuer = new Issuer("MASTER");
        issuer.setPanMaskPattern(Constants.DEF_PAN_MASK_PATTERN);
        issuer.setFloorLimit(0);
        issuer.setAdjustPercent(10);
        acqManager.insertIssuer(issuer);
        acqManager.bind(acquirer, issuer);

        cardRang = new CardRange("MASTER", "5000000000", "5999999999", 0, issuer);
        acqManager.insertCardRange(cardRang);
        cardRang = new CardRange("MASTER", "2000000000", "2999999999", 0, issuer);
        acqManager.insertCardRange(cardRang);
        cardRang = new CardRange("MASTER", "6700000000", "6799999999", 0, issuer);
        acqManager.insertCardRange(cardRang);

        issuer = new Issuer("AMEX");
        issuer.setPanMaskPattern(Constants.DEF_PAN_MASK_PATTERN);
        issuer.setFloorLimit(0);
        issuer.setAdjustPercent(10);
        acqManager.insertIssuer(issuer);
        acqManager.bind(acquirer, issuer);

        cardRang = new CardRange("AMEX", "3400000000", "3499999999", 0, issuer);
        acqManager.insertCardRange(cardRang);
        cardRang = new CardRange("AMEX", "3700000000", "3799999999", 0, issuer);
        acqManager.insertCardRange(cardRang);

        issuer = new Issuer("UnionPay");
        issuer.setPanMaskPattern(Constants.DEF_PAN_MASK_PATTERN);
        issuer.setFloorLimit(0);
        issuer.setAdjustPercent(10);
        acqManager.insertIssuer(issuer);
        acqManager.bind(acquirer, issuer);

        cardRang = new CardRange("UnionPay", "6000000000", "6999999999", 0, issuer);
        acqManager.insertCardRange(cardRang);
    }

}
