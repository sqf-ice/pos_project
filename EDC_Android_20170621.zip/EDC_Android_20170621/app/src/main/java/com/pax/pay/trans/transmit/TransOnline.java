/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.transmit;

import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.constant.Constants;
import com.pax.pay.emv.CardBinBlack;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.Controller;
import com.pax.pay.trans.model.ETransType;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransData.OfflineStatus;
import com.pax.pay.trans.model.TransTotal;
import com.pax.pay.utils.ResponseCode;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

import java.util.ArrayList;
import java.util.List;

/**
 * 单独联机处理， 例如签到
 *
 * @author Steven.W
 */
public class TransOnline {
    private Online online = new Online();

    /**
     * 检查应答码
     *
     * @return {@link TransResult}
     */
    private int checkRspCode(TransData transData, TransProcessListener listener) {
        if (!"00".equals(transData.getResponseCode().getCode())) {
            if (listener != null) {
                listener.onHideProgress();
                listener.onShowErrMessageWithConfirm(Utils.getString(R.string.prompt_err_code)
                                + transData.getResponseCode().toString(),
                        Constants.FAILED_DIALOG_SHOW_TIME);
            }
            return TransResult.ERR_HOST_REJECT;
        }
        return TransResult.SUCC;
    }

    /**
     * 保存黑名单
     *
     * @param blackList the black list array
     */
    @SuppressWarnings("unused")
    private void writeBlack(byte[] blackList) {
        if (blackList == null)
            return;
        int loc = 0;
        while (loc < blackList.length) {
            int len = Integer.parseInt(new String(new byte[]{blackList[loc], blackList[loc + 1]}));
            byte[] cardNo = new byte[len];
            if (len + loc + 2 > blackList.length) {
                return;
            }
            System.arraycopy(blackList, loc + 2, cardNo, 0, len);
            CardBinBlack cardBinBlack = new CardBinBlack();
            cardBinBlack.setBin(new String(cardNo));
            cardBinBlack.setCardNoLen(cardNo.length);
            FinancialApplication.getCardBinDb().insertBlack(cardBinBlack);
            loc += 2 + len;
        }
    }

    /**
     * 结算
     *
     * @return {@link TransResult}
     */
    public int settle(TransTotal total, TransProcessListener listener) {
        int ret;
        if (FinancialApplication.getController().get(Controller.BATCH_UP_STATUS) != Controller.Constant.BATCH_UP) {
            Transmit transmit = new Transmit();
            // 处理脱机交易
            ret = transmit.sendOfflineTrans(listener, true, true);
            if (ret != TransResult.SUCC) {
                return ret;
            }
            // 处理冲正
            ret = transmit.sendReversal(listener);
            if (ret == TransResult.ERR_ABORTED) {
                return ret;
            }

            ret = settleRequest(total, listener);
            if (ret != TransResult.SUCC) {
                if (listener != null) {
                    listener.onHideProgress();
                }
                return ret;
            }
        }

        ret = batchUp(listener);
        if (ret != TransResult.SUCC) {
            if (listener != null) {
                listener.onHideProgress();
            }
            return ret;
        }

        return TransResult.SUCC;
    }

    /**
     * 结算请求
     *
     * @return {@link TransResult}
     */
    private int settleRequest(TransTotal total, TransProcessListener listener) {

        TransData transData = Component.transInit();
        transData.setTransType(ETransType.SETTLE);
        if (listener != null) {
            listener.onUpdateProgressTitle(ETransType.SETTLE.getTransName());
        }

        String saleAmt;
        String saleNum;
        String refundAmt;
        String refundNum;

        String buf;
        saleAmt = Component.getPaddedNumber(total.getSaleTotalAmt(), 12);
        saleNum = Component.getPaddedNumber(total.getSaleTotalNum(), 3);
        refundAmt = Component.getPaddedNumber(total.getRefundTotalAmt(), 12);
        refundNum = Component.getPaddedNumber(total.getRefundTotalNum(), 3);
        buf = saleNum + saleAmt + refundNum + refundAmt;
        buf += "000000000000000000000000000000";
        transData.setField63(buf);

        int ret = online.online(transData, listener);
        if (listener != null) {
            listener.onHideProgress();
        }
        if (ret != TransResult.SUCC) {
            return ret;
        }
        ResponseCode responseCode = transData.getResponseCode();
        //AET-31
        if (!"95".equals(responseCode.getCode())) {
            if ("00".equals(responseCode.getCode())) {
                return TransResult.SUCC_NOREQ_BATCH;
            }
            if (listener != null) {
                listener.onShowErrMessageWithConfirm(responseCode.getMessage(), Constants.FAILED_DIALOG_SHOW_TIME);
            }
            return TransResult.ERR_HOST_REJECT;
        }

        FinancialApplication.getController().set(Controller.BATCH_UP_STATUS, Controller.Constant.BATCH_UP);
        FinancialApplication.getController().set(Controller.BATCH_NUM, 0);

        return TransResult.SUCC;
    }

    /**
     * 批上送
     *
     * @return {@link TransResult}
     */
    private int batchUp(TransProcessListener listener) {
        int ret;
        if (listener != null)
            listener.onUpdateProgressTitle(ETransType.BATCH_UP.getTransName());
        // 获取交易记录条数
        long cnt = FinancialApplication.getTransDataDbHelper().countOf();
        if (cnt <= 0) {
            FinancialApplication.getController().set(Controller.BATCH_UP_STATUS, Controller.Constant.WORKED);
            return TransResult.ERR_NO_TRANS;
        }
        // 获取交易重复次数
        int resendTimes = FinancialApplication.getSysParam().get(SysParam.NumberParam.COMM_REDIAL_TIMES);
        int sendCnt = 0;
        final boolean[] left = new boolean[]{false};
        while (sendCnt < resendTimes + 1) {
            // 1)(对账平不送)全部磁条卡离线类交易，包括结算调整
            // 2)(对账平不送)基于PBOC标准的借/贷记IC卡脱机消费(含小额支付)成功交易
            // 3)(不存在)基于PBOC标准的电子钱包IC卡脱机消费成功交易 --- 不存在

            // 4)(对账平不送)全部磁条卡的请求类联机成功交易明细
            ret = new AllMagCardTransBatch(listener, new BatchUpListener() {

                @Override
                public void onLeftResult(boolean l) {
                    left[0] = l;
                }
            }).process();
            if (ret != TransResult.SUCC) {
                return ret;
            }
            // 5)(对账平不送)磁条卡和基于PBOC借/贷记标准IC卡的通知类交易明细，包括退货和预授权完成(通知)交易
            // 6)(对账平也送)为了上送基于PBOC标准的借/贷记IC卡成功交易产生的TC值，所有成功的IC卡借贷记联机交易明细全部重新上送
            // 7)(对账平也送)为了让发卡方了解基于PBOC标准的借/贷记IC卡脱机消费(含小额支付)交易的全部情况，上送所有失败的脱机消费交易明细
            // 8)(对账平也送)为了让发卡方防范基于PBOC标准的借/贷记IC卡风险交易，上送所有ARPC错但卡片仍然承兑的IC卡借贷记联机交易明细
            // 9)(不存在)为了上送基于PBOC标准的电子钱包IC卡成功圈存交易产生的TAC值，上送所有圈存确认的交易明细
            if (!left[0]) {
                break;
            }
            left[0] = false;
            sendCnt++;
        }
        // 10)(对账平也送)最后需上送批上送结束报文
        ret = batchUpEnd(listener);
        if (ret != TransResult.SUCC) {
            return ret;
        }
        return TransResult.SUCC;
    }

    /**
     * 结算结束
     *
     * @return {@link TransResult}
     */
    private int batchUpEnd(TransProcessListener listener) {
        if (listener != null)
            listener.onUpdateProgressTitle(ETransType.SETTLE_END.getTransName());
        TransData transData = Component.transInit();
        String f60 = "00" + Component.getPaddedNumber(FinancialApplication.getAcqManager().getCurAcq().getCurrBatchNo(), 6);
        f60 += "207";

        int batchUpNum = FinancialApplication.getController().get(Controller.BATCH_NUM);
        transData.setField48(Component.getPaddedNumber(batchUpNum, 4));
        transData.setField60(f60);
        transData.setTransType(ETransType.SETTLE_END);
        return online.online(transData, listener);
    }

    interface BatchUpListener {
        void onLeftResult(boolean left);
    }

    /**
     * 全部磁条卡的请求类联机成功交易明细上送
     */
    private class AllMagCardTransBatch{
        private final TransProcessListener listener;
        private final BatchUpListener batchUpListener;
        private boolean isFirst = true;
        private int ret = TransResult.SUCC;

        AllMagCardTransBatch(TransProcessListener listener,
                             BatchUpListener batchUpListener){
            this.listener = listener;
            this.batchUpListener = batchUpListener;
        }

        private boolean needUpload(TransData transLog){
            //AET-31、AET-43
            // 已上送的交易不再上送
            return !(transLog.getTransType() == ETransType.PREAUTH || transLog.getTransType() == ETransType.VOID || transLog.isUpload());
        }

        private TransData genTranData(TransData transLog){
            transLog.setOrigTransType(transLog.getTransType());

            if(!needUpload(transLog))
                return null;
            TransData transData = Component.transInit();
            // field 2
            String field2 = transLog.getPan();
            if (field2 != null) {
                transData.setPan(field2);
            }
            // field 4
            transData.setAmount(transLog.getAmount());
            //field 11
            String field11 = Component.getPaddedNumber(transLog.getTraceNo(), 6);
            transData.setTraceNo(Long.parseLong(field11));
            //field 12
            String dateTime = transLog.getDateTime();
            if (dateTime != null) {
                transData.setDateTime(dateTime);
            }
            //field 13
            String date = transLog.getExpDate();
            if (date != null) {
                transData.setExpDate(date);
            }
            //field 22
            transData.setEnterMode(transLog.getEnterMode());
            //field 24
            String nii = transLog.getNii();
            if (nii != null) {
                transData.setNii(nii);
            }
            //field 37
            String refNo = transLog.getRefNo();
            if (refNo != null) {
                transData.setRefNo(refNo);
            }
            transData.setOrigTransType(transLog.getTransType());
            transData.setTransType(ETransType.BATCH_UP);
            return transData;
        }

        private boolean continueOnline(TransData transData){
            if(transData == null)
                return true;
            ret = online.online(transData, listener, isFirst, false);
            isFirst = false;
            if (ret != TransResult.SUCC) {
                if (ret != TransResult.ERR_RECV) {
                    return false;
                }
                batchUpListener.onLeftResult(true);// 批上送交易无应答时，终端应在本轮上送完毕后再重发，而非立即重发
            }
            return true;
        }

        /**
         * @return {@link TransResult}
         */
        int process(){
            List<TransData> allTrans = FinancialApplication.getTransDataDbHelper().findAllTransData(FinancialApplication.getAcqManager().getCurAcq());
            if (allTrans.isEmpty()) {
                return TransResult.ERR_NO_TRANS;
            }
            int transCnt = allTrans.size();

            isFirst = true;
            for (int cnt = 0; cnt < transCnt; cnt++) {
                updateProgressTitle(cnt + 1, transCnt);
                if(!continueOnline(genTranData(allTrans.get(cnt))))
                    break;
            }
            online.close();
            return ret;
        }

        private void updateProgressTitle(int cnt, int total){
            if (listener != null)
                listener.onUpdateProgressTitle(ETransType.BATCH_UP.getTransName() + "[" + cnt + "/" + total + "]");
        }
    }

    /**
     * 脱机交易上送
     *
     * @param listener isOnline 是否为下一笔联机交易
     * @return {@link TransResult}
     */
    public int offlineTransSend(TransProcessListener listener, boolean isSendAllOfflineTrans, boolean isSettlement) {
        int sendMaxTime = FinancialApplication.getSysParam().get(SysParam.NumberParam.OFFLINE_TC_UPLOAD_TIMES);
        int maxOfflineNum = FinancialApplication.getSysParam().get(SysParam.NumberParam.OFFLINE_TC_UPLOAD_NUM);

        final List<TransData.OfflineStatus> defFilter = new ArrayList<>();
        defFilter.add(TransData.OfflineStatus.OFFLINE_NOT_SENT);

        List<TransData> records = FinancialApplication.getTransDataDbHelper().findOfflineTransData(defFilter);
        List<TransData> notSendRecords = new ArrayList<>();
        if (records.isEmpty()) {
            return TransResult.SUCC;
        }

        Acquirer acquirer = FinancialApplication.getAcqManager().getCurAcq();
        if (acquirer == null || (!isSettlement && acquirer.isDisableTrickFeed())) {
            return TransResult.SUCC;
        }

        if (!isSettlement) {
            notSendRecords.add(records.get(0));
        } else {
            notSendRecords.addAll(records);
        }

        if (listener != null) {
            listener.onUpdateProgressTitle(ETransType.OFFLINE_TRANS_SEND.getTransName());
        }

        // 累计达到设置中“满足自动上送的累计笔数”，终端应主动拨号上送当前所有的离线类交易和IC卡脱机交易
        if (!isSendAllOfflineTrans && notSendRecords.size() < maxOfflineNum) {
            return TransResult.SUCC;
        }

        // 离线交易上送
        int ret = new OfflineTransProc(sendMaxTime, notSendRecords, listener).process();
        if (ret != TransResult.SUCC) {
            return ret;
        }
        // IC卡脱机交易上送

        return TransResult.SUCC;
    }

    /****************************************************************************
     * OfflineTransProc 离线交易上送处理
     ****************************************************************************/
    private class OfflineTransProc{
        private final int sendMaxTime;
        private final List<TransData> records;
        private final TransProcessListener listener;

        private int dupNum = 0;// 重发次数
        private boolean isLastTime = false;
        private int sendCount = 0;
        private TransData transData;
        private int result = TransResult.SUCC;

        OfflineTransProc(int sendMaxTime, List<TransData> records, TransProcessListener listener){
            this.sendMaxTime = sendMaxTime;
            this.records = records;
            this.listener = listener;
        }

        private boolean isFilteredOfflineTran(TransData record){
            // 跳过上送不成功的和应答码非"00"的交易
            return record.getOfflineSendState() == null || !record.getOfflineSendState().equals(OfflineStatus.OFFLINE_NOT_SENT);
        }

        private boolean uploadAll(){
            for (TransData record : records) { // 逐笔上送
                if(isFilteredOfflineTran(record))
                    continue;
                boolean isContinue = handleOnlineResult(record, uploadOne(record));
                if(!isContinue && result != TransResult.SUCC)
                    return false;
            }
            return true;
        }

        private int uploadOne(TransData record){
            sendCount++;
            if (listener != null) {
                listener.onUpdateProgressTitle(ETransType.OFFLINE_TRANS_SEND.getTransName() + "[" + sendCount + "]");
            }
            transData = (TransData) record.clone();
            transData.setTransType(ETransType.OFFLINE_TRANS_SEND);
            Component.transInit(transData);
            transData.setTraceNo(record.getTraceNo());
            return online.online(transData, listener);
        }

        private boolean handleOnlineResult(TransData record, int ret){
            return ret != TransResult.SUCC ? handleOnlineFailedCase(record, ret)
                        : handleOnlineSuccCase(record);
        }

        private boolean handleOnlineFailedCase(TransData record, int ret){
            if (ret == TransResult.ERR_CONNECT || ret == TransResult.ERR_SEND || ret == TransResult.ERR_PACK
                    || ret == TransResult.ERR_MAC) {
                // 如果是发送数据时发生错误(连接错、发送错、数据包错、接收失败、MAC错)，则直接退出，不进行重发
                showErrMsg(TransResult.getMessage(ret));
                result = TransResult.ERR_ABORTED;
                return false;
            }

            // BCTC要求离线交易上送时，如果平台无应答要离线交易上送次数上送
            // 未达到上送次数，继续送， 如果已达到上送次数，但接收失败按失败处理，不再上送
            if (ret == TransResult.ERR_RECV && !isLastTime) {
                return true;
            }
            record.setOfflineSendState(OfflineStatus.OFFLINE_ERR_SEND);
            FinancialApplication.getTransDataDbHelper().updateTransData(record);
            return false;
        }

        private boolean handleOnlineSuccCase(TransData record){
            ResponseCode responseCode = transData.getResponseCode();
            // 返回码失败处理
            if ("A0".equals(responseCode.getCode())) {
                showErrMsg(responseCode.getMessage());
                result = TransResult.ERR_ABORTED;
                return false;
            }
            if (!"00".equals(responseCode.getCode()) && !"94".equals(responseCode.getCode())) { //AET-28
                showErrMsg(responseCode.getMessage());
                record.setOfflineSendState(OfflineStatus.OFFLINE_ERR_RESP);
                FinancialApplication.getTransDataDbHelper().updateTransData(record);
                return true;
            }

            record.setSettleDateTime(transData.getSettleDateTime() != null ? transData.getSettleDateTime() : "");
            record.setAuthCode(transData.getAuthCode() != null ? transData.getAuthCode() : "");
            record.setRefNo(transData.getRefNo());

            record.setAcqCode(transData.getAcqCode() != null ? transData.getAcqCode() : "");
            record.setIssuerCode(transData.getIssuerCode() != null ? transData.getIssuerCode() : "");

            record.setReserved(transData.getReserved() != null ? transData.getReserved() : "");

            record.setAuthCode(transData.getAuthCode());
            record.setOfflineSendState(OfflineStatus.OFFLINE_SENT);
            FinancialApplication.getTransDataDbHelper().updateTransData(record);
            return false;
        }

        int process(){
            while (dupNum < sendMaxTime + 1) {
                sendCount = 0;
                if (dupNum == sendMaxTime) {
                    isLastTime = true;
                }
                if(!uploadAll()){
                    return result;
                }
                dupNum++;
            }
            if (listener != null)
                listener.onHideProgress();
            return TransResult.SUCC;
        }

        private void showErrMsg(String str){
            if (listener != null) {
                listener.onShowErrMessageWithConfirm(str, Constants.FAILED_DIALOG_SHOW_TIME);
            }
        }
    }

    /**
     * 回响功能
     *
     * @return {@link TransResult}
     */
    public int echo(TransProcessListener listener) {
        TransData transData = Component.transInit();
        int ret;
        transData.setTransType(ETransType.ECHO);
        if (listener != null) {
            listener.onUpdateProgressTitle(ETransType.ECHO.getTransName());
        }
        ret = online.online(transData, listener);
        if (ret != TransResult.SUCC) {
            if (listener != null) {
                listener.onHideProgress();
            }
            return ret;
        }
        ret = checkRspCode(transData, listener);
        return ret;
    }
}
