/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action.activity;

import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.Rect;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.pax.abl.core.ActionResult;
import com.pax.edc.R;
import com.pax.pay.BaseActivityWithTickForAction;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.Constants;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.TransResult;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.ToastUtils;
import com.pax.view.ElectronicSignatureView;

public class SignatureActivity extends BaseActivityWithTickForAction {

    public static final String SIGNATURE_FILE_NAME = "customSignature.png";
    public static final String PARAM_TITLE = "title";
    public static final String PARAM_AMOUNT = "amount";

    private ElectronicSignatureView mSignatureView;

    private RelativeLayout writeUserName = null;

    private Button clearBtn;
    private Button confirmBtn;

    private String amount;

    private boolean processing = false;

    private OnKeyListener onkeyListener = new OnKeyListener() {

        @Override
        public boolean onKey(View v, int keyCode, KeyEvent event) {
            if (event.getAction() == KeyEvent.ACTION_DOWN) {
                switch (keyCode) {
                    case KeyEvent.KEYCODE_BACK:
                        clearBtn.performClick();
                        return true;
                    case KeyEvent.KEYCODE_ENTER:
                        confirmBtn.performClick();
                        break;
                    case KeyEvent.KEYCODE_DEL:
                        clearBtn.performClick();
                        break;
                    default:
                        break;
                }
            }
            return false;
        }

    };


    @Override
    protected int getLayoutId() {
        return R.layout.activity_authgraph_layout;
    }

    @Override
    protected void loadParam() {
        Bundle bundle = getIntent().getExtras();
        amount = bundle.getString(EUIParamKeys.TRANS_AMOUNT.toString());
    }

    @Override
    protected void initViews() {

        TextView headerText = (TextView) findViewById(R.id.header_title);
        headerText.setText(R.string.trans_signature);
        ImageView headerBack = (ImageView) findViewById(R.id.header_back);
        headerBack.setVisibility(View.GONE);

        TextView amountText = (TextView) findViewById(R.id.trans_amount_tv);
        amount = CurrencyConverter.convert(Long.parseLong(amount));
        amountText.setText(amount);

        writeUserName = (RelativeLayout) findViewById(R.id.writeUserNameSpace);
        mSignatureView = new ElectronicSignatureView(SignatureActivity.this);
        mSignatureView.setBitmap(new Rect(0, 0, 474, 158), 10, Color.WHITE);
        writeUserName.addView(mSignatureView);

        RelativeLayout.LayoutParams lp = new RelativeLayout.LayoutParams(LayoutParams.WRAP_CONTENT,
                LayoutParams.WRAP_CONTENT);
        lp.addRule(RelativeLayout.CENTER_IN_PARENT);

        clearBtn = (Button) findViewById(R.id.clear_btn);
        confirmBtn = (Button) findViewById(R.id.confirm_btn);

    }

    @Override
    protected void setListeners() {
        clearBtn.setOnClickListener(this);
        confirmBtn.setOnClickListener(this);

        writeUserName.setOnKeyListener(onkeyListener);
        mSignatureView.setOnKeyListener(onkeyListener);
        clearBtn.setOnKeyListener(onkeyListener);
        confirmBtn.setOnKeyListener(onkeyListener);

    }

    @Override
    protected boolean onKeyBackDown() {
        Toast.makeText(SignatureActivity.this, R.string.err_not_allowed, Toast.LENGTH_SHORT).show();
        return true;
    }

    @Override
    public void onClickProtected(View v) {

        switch (v.getId()) {
            case R.id.clear_btn:

                if (isProcessing()) {
                    return;
                }
                setProcessFlag();
                mSignatureView.clear();
                clearProcessFlag();
                break;
            case R.id.confirm_btn:
                Log.i("TAG", "sign confirm_btn");
                if (isProcessing()) {
                    return;
                }
                setProcessFlag();
                if (!mSignatureView.getTouched()) {
                    Log.i("touch", "no touch");
                    clearProcessFlag();
                    return;
                }

                Bitmap bitmap = mSignatureView.save(true, 0);
                // 保存签名图片
                byte[] data = FinancialApplication.getGl().getImgProcessing().bitmapToJbig(bitmap, Constants.rgb2MonoAlgo);

                Log.i("TAG", "电子签名数据长度为:" + data.length);

                if (data.length > 999) {
                    ToastUtils.showMessage(SignatureActivity.this, getString(R.string.signature_redo));
                    setProcessFlag();
                    mSignatureView.clear();
                    clearProcessFlag();
                    return;
                }
                clearProcessFlag();
                finish(new ActionResult(TransResult.SUCC, data));

                break;
            default:
                break;
        }

    }

    protected void setProcessFlag() {
        processing = true;
    }

    protected void clearProcessFlag() {
        processing = false;
    }

    protected boolean isProcessing() {
        return processing;
    }

}