/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.content.Context;
import android.content.Intent;

import com.pax.abl.core.AAction;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.action.activity.SignatureActivity;

public class ActionSignature extends AAction {
    private String amount;
    private Context context;

    public ActionSignature(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(Context context, String amount) {
        this.context = context;
        this.amount = amount;
    }

    @Override
    protected void process() {
        Intent intent = new Intent(context, SignatureActivity.class);
        intent.putExtra(EUIParamKeys.TRANS_AMOUNT.toString(), amount);
        context.startActivity(intent);
    }
}
