/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-10
 * Module Author: xiawh
 * Description:
 *
 * ============================================================================
 */
package com.pax.settings.host;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView.BufferType;
import android.widget.Toast;

import com.pax.edc.R;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.base.Acquirer;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.component.Component;
import com.pax.pay.utils.TextValueWatcher;
import com.pax.pay.utils.Utils;
import com.pax.settings.BaseFragment;
import com.pax.settings.NewSpinnerAdapter;

import java.util.List;

public class AcquirerFragment extends BaseFragment implements CompoundButton.OnCheckedChangeListener {

    private Acquirer acquirer;

    private NewSpinnerAdapter<Acquirer> adapter;

    private EditText etTerminalId;
    private EditText etMerchantId;
    private EditText etNii;
    private EditText etBatch;
    private EditText etIp;
    private EditText etPort;
    private CheckBox isDefault;
    private CheckBox enableTrickFeed;

    //AET-63
    private boolean isFirst = true;

    @Override
    protected int getLayoutId() {
        return R.layout.fragment_acquirer_details;
    }

    @Override
    protected void initData() {
        Bundle bundle = getArguments();
        if (bundle != null) {
            String acqName = bundle.getString(EUIParamKeys.ACQUIRER_NAME.toString());
            acquirer = FinancialApplication.getAcqManager().findAcquirer(acqName);
        }

        List<Acquirer> listAcquirers = FinancialApplication.getAcqManager().findAllAcquirers();
        if (acquirer == null) {
            acquirer = listAcquirers.isEmpty() ? new Acquirer() : listAcquirers.get(0);
        }

        adapter = new NewSpinnerAdapter<>(this.context);
        adapter.setListInfo(listAcquirers);
        adapter.setOnTextUpdateListener(new NewSpinnerAdapter.OnTextUpdateListener() {
            @Override
            public String onTextUpdate(final List<?> list, int position) {
                return ((Acquirer) list.get(position)).getName();
            }
        });

    }

    @Override
    protected void initView(View view) {
        Spinner spinner = (Spinner) view.findViewById(R.id.acquirer_list);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view,
                                       int pos, long id) {
                Acquirer newAcquirer = adapter.getListInfo().get(pos);
                if (newAcquirer.getId() != acquirer.getId()) {
                    //AET-36
                    FinancialApplication.getAcqManager().updateAcquirer(acquirer);
                    acquirer = newAcquirer;
                    updateItemsValue();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Another interface callback
            }
        });

        if (!adapter.getListInfo().isEmpty()) {
            updateItems(view);
            updateItemsValue();
        } else {
            view.findViewById(R.id.acquirer_details).setVisibility(View.GONE);
        }
    }

    private void updateItems(View view) {
        isDefault = (CheckBox) view.findViewById(R.id.acquirer_is_default);
        isDefault.setOnCheckedChangeListener(AcquirerFragment.this);

        ImageView imgCommParam = (ImageView) view.findViewById(R.id.commParam_image);
        imgCommParam.setOnClickListener(AcquirerFragment.this);

        etTerminalId = (EditText) view.findViewById(R.id.terminal_id);
        etTerminalId.addTextChangedListener(new Watcher(R.id.terminal_id));

        etMerchantId = (EditText) view.findViewById(R.id.merchant_id);
        etMerchantId.addTextChangedListener(new Watcher(R.id.merchant_id));

        etNii = (EditText) view.findViewById(R.id.nii_acq);
        etNii.addTextChangedListener(new Watcher(R.id.nii_acq));

        etBatch = (EditText) view.findViewById(R.id.batch_num);
        etBatch.addTextChangedListener(new Watcher(R.id.batch_num));

        etIp = (EditText) view.findViewById(R.id.acq_ip);
        etIp.addTextChangedListener(new Watcher(R.id.acq_ip));

        etPort = (EditText) view.findViewById(R.id.acq_ip_port);
        TextValueWatcher<Integer> textValueWatcher = new TextValueWatcher<>(0, 65535);
        textValueWatcher.setOnCompareListener(new TextValueWatcher.OnCompareListener() {
            @Override
            public boolean onCompare(String value, Object min, Object max) {
                int temp = Integer.parseInt(value);
                return temp >= (int) min && temp <= (int) max;
            }
        });
        textValueWatcher.setOnTextChangedListener(new TextValueWatcher.OnTextChangedListener() {
            @Override
            public void afterTextChanged(String value) {
                acquirer.setPort(Integer.parseInt(value));
            }
        });
        etPort.addTextChangedListener(textValueWatcher);

        enableTrickFeed = (CheckBox) view.findViewById(R.id.acquirer_disable_trick_feed);
        enableTrickFeed.setOnCheckedChangeListener(AcquirerFragment.this);
    }

    private void updateItemsValue() {
        if (acquirer == null)
            return;
        isDefault.setChecked(acquirer.getId() == FinancialApplication.getAcqManager().getCurAcq().getId());

        etTerminalId.setText(acquirer.getTerminalId(), BufferType.EDITABLE);

        etMerchantId.setText(acquirer.getMerchantId(), BufferType.EDITABLE);

        etNii.setText(acquirer.getNii(), BufferType.EDITABLE);

        String szBatchNo = Component.getPaddedNumber(acquirer.getCurrBatchNo(), 6);
        etBatch.setText(szBatchNo, BufferType.EDITABLE);

        etIp.setText(acquirer.getIp());

        etPort.setText(String.valueOf(acquirer.getPort()));

        enableTrickFeed.setChecked(acquirer.isDisableTrickFeed());

        //AET-63
        isFirst = false;
    }

    @Override
    public void onClickProtected(View v) {
        //do nothing
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.acquirer_disable_trick_feed:
                acquirer.setDisableTrickFeed(isChecked);
                break;
            case R.id.acquirer_is_default:
                if (isChecked && acquirer.getId() != FinancialApplication.getAcqManager().getCurAcq().getId())
                    FinancialApplication.getAcqManager().setCurAcq(acquirer);
                //AET-63
                isFirst = true;
                break;
            default:
                break;
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        FinancialApplication.getAcqManager().updateAcquirer(acquirer);
        //AET-36
        String curAcqName = FinancialApplication.getAcqManager().getCurAcq().getName();
        FinancialApplication.getAcqManager().setCurAcq(FinancialApplication.getAcqManager().findAcquirer(curAcqName));
    }

    private class Watcher implements TextWatcher {
        final int id;

        Watcher(int id) {
            this.id = id;
        }

        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            //do nothing
        }

        @Override
        public void afterTextChanged(Editable s) {
            String content = s.toString();
            switch (id) {
                case R.id.terminal_id:
                    acquirer.setTerminalId(content);
                    break;
                case R.id.merchant_id:
                    acquirer.setMerchantId(content);
                    break;
                case R.id.nii_acq:
                    acquirer.setNii(content);
                    break;
                case R.id.batch_num:
                    updateBatchNo(content);
                    break;
                case R.id.acq_ip:
                    if (Utils.checkIp(content))
                        acquirer.setIp(content);
                    break;
                default:
                    break;

            }
        }

        @Override
        public void onTextChanged(CharSequence s, int start, int before, int count) {
            //do nothing for now
        }

        private void updateBatchNo(String content) {
            //AET-63
            if (!isFirst && !FinancialApplication.getTransDataDbHelper().findAllTransData(acquirer).isEmpty()) {
                Toast.makeText(ActivityStack.getInstance().top(), R.string.has_trans_for_settle, Toast.LENGTH_LONG).show();
            } else {
                acquirer.setCurrBatchNo(Integer.parseInt(content));
            }
        }
    }

}
