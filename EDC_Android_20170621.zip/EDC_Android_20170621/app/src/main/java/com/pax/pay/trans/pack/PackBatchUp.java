/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.pack;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.abl.core.ipacker.PackListener;
import com.pax.gl.pack.exception.Iso8583Exception;
import com.pax.pay.trans.model.TransData;

public class PackBatchUp extends PackIso8583 {

    public PackBatchUp(PackListener listener) {
        super(listener);
    }

    @Override
    @NonNull
    public
    byte[] pack(@NonNull TransData transData) {
        try {
            setMandatoryData(transData);

            setCommonData(transData);
            setBitData60(transData);
            return pack(false);
        } catch (Iso8583Exception e) {
            Log.e(TAG, "", e);
        }
        return "".getBytes();
    }

    /**
     * 设置批上送公共数据
     * <p>
     * 设置域： h,m, field 3, field 25, field 41,field 42
     */
    @Override
    protected void setCommonData(@NonNull TransData transData) throws Iso8583Exception {
        //field 2
        setBitData2(transData);

        // field 4 交易金額
        setBitData4(transData);

        // field 11 流水号
        setBitData11(transData);

        //field 12
        setBitData12(transData);

        //field 14
        setBitData14(transData);

        // field 22
        setBitData22(transData);

        //field 37
        setBitData37(transData);
    }

}
