/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.service;

import android.util.Log;

import com.pax.abl.core.ActionResult;
import com.pax.abl.utils.PanUtils;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.action.ActionSearchCard.CardInformation;
import com.pax.pay.trans.component.Component;
import com.pax.pay.trans.model.TransData;
import com.pax.settings.SysParam;

import org.json.JSONException;
import org.json.JSONObject;

public class ParseResp {

    private static final String TAG = "ParseResp";
    private static ParseResp parseResp;

    private ParseResp() {

    }

    public static synchronized ParseResp getInstance() {
        if (parseResp == null) {
            parseResp = new ParseResp();
        }

        return parseResp;
    }

    public String parse(ActionResult result) {
        try {
            String temp;
            JSONObject json = new JSONStringObject();

            if (result == null) {
                json.put(ServiceConstant.RSP_CODE, TransResult.ERR_HOST_REJECT);
                return json.toString();
            }

            ParseReq.RequestData requestData = ParseReq.getInstance().getRequestData();
            if (requestData != null) {
                json.put(ServiceConstant.APP_ID, requestData.getAppId());
            }

            // 应答码
            json.put(ServiceConstant.RSP_CODE, result.getRet());

            if (result.getRet() != TransResult.SUCC) {
                // 错误应答信息
                json.put(ServiceConstant.RSP_MSG, result.getData());
                return json.toString();
            }

            if (result.getData() == null) {
                return json.toString();
            }

            if (result.getData() instanceof CardInformation) {
                CardInformation cardInfo = (CardInformation) result.getData();

                if (cardInfo != null) {
                    json.put(ServiceConstant.CARD_NO, cardInfo.getPan());
                }

                return json.toString();
            }

            // 商户名称
            json.put(ServiceConstant.MERCH_NAME, FinancialApplication.getSysParam().get(SysParam.StringParam.EDC_MERCHANT_NAME_EN));
            // 商户编号
            json.put(ServiceConstant.MERCH_ID, FinancialApplication.getAcqManager().getCurAcq().getMerchantId());
            // 终端编号
            json.put(ServiceConstant.TERM_ID, FinancialApplication.getAcqManager().getCurAcq().getTerminalId());

            TransData transData = (TransData) result.getData();

            // 卡号
            json.put(ServiceConstant.CARD_NO, PanUtils.maskCardNo(transData.getPan(), transData.getIssuer().getPanMaskPattern()));

            // 凭证号
            temp = String.valueOf(transData.getTraceNo());
            if (!temp.isEmpty()) {
                json.put(ServiceConstant.VOUCHER_NO, Component.getPaddedNumber(transData.getTraceNo(), 6));
            }

            // 批次号
            temp = String.valueOf(transData.getBatchNo());
            if (!temp.isEmpty()) {
                json.put(ServiceConstant.BATCH_NO, Component.getPaddedNumber(transData.getBatchNo(), 6));
            }

            // 发卡行号
            json.put(ServiceConstant.ISSER_CODE, transData.getIssuerCode());

            // 收单行号
            json.put(ServiceConstant.ACQ_CODE, transData.getAcqCode());

            // 授权码
            json.put(ServiceConstant.AUTH_NO, transData.getAuthCode());

            // 参考号
            json.put(ServiceConstant.REF_NO, transData.getRefNo());

            // 交易时间/日期
            temp = transData.getDateTime();
            if (temp != null && !temp.isEmpty()) {
                json.put(ServiceConstant.TRANS_TIME, temp.substring(8));
                json.put(ServiceConstant.TRANS_DATE, temp.substring(4, 8));
            }

            // 交易金额
            json.put(ServiceConstant.TRANS_AMOUNT, transData.getAmount());

            // 原授权码
            json.put(ServiceConstant.ORIG_AUTH_NO, transData.getOrigAuthCode());

            // 原凭证号
            temp = String.valueOf(transData.getOrigTransNo());
            if (!temp.isEmpty() && !"0".equals(temp)) {
                json.put(ServiceConstant.ORIG_VOUCHER_NO, Component.getPaddedNumber(transData.getOrigTransNo(), 6));
            }

            // 原参考号
            json.put(ServiceConstant.ORIG_REF_NO, transData.getOrigRefNo());

            return json.toString();
        } catch (JSONException e) {
            Log.e(TAG, "", e);

        }
        return null;
    }

    private class JSONStringObject extends JSONObject {
        @Override
        public JSONObject put(String name, Object value) throws JSONException {
            if (value != null && !((String) value).isEmpty()) {
                return super.put(name, value);
            }
            return this;
        }
    }

}
