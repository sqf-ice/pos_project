/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-26
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.utils;

import com.pax.edc.R;
import com.pax.pay.app.FinancialApplication;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

public class ResponseCode implements Serializable {
    private static final long serialVersionUID = 1L;

    private String code;
    private String message;
    private HashMap<String, ResponseCode> map;
    private static ResponseCode rcCode;

    private static Map<String, Integer> responses = new HashMap<>();

    static {
        responses.put("00", R.string.response_00);
        responses.put("01", R.string.response_01);
        responses.put("03", R.string.response_03);
        responses.put("04", R.string.response_04);
        responses.put("05", R.string.response_05);
        responses.put("08", R.string.response_08);

        responses.put("12", R.string.response_12);
        responses.put("13", R.string.response_13);
        responses.put("14", R.string.response_14);
        responses.put("19", R.string.response_19);

        responses.put("21", R.string.response_21);
        responses.put("25", R.string.response_25);

        responses.put("30", R.string.response_30);

        responses.put("41", R.string.response_41);
        responses.put("43", R.string.response_43);

        responses.put("51", R.string.response_51);
        responses.put("54", R.string.response_54);
        responses.put("55", R.string.response_55);
        responses.put("58", R.string.response_58);

        responses.put("60", R.string.response_60);

        responses.put("76", R.string.response_76);
        responses.put("77", R.string.response_77);
        responses.put("78", R.string.response_78);

        responses.put("80", R.string.response_80);
        responses.put("85", R.string.response_85);
        responses.put("88", R.string.response_88);
        responses.put("89", R.string.response_89);

        responses.put("91", R.string.response_91);
        responses.put("94", R.string.response_94);
        responses.put("95", R.string.response_95);
        responses.put("96", R.string.response_96);
        responses.put("97", R.string.response_97);

        responses.put("N1", R.string.response_N1);
        responses.put("Q1", R.string.response_Q1);
        responses.put("Y1", R.string.response_Y1);
        responses.put("Z1", R.string.response_Z1);

        responses.put("Y2", R.string.response_Y2);
        responses.put("Z2", R.string.response_Z2);

        responses.put("Y3", R.string.response_Y3);
        responses.put("Z3", R.string.response_Z3);

        responses.put("NA", R.string.response_NA);
        responses.put("P0", R.string.response_P0);
        responses.put("XY", R.string.response_XY);
        responses.put("XX", R.string.response_XX);
    }

    private ResponseCode() {
        if (map == null)
            map = new HashMap<>();
    }

    private ResponseCode(String code, String message) {
        this.code = code;
        this.message = message;
    }

    public static ResponseCode getInstance() {
        if (rcCode == null) {
            rcCode = new ResponseCode();
        }
        return rcCode;
    }

    /**
     * init方法必须调用， 一般放在应用启动的时候
     */
    public void init() {
        for (String i : responses.keySet()) {
            String msg = findResponse(i);
            ResponseCode rspCode = new ResponseCode(i, msg);
            map.put(i, rspCode);
        }
    }

    public ResponseCode parse(String code) {
        ResponseCode rc = map.get(code);
        if (rc == null)
            return new ResponseCode(code, Utils.getString(R.string.err_undefine_info));
        return rc;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    private static String findResponse(final String code) {
        Integer id = responses.get(code);
        if (id == null) {
            id = R.string.response_unknown;
        }
        return FinancialApplication.getApp().getString(id);
    }

    @Override
    public String toString() {
        return this.getCode() + "\n" + this.getMessage();
    }
}
