/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-30
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.settings;

import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.RingtonePreference;
import android.support.annotation.XmlRes;
import android.widget.Toast;

import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.glwrapper.convert.IConvert.EPaddingPosition;
import com.pax.pay.app.FinancialApplication;

public class KeyManageFragment extends BasePreferenceFragment {
    @Override
    @XmlRes
    protected
    int getResourceId() {
        return R.xml.key_manage_pref;
    }

    @Override
    protected void initPreference() {
        bindPreference(SysParam.NumberParam.MK_INDEX);
        bindPreference(SysParam.StringParam.KEY_ALGORITHM);
        bindPreference(SysParam.NumberParam.MK_INDEX_MANUAL);
        bindPreference(SysParam.StringParam.MK_VALUE);
        bindPreference(SysParam.StringParam.PK_VALUE);
        bindPreference(SysParam.StringParam.AK_VALUE);
    }

    @Override
    protected boolean onCheckBoxPreferenceChanged(CheckBoxPreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    @Override
    protected boolean onRingtonePreferenceChanged(RingtonePreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    private void writeMK(EditTextPreference preference, String stringValue) {
        int index = FinancialApplication.getSysParam().get(SysParam.NumberParam.MK_INDEX_MANUAL, -1);
        if ((index < 0) || (index >= 100)) {
            Toast.makeText(preference.getContext(), R.string.keyManage_menu_tmk_index_no,
                    Toast.LENGTH_SHORT).show();
        } else {
            if (stringValue.length() != 16) {
                Toast.makeText(preference.getContext(), R.string.input_len_err, Toast.LENGTH_SHORT).show();
            } else {
                // 写主密钥
                if (Device.writeTMK((byte) index,
                        FinancialApplication.getConvert().strToBcd(stringValue, EPaddingPosition.PADDING_LEFT))) {
                    Device.beepOk();
                    Toast.makeText(preference.getContext(), R.string.set_key_success, Toast.LENGTH_SHORT).show();
                    //Don't return true cuz we don't want to write it to file
                } else {
                    Device.beepErr();
                    Toast.makeText(preference.getContext(), R.string.set_key_fail, Toast.LENGTH_SHORT).show();
                }
            }
        }
    }

    private void writePK(EditTextPreference preference, String stringValue) {
        if (stringValue.length() != 16) {
            Toast.makeText(preference.getContext(), R.string.input_len_err, Toast.LENGTH_SHORT).show();
        } else {
            if (Device.writeTPK(FinancialApplication.getConvert().strToBcd(stringValue,
                    EPaddingPosition.PADDING_LEFT), null)) {
                Device.beepOk();
                Toast.makeText(preference.getContext(), R.string.set_key_success, Toast.LENGTH_SHORT).show();
            } else {
                Device.beepErr();
                Toast.makeText(preference.getContext(), R.string.set_key_fail, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void writeAK(EditTextPreference preference, String stringValue) {
        if (stringValue.length() != 16) {
            Toast.makeText(preference.getContext(), R.string.input_len_err, Toast.LENGTH_SHORT).show();
        } else {
            if (Device.writeTAK(FinancialApplication.getConvert().strToBcd(stringValue,
                    EPaddingPosition.PADDING_LEFT), null)) {
                Device.beepOk();
                Toast.makeText(preference.getContext(), R.string.set_key_success, Toast.LENGTH_SHORT).show();
            } else {
                Device.beepErr();
                Toast.makeText(preference.getContext(), R.string.set_key_fail, Toast.LENGTH_SHORT).show();
            }
        }
    }

    private boolean writeMKIndex(EditTextPreference preference, String stringValue) {
        boolean failed = false;
        int intValue = Integer.parseInt(stringValue);
        if (intValue < 0 || intValue >= 100) {
            failed = true;
        } else {
            preference.setSummary(stringValue);
        }

        if (failed) {
            Toast.makeText(preference.getContext(), R.string.input_err, Toast.LENGTH_SHORT).show();
        }

        return !failed;
    }

    @Override
    protected boolean onEditTextPreferenceChanged(EditTextPreference preference, Object value, boolean isInitLoading) {
        String key = preference.getKey();
        String stringValue = value.toString();

        if (SysParam.StringParam.MK_VALUE.toString().equals(key)) {
            if (!isInitLoading) {
                writeMK(preference, stringValue);
            }
            return false;
        } else if (SysParam.StringParam.PK_VALUE.toString().equals(key)) {
            if (!isInitLoading) {
                writePK(preference, stringValue);
            }
            return false;
        } else if (SysParam.StringParam.AK_VALUE.toString().equals(key)) {
            if (!isInitLoading) {
                writeAK(preference, stringValue);
            }
            return false;
        } else if (SysParam.NumberParam.MK_INDEX.toString().equals(key)
                || SysParam.NumberParam.MK_INDEX_MANUAL.toString().equals(key)) {
            return writeMKIndex(preference, stringValue);
        } else {
            preference.setSummary(value.toString());
        }
        return true;
    }

    @Override
    protected boolean onListPreferenceChanged(ListPreference preference, Object value,
                                              boolean isInitLoading) {
        String stringValue = value.toString();
        int index = preference.findIndexOfValue(stringValue);
        preference.setSummary(index >= 0 ? preference.getEntries()[index] : null);
        return true;
    }

    @Override
    protected boolean onMultiSelectListPreferenceChanged(MultiSelectListPreference preference, Object value, boolean isInitLoading) {
        return false;
    }
}
