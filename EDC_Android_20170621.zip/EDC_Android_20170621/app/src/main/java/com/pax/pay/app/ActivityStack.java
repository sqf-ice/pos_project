/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.app;

import android.app.Activity;
import android.util.Log;

import java.util.Deque;
import java.util.LinkedList;

public class ActivityStack {
    private static final String TAG = "ActivityStack";

    private Deque<Activity> activities;
    private static ActivityStack instance;

    private ActivityStack() {
        activities = new LinkedList<>();
    }

    public static ActivityStack getInstance() {
        if (instance == null)
            instance = new ActivityStack();

        return instance;
    }

    public void pop() {
        try {
            Activity activity = top();
            if (activity != null) {
                remove(activity);
            }
        } catch (Exception e) {
            Log.w(TAG, e);
        }
    }

    /**
     * 从栈的后面开始删除，知道删除自身界面为止
     *
     * @param activity the specific activity
     */
    public void popTo(Activity activity) {
        if (activity != null) {
            while (true) {
                Activity lastCurrent = top();
                if (activity == top()) {
                    return;
                }
                remove(lastCurrent);
            }
        }
    }

    public Activity top() {
        try {
            return activities.getLast();
        } catch (Exception e) {
            Log.w(TAG, e);
        }
        return null;
    }

    public void push(Activity activity) {
        activities.addLast(activity);
    }

    // 查找栈中是否存在指定的activity
    public boolean find(Class<?> cls) {
        for (Activity activity : activities) {
            if (activity.getClass().equals(cls)) {
                return true;
            }
        }
        return false;
    }

    /**
     * 除站底外，其他pop掉
     */
    public void popAllButBottom() {
        while (true) {
            Activity topActivity = top();
            if (topActivity == null || topActivity == bottom()) {
                break;
            }
            remove(topActivity);
        }

    }

    /**
     * 结束所有栈中的activity
     */
    public void popAll() {
        if (activities == null) {
            return;
        }
        while (true) {
            Activity activity = top();
            if (activity == null) {
                break;
            }
            remove(activity);
        }
    }

    public Activity bottom() {
        return activities.getFirst();
    }

    private void remove(Activity activity) {
        activity.finish();
        activities.remove(activity);
    }
}
