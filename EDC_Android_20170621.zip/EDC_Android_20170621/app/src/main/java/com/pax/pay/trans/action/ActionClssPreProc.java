/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-3-16
 * Module Author: laiyi
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.device.Device;
import com.pax.device.DeviceImplNeptune;
import com.pax.glwrapper.convert.IConvert;
import com.pax.jemv.clcommon.Clss_PreProcInfo;
import com.pax.jemv.clcommon.Clss_TransParam;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.device.DeviceManager;
import com.pax.jemv.entrypoint.api.ClssEntryApi;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.clss.ClssTransProcess;
import com.pax.pay.constant.Constants;
import com.pax.pay.emv.EmvAid;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.utils.Utils;
import com.pax.settings.SysParam;

import java.util.List;

public class ActionClssPreProc extends AAction {

    private TransData transData;
    private ClssTransProcess clssTransProcess;

    public ActionClssPreProc(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(ClssTransProcess clssTransProcess, TransData transData) {
        this.clssTransProcess = clssTransProcess;
        this.transData = transData;
    }

    @Override
    protected void process() {
        FinancialApplication.getApp().runInBackground(new ProcessRunnable());
    }

    private class ProcessRunnable implements Runnable {

        ProcessRunnable() {
            DeviceManager.getInstance().setIDevice(DeviceImplNeptune.getInstance());

            if (ClssEntryApi.Clss_CoreInit_Entry() != RetCode.EMV_OK) {
                setResult(new ActionResult(TransResult.ERR_CLSS_PRE_PROC, null));
                return;
            }
            addApp();
        }

        @Override
        public void run() {
            long ulAmtAuth = Long.parseLong(transData.getAmount());
            String date = Device.getTime(Constants.TIME_PATTERN_TRANS2).substring(0, 6);
            String time = Device.getTime(Constants.TIME_PATTERN_TRANS2).substring(6);
            byte[] dateByte = FinancialApplication.getConvert().strToBcd(date, IConvert.EPaddingPosition.PADDING_RIGHT);
            byte[] timeByte = FinancialApplication.getConvert().strToBcd(time, IConvert.EPaddingPosition.PADDING_RIGHT);

            Clss_TransParam clssTransParam = new Clss_TransParam(ulAmtAuth, 0,
                    FinancialApplication.getSysParam().get(SysParam.NumberParam.EDC_TRACE_NO),
                    (byte) 0x00, dateByte, timeByte);
            clssTransProcess.setClssTransParam(clssTransParam);

            if (ClssEntryApi.Clss_PreTransProc_Entry(clssTransParam) != RetCode.EMV_OK) {
                setResult(new ActionResult(TransResult.ERR_CLSS_PRE_PROC, null));
                return;
            }

            setResult(new ActionResult(TransResult.SUCC, null));
        }

        private Clss_PreProcInfo getClssPreProcInfo(byte[] aucAID, byte ucAidLen) {
            byte[] ttq = new byte[]{(byte) 0x36, (byte) 0x00, (byte) 0x80, (byte) 0x00};
            return new Clss_PreProcInfo(5000, 100000, 3000, 5000, aucAID, ucAidLen, (byte) 0,
                    (byte) 1, (byte) 0, (byte) 0, ttq, (byte) 1, (byte) 1, (byte) 1, (byte) 1, new byte[2]);
        }

        private void addApp() {
            List<EmvAid> aidList = FinancialApplication.getEmvDbHelper().findAllAID();
            Clss_PreProcInfo[] clssPreProcInfos = new Clss_PreProcInfo[aidList.size()];
            for (int i = 0; i < aidList.size(); ++i) {
                ClssEntryApi.Clss_AddAidList_Entry(Utils.str2Bcd(aidList.get(i).getAid()),
                        (byte) (aidList.get(i).getAid().length() / 2), (byte) aidList.get(i).getSelFlag(), (byte) KernType.KERNTYPE_DEF);
                Clss_PreProcInfo clssPreProcInfo = getClssPreProcInfo(Utils.str2Bcd(aidList.get(i).getAid()), (byte) (aidList.get(i).getAid().length() / 2));
                clssPreProcInfos[i] = clssPreProcInfo;
                ClssEntryApi.Clss_SetPreProcInfo_Entry(clssPreProcInfo);
            }
            clssTransProcess.setClssPreProcInfo(clssPreProcInfos);
        }
    }

}
