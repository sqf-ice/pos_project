/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.app.Activity;
import android.content.Context;
import android.util.Log;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.device.Device;
import com.pax.device.DeviceImplNeptune;
import com.pax.edc.R;
import com.pax.eemv.IEmv;
import com.pax.eemv.enums.ETransResult;
import com.pax.eemv.exception.EEmvExceptions;
import com.pax.eemv.exception.EmvException;
import com.pax.eventbus.EmvCallbackEvent;
import com.pax.jemv.device.DeviceManager;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.constant.Constants;
import com.pax.pay.emv.EmvListenerImpl;
import com.pax.pay.emv.EmvTransProcess;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.model.TransData.EnterMode;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.trans.transmit.TransProcessListenerImpl;
import com.pax.settings.SysParam;

import org.greenrobot.eventbus.Subscribe;
import org.greenrobot.eventbus.ThreadMode;

public class ActionEmvProcess extends AAction {
    private Context context;
    private IEmv emv;
    private TransData transData;
    private TransProcessListener transProcessListener;
    private EmvListenerImpl emvListener;

    public ActionEmvProcess(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(Context context, IEmv emv, TransData transData) {
        this.context = context;
        this.emv = emv;
        this.transData = transData;
        transProcessListener = new TransProcessListenerImpl(context);
        emvListener = new EmvListenerImpl(context, emv, transData, transProcessListener);
    }

    @SuppressWarnings("unused")
    @Subscribe(threadMode = ThreadMode.BACKGROUND)
    public void onCardNumConfirmEvent(EmvCallbackEvent event) {
        switch ((EmvCallbackEvent.Status) event.getStatus()) {
            case OFFLINE_PIN_ENTER_READY:
                emvListener.offlinePinEnterReady();
                break;
            case CARD_NUM_CONFIRM_SUCCESS:
                emvListener.cardNumConfigSucc((String[]) event.getData());
                break;
            case CARD_NUM_CONFIRM_ERROR:
            default:
                emvListener.cardNumConfigErr();
                break;
        }
    }

    @Override
    protected void process() {
        DeviceManager.getInstance().setIDevice(DeviceImplNeptune.getInstance());
        FinancialApplication.getApp().runInBackground(new ProcessRunnable());
    }

    private class ProcessRunnable implements Runnable {
        private EmvTransProcess emvTransProcess;

        ProcessRunnable() {
            if (transData.getEnterMode() == EnterMode.INSERT) {
                transProcessListener.onShowProgress(context.getString(R.string.wait_process), 0);
            }
            emvTransProcess = new EmvTransProcess(emv);
            emvTransProcess.init();
        }

        @Override
        public void run() {
            try {
                FinancialApplication.getApp().register(ActionEmvProcess.this);
                ETransResult result = emvTransProcess.transProcess(transData, emvListener);
                transProcessListener.onHideProgress();
                setResult(new ActionResult(TransResult.SUCC, result));
            } catch (EmvException e) {
                Log.e(TAG, "", e);
                handleException(e);
            } finally {
                byte[] value95 = emv.getTlv(0x95);
                byte[] value9B = emv.getTlv(0x9B);

                Log.e("TLV", "95:" + FinancialApplication.getConvert().bcdToStr(value95));
                Log.e("TLV", "9b:" + FinancialApplication.getConvert().bcdToStr(value9B));

                // no memory leak
                emv.setListener(null);
                FinancialApplication.getApp().unregister(ActionEmvProcess.this);
            }
        }

        private void handleException(EmvException e) {
            ActivityStack.getInstance().popTo((Activity) context);
            String commType = FinancialApplication.getSysParam().get(SysParam.StringParam.COMM_TYPE);
            if (SysParam.Constant.CommType.DEMO.toString().equals(commType) &&
                    e.getErrCode() == EEmvExceptions.EMV_ERR_UNKNOWN.ordinal()) {
                transProcessListener.onHideProgress();
                // end the EMV process, and continue a mag process
                setResult(new ActionResult(TransResult.SUCC, ETransResult.ARQC));
                return;
            }

            Device.beepErr();
            if (e.getErrCode() != EEmvExceptions.EMV_ERR_UNKNOWN.ordinal()) {
                if (e.getErrCode() == EEmvExceptions.EMV_ERR_FALL_BACK.ordinal()) {
                    transProcessListener.onShowNormalMessageWithConfirm(
                            context.getString(R.string.prompt_fall_back),
                            Constants.SUCCESS_DIALOG_SHOW_TIME);
                    transProcessListener.onHideProgress();
                    setResult(new ActionResult(TransResult.NEED_FALL_BACK, null));
                    return;
                } else if (e.getErrCode() == EEmvExceptions.EMV_ERR_USER_CANCEL.ordinal()) {
                    // 用户取消， 不提示
                    transProcessListener.onShowErrMessageWithConfirm(
                            context.getString(R.string.err_user_cancel),
                            Constants.FAILED_DIALOG_SHOW_TIME);
                } else {
                    transProcessListener.onShowErrMessageWithConfirm(e.getErrMsg(),
                            Constants.FAILED_DIALOG_SHOW_TIME);
                }
            }
            transProcessListener.onHideProgress();
            setResult(new ActionResult(TransResult.ERR_ABORTED, null));
        }
    }
}

