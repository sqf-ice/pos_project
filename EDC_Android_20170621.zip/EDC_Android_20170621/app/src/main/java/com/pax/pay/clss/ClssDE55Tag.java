/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-4-25
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import java.util.List;

public class ClssDE55Tag {
    private byte[] emvTag;
    private byte option;
    private byte len;

    public static final byte DE55_MUST_SET = 0x10;// 必须存在
    public static final byte DE55_OPT_SET = 0x20;// 可选择存在
    public static final byte DE55_COND_SET = 0x30;// 根据条件存在

    public ClssDE55Tag(byte[] uiEmvTag, byte ucOption, byte ucLen) {
        this.emvTag = uiEmvTag;
        this.option = ucOption;
        this.len = ucLen;
    }

    public byte[] getEmvTag() {
        return emvTag;
    }

    public void setEmvTag(byte[] emvTag) {
        this.emvTag = emvTag;
    }

    public byte getOption() {
        return option;
    }

    public void setOption(byte option) {
        this.option = option;
    }

    public byte getLen() {
        return len;
    }

    public void setLen(byte len) {
        this.len = len;
    }

    // 非接消费55域标签
    public static void addClssDE55Tags(List<ClssDE55Tag> clssDE55Tags) {
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x57}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x5A}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x5F, 0x24}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x5F, 0x2A}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.PAN_SEQ_NO, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x82}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x84}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.TVR, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.TRANS_DATE, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.TSI, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.TRANS_TYPE, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.AMOUNT, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.AMOUNT_OTHER, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x08}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x09}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x10}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.COUNTRY_CODE, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x1E}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.APP_CRYPTO, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.CRYPTO, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x33}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x34}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x35}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(ClssTlvTag.ATC, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x37}, DE55_MUST_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x41}, DE55_OPT_SET, (byte) 0));
        clssDE55Tags.add(new ClssDE55Tag(new byte[]{(byte) 0x9F, 0x5B}, DE55_OPT_SET, (byte) 0));
    }
}
