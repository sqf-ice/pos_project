/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-2-28
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.clss;

import android.util.Log;

import com.pax.eventbus.SearchCardEvent;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.Clss_PreProcInfo;
import com.pax.jemv.clcommon.Clss_PreProcInterInfo;
import com.pax.jemv.clcommon.Clss_TransParam;
import com.pax.jemv.clcommon.KernType;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.entrypoint.api.ClssEntryApi;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;

public class ClssTransProcess {

    private static final String TAG = "ClssTransProcess";

    private KernType kernType;
    private Clss_PreProcInfo[] clssPreProcInfo;
    private Clss_TransParam clssTransParam;
    private ClssProc clssProc = null;

    public CTransResult transProcess(TransData transData, TransProcessListener transProcessListener) {

        CTransResult result = new CTransResult();

        FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.CLSS_LIGHT_STATUS_PROCESSING));

        int ret = ClssEntryApi.Clss_SetMCVersion_Entry((byte) 0x03);
        Log.i("clssEntrySetMCVersion", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        ret = ClssEntryApi.Clss_AppSlt_Entry(0, 0);
        Log.i("clssEntryAppSlt", "ret = " + ret);
        if (ret != RetCode.EMV_OK) {
            result.setTransResult(ret);
            return result;
        }

        while (true) {
            kernType = new KernType();
            ByteArray daArray = new ByteArray();
            ret = ClssEntryApi.Clss_FinalSelect_Entry(kernType, daArray);// output parameter?
            Log.i("clssEntryFinalSelect", "ret = " + ret + ", Kernel Type = " + kernType.kernType);
            if (ret == RetCode.EMV_RSP_ERR || ret == RetCode.EMV_APP_BLOCK
                    || ret == RetCode.ICC_BLOCK || ret == RetCode.CLSS_RESELECT_APP) {
                ret = ClssEntryApi.Clss_DelCurCandApp_Entry();
                if (ret != RetCode.EMV_OK) {
                    // 候选列表为空，进行相应错误处理，退出
                    result.setTransResult(ret);
                    return result;
                }
                continue;
            } else if (ret != RetCode.EMV_OK) {
                result.setTransResult(ret);
                return result;
            }

            Clss_PreProcInterInfo clssPreProcInterInfo = new Clss_PreProcInterInfo();
            ret = ClssEntryApi.Clss_GetPreProcInterFlg_Entry(clssPreProcInterInfo);
            if (ret != RetCode.EMV_OK) {
                result.setTransResult(ret);
                return result;
            }

            ByteArray byteArray = new ByteArray();
            ret = ClssEntryApi.Clss_GetFinalSelectData_Entry(byteArray);
            if (ret != RetCode.EMV_OK) {
                result.setTransResult(ret);
                return result;
            }

            try {
                clssProc = ClssProc.generate(kernType.kernType)
                        .setAid(daArray.data, daArray.length)
                        .setFinalSelectData(byteArray.data, byteArray.length)
                        .setClssTransParam(clssTransParam)
                        .setClssPreProcInfo(clssPreProcInfo)
                        .setClssPreProcInterInfo(clssPreProcInterInfo);
            } catch (IllegalArgumentException e) {
                Log.e(TAG, "", e);
                result.setTransResult(CTransResult.UNSUPPORTED_KERNEL);
                return result;
            }

            result = clssProc.process(transData, transProcessListener);
            if (result.getTransResult() != RetCode.CLSS_RESELECT_APP) {
                return result;
            }
            ret = ClssEntryApi.Clss_DelCurCandApp_Entry();
            if (ret != RetCode.EMV_OK) {
                result.setTransResult(ret);
                return result;
            }
        }
    }

    public void resultProcess(CTransResult result, TransData transData) {
        if (clssProc != null)
            clssProc.resultProcess(result, transData);
    }

    public Clss_PreProcInfo[] getClssPreProcInfo() {
        return clssPreProcInfo;
    }

    public void setClssPreProcInfo(Clss_PreProcInfo[] clssPreProcInfo) {
        this.clssPreProcInfo = clssPreProcInfo;
    }

    public Clss_TransParam getClssTransParam() {
        return clssTransParam;
    }

    public void setClssTransParam(Clss_TransParam clssTransParam) {
        this.clssTransParam = clssTransParam;
    }

    public int getKernType() {
        return kernType.kernType;
    }

    public int getTransPath() {
        return clssProc.getTransPath();
    }

    public void completeTrans(TransData transData) {
        if (clssProc != null)
            clssProc.completeTrans(transData);
    }
}
