/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-11
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.content.Context;
import android.content.Intent;

import com.pax.abl.core.AAction;
import com.pax.pay.constant.EUIParamKeys;
import com.pax.pay.trans.action.activity.EnterAmountActivity;

public class ActionEnterAmount extends AAction {
    private Context context;
    private String title;
    private boolean hasTip;
    private float percent;

    public ActionEnterAmount(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(Context context, String title, boolean hasTip, float percent) {
        this.context = context;
        this.title = title;
        this.hasTip = hasTip;
        this.percent = percent;
    }

    public void setParam(Context context, String title, boolean hasTip) {
        this.context = context;
        this.title = title;
        this.hasTip = hasTip;
    }

    @Override
    protected void process() {
        Intent intent = new Intent(context, EnterAmountActivity.class);
        intent.putExtra(EUIParamKeys.NAV_TITLE.toString(), title);
        intent.putExtra(EUIParamKeys.HAS_TIP.toString(), hasTip);
        if (hasTip) {
            intent.putExtra(EUIParamKeys.TIP_PERCENT.toString(), percent);
        }
        context.startActivity(intent);
    }
}
