/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-1-10
 * Module Author: xiawh
 * Description:
 *
 * ============================================================================
 */
package com.pax.settings.host;

import android.preference.CheckBoxPreference;
import android.preference.EditTextPreference;
import android.preference.ListPreference;
import android.preference.MultiSelectListPreference;
import android.preference.RingtonePreference;
import android.support.annotation.XmlRes;
import android.text.InputType;
import android.util.Log;
import android.widget.Toast;

import com.pax.edc.R;
import com.pax.pay.app.ActivityStack;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.utils.CurrencyConverter;
import com.pax.pay.utils.Utils;
import com.pax.settings.BasePreferenceFragment;
import com.pax.settings.SysParam;
import com.pax.view.widget.BaseWidget;

import java.util.Currency;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

public class EDCFragment extends BasePreferenceFragment {

    private static CharSequence[] entries;
    private static CharSequence[] entryValues;

    // AET-116
    private static void updateEntries() {
        Map<String, String> allEntries = new TreeMap<>();
        List<Locale> locales = CurrencyConverter.getSupportedLocale();
        for (Locale i : locales) {
            try {
                Currency currency = Currency.getInstance(i);
                Log.i("TAG", i.getISO3Country() + "  " + i.getDisplayName(Locale.US) + " " + currency.getDisplayName(Locale.US));
                allEntries.put(i.getDisplayName(Locale.US) + " " + currency.getDisplayName(), i.getDisplayName(Locale.US));
            } catch (IllegalArgumentException e) {
                Log.d(TAG, "", e);
            }
        }
        entries = allEntries.keySet().toArray(new CharSequence[allEntries.size()]);
        entryValues = allEntries.values().toArray(new CharSequence[allEntries.size()]);
    }

    @Override
    @XmlRes
    protected
    int getResourceId() {
        return R.xml.edc_para_pref;
    }

    @Override
    protected void initPreference() {
        updateEntries();

        bindListPreference(SysParam.StringParam.EDC_CURRENCY_LIST, entries, entryValues);

        bindPreference(SysParam.StringParam.EDC_MERCHANT_NAME_EN);
        bindPreference(SysParam.StringParam.EDC_MERCHANT_ADDRESS);
        bindPreference(SysParam.StringParam.EDC_CURRENCY_LIST);
        bindPreference(SysParam.StringParam.EDC_PED_MODE);
        bindPreference(SysParam.NumberParam.EDC_RECEIPT_NUM);
        bindPreference(SysParam.NumberParam.EDC_TRACE_NO);
        bindPreference(SysParam.BooleanParam.EDC_SUPPORT_TIP);
        bindPreference(SysParam.BooleanParam.EDC_SUPPORT_KEYIN);

        bindPreference(SysParam.BooleanParam.SUPPORT_USER_AGREEMENT);
        bindPreference(SysParam.BooleanParam.EDC_ENABLE_PAPERLESS);
        bindPreference(SysParam.StringParam.EDC_SMTP_HOST);
        bindPreference(SysParam.NumberParam.EDC_SMTP_PORT);
        bindPreference(SysParam.StringParam.EDC_SMTP_USERNAME);
        bindPreference(SysParam.StringParam.EDC_SMTP_PASSWORD);
        bindPreference(SysParam.BooleanParam.EDC_SMTP_ENABLE_SSL);
        bindPreference(SysParam.NumberParam.EDC_SMTP_SSL_PORT);
        bindPreference(SysParam.StringParam.EDC_SMTP_FROM);
    }

    @Override
    protected boolean onListPreferenceChanged(ListPreference preference, Object value, boolean isInitLoading) {
        String stringValue = value.toString();
        int index = preference.findIndexOfValue(stringValue);

        if (SysParam.StringParam.EDC_CURRENCY_LIST.toString().equals(preference.getKey()) && index >= 0) {
            if (!isInitLoading && FinancialApplication.getTransDataDbHelper().countOf() > 0) {
                Toast.makeText(ActivityStack.getInstance().top(), R.string.has_trans_for_settle, Toast.LENGTH_LONG).show();
                return false;
            } else {
                preference.setSummary(index >= 0 ? preference.getEntries()[index] : null);
                if (!isInitLoading && !CurrencyConverter.getDefCurrency().getCountry().equals(preference.getEntryValues()[index].toString())) {
                    BaseWidget.updateWidget(FinancialApplication.getApp());
                    Utils.changeAppLanguage(FinancialApplication.getApp(), CurrencyConverter.setDefCurrency(preference.getEntryValues()[index].toString()));

                    Utils.restart();
                }
            }
            return true;
        }
        preference.setSummary(index >= 0 ? preference.getEntries()[index] : null);
        return true;
    }

    @Override
    protected boolean onCheckBoxPreferenceChanged(CheckBoxPreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    @Override
    protected boolean onRingtonePreferenceChanged(RingtonePreference preference, Object value, boolean isInitLoading) {
        return true;
    }

    @Override
    protected boolean onEditTextPreferenceChanged(EditTextPreference preference, Object value, boolean isInitLoading) {
        String stringValue = value.toString();
        if ((preference.getEditText().getInputType() & InputType.TYPE_TEXT_VARIATION_PASSWORD) == InputType.TYPE_TEXT_VARIATION_PASSWORD) {
            String temp = !stringValue.isEmpty() ? "******" : stringValue;
            preference.setSummary(temp);
        } else {
            preference.setSummary(stringValue);
        }
        return true;
    }

    @Override
    protected boolean onMultiSelectListPreferenceChanged(MultiSelectListPreference preference, Object value, boolean isInitLoading) {
        return false;
    }
}
