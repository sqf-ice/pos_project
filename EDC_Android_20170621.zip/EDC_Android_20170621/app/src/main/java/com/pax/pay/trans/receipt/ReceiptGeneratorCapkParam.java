/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.receipt;

import android.content.Context;

import com.pax.device.Device;
import com.pax.gl.page.IPage;
import com.pax.gl.page.IPage.EAlign;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.emv.EmvCapk;

import java.util.ArrayList;
import java.util.List;

/**
 * receipt generator
 *
 * @author Steven.W
 */
class ReceiptGeneratorCapkParam extends ReceiptGeneratorParam implements IReceiptGenerator {

    public ReceiptGeneratorCapkParam() {
        //do nothing
    }

    @Override
    protected List<IPage> generatePages(Context context) {
        List<IPage> pages = new ArrayList<>();
        List<EmvCapk> capks = FinancialApplication.getEmvDbHelper().findAllCAPK();

        IPage page = Device.generatePage();
        page.addLine().addUnit("\nCAPK\n", FONT_NORMAL, EAlign.CENTER);
        pages.add(page);

        for (EmvCapk i : capks) {
            page = Device.generatePage();
            //RID
            page.addLine().addUnit("RID", FONT_NORMAL, (float) 3)
                    .addUnit(i.getRID(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //KeyID
            page.addLine().addUnit("Key ID", FONT_NORMAL, (float) 3)
                    .addUnit(Integer.toString(i.getKeyID()), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //HashInd
            page.addLine().addUnit("Hash Index", FONT_NORMAL, (float) 4)
                    .addUnit(Integer.toString(i.getHashInd()), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            //arithInd
            page.addLine().addUnit("arith Index", FONT_NORMAL, (float) 3)
                    .addUnit(Integer.toString(i.getArithInd()), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //module
            page.addLine().addUnit("Modules", FONT_NORMAL, (float) 3)
                    .addUnit(i.getModule(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //Exponent
            page.addLine().addUnit("Exponent", FONT_NORMAL, (float) 3)
                    .addUnit(i.getExponent(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //expDate
            page.addLine().addUnit("ExpDate", FONT_NORMAL, (float) 3)
                    .addUnit(i.getExpDate(), FONT_NORMAL, EAlign.RIGHT, (float) 7);
            //checkSum
            page.addLine().addUnit("Checksum", FONT_NORMAL, (float) 4)
                    .addUnit(i.getCheckSum(), FONT_NORMAL, EAlign.RIGHT, (float) 6);
            pages.add(page);
        }

        page = Device.generatePage();
        page.addLine().addUnit("\n\n\n\n", FONT_NORMAL);
        pages.add(page);
        return pages;
    }
}
