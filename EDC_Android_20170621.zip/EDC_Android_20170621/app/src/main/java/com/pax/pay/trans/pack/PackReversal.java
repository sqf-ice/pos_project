/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2016 - ? Pax Corporation. All rights reserved.
 * Module Date: 2016-11-25
 * Module Author: Steven.W
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.pack;

import android.support.annotation.NonNull;
import android.util.Log;

import com.pax.abl.core.ipacker.PackListener;
import com.pax.gl.pack.exception.Iso8583Exception;
import com.pax.glwrapper.convert.IConvert;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.trans.model.TransData;

public class PackReversal extends PackIso8583 {

    public PackReversal(PackListener listener) {
        super(listener);
    }

    @Override
    @NonNull
    public
    byte[] pack(@NonNull TransData transData) {
        try {
            setCommonData(transData);
            setBitData60(transData);

            return pack(true);

        } catch (Exception e) {
            Log.e(TAG, "", e);
        }
        return "".getBytes();
    }

    /**
     * 设置冲正公共类数据
     * <p>
     * <p>
     * 设置域
     * <p>
     * filed 2, field 4,field 11,field 14,field 22,field 23,field 38,
     * <p>
     * field 39,field 49,field 55,field 61
     *
     * @param transData
     * @return
     */
    @Override
    protected void setCommonData(@NonNull TransData transData) throws Iso8583Exception {
        setMandatoryData(transData);

        TransData.EnterMode enterMode = transData.getEnterMode();

        if (enterMode != TransData.EnterMode.SWIPE && enterMode != TransData.EnterMode.FALLBACK) {// 磁条卡交易冲正,不上送2域
            // field 2 主账号
            setBitData2(transData);
        }
        // field 4 交易金額
        setBitData4(transData);

        // field 11 流水号
        setBitData11(transData);

        // field 14 有效期
        setBitData14(transData);

        // field 22 服务点输入方式码
        setBitData22(transData);

        // field 23 卡片序列号
        if (enterMode == TransData.EnterMode.INSERT || enterMode == TransData.EnterMode.CLSS) {
            setBitData23(transData);
        }

        // field 24 NII
        setBitData24(transData);

        // field 38
        setBitData38(transData);

        // filed 39
        setBitData39(transData);

        // [55]IC卡数据域
        setBitData55(transData);

    }

    @Override
    protected void setBitData24(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("24", FinancialApplication.getAcqManager().getCurAcq().getNii());
    }

    @Override
    protected void setBitData39(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("39", transData.getDupReason());
    }

    @Override
    protected void setBitData55(@NonNull TransData transData) throws Iso8583Exception {
        setBitData("55", FinancialApplication.getConvert().strToBcd(transData.getDupIccData(), IConvert.EPaddingPosition.PADDING_LEFT));
    }
}
