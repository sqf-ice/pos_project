/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-2-28
 * Module Author: lixc
 * Description:
 *
 * ============================================================================
 */
package com.pax.pay.trans.action;

import android.content.Context;

import com.pax.abl.core.AAction;
import com.pax.abl.core.ActionResult;
import com.pax.device.Device;
import com.pax.edc.R;
import com.pax.eventbus.SearchCardEvent;
import com.pax.jemv.clcommon.OutcomeParam;
import com.pax.pay.app.FinancialApplication;
import com.pax.pay.clss.CTransResult;
import com.pax.pay.clss.ClssTransProcess;
import com.pax.pay.constant.Constants;
import com.pax.pay.trans.TransResult;
import com.pax.pay.trans.model.TransData;
import com.pax.pay.trans.transmit.TransProcessListener;
import com.pax.pay.trans.transmit.TransProcessListenerImpl;

public class ActionClssProcess extends AAction {
    private Context context;
    private ClssTransProcess clssTransProcess;
    private TransData transData;

    public ActionClssProcess(ActionStartListener listener) {
        super(listener);
    }

    public void setParam(Context context, ClssTransProcess clssTransProcess, TransData transData) {
        this.context = context;
        this.clssTransProcess = clssTransProcess;
        this.transData = transData;
    }

    @Override
    protected void process() {
        FinancialApplication.getApp().runInBackground(new ProcessRunnable());
    }

    private class ProcessRunnable implements Runnable {
        private final TransProcessListener transProcessListener;

        ProcessRunnable() {
            transProcessListener = new TransProcessListenerImpl(context);
            if (transData.getEnterMode() == TransData.EnterMode.CLSS) {
                transProcessListener.onShowProgress(context.getString(R.string.wait_process), 0);
            }
        }

        @Override
        public void run() {
            CTransResult result = clssTransProcess.transProcess(transData, transProcessListener);
            if (result.getTransResult() < 0 || (result.getTransResult() != 0
                    && result.getTransResult() != OutcomeParam.CLSS_OC_APPROVED
                    && result.getTransResult() != OutcomeParam.CLSS_OC_ONLINE_REQUEST)) {
                if (result.getTransResult() == OutcomeParam.CLSS_OC_TRY_AGAIN) {
                    transProcessListener.onHideProgress();
                    setResult(new ActionResult(TransResult.SUCC, result));
                } else {
                    FinancialApplication.getApp().doEvent(new SearchCardEvent(SearchCardEvent.Status.CLSS_LIGHT_STATUS_ERROR));
                    transProcessListener.onShowErrMessageWithConfirm(result.getMessage(result.getTransResult()),
                            Constants.FAILED_DIALOG_SHOW_TIME);
                    setResult(new ActionResult(TransResult.ERR_ABORTED, null));
                }
            } else {
                Device.beepPrompt();
                transProcessListener.onHideProgress();
                setResult(new ActionResult(TransResult.SUCC, result));
            }
        }
    }
}
