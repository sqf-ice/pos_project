package com.pax.eemv.enums;

public enum EOnlineResult {
    APPROVE((byte) 0),

    FAILED((byte) 1),

    REFER((byte) 2),

    DENIAL((byte) 3),

    ABORT((byte) 4);

    private byte onlineResult;

    EOnlineResult(byte onlineResult) {
        this.onlineResult = onlineResult;
    }

    public byte getOnlineResult() {
        return this.onlineResult;
    }

    public byte index() {
        return (byte) ordinal();
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.enums.EOnlineResult
 * JD-Core Version:    0.6.0
 */