package com.pax.eemv.entity;


import com.pax.eemv.utils.Tools;

public class Config {
    private long referCurrCon;
    private byte[] merchName;
    private byte[] merchCateCode;
    private byte[] merchId;
    private byte[] termId;
    private byte termType;
    private byte[] capability;
    private byte[] exCapability;
    private byte transCurrExp;
    private byte referCurrExp;
    private byte[] referCurrCode;
    private byte[] countryCode;
    private byte[] transCurrCode;
    private byte transType;
    private byte forceOnline;
    private byte getDataPIN;
    private byte surportPSESel;
    private byte useTermAIPFlag;
    private byte[] termAIP;
    private byte bypassAllFlag;
    private byte bypassPin;
    private byte batchCapture;
    private byte adviceFlag;
    private byte scriptMethod;
    private byte forceAccept;
    private byte noPinConfirmAmtFlg;
    private byte isInputAmount;
    private byte[] acquirerId;
    private byte[] reserve;

    public Config() {
        this.referCurrCon = 0L;
        this.merchName = new byte[256];
        this.merchCateCode = new byte[2];
        this.merchId = new byte[15];
        this.termId = new byte[8];
        this.termType = 0;
        this.capability = new byte[3];
        this.exCapability = new byte[5];
        this.transCurrExp = 0;
        this.referCurrExp = 0;
        this.referCurrCode = new byte[2];
        this.countryCode = new byte[2];
        this.transCurrCode = new byte[2];
        this.transType = 0;
        this.forceOnline = 0;
        this.getDataPIN = 0;
        this.surportPSESel = 0;
        this.useTermAIPFlag = 0;
        this.termAIP = new byte[2];
        this.bypassAllFlag = 0;
        this.bypassPin = 0;
        this.batchCapture = 0;
        this.adviceFlag = 0;
        this.scriptMethod = 0;
        this.forceAccept = 0;
        this.noPinConfirmAmtFlg = 0;
        this.isInputAmount = 0;
        this.acquirerId = new byte[6];
        this.reserve = new byte[100];
    }

    public long getReferCurrCon() {
        return this.referCurrCon;
    }

    public void setReferCurrCon(long referCurrCon) {
        this.referCurrCon = referCurrCon;
    }

    public String getMerchName() {
        return Tools.bytes2String(this.merchName);
    }

    public void setMerchName(String merchName) {
        this.merchName = Tools.string2Bytes(merchName);
    }

    public byte[] getMerchCateCode() {
        return this.merchCateCode;
    }

    public void setMerchCateCode(byte[] merchCateCode) {
        this.merchCateCode = merchCateCode;
    }

    public String getMerchId() {
        return Tools.bytes2String(this.merchId);
    }

    public void setMerchId(String merchId) {
        this.merchId = Tools.string2Bytes(merchId);
    }

    public String getTermId() {
        return Tools.bytes2String(this.termId);
    }

    public void setTermId(String termId) {
        this.termId = Tools.string2Bytes(termId, 8);
    }

    public byte getTermType() {
        return this.termType;
    }

    public void setTermType(byte termType) {
        this.termType = termType;
    }

    public byte[] getCapability() {
        return this.capability;
    }

    public void setCapability(byte[] capability) {
        this.capability = capability;
    }

    public byte[] getExCapability() {
        return this.exCapability;
    }

    public void setExCapability(byte[] exCapability) {
        this.exCapability = exCapability;
    }

    public byte getTransCurrExp() {
        return this.transCurrExp;
    }

    public void setTransCurrExp(byte transCurrExp) {
        this.transCurrExp = transCurrExp;
    }

    public byte getReferCurrExp() {
        return this.referCurrExp;
    }

    public void setReferCurrExp(byte referCurrExp) {
        this.referCurrExp = referCurrExp;
    }

    public byte[] getReferCurrCode() {
        return this.referCurrCode;
    }

    public void setReferCurrCode(byte[] referCurrCode) {
        this.referCurrCode = referCurrCode;
    }

    public byte[] getCountryCode() {
        return this.countryCode;
    }

    public void setCountryCode(byte[] countryCode) {
        this.countryCode = countryCode;
    }

    public byte[] getTransCurrCode() {
        return this.transCurrCode;
    }

    public void setTransCurrCode(byte[] transCurrCode) {
        this.transCurrCode = transCurrCode;
    }

    public byte getTransType() {
        return this.transType;
    }

    public void setTransType(byte transType) {
        this.transType = transType;
    }

    public byte getForceOnline() {
        return this.forceOnline;
    }

    public void setForceOnline(byte forceOnline) {
        this.forceOnline = forceOnline;
    }

    public byte getGetDataPIN() {
        return this.getDataPIN;
    }

    public void setGetDataPIN(byte getDataPIN) {
        this.getDataPIN = getDataPIN;
    }

    public byte getSurportPSESel() {
        return this.surportPSESel;
    }

    public void setSurportPSESel(byte surportPSESel) {
        this.surportPSESel = surportPSESel;
    }

    public byte getUseTermAIPFlag() {
        return this.useTermAIPFlag;
    }

    public void setUseTermAIPFlag(byte useTermAIPFlag) {
        this.useTermAIPFlag = useTermAIPFlag;
    }

    public byte[] getTermAIP() {
        return this.termAIP;
    }

    public void setTermAIP(byte[] termAIP) {
        this.termAIP = termAIP;
    }

    public byte getBypassAllFlag() {
        return this.bypassAllFlag;
    }

    public void setBypassAllFlag(byte bypassAllFlag) {
        this.bypassAllFlag = bypassAllFlag;
    }

    public byte getBypassPin() {
        return this.bypassPin;
    }

    public void setBypassPin(byte bypassPin) {
        this.bypassPin = bypassPin;
    }

    public byte getBatchCapture() {
        return this.batchCapture;
    }

    public void setBatchCapture(byte batchCapture) {
        this.batchCapture = batchCapture;
    }

    public byte getAdviceFlag() {
        return this.adviceFlag;
    }

    public void setAdviceFlag(byte adviceFlag) {
        this.adviceFlag = adviceFlag;
    }

    public byte getScriptMethod() {
        return this.scriptMethod;
    }

    public void setScriptMethod(byte scriptMethod) {
        this.scriptMethod = scriptMethod;
    }

    public byte getForceAccept() {
        return this.forceAccept;
    }

    public void setForceAccept(byte forceAccept) {
        this.forceAccept = forceAccept;
    }

    public byte getNoPinConfirmAmtFlg() {
        return this.noPinConfirmAmtFlg;
    }

    public void setNoPinConfirmAmtFlg(byte noPinConfirmAmtFlg) {
        this.noPinConfirmAmtFlg = noPinConfirmAmtFlg;
    }

    public byte getIsInputAmount() {
        return this.isInputAmount;
    }

    public void setIsInputAmount(byte isInputAmount) {
        this.isInputAmount = isInputAmount;
    }


    public byte[] getAcquirerId() {
        return this.acquirerId;
    }

    public void setAcquirerId(byte[] acquirerId) {
        this.acquirerId = acquirerId;
    }

    public byte[] getReserve() {
        return this.reserve;
    }

    public void setReserve(byte[] reserve) {
        this.reserve = reserve;
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.entity.Config
 * JD-Core Version:    0.6.0
 */