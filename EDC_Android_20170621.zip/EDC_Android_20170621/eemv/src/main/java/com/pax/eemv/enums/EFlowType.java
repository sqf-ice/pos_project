package com.pax.eemv.enums;

public enum EFlowType {
    COMPLETE((byte) 0),

    SIMPLE((byte) 1),

    QPBOC((byte) 2);

    private byte flowType;

    EFlowType(byte flowType) {
        this.flowType = flowType;
    }

    public byte getFlowType() {
        return this.flowType;
    }

    public byte index() {
        return (byte) ordinal();
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.enums.EFlowType
 * JD-Core Version:    0.6.0
 */