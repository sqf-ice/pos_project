/*
 * ============================================================================
 * COPYRIGHT
 *              Pax CORPORATION PROPRIETARY INFORMATION
 *   This software is supplied under the terms of a license agreement or
 *   nondisclosure agreement with Pax Corporation and may not be copied
 *   or disclosed except in accordance with the terms in that agreement.
 *      Copyright (C) 2017 - ? Pax Corporation. All rights reserved.
 * Module Date: 2017-4-17
 * Module Author: Kim.L
 * Description:
 *
 * ============================================================================
 */
package com.pax.eemv.utils;

import com.pax.eemv.entity.AidParam;
import com.pax.eemv.entity.CandList;
import com.pax.eemv.entity.Capk;
import com.pax.jemv.clcommon.EMV_APPLIST;
import com.pax.jemv.clcommon.EMV_CAPK;

public class Converter {

    private Converter(){

    }

    public static EMV_APPLIST toEMVApp(AidParam aidParam) {
        EMV_APPLIST appList = new EMV_APPLIST();
        appList.appName = aidParam.getAppName().getBytes();
        appList.aid = aidParam.getAid();
        appList.aidLen = (byte) appList.aid.length;
        appList.selFlag = aidParam.getSelFlag();
        appList.priority = aidParam.getPriority();
        appList.floorLimit = aidParam.getFloorLimit();
        appList.floorLimitCheck = aidParam.getFloorLimitCheck();
        appList.threshold = aidParam.getThreshold();
        appList.targetPer = aidParam.getTargetPer();
        appList.maxTargetPer = aidParam.getMaxTargetPer();
        appList.randTransSel = aidParam.getRandTransSel();
        appList.velocityCheck = aidParam.getVelocityCheck();
        appList.tacDenial = aidParam.getTacDenial();
        appList.tacOnline = aidParam.getTacOnline();
        appList.tacDefault = aidParam.getTacDefault();
        appList.acquierId = aidParam.getAcquierId();
        appList.dDOL = aidParam.getdDol();
        appList.tDOL = aidParam.gettDol();
        appList.version = aidParam.getVersion();
        appList.riskManData = aidParam.getRiskManData();
        return appList;
    }

    public static CandList toCandList(EMV_APPLIST emvAppList) {
        CandList candList = new CandList();
        candList.setAid(emvAppList.aid);
        candList.setAidLen(emvAppList.aidLen);
        candList.setPriority(emvAppList.priority);
        candList.setAppName(Tools.bytes2String(emvAppList.appName));
        return candList;
    }

    public static EMV_CAPK toEMVCapk(Capk capk) {
        EMV_CAPK emvCapk = new EMV_CAPK();
        emvCapk.rID = capk.getRid();
        emvCapk.keyID = capk.getKeyID();
        emvCapk.hashInd = capk.getHashInd();
        emvCapk.arithInd = capk.getArithInd();
        emvCapk.modul = capk.getModul();
        emvCapk.modulLen = (short) capk.getModul().length;
        emvCapk.exponent = capk.getExponent();
        emvCapk.exponentLen = (byte) capk.getExponent().length;
        emvCapk.expDate = capk.getExpDate();
        emvCapk.checkSum = capk.getCheckSum();
        return emvCapk;
    }
}
