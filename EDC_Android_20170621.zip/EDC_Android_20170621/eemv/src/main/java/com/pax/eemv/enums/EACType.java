package com.pax.eemv.enums;

public enum EACType {
    AAC((byte) 0),

    TC((byte) 1),

    ARQC((byte) 2),

    AAC_HOST((byte) 3);

    private byte acType;

    EACType(byte acType) {
        this.acType = acType;
    }

    public byte getACType() {
        return this.acType;
    }

    public byte index() {
        return (byte) ordinal();
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.enums.EACType
 * JD-Core Version:    0.6.0
 */