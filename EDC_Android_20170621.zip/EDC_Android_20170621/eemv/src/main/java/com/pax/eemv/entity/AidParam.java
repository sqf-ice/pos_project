package com.pax.eemv.entity;

import com.pax.eemv.utils.Tools;

public class AidParam {
    private byte[] appName;
    private byte[] aid;
    private byte selFlag;
    private byte priority;
    private byte onlinePin;
    private long ecTTLVal;
    private long rdCVMLmt;
    private long rdClssTxnLmt;
    private long rdClssFLmt;
    private byte ecTTLFlag;
    private byte rdClssFLmtFlag;
    private byte rdClssTxnLmtFlag;
    private byte rdCVMLmtFlag;
    private long floorLimit;
    private byte floorLimitCheck;
    private long threshold;
    private byte targetPer;
    private byte maxTargetPer;
    private byte randTransSel;
    private byte velocityCheck;
    private byte[] tacDenial;
    private byte[] tacOnline;
    private byte[] tacDefault;
    private byte[] acquierId;
    private byte[] dDol;
    private byte[] tDol;
    private byte[] version;
    private byte[] riskManData;

    public AidParam() {
        this.appName = new byte[0];
        this.aid = new byte[0];
        this.selFlag = 0;
        this.priority = 0;
        this.onlinePin = 0;

        this.ecTTLVal = 0L;
        this.rdCVMLmt = 0L;
        this.rdClssTxnLmt = 0L;
        this.rdClssFLmt = 0L;

        this.ecTTLFlag = 0;
        this.rdClssFLmtFlag = 0;
        this.rdClssTxnLmtFlag = 0;
        this.rdCVMLmtFlag = 0;

        this.floorLimit = 0L;
        this.floorLimitCheck = 0;
        this.threshold = 0L;
        this.targetPer = 0;
        this.maxTargetPer = 0;
        this.randTransSel = 0;
        this.velocityCheck = 0;
        this.tacDenial = new byte[0];
        this.tacOnline = new byte[0];
        this.tacDefault = new byte[0];
        this.acquierId = new byte[0];
        this.dDol = new byte[0];
        this.tDol = new byte[0];
        this.version = new byte[0];
        this.riskManData = new byte[0];
    }

    public String getAppName() {
        return Tools.bytes2String(this.appName).trim();
    }

    public void setAppName(String appName) {
        this.appName = Tools.string2Bytes(appName);
    }

    public byte[] getAid() {
        return this.aid;
    }

    public void setAid(byte[] aid) {
        this.aid = aid;
    }

    public byte getSelFlag() {
        return this.selFlag;
    }

    public void setSelFlag(byte selFlag) {
        this.selFlag = selFlag;
    }

    public byte getPriority() {
        return this.priority;
    }

    public void setPriority(byte priority) {
        this.priority = priority;
    }

    public byte getOnlinePin() {
        return this.onlinePin;
    }

    public void setOnlinePin(byte onlinePin) {
        this.onlinePin = onlinePin;
    }

    public long getEcTTLVal() {
        return this.ecTTLVal;
    }

    public void setEcTTLVal(long ecTTLVal) {
        this.ecTTLVal = ecTTLVal;
    }

    public long getRdCVMLmt() {
        return this.rdCVMLmt;
    }

    public void setRdCVMLmt(long rdCVMLmt) {
        this.rdCVMLmt = rdCVMLmt;
    }

    public long getRdClssTxnLmt() {
        return this.rdClssTxnLmt;
    }

    public void setRdClssTxnLmt(long rdClssTxnLmt) {
        this.rdClssTxnLmt = rdClssTxnLmt;
    }

    public long getRdClssFLmt() {
        return this.rdClssFLmt;
    }

    public void setRdClssFLmt(long rdClssFLmt) {
        this.rdClssFLmt = rdClssFLmt;
    }

    public byte getEcTTLFlag() {
        return this.ecTTLFlag;
    }

    public void setEcTTLFlag(byte ecTTLFlag) {
        this.ecTTLFlag = ecTTLFlag;
    }

    public byte getRdClssFLmtFlag() {
        return this.rdClssFLmtFlag;
    }

    public void setRdClssFLmtFlag(byte rdClssFLmtFlag) {
        this.rdClssFLmtFlag = rdClssFLmtFlag;
    }

    public byte getRdClssTxnLmtFlag() {
        return this.rdClssTxnLmtFlag;
    }

    public void setRdClssTxnLmtFlag(byte rdClssTxnLmtFlag) {
        this.rdClssTxnLmtFlag = rdClssTxnLmtFlag;
    }

    public byte getRdCVMLmtFlag() {
        return this.rdCVMLmtFlag;
    }

    public void setRdCVMLmtFlag(byte rdCVMLmtFlag) {
        this.rdCVMLmtFlag = rdCVMLmtFlag;
    }

    public long getFloorLimit() {
        return this.floorLimit;
    }

    public void setFloorLimit(long floorLimit) {
        this.floorLimit = floorLimit;
    }

    public byte getFloorLimitCheck() {
        return this.floorLimitCheck;
    }

    public void setFloorLimitCheck(byte floorLimitCheck) {
        this.floorLimitCheck = floorLimitCheck;
    }

    public long getThreshold() {
        return this.threshold;
    }

    public void setThreshold(long threshold) {
        this.threshold = threshold;
    }

    public byte getTargetPer() {
        return this.targetPer;
    }

    public void setTargetPer(byte targetPer) {
        this.targetPer = targetPer;
    }

    public byte getMaxTargetPer() {
        return this.maxTargetPer;
    }

    public void setMaxTargetPer(byte maxTargetPer) {
        this.maxTargetPer = maxTargetPer;
    }

    public byte getRandTransSel() {
        return this.randTransSel;
    }

    public void setRandTransSel(byte randTransSel) {
        this.randTransSel = randTransSel;
    }

    public byte getVelocityCheck() {
        return this.velocityCheck;
    }

    public void setVelocityCheck(byte velocityCheck) {
        this.velocityCheck = velocityCheck;
    }

    public byte[] getTacDenial() {
        return this.tacDenial;
    }

    public void setTacDenial(byte[] tacDenial) {
        this.tacDenial = tacDenial;
    }

    public byte[] getTacOnline() {
        return this.tacOnline;
    }

    public void setTacOnline(byte[] tacOnline) {
        this.tacOnline = tacOnline;
    }

    public byte[] getTacDefault() {
        return this.tacDefault;
    }

    public void setTacDefault(byte[] tacDefault) {
        this.tacDefault = tacDefault;
    }

    public byte[] getAcquierId() {
        return this.acquierId;
    }

    public void setAcquierId(byte[] acquierId) {
        this.acquierId = acquierId;
    }

    public byte[] getdDol() {
        return this.dDol;
    }

    public void setdDol(byte[] dDol) {
        this.dDol = dDol;
    }

    public byte[] gettDol() {
        return this.tDol;
    }

    public void settDol(byte[] tDol) {
        this.tDol = tDol;
    }

    public byte[] getVersion() {
        return this.version;
    }

    public void setVersion(byte[] version) {
        this.version = version;
    }

    public byte[] getRiskManData() {
        return this.riskManData;
    }

    public void setRiskManData(byte[] riskManData) {
        this.riskManData = riskManData;
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.entity.AidParam
 * JD-Core Version:    0.6.0
 */