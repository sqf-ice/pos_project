package com.pax.eemv.entity;

public class TagPresent {
    private int tag;
    private byte present;

    public TagPresent() {
        this.tag = 0;
        this.present = 0;
    }

    public int getTag() {
        return this.tag;
    }

    public void setTag(int tag) {
        this.tag = tag;
    }

    public byte getPresent() {
        return this.present;
    }

    public void setPresent(byte present) {
        this.present = present;
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.entity.TagPresent
 * JD-Core Version:    0.6.0
 */