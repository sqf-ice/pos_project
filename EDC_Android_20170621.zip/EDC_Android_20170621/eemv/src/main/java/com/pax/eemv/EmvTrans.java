package com.pax.eemv;

import android.util.Log;

import com.pax.eemv.entity.Amounts;
import com.pax.eemv.entity.CandList;
import com.pax.eemv.exception.EEmvExceptions;
import com.pax.eemv.exception.EmvException;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

class EmvTrans {
    private IEmvListener listener;

    public EmvTrans() {
        //do nothing
    }

    public void setEmvListener(IEmvListener listener) {
        this.listener = listener;
    }

    public Amount getAmount() {
        Amount amt = new Amount();
        if (listener != null) {
            Amounts emvAmounts = listener.onGetAmounts();
            try {
                amt.setAmount(emvAmounts.getTransAmount());
                amt.setCashBackAmt(emvAmounts.getCashBackAmount());
            } catch (EmvException e) {
                Log.w("EmvTrans", "", e);
            }
        }
        return amt;
    }

    public int waitAppSelect(int tryCnt, CandList[] appList) {
        if (listener != null) {
            List<CandList> candLists = new ArrayList<>();
            candLists.addAll(Arrays.asList(appList));
            return listener.onWaitAppSelect(tryCnt < 1, candLists);
        }
        return EEmvExceptions.EMV_ERR_LISTENER_IS_NULL.getErrCodeFromBasement();
    }

    public int setParam(byte onlinePin, byte[] aid) {
        if (listener != null) {
            return listener.onSetParam(onlinePin, aid);
        }
        return EEmvExceptions.EMV_ERR_LISTENER_IS_NULL.getErrCodeFromBasement();
    }

    public int confirmCardNo(String pan) {
        if (listener != null) {
            return listener.onConfirmCardNo(pan);
        }
        return EEmvExceptions.EMV_ERR_LISTENER_IS_NULL.getErrCodeFromBasement();
    }

    public int cardHolderPwd(boolean bOnlinePin, int leftTimes, byte[] pinData) {
        if (listener != null) {
            return listener.onCardHolderPwd(bOnlinePin, leftTimes, pinData);
        }
        return EEmvExceptions.EMV_ERR_LISTENER_IS_NULL.getErrCodeFromBasement();
    }

    public int onlineProc() {
        if (listener != null) {
            return listener.onOnlineProc().getOnlineResult();
        }

        return EEmvExceptions.EMV_ERR_LISTENER_IS_NULL.getErrCodeFromBasement();
    }

    public boolean chkExceptionFile() {
        if (listener != null) {
            return listener.onChkExceptionFile();
        }
        return false;
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.EmvTrans
 * JD-Core Version:    0.6.0
 */