package com.pax.eemv.entity;


import com.pax.eemv.enums.EFlowType;
import com.pax.eemv.utils.Tools;

public class InputParam {
    private byte[] amount;
    private byte[] cashBackAmount;
    private byte tag9CValue;
    private byte[] transDate;
    private byte[] transTime;
    private byte[] transTraceNo;
    private byte isSupportSM;
    private byte isForceOnline;
    private byte isSupportCvm;
    private byte isSupportEC;
    private byte isCardAuth;
    private int flowType;
    private int pciTimeout = 60 * 1000;

    public InputParam() {
        this.amount = new byte[12];
        this.cashBackAmount = new byte[12];
        this.tag9CValue = 0;
        this.transDate = new byte[8];
        this.transTime = new byte[6];
        this.transTraceNo = new byte[4];
        this.isSupportSM = 0;
        this.isForceOnline = 0;
        this.isSupportCvm = 0;
        this.isSupportEC = 0;
        this.isCardAuth = 0;
        this.flowType = 0;
    }

    public String getAmount() {
        return Tools.bytes2String(this.amount);
    }

    public void setAmount(String amount) {
        this.amount = Tools.fillData(12, Tools.string2Bytes(amount), 12 - amount.length(), (byte) 48);
    }

    public String getCashBackAmount() {
        return Tools.bytes2String(this.cashBackAmount);
    }

    public void setCashBackAmount(String cashBackAmount) {
        this.cashBackAmount = Tools.fillData(12, Tools.string2Bytes(cashBackAmount), 12 - cashBackAmount.length(), (byte) 48);
    }

    public byte getTag9CValue() {
        return this.tag9CValue;
    }

    public void setTag9CValue(byte tag9cValue) {
        this.tag9CValue = tag9cValue;
    }

    public String getTransDate() {
        return Tools.bytes2String(this.transDate);
    }

    public void setTransDate(String transDate) {
        this.transDate = Tools.string2Bytes(transDate);
    }

    public String getTransTime() {
        return Tools.bytes2String(this.transTime);
    }

    public void setTransTime(String transTime) {
        this.transTime = Tools.string2Bytes(transTime);
    }

    public String getTransTraceNo() {
        return Tools.bytes2String(this.transTraceNo);
    }

    public void setTransTraceNo(String transTraceNo) {
        this.transTraceNo = Tools.string2Bytes(transTraceNo);
    }

    public boolean getIsSupportSM() {
        return this.isSupportSM != 0;
    }

    public void setIsSupportSM(boolean isSupportSM) {
        this.isSupportSM = (byte) (isSupportSM ? 1 : 0);
    }

    public boolean getIsCardAuth() {
        return this.isCardAuth != 0;
    }

    public void setIsCardAuth(boolean isCardAuth) {
        this.isCardAuth = (byte) (isCardAuth ? 1 : 0);
    }

    public boolean getIsForceOnline() {
        return this.isForceOnline != 0;
    }

    public void setIsForceOnline(boolean isForceOnline) {
        this.isForceOnline = (byte) (isForceOnline ? 1 : 0);
    }

    public boolean getIsSupportEC() {
        return this.isSupportEC != 0;
    }

    public void setIsSupportEC(boolean isSupportEC) {
        this.isSupportEC = (byte) (isSupportEC ? 1 : 0);
    }

    public boolean getIsSupportCvm() {
        return this.isSupportCvm != 0;
    }

    public void setIsSupportCvm(boolean isSupportCvm) {
        this.isSupportCvm = (byte) (isSupportCvm ? 1 : 0);
    }

    public EFlowType getFlowType() {
        return EFlowType.values()[this.flowType];
    }

    public void setFlowType(EFlowType flowType) {
        if (flowType == null)
            this.flowType = EFlowType.COMPLETE.getFlowType();
        else
            this.flowType = flowType.getFlowType();
    }

    public int getPciTimeout() {
        return pciTimeout;
    }

    public void setPciTimeout(int pciTimeout) {
        this.pciTimeout = pciTimeout;
    }

}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.entity.InputParam
 * JD-Core Version:    0.6.0
 */