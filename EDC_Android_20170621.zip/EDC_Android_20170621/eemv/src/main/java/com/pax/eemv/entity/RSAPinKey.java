package com.pax.eemv.entity;

import com.pax.eemv.utils.Tools;

public class RSAPinKey {
    private int modulusLen;
    private byte[] modulus;
    private byte[] exponent;
    private byte[] iccRandom;

    public int getModulusLen() {
        return this.modulusLen;
    }

    public void setModulusLen(int modulusLen) {
        this.modulusLen = modulusLen;
    }

    public byte[] getModulus() {
        return this.modulus;
    }

    public void setModulus(byte[] modulus) {
        this.modulus = leftFillData(modulus, 256);
    }

    public byte[] getExponent() {
        return this.exponent;
    }

    public void setExponent(byte[] exponent) {
        this.exponent = leftFillData(exponent, 4);
    }

    public byte[] getIccRandom() {
        return this.iccRandom;
    }

    public void setIccRandom(byte[] iccRandom) {
        this.iccRandom = leftFillData(iccRandom, 8);
    }

    private byte[] leftFillData(byte[] source, int length) {
        int offset = length - source.length;
        return Tools.fillData(length, source, offset);
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.entity.RSAPinKey
 * JD-Core Version:    0.6.0
 */