package com.pax.eemv;

import android.util.Log;
import android.util.SparseArray;

import com.pax.eemv.entity.AidParam;
import com.pax.eemv.entity.CandList;
import com.pax.eemv.entity.Capk;
import com.pax.eemv.entity.Config;
import com.pax.eemv.entity.InputParam;
import com.pax.eemv.enums.EOnlineResult;
import com.pax.eemv.enums.ETransResult;
import com.pax.eemv.exception.EEmvExceptions;
import com.pax.eemv.exception.EmvException;
import com.pax.eemv.utils.Converter;
import com.pax.eemv.utils.Tools;
import com.pax.jemv.clcommon.ACType;
import com.pax.jemv.clcommon.ByteArray;
import com.pax.jemv.clcommon.EMV_APPLIST;
import com.pax.jemv.clcommon.EMV_CAPK;
import com.pax.jemv.clcommon.RetCode;
import com.pax.jemv.device.DeviceManager;
import com.pax.jemv.emv.api.EMVCallback;
import com.pax.jemv.emv.model.EmvEXTMParam;
import com.pax.jemv.emv.model.EmvMCKParam;
import com.pax.jemv.emv.model.EmvParam;

import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class EmvImpl implements IEmv {
    private static EMVCallback emvCallback;
    private static EmvTrans paxEmvTrans;
    private List<Capk> capkList;
    private List<AidParam> aidParamList;
    private EmvParam emvParam;
    private EmvMCKParam mckParam;
    private Config cfg = new Config();
    private SparseArray<byte[]> tags = new SparseArray<>();

    static {
        System.loadLibrary("JniEMV_V1.00.00_20170616");
    }

    private class Callback implements EMVCallback.EmvCallbackListener{
        @Override
        public void emvWaitAppSel(int tryCnt, EMV_APPLIST[] list, int appNum) {
            CandList[] candLists = new CandList[list.length];
            int size = Math.min(list.length, appNum);
            for (int i = 0; i < size; ++i) {
                candLists[i] = Converter.toCandList(list[i]);
            }
            int idx = paxEmvTrans.waitAppSelect(tryCnt, candLists);
            if (idx >= 0)
                emvCallback.setCallBackResult(idx);
            else {
                emvCallback.setCallBackResult(RetCode.EMV_USER_CANCEL);
            }
        }

        @Override
        public void emvInputAmount(long[] amt) {
            Amount amount = paxEmvTrans.getAmount();
            if (amount != null) {
                amt[0] = Long.parseLong(amount.getAmount());
                if (amt.length > 1) {
                    if (amount.getCashBackAmt() == null || amount.getCashBackAmt().isEmpty()) {
                        amt[1] = 0;
                    } else {
                        amt[1] = Long.parseLong(amount.getCashBackAmt());
                    }
                }
            }
            emvCallback.setCallBackResult(RetCode.EMV_OK);
        }

        @Override
        public void emvGetHolderPwd(int tryFlag, int remainCnt, byte[] pin) {
            if (pin == null) {
                Log.i("log", "emvGetHolderPwd pin is null, tryFlag" + tryFlag + " remainCnt:" + remainCnt);
            } else {
                Log.i("log", "emvGetHolderPwd pin is not null, tryFlag" + tryFlag + " remainCnt:" + remainCnt);
            }

            int ret = paxEmvTrans.cardHolderPwd(pin == null, remainCnt, pin);
            int result;
            if (ret == EEmvExceptions.EMV_OK.getErrCodeFromBasement())
                result = RetCode.EMV_OK;
            else if (ret == EEmvExceptions.EMV_ERR_NO_PASSWORD.getErrCodeFromBasement()) {
                result = RetCode.EMV_NO_PASSWORD;
            } else {
                result = RetCode.EMV_USER_CANCEL;
            }

            emvCallback.setCallBackResult(result);
        }

        @Override
        public void emvAdviceProc() {
            //do nothing
        }

        @Override
        public void emvVerifyPINOK() {
            //do nothing
        }

        @Override
        public int emvUnknowTLVData(short tag, ByteArray data) {
            Log.i("EMV", "emvUnknowTLVData tag: " + Integer.toHexString(tag) + " data:" + data.data.length);
            switch ((int) tag) {
                case 0x9A:
                    byte[] date = new byte[7];
                    DeviceManager.getInstance().getTime(date);
                    System.arraycopy(date, 0, data.data, 0, 3);
                    break;
                case 0x9F1E:
                    byte[] sn = new byte[10];
                    DeviceManager.getInstance().readSN(sn);
                    System.arraycopy(sn, 0, data.data, 0, Math.min(data.data.length, sn.length));
                    break;
                case 0x9F21:
                    byte[] time = new byte[7];
                    DeviceManager.getInstance().getTime(time);
                    System.arraycopy(time, 3, data.data, 0, 3);
                    break;
                case 0x9F37:
                    byte[] random = new byte[4];
                    DeviceManager.getInstance().getRand(random, 4);
                    System.arraycopy(random, 0, data.data, 0, data.data.length);
                    break;
                case 0xFF01:
                    Arrays.fill(data.data, (byte) 0x00);
                    break;
                default:
                    return RetCode.EMV_PARAM_ERR;
            }
            data.length = data.data.length;
            return RetCode.EMV_OK;
        }

        @Override
        public void certVerify() {
            emvCallback.setCallBackResult(RetCode.EMV_OK);
        }

        @Override
        public int emvSetParam() {
            return RetCode.EMV_OK;
        }

        @Override
        public int cRFU1() {
            return 0;
        }

        @Override
        public int cRFU2() {
            return 0;
        }
    }

    public EmvImpl() {
        capkList = new ArrayList<>();
        aidParamList = new ArrayList<>();
        emvParam = new EmvParam();
        mckParam = new EmvMCKParam();
        mckParam.extmParam = new EmvEXTMParam();

        paxEmvTrans = new EmvTrans();

        emvCallback = EMVCallback.getInstance();
        emvCallback.setCallbackListener(new Callback());
    }

    public IEmv getEmv() {
        return this;
    }

    public int emvInit() throws EmvException {
        tags.clear();
        int ret = EMVCallback.EMVCoreInit();
        if (ret == RetCode.EMV_OK) {
            EMVCallback.EMVSetCallback();
            EMVCallback.EMVGetParameter(emvParam);
            EMVCallback.EMVGetMCKParam(mckParam);
            paramToConfig();
            return 0;
        }

        throw new EmvException(EEmvExceptions.EMV_ERR_FILE);
    }

    public void setConfig(Config emvCfg) {
        cfg = emvCfg;
    }

    public Config getConfig() {
        return cfg;
    }

    private void paramToConfig() {
        cfg.setCapability(emvParam.capability);
        cfg.setCountryCode(emvParam.countryCode);
        cfg.setExCapability(emvParam.exCapability);
        cfg.setForceOnline(emvParam.forceOnline);
        cfg.setGetDataPIN(emvParam.getDataPIN);
        cfg.setMerchCateCode(emvParam.merchCateCode);
        cfg.setReferCurrCode(emvParam.referCurrCode);
        cfg.setReferCurrCon(emvParam.referCurrCon);
        cfg.setReferCurrExp(emvParam.referCurrExp);
        cfg.setSurportPSESel(emvParam.surportPSESel);
        cfg.setTermType(emvParam.terminalType);
        cfg.setTransCurrCode(emvParam.transCurrCode);
        cfg.setTransCurrExp(emvParam.transCurrExp);
        cfg.setTransType(emvParam.transType);
        cfg.setTermId(Arrays.toString(emvParam.termId));
        cfg.setMerchId(Arrays.toString(emvParam.merchId));
        cfg.setMerchName(Arrays.toString(emvParam.merchName));

        cfg.setBypassPin(mckParam.ucBypassPin);
        cfg.setBatchCapture(mckParam.ucBatchCapture);

        cfg.setTermAIP(mckParam.extmParam.aucTermAIP);
        cfg.setBypassAllFlag(mckParam.extmParam.ucBypassAllFlg);
        cfg.setUseTermAIPFlag(mckParam.extmParam.ucUseTermAIPFlg);
    }

    private void configToParam() {
        emvParam.capability = cfg.getCapability();
        emvParam.countryCode = cfg.getCountryCode();
        emvParam.exCapability = cfg.getExCapability();
        emvParam.forceOnline = cfg.getForceOnline();
        emvParam.getDataPIN = cfg.getGetDataPIN();
        emvParam.merchCateCode = cfg.getMerchCateCode();
        emvParam.referCurrCode = cfg.getReferCurrCode();
        emvParam.referCurrCon = cfg.getReferCurrCon();
        emvParam.referCurrExp = cfg.getReferCurrExp();
        emvParam.surportPSESel = cfg.getSurportPSESel();
        emvParam.terminalType = cfg.getTermType();
        emvParam.transCurrCode = cfg.getTransCurrCode();
        emvParam.transCurrExp = cfg.getTransCurrExp();
        emvParam.transType = cfg.getTransType();
        emvParam.termId = cfg.getTermId().getBytes();
        emvParam.merchId = cfg.getMerchId().getBytes();
        emvParam.merchName = cfg.getMerchName().getBytes();

        mckParam.ucBypassPin = cfg.getBypassPin();
        mckParam.ucBatchCapture = cfg.getBatchCapture();

        mckParam.extmParam.aucTermAIP = cfg.getTermAIP();
        mckParam.extmParam.ucBypassAllFlg = cfg.getBypassAllFlag();
        mckParam.extmParam.ucUseTermAIPFlg = cfg.getUseTermAIPFlag();
    }


    public byte[] getTlv(int tag) {
        ByteArray byteArray = new ByteArray();
        if (EMVCallback.EMVGetTLVData((short) tag, byteArray) == RetCode.EMV_OK) {
            byte[] data = Arrays.copyOfRange(byteArray.data, 0, byteArray.length);
            tags.put(tag, data);
            return data;
        }
        return tags.get(tag, null);
    }

    public void setTlv(int tag, byte[] value) throws EmvException {
        int ret = EMVCallback.EMVSetTLVData((short) tag, value, value.length);
        if (tag != 0x71 && tag != 0x72 && ret != EEmvExceptions.EMV_OK.getErrCodeFromBasement()) {
            throw new EmvException(ret);
        }
        tags.put(tag, value);
    }

    // Run callback
    // Parameter settings, loading aid,
    // select the application, application initialization,read application data, offline data authentication,
    // terminal risk management,cardholder authentication, terminal behavior analysis,
    // issuing bank data authentication, execution script
    public ETransResult emvProcess(InputParam inputParam) throws EmvException {
        configToParam();
        EMVCallback.EMVSetParameter(emvParam);
        int ret = EMVCallback.EMVSetMCKParam(mckParam);
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        EMVCallback.EMVSetPCIModeParam((byte) 1, "0,4,5,6,7,8,9,10,11,12".getBytes(), inputParam.getPciTimeout());

        for (AidParam i : aidParamList) {
            ret = EMVCallback.EMVAddApp(Converter.toEMVApp(i));
            if (ret != RetCode.EMV_OK) {
                throw new EmvException(ret);
            }
        }

        ret = EMVCallback.EMVAppSelect(0, Long.parseLong(inputParam.getTransTraceNo()));   //callback emvWaitAppSel
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        ret = EMVCallback.EMVReadAppData(); //callback emvInputAmount
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        ByteArray pan = new ByteArray();
        EMVCallback.EMVGetTLVData((byte) 0x5A, pan);
        String filtPan = Tools.bcd2Str(pan.data, pan.length);
        int indexF = filtPan.indexOf('F');

        if (pan.length > 0 && pan.data != null) {
            ret = paxEmvTrans.confirmCardNo(filtPan.substring(0, indexF != -1 ? indexF : filtPan.length()));
            if (ret != RetCode.EMV_OK) {
                throw new EmvException(ret);
            }
        }

        addCapkIntoEmvLib(); // ignore return value for some case which the card doesn't has the capk index

        ret = EMVCallback.EMVCardAuth();
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        ACType acType = new ACType();
        ret = EMVCallback.EMVStartTrans(Long.parseLong(inputParam.getAmount()),
                Long.parseLong(inputParam.getCashBackAmount()), acType);
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        if (acType.type == ACType.AC_TC) {
            return ETransResult.OFFLINE_APPROVED;
        } else if (acType.type == ACType.AC_AAC) {
            return ETransResult.OFFLINE_DENIED;
        }

        ETransResult result = onlineProc();
        //AET-146
        if (result != ETransResult.ONLINE_APPROVED) {
            throw new EmvException(EEmvExceptions.EMV_ERR_ONLINE_TRANS_ABORT);
        }

        ByteArray f71 = new ByteArray();
        ByteArray f72 = new ByteArray();
        f71.data = getTlv(0x71);
        if (f71.data != null) {
            f71.length = f71.data.length;
        }
        f72.data = getTlv(0x72);
        if (f72.data != null) {
            f72.length = f72.data.length;
        }

        ByteArray script = combine7172(f71, f72);

        ret = EMVCallback.EMVCompleteTrans(result.getTransResult(), script.data, script.data == null ? 0 : script.length, acType);
        if (ret != RetCode.EMV_OK) {
            throw new EmvException(ret);
        }

        if (acType.type == ACType.AC_TC) {
            return ETransResult.ONLINE_APPROVED;
        } else if (acType.type == ACType.AC_AAC) {
            return ETransResult.ONLINE_CARD_DENIED;
        }

        ETransResult transResult = Tools.getEnum(ETransResult.class, ret - 1);
        if (transResult == null) {
            throw new EmvException(EEmvExceptions.EMV_ERR_UNKNOWN.getErrCodeFromBasement());
        }
        return transResult;
    }

    private static ByteArray combine7172(ByteArray f71, ByteArray f72) {
        if (f71 == null || f71.data == null || f71.length == 0)
            return f72;
        if (f72 == null || f72.data == null || f72.length == 0)
            return f71;

        ByteBuffer bb = ByteBuffer.allocate(f71.length + f72.length + 6);

        bb.put((byte) 0x71);
        if (f71.length > 127)
            bb.put((byte) 0x81);
        bb.put((byte) f71.length);
        bb.put(f71.data, 0, f71.length);

        bb.put((byte) 0x72);
        if (f72.length > 127)
            bb.put((byte) 0x81);
        bb.put((byte) f72.length);
        bb.put(f72.data, 0, f72.length);

        int len = bb.position();
        bb.position(0);

        ByteArray script = new ByteArray(len);
        bb.get(script.data, 0, len);

        return script;
    }

    public static ByteArray combine917172(ByteArray f91, ByteArray f71, ByteArray f72) {
        if (f91 == null || f91.data == null || f91.length == 0)
            return combine7172(f71, f72);
        if (f71 == null || f71.data == null || f71.length == 0)
            return f72;
        if (f72 == null || f72.data == null || f72.length == 0)
            return f71;

        ByteBuffer bb = ByteBuffer.allocate(f71.length + f72.length + 6);

        bb.put((byte) 0x91);
        bb.put((byte) f91.length); //fix 16
        bb.put(f91.data, 0, f91.length);

        ByteArray f7172 = combine7172(f71, f72);
        bb.put(f7172.data, 0, f7172.length);

        int len = bb.position();
        bb.position(0);

        ByteArray script = new ByteArray(len);
        bb.get(script.data, 0, len);

        return script;
    }

    public void setListener(IEmvListener listener) {
        paxEmvTrans.setEmvListener(listener);
    }

    public void setAidParamList(List<AidParam> aidParamList) {
        this.aidParamList = aidParamList == null ? new ArrayList<AidParam>() : aidParamList;
    }

    public void setCapkList(List<Capk> capkList) {
        this.capkList = capkList == null ? new ArrayList<Capk>() : capkList;
    }

    public String getVersion() {
        ByteArray byteArray = new ByteArray();
        EMVCallback.EMVReadVerInfo(byteArray);
        return Arrays.toString(byteArray.data);
    }

    private int addCapkIntoEmvLib() {
        int ret;
        ByteArray dataList = new ByteArray();
        ret = EMVCallback.EMVGetTLVData((short) 0x4F, dataList);
        if (ret != RetCode.EMV_OK) {
            ret = EMVCallback.EMVGetTLVData((short) 0x84, dataList);
        }
        if (ret != RetCode.EMV_OK) {
            return ret;
        }

        byte[] rid = new byte[5];
        System.arraycopy(dataList.data, 0, rid, 0, 5);
        ret = EMVCallback.EMVGetTLVData((short) 0x8F, dataList);
        if (ret != RetCode.EMV_OK) {
            return ret;
        }
        byte keyId = dataList.data[0];
        for (Capk capk : capkList) {
            if (Tools.bytes2String(capk.getRid()).equals(new String(rid)) && capk.getKeyID() == keyId) {
                EMV_CAPK emvCapk = Converter.toEMVCapk(capk);
                ret = EMVCallback.EMVAddCAPK(emvCapk);
            }
        }
        return ret;
    }

    private ETransResult onlineProc() {
        // TODO
        byte ret = (byte) paxEmvTrans.onlineProc();
        if (ret == EOnlineResult.APPROVE.getOnlineResult()) {
            return ETransResult.ONLINE_APPROVED;
        } else if (ret == EOnlineResult.ABORT.getOnlineResult()) {
            return ETransResult.ABORT_TERMINATED;
        } else {
            return ETransResult.ONLINE_DENIED;
        }
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.EmvImpl
 * JD-Core Version:    0.6.0
 */