package com.pax.eemv.enums;

public enum ETransResult {
    ONLINE_APPROVED((byte) 0),

    ONLINE_DENIED((byte) 1),

    OFFLINE_APPROVED((byte) 2),

    OFFLINE_DENIED((byte) 3),

    ONLINE_CARD_DENIED((byte) 4),

    ABORT_TERMINATED((byte) 5),

    ARQC((byte) 6),

    SIMPLE_FLOW_END((byte) 7);

    private byte transResult;

    ETransResult(byte transResult) {
        this.transResult = transResult;
    }

    public byte getTransResult() {
        return this.transResult;
    }

    public byte index() {
        return (byte) ordinal();
    }
}

/* Location:           E:\Linhb\projects\Android\PaxEEmv_V1.00.00_20170401\lib\PaxEEmv_V1.00.00_20170401.jar
 * Qualified Name:     com.pax.eemv.enums.ETransResult
 * JD-Core Version:    0.6.0
 */